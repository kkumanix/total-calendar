// Total Calendar 계정 · 동기화 (Firebase 무료 요금제, REST 방식)
// - 로그인: 이메일·비밀번호 (Firebase Authentication)
// - 저장소: Firestore  users/{uid} (무엇이 언제 바뀌었는지 목록) + users/{uid}/data/{항목}
// - 올리는 것: 내 기기(로컬) 일정, 메모, 메모장, 일정별 알림·카테고리·태어난 해, 스티커, 꾸미기·카테고리·캐릭터·알림 설정
// - 올리지 않는 것: 캘린더 연결 비밀번호, iCal 비공개 주소(그 주소만 알면 일정을 볼 수 있어서), 창 위치·모니터·단축키 같은 기기마다 다른 값
// - 합치는 규칙: 항목(일정 하나, 메모 하나)마다 '나중에 바뀐 쪽'이 이김, 지운 것도 기록해서 다른 기기에서도 지워짐
const CFG = require('./cloud-config');

const AUTH = (CFG.authBase || 'https://identitytoolkit.googleapis.com/v1') + '/accounts:';
const TOKEN = (CFG.tokenBase || 'https://securetoken.googleapis.com/v1') + '/token';
const FS = () => `${CFG.fsBase || 'https://firestore.googleapis.com/v1'}/projects/${CFG.projectId}/databases/(default)/documents`;

// 목록형 항목: 파일 이름, 식별 키
const COLLS = {
  events: { file: 'local-events.json', key: 'uid' },
  notes: { file: 'notes.json', key: 'id' },
  stickies: { file: 'stickies.json', key: 'id' },
  // 캘린더 연결 목록 (설정 안에 있음) — 주소·이름·색은 맞추고, 비밀번호는 올리지 않음 / '내 기기' 캘린더는 기기마다
  sources: { file: 'settings.json', key: 'id', fromSettings: true }
};
// iCal 주소는 그 자체가 '열쇠'라서 서버에 올리지 않음 (이름·색만 맞추고, 주소는 기기마다 한 번씩 넣음)
const stripSrc = (x) => { const o = { ...x }; delete o.password; delete o.hasPassword; if (o.type === 'ics') delete o.url; return o; };
function cleanSources(st) {
  return ((st && st.sources) || []).filter((x) => x && x.type !== 'local').map(stripSrc);
}
const listOf = (c, data) => (COLLS[c].fromSettings ? cleanSources(data) : (data || []));
// 키-값형 항목
const MAPS = {
  remind: { file: 'event-reminders.json' },
  cats: { file: 'categories.json' },
  birth: { file: 'birthyears.json' }
};
// 통째로 맞추는 항목
const WHOLE = { stickers: { file: 'stickers.json' } };
// 설정 중 기기 사이에 맞출 부분
const SETTING_KEYS = ['appearance', 'categories', 'characters', 'reminders', 'alarms', 'colorBy', 'view', 'exportTargets'];
const APPEAR_LOCAL = ['wallpaperAlign', 'wallpaperWidth']; // 화면 크기에 따라 다른 값은 기기마다

let store = null, fetchFn = null, hooks = {}, device = 'pc';
let tok = { id: '', exp: 0 };
let state = { signedIn: false, email: '', uid: '', syncing: false, lastSync: 0, message: '', error: '' };
let pushTimer = null, running = null;

const now = () => Date.now();
const META = 'sync-meta.json';
const getMeta = () => ({ t: {}, tomb: {}, seen: {}, dirty: {}, base: 0, ...store.readJSON(META, {}) });
const saveMeta = (m) => store.quiet(() => store.writeJSON(META, m));
const getAcc = () => store.readJSON('account.json', null);
const setState = (s) => { state = { ...state, ...s }; hooks.onState && hooks.onState(getState()); };
const getState = () => ({ ...state, configured: !!(CFG.apiKey && CFG.projectId) });

// ---------------------------------------------------------------- 시작
function init(o) {
  store = o.store; fetchFn = o.fetch || fetch; hooks = o.hooks || {}; device = o.device || 'pc';
  const acc = getAcc();
  if (acc && acc.uid) state = { ...state, signedIn: true, email: acc.email, uid: acc.uid, lastSync: acc.lastSync || 0 };
  // 이 기기에서 바뀐 것 기록
  store.onSave((name, data, old) => {
    if (name === META || name === 'account.json') return;
    if (!state.signedIn) return;
    const m = getMeta();
    let changed = false, any = false;
    for (const [c, d] of Object.entries(COLLS)) {
      if (d.file !== name) continue;
      const k = d.key, before = new Map(listOf(c, old).map((x) => [String(x[k]), JSON.stringify(x)]));
      const after = new Map(listOf(c, data).map((x) => [String(x[k]), JSON.stringify(x)]));
      changed = false;
      m.t[c] = m.t[c] || {}; m.tomb[c] = m.tomb[c] || {};
      for (const [id, js] of after) if (before.get(id) !== js) { m.t[c][id] = now(); delete m.tomb[c][id]; changed = true; }
      // 캘린더 연결은 '없어졌다'고 지움으로 보지 않음 (사용자가 직접 지운 것만 markRemoved로 기록)
      if (!d.fromSettings) for (const id of before.keys()) if (!after.has(id)) { m.tomb[c][id] = now(); delete m.t[c][id]; changed = true; }
      if (changed) { m.dirty[c] = true; any = true; }
    }
    changed = any;
    for (const [c, d] of Object.entries(MAPS)) {
      if (d.file !== name) continue;
      m.t[c] = m.t[c] || {}; m.tomb[c] = m.tomb[c] || {};
      const o2 = old || {}, n2 = data || {};
      for (const k of Object.keys(n2)) if (JSON.stringify(o2[k]) !== JSON.stringify(n2[k])) { m.t[c][k] = now(); delete m.tomb[c][k]; changed = true; }
      for (const k of Object.keys(o2)) if (!(k in n2)) { m.tomb[c][k] = now(); delete m.t[c][k]; changed = true; }
      if (changed) m.dirty[c] = true;
    }
    for (const [c, d] of Object.entries(WHOLE)) {
      if (d.file !== name || JSON.stringify(old) === JSON.stringify(data)) continue;
      m.t[c] = now(); m.dirty[c] = true; changed = true;
    }
    if (name === 'settings.json' && JSON.stringify(pickSettings(old)) !== JSON.stringify(pickSettings(data))) {
      m.t.settings = now(); m.dirty.settings = true; changed = true;
    }
    if (changed) { saveMeta(m); schedulePush(); }
  });
}
// 사용자가 직접 지운 항목 (예: 설정에서 캘린더 연결 삭제)
function markRemoved(c, ids) {
  if (!state.signedIn || !ids || !ids.length) return;
  const m = getMeta(); m.tomb[c] = m.tomb[c] || {}; m.t[c] = m.t[c] || {};
  for (const id of ids) { m.tomb[c][id] = now(); delete m.t[c][id]; }
  m.dirty[c] = true; saveMeta(m); schedulePush();
}
function pickSettings(s) {
  if (!s) return null;
  const out = {};
  for (const k of SETTING_KEYS) if (k in s) out[k] = s[k];
  if (out.appearance) { out.appearance = { ...out.appearance }; for (const k of APPEAR_LOCAL) delete out.appearance[k]; }
  return out;
}
function schedulePush() { clearTimeout(pushTimer); pushTimer = setTimeout(() => sync().catch(() => {}), 3000); }

// ---------------------------------------------------------------- 로그인
const ERR = {
  EMAIL_EXISTS: '이미 가입된 이메일이에요. 로그인해 주세요',
  EMAIL_NOT_FOUND: '가입되지 않은 이메일이에요',
  INVALID_PASSWORD: '비밀번호가 맞지 않아요',
  INVALID_LOGIN_CREDENTIALS: '이메일이나 비밀번호가 맞지 않아요',
  INVALID_EMAIL: '이메일 주소 형식이 맞지 않아요',
  MISSING_PASSWORD: '비밀번호를 넣어 주세요',
  WEAK_PASSWORD: '비밀번호는 6자 이상으로 정해 주세요',
  USER_DISABLED: '사용이 중지된 계정이에요',
  TOO_MANY_ATTEMPTS_TRY_LATER: '시도가 너무 많아요. 잠시 뒤에 다시 해 주세요',
  OPERATION_NOT_ALLOWED: '이메일 로그인이 아직 켜져 있지 않아요 (서버 설정 확인 필요)',
  TOKEN_EXPIRED: '로그인이 만료됐어요. 다시 로그인해 주세요',
  INVALID_REFRESH_TOKEN: '로그인이 만료됐어요. 다시 로그인해 주세요',
  USER_NOT_FOUND: '계정을 찾지 못했어요. 다시 로그인해 주세요'
};
function niceErr(j, status) {
  const code = String((j && j.error && j.error.message) || '').split(' ')[0].split(':')[0];
  return new Error(ERR[code] || (j && j.error && j.error.message) || `서버 오류 (${status})`);
}
async function post(url, body, form) {
  const r = await fetchFn(url, {
    method: 'POST',
    headers: { 'Content-Type': form ? 'application/x-www-form-urlencoded' : 'application/json' },
    body: form ? new URLSearchParams(body).toString() : JSON.stringify(body)
  });
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) throw niceErr(j, r.status);
  return j;
}
function ensureCfg() { if (!CFG.apiKey || !CFG.projectId) throw new Error('동기화 서버가 아직 연결되지 않았어요 (개발자 설정 필요)'); }

async function signIn(email, password, create) {
  ensureCfg();
  email = String(email || '').trim();
  const j = await post(`${AUTH}${create ? 'signUp' : 'signInWithPassword'}?key=${CFG.apiKey}`, { email, password, returnSecureToken: true });
  tok = { id: j.idToken, exp: now() + (Number(j.expiresIn) || 3600) * 1000 - 60000 };
  store.quiet(() => store.writeJSON('account.json', { email: j.email || email, uid: j.localId, refresh: store.encrypt(j.refreshToken), since: now() }));
  // 처음 로그인한 기기: 지금 가진 것 전부를 '올릴 것'으로 표시 (서버에 더 최근 것이 있으면 그쪽이 이김)
  const m = getMeta(); m.base = 1; m.seen = {}; m.dirty = { events: true, notes: true, stickies: true, sources: true, remind: true, cats: true, birth: true, stickers: true, settings: true };
  saveMeta(m);
  setState({ signedIn: true, email: j.email || email, uid: j.localId, error: '', message: create ? '가입하고 로그인했어요' : '로그인했어요' });
  await sync();
  return getState();
}
async function resetPassword(email) {
  ensureCfg();
  await post(`${AUTH}sendOobCode?key=${CFG.apiKey}`, { requestType: 'PASSWORD_RESET', email: String(email || '').trim() });
  return true;
}
// 계정 삭제: 비밀번호를 한 번 더 확인 → 서버에 올린 내 자료 전부 + 계정 삭제 (이 기기 안의 일정·메모는 남김)
async function deleteAccount(password) {
  ensureCfg();
  if (!state.signedIn) throw new Error('로그인이 필요해요');
  const email = state.email;
  const j = await post(`${AUTH}signInWithPassword?key=${CFG.apiKey}`, { email, password, returnSecureToken: true });
  tok = { id: j.idToken, exp: now() + (Number(j.expiresIn) || 3600) * 1000 - 60000 };
  const uid = j.localId, auth = { Authorization: 'Bearer ' + j.idToken };
  const del = async (path) => { const r = await fetchFn(`${FS()}/${path}`, { method: 'DELETE', headers: auth }); if (!r.ok && r.status !== 404 && r.status !== 403) throw new Error(`서버 자료를 지우지 못했어요 (${r.status})`); };
  // users/{uid}/data/* → users/{uid}
  let page = '';
  for (let i = 0; i < 20; i++) {
    const r = await fetchFn(`${FS()}/users/${uid}/data?pageSize=300&mask.fieldPaths=__name__${page ? '&pageToken=' + encodeURIComponent(page) : ''}`, { headers: auth });
    let jj = null; try { jj = await r.json(); } catch {}
    if (!r.ok) break;
    for (const d of (jj && jj.documents) || []) await del(d.name.split('/documents/')[1]);
    page = jj && jj.nextPageToken; if (!page) break;
  }
  for (const n of [...Object.keys(COLLS), ...Object.keys(MAPS), ...Object.keys(WHOLE), 'settings']) await del(`users/${uid}/data/${n}`);
  await del(`users/${uid}`);
  await del(`grants/${encodeURIComponent(String(email).trim().toLowerCase())}`);   // 받은 이용권 기록도
  await post(`${AUTH}delete?key=${CFG.apiKey}`, { idToken: j.idToken });
  store.quiet(() => { store.writeJSON('account.json', {}); store.writeJSON(META, {}); store.writeJSON('premium.json', {}); });
  tok = { id: '', exp: 0 };
  setState({ signedIn: false, email: '', uid: '', lastSync: 0, message: '계정과 서버에 올린 자료를 모두 지웠어요. 이 기기의 일정·메모는 그대로 남아 있어요', error: '' });
  return true;
}
// 이메일 인증 (관리자 계정 보안용)
async function accountInfo() {
  const r = await post(`${AUTH}lookup?key=${CFG.apiKey}`, { idToken: await idToken() });
  const u = (r.users || [])[0] || {};
  return { email: u.email || state.email, verified: !!u.emailVerified };
}
async function sendVerify() {
  await post(`${AUTH}sendOobCode?key=${CFG.apiKey}`, { requestType: 'VERIFY_EMAIL', idToken: await idToken() });
  return true;
}
function signOut() {
  store.quiet(() => { store.writeJSON('account.json', {}); store.writeJSON(META, {}); });
  tok = { id: '', exp: 0 };
  setState({ signedIn: false, email: '', uid: '', lastSync: 0, message: '로그아웃했어요. 이 기기의 일정·메모는 그대로 남아 있어요', error: '' });
}
async function idToken() {
  if (tok.id && tok.exp > now()) return tok.id;
  const acc = getAcc();
  if (!acc || !acc.refresh) throw new Error('로그인이 필요해요');
  try {
    const j = await post(`${TOKEN}?key=${CFG.apiKey}`, { grant_type: 'refresh_token', refresh_token: store.decrypt(acc.refresh) }, true);
    tok = { id: j.id_token, exp: now() + (Number(j.expires_in) || 3600) * 1000 - 60000 };
    return tok.id;
  } catch (e) {
    if (/만료|찾지 못/.test(e.message)) signOut();
    throw e;
  }
}

// ---------------------------------------------------------------- Firestore (문서 하나 = { json: 문자열 })
async function fsGet(path) {
  const r = await fetchFn(`${FS()}/${path}`, { headers: { Authorization: 'Bearer ' + await idToken() } });
  if (r.status === 404) return { data: null, updateTime: null };
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) throw niceErr(j, r.status);
  let data = null;
  try { data = JSON.parse(j.fields.json.stringValue); } catch {}
  return { data, updateTime: j.updateTime };
}
async function fsPut(path, data, updateTime) {
  const pre = updateTime ? `&currentDocument.updateTime=${encodeURIComponent(updateTime)}` : '&currentDocument.exists=false';
  const r = await fetchFn(`${FS()}/${path}?updateMask.fieldPaths=json&updateMask.fieldPaths=device&updateMask.fieldPaths=at${pre}`, {
    method: 'PATCH',
    headers: { Authorization: 'Bearer ' + await idToken(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: { json: { stringValue: JSON.stringify(data) }, device: { stringValue: device }, at: { integerValue: String(now()) } } })
  });
  if (r.status === 409 || r.status === 400 || r.status === 412) { const e = new Error('conflict'); e.conflict = true; throw e; }
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) throw niceErr(j, r.status);
  return j.updateTime;
}

// ---------------------------------------------------------------- 합치기
function mergeEntries(localItems, localT, localTomb, remote) {
  // localItems: Map id → value / remote: { items: { id: { v, t } }, tomb: { id: t } }
  const r = remote || { items: {}, tomb: {} };
  const ids = new Set([...localItems.keys(), ...Object.keys(r.items || {}), ...Object.keys(r.tomb || {}), ...Object.keys(localTomb || {})]);
  const items = {}, tomb = {};
  for (const id of ids) {
    const cand = [];
    if (localItems.has(id)) cand.push({ v: localItems.get(id), t: localT[id] || 1 });
    if (localTomb && localTomb[id]) cand.push({ del: true, t: localTomb[id] });
    if (r.items && r.items[id]) cand.push({ v: r.items[id].v, t: r.items[id].t || 1 });
    if (r.tomb && r.tomb[id]) cand.push({ del: true, t: r.tomb[id] });
    cand.sort((a, b) => b.t - a.t || (a.del ? -1 : 1));
    const w = cand[0];
    if (w.del) tomb[id] = w.t; else items[id] = { v: w.v, t: w.t };
  }
  // 30일 지난 '지움' 기록은 정리
  const cut = now() - 30 * 864e5;
  for (const id of Object.keys(tomb)) if (tomb[id] < cut) delete tomb[id];
  return { items, tomb };
}

async function syncOne(name, m, remoteStamp, changes) {
  const path = `users/${state.uid}/data/${name}`;
  const isDirty = !!m.dirty[name];
  const remoteChanged = remoteStamp && remoteStamp !== m.seen[name];
  if (!isDirty && !remoteChanged) return false;
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data: remote, updateTime } = await fsGet(path);
    let merged, localNew, applyLocal = false;
    if (COLLS[name]) {
      const d = COLLS[name];
      const list = listOf(name, store.readJSON(d.file, d.fromSettings ? {} : []));
      const map = new Map(list.map((x) => [String(x[d.key]), x]));
      merged = mergeEntries(map, (m.t[name] || {}), (m.tomb[name] || {}), remote);
      if (d.fromSettings) for (const it of Object.values(merged.items)) if (it && it.v) it.v = stripSrc(it.v);   // 예전에 올라간 주소도 지움
      localNew = Object.values(merged.items).map((x) => x.v);
      applyLocal = JSON.stringify(sortBy(localNew, d.key)) !== JSON.stringify(sortBy(list, d.key));
      if (applyLocal) {
        if (d.fromSettings) changes[name] = localNew;               // 화면 쪽(app-main)이 비밀번호를 지켜서 반영
        else { store.quiet(() => store.writeJSON(d.file, localNew)); changes[name] = true; }
      }
    } else if (MAPS[name]) {
      const d = MAPS[name];
      const obj = store.readJSON(d.file, {});
      merged = mergeEntries(new Map(Object.entries(obj)), (m.t[name] || {}), (m.tomb[name] || {}), remote);
      localNew = Object.fromEntries(Object.entries(merged.items).map(([k, x]) => [k, x.v]));
      if (JSON.stringify(sortObj(localNew)) !== JSON.stringify(sortObj(obj))) { store.quiet(() => store.writeJSON(d.file, localNew)); changes[name] = true; }
    } else {
      // 통째로: 나중에 바뀐 쪽
      const lt = name === 'settings' ? (m.t.settings || 1) : (m.t[name] || 1);
      const local = name === 'settings' ? pickSettings(store.readJSON('settings.json', {})) : store.readJSON(WHOLE[name].file, null);
      if (remote && remote.t > lt) {
        merged = remote;
        if (name === 'settings') changes.settings = remote.v;
        else { store.quiet(() => store.writeJSON(WHOLE[name].file, remote.v)); changes[name] = true; }
      } else merged = { v: local, t: lt };
    }
    // 서버 쪽 갱신이 필요하면 올림 (그 사이 다른 기기가 바꿨으면 다시 받아서 합침)
    const need = JSON.stringify(remote) !== JSON.stringify(merged);
    try {
      let stamp = remoteStamp;
      if (need) { await fsPut(path, merged, updateTime); stamp = now(); changes.__stamp = changes.__stamp || {}; changes.__stamp[name] = stamp; }
      // 이 기기 기록 정리: 합친 결과의 시각을 내 기록으로
      if (COLLS[name] || MAPS[name]) { m.t[name] = Object.fromEntries(Object.entries(merged.items).map(([k, x]) => [k, x.t])); m.tomb[name] = { ...merged.tomb }; }
      else m.t[name] = merged.t;
      m.dirty[name] = false;
      m.seen[name] = stamp || m.seen[name];
      return true;
    } catch (e) {
      if (!e.conflict) throw e;
    }
  }
  throw new Error('동시에 바뀐 내용이 많아 잠시 뒤 다시 맞출게요');
}
const sortBy = (l, k) => [...(l || [])].sort((a, b) => String(a[k]).localeCompare(String(b[k])));
const sortObj = (o) => Object.fromEntries(Object.entries(o || {}).sort(([a], [b]) => a.localeCompare(b)));

// 전체 동기화: 목록(users/{uid})을 먼저 읽고 바뀐 항목만 주고받음
async function sync() {
  if (!state.signedIn || !CFG.apiKey) return getState();
  if (running) return running;
  running = (async () => {
    setState({ syncing: true, error: '' });
    try {
      const m = getMeta();
      // 한 번만: 예전 버전이 올린 iCal 주소를 서버에서 지우도록 이 기기 목록을 최신으로 표시
      if (!m.purgeUrl1) { const ts = now(); m.t.sources = Object.fromEntries(Object.keys(m.t.sources || {}).map((k) => [k, ts])); m.dirty.sources = true; m.purgeUrl1 = 1; }
      const { data: man, updateTime } = await fsGet(`users/${state.uid}`);
      const stamps = (man && man.stamps) || {};
      const changes = {};
      // 새로 생긴 항목(예: 캘린더 연결 목록)은 이 기기에서 한 번도 맞춘 적 없으면 올릴 것으로 표시
      for (const name of [...Object.keys(COLLS), ...Object.keys(MAPS), ...Object.keys(WHOLE), 'settings']) {
        if (!(name in m.seen) && !(name in m.t)) m.dirty[name] = true;
      }
      for (const name of [...Object.keys(COLLS), ...Object.keys(MAPS), ...Object.keys(WHOLE), 'settings']) {
        await syncOne(name, m, stamps[name], changes);
      }
      if (changes.__stamp) {
        const next = { stamps: { ...stamps, ...changes.__stamp }, device, at: now() };
        for (const [k, v] of Object.entries(changes.__stamp)) m.seen[k] = v;
        try { await fsPut(`users/${state.uid}`, next, updateTime); }
        catch (e) {
          if (!e.conflict) throw e;
          const again = await fsGet(`users/${state.uid}`);
          await fsPut(`users/${state.uid}`, { stamps: { ...((again.data && again.data.stamps) || {}), ...changes.__stamp }, device, at: now() }, again.updateTime);
        }
        delete changes.__stamp;
      }
      saveMeta(m);
      const acc = getAcc(); if (acc) store.quiet(() => store.writeJSON('account.json', { ...acc, lastSync: now() }));
      setState({ syncing: false, lastSync: now(), message: '' });
      if (Object.keys(changes).length && hooks.onRemoteChange) hooks.onRemoteChange(changes);
    } catch (e) {
      setState({ syncing: false, error: String(e.message || e) });
    } finally {
      running = null;
    }
    return getState();
  })();
  return running;
}

module.exports = { init, signIn, signOut, resetPassword, sync, getState, schedulePush, markRemoved, idToken, deleteAccount, accountInfo, sendVerify };
