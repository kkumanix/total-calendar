// 자동 백업 · 되돌리기 (이 기기 안에만 저장, 서버로 보내지 않음)
// - 하루 한 번: 그날 처음 켰을 때(또는 켜 둔 채 날짜가 바뀌었을 때) 그 순간의 자료를 저장 → 최근 7일치 보관
// - 큰 변경 직전: 다른 기기에서 받은 내용으로 덮어쓰기 직전, 되돌리기 직전, '지금 백업' → 최근 3개 보관
// - 되돌리기: 백업 내용을 보통 저장처럼 다시 써서, 계정 동기화를 켜 둔 경우 다른 기기에도 그대로 퍼짐
const fs = require('fs');
const path = require('path');

const FILES = ['settings.json', 'local-events.json', 'notes.json', 'stickies.json', 'event-reminders.json', 'categories.json', 'birthyears.json', 'stickers.json'];
const KEEP_DAILY = 7, KEEP_EXTRA = 3, EXTRA_GAP = 60 * 60 * 1000; // 동기화 직전 백업은 1시간에 한 번까지
let store = null, DIR = '', timer = null;

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fileOf = (id) => path.join(DIR, id + '.json');
const IDX = () => path.join(DIR, 'index.json');

function init(o) {
  store = o.store; DIR = path.join(o.dir || store.DIR, 'backups');
  try { daily(); } catch (e) { console.error('backup', e); }
  clearInterval(timer);
  timer = setInterval(() => { try { daily(); } catch {} }, 30 * 60 * 1000);   // 켜 둔 채 날짜가 바뀌어도
  if (timer && timer.unref) timer.unref();
}
function readIndex() { try { const l = JSON.parse(fs.readFileSync(IDX(), 'utf8')); return Array.isArray(l) ? l : []; } catch { return []; } }
function writeIndex(l) { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(IDX(), JSON.stringify(l), 'utf8'); }

function collect() {
  const files = {};
  for (const f of FILES) { const v = store.readJSON(f, undefined); if (v !== undefined) files[f] = v; }
  return files;
}
function countsOf(files) {
  const s = files['settings.json'] || {};
  const n = (x) => (Array.isArray(x) ? x.length : 0);
  return { events: n(files['local-events.json']), notes: n(files['notes.json']), stickies: n(files['stickies.json']), cals: n((s.sources || []).filter((x) => x && x.type !== 'local')) };
}
const sig = (files) => { const t = JSON.stringify(files); let h = 0; for (let i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) | 0; return h + ':' + t.length; };

// kind: 'daily' | 'sync'(받은 내용으로 바꾸기 직전) | 'restore'(되돌리기 직전) | 'manual'
function snapshot(kind = 'manual') {
  const files = collect();
  if (!Object.keys(files).length) return null;
  const list = readIndex(), s = sig(files);
  let at = Date.now(); while (list.some((x) => x.id === 'b' + at)) at++;   // 같은 순간에 두 번 눌러도 겹치지 않게
  const last = list[0];
  if (kind !== 'manual' && last && last.sig === s) {   // 바로 앞 백업과 똑같으면 새로 만들지 않음
    if (kind === 'daily' && last.day !== ymd(new Date(at))) { last.day = ymd(new Date(at)); last.daily = true; writeIndex(prune(list)); }
    return last;
  }
  const id = 'b' + at;
  const meta = { id, at, kind, day: ymd(new Date(at)), daily: kind === 'daily', counts: countsOf(files), sig: s };
  const body = JSON.stringify({ v: 1, at, kind, files });
  let next = [meta, ...list];
  next = prune(next);
  // 저장 공간이 모자라면(휴대폰) 오래된 것부터 지우고 다시
  for (let i = 0; i < 12; i++) {
    try { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(fileOf(id), body, 'utf8'); break; }
    catch (e) {
      const old = [...next].reverse().find((x) => x.id !== id);
      if (!old) return null;
      next = next.filter((x) => x !== old); try { fs.unlinkSync(fileOf(old.id)); } catch {}
    }
  }
  writeIndex(next);
  for (const x of list) if (!next.find((y) => y.id === x.id)) { try { fs.unlinkSync(fileOf(x.id)); } catch {} }
  return meta;
}
function prune(list) {
  const daily = list.filter((x) => x.daily).slice(0, KEEP_DAILY);
  const extra = list.filter((x) => !x.daily).slice(0, KEEP_EXTRA);
  return list.filter((x) => daily.includes(x) || extra.includes(x));
}
function daily() {
  const today = ymd(new Date());
  if (readIndex().some((x) => x.daily && x.day === today)) return null;
  return snapshot('daily');
}
// 다른 기기에서 받은 내용으로 이 기기 자료를 바꾸기 직전 (한 시간에 한 번까지)
function beforeRemote() {
  const l = readIndex().find((x) => x.kind === 'sync');
  if (l && Date.now() - l.at < EXTRA_GAP) return null;
  try { return snapshot('sync'); } catch { return null; }
}

function list() { return readIndex().map(({ sig: _s, ...x }) => x); }
function read(id) {
  if (!/^b\d+$/.test(String(id))) throw new Error('bad id');
  return JSON.parse(fs.readFileSync(fileOf(id), 'utf8'));
}
// '어제로 되돌리기' 대상: 오늘 처음 켰을 때 백업(= 어제 쓰고 끝낸 상태), 없으면 오늘 이전 것 중 가장 최근
function yesterday() {
  const today = ymd(new Date()), l = list();
  return l.find((x) => x.daily && x.day === today) || l.find((x) => x.day < today) || null;
}
// 되돌리기: 지금 상태를 먼저 백업 → 백업 내용을 보통 저장으로 다시 씀 (동기화가 '새로 바뀐 것'으로 알고 다른 기기에도 반영)
function restore(id) {
  const b = read(id);
  snapshot('restore');
  const files = b.files || {};
  for (const f of FILES) {
    if (!(f in files)) continue;
    let v = files[f];
    if (f === 'settings.json') {
      const cur = store.readJSON('settings.json', {}) || {};
      // 기기마다 다른 값(창 위치·모니터·단축키·언어)은 지금 것 그대로, 캘린더 비밀번호는 지금 것이 있으면 지금 것
      v = { ...v, widget: cur.widget || v.widget, displayId: cur.displayId, hotkeyQuickAdd: cur.hotkeyQuickAdd || v.hotkeyQuickAdd, hotkeyEdit: cur.hotkeyEdit || v.hotkeyEdit, language: cur.language || v.language };
      v.sources = (v.sources || []).map((s) => { const c = (cur.sources || []).find((x) => x.id === s.id); return c && c.password && !s.password ? { ...s, password: c.password } : s; });
    }
    store.writeJSON(f, v);
  }
  return { at: b.at, counts: countsOf(files) };
}

module.exports = { init, snapshot, daily, beforeRemote, list, read, restore, yesterday, FILES };
