// 동기화 서버(Firebase) 연결 정보 — 웹 앱 등록 때 나오는 공개 값 (비밀 아님, 보안은 서버의 보안 규칙이 맡음)
module.exports = {
  apiKey: 'AIzaSyCBJZJrVKkxOnJHdizuZ81JpMn8Fv8jEls',
  projectId: 'total-calendar-8d0f2'
};
// 개발 점검용: 가짜 서버로 시험할 때
if (typeof process !== 'undefined' && process.env && process.env.TC_CLOUD_MOCK) {
  const b = process.env.TC_CLOUD_MOCK;
  Object.assign(module.exports, { apiKey: 'mock', projectId: 'mock', authBase: b + '/v1', tokenBase: b + '/v1', fsBase: b + '/v1' });
}
