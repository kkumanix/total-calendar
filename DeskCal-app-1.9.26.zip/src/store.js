// 설정·로컬 일정·알림 기록을 사용자 폴더(JSON)에 저장
const fs = require('fs');
const path = require('path');
const { app, safeStorage } = require('electron');

const DIR = app.getPath('userData');
const file = (n) => path.join(DIR, n);

const DEFAULT_SETTINGS = {
  mode: 'wallpaper',            // 'wallpaper' | 'widget'
  view: 'month',                // 'month' | 'week'
  displayId: null,              // 표시할 모니터 (null = 주 모니터)
  iconGutter: 170,              // 배경 모드: 왼쪽 아이콘 공간(px)
  widget: { x: null, y: null, width: 860, height: 640, opacity: 0.94, locked: false },
  appearance: {
    theme: 'midnight',          // renderer/themes.js 의 테마 id
    bgColor: '',                // 직접 고른 배경색 ('' = 테마 그대로)
    textColor: '',              // 직접 고른 글자색
    deco: true,                 // Linaverse 테마 장식
    decoChar: true,             // 오른쪽 아래 컨셉 동물 (Linaverse 테마)
    clickSound: true,           // 버튼 누를 때 딸깍 소리
    typo: { preset: 'bigdate' },// 달력 스타일 (글자 크기) — 'custom'이면 직접 조절한 값
    listSide: 'left',           // 목록 패널 위치
    shape: 'square',            // 모양: square(각지게) | soft(둥글게) | cozy(포근하게)
    accent: '#D27A4A',
    font: 'pretendard',         // pretendard | noto | ibm | gowun | myeongjo | malgun | custom
    customFont: '',
    fontScale: 1,
    weekStart: 0,               // 0 = 일요일, 1 = 월요일
    timeFormat: '24',           // '24' | '12'
    wallpaperAlign: 'full',     // full | right | center | left
    wallpaperWidth: 72,         // % (full이 아닐 때)
    dimPast: true,
    timeZone: 'system',         // 앱 시간대: 'system' = Windows 설정을 따름
    worldZones: []              // 함께 볼 시간대 (예: ['Asia/Riyadh'])
  },
  refreshMinutes: 3,
  autoStart: true,
  hotkeyQuickAdd: 'CommandOrControl+Alt+Space',
  hotkeyEdit: 'CommandOrControl+Alt+E',
  lastWriteSource: 'local',
  colorBy: 'category',          // 'category' | 'source' : 일정 카드 색 기준
  categories: [
    { id: 'work', name: '업무', color: '#5B7DB1', keywords: '회의, 면접, 보고, 마감, 출장, 미팅' },
    { id: 'meet', name: '약속', color: '#C49A3A', keywords: '약속, 점심, 저녁, 모임, 식사' },
    { id: 'personal', name: '개인', color: '#8E6BA6', keywords: '병원, 운동, 치과' },
    { id: 'anniv', name: '기념일', color: '#C2637A', keywords: '기념일, 결혼' },
    { id: 'bday', name: '생일', color: '#6E9B5E', keywords: '생일' }
  ],
  minimal: false,                // 미니 달력 모드
  clickToEdit: true,             // 바탕화면에 박힌 캘린더를 바로 클릭해 쓰기
  characters: {                  // Linaverse 12지신
    enabled: true,
    clock: true,                 // 시계 옆 캐릭터 친구 (누르면 반응)
    buddy: 'theme',
    seasonPet: 'mix',            // 시즌 혼합 컬렉션의 동물 ('mix' 섞어서 랜덤 · 'daily' 매일 한 마리 · 동물 id 고정)
    outfit: true,                // 계절 따라 옷 갈아입기
    greeting: true,              // 새해·설날·추석 인사 배너              // 친구 캐릭터: 'theme' = Linaverse 테마 동물 (아니면 토끼)
    deliverer: true,             // 알림을 가져오는 담당 동물
    stickers: true,              // 메모 완료 스티커
    birthday: true,              // 생일에 나이·띠
    map: { work: 'ox', meet: 'horse', personal: 'pig', anniv: 'dragon', bday: 'rabbit' } // 카테고리 → 담당 ('hour' = 그 시각 동물)
  },
  panels: {
    wallpaper: { list: true, clock: true, next: true, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true },
    widget: { list: true, clock: true, next: true, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true }
  },
  reminders: { month: true, week: true, day: true, sameDay: true, sameDayHour: 8, before: 10 },
  sources: [
    { id: 'local', type: 'local', name: '내 PC', color: '#A78BFA', enabled: true }
  ]
};

// 새로 설치한 PC의 첫 화면 (settings.json이 없을 때만) = 개발자가 실제로 쓰는 위젯 화면
// 캘린더 연결·비밀번호·창 위치·세계 시간대 같은 개인 정보는 넣지 않음
const FRESH_SETTINGS = {
  mode: 'widget',               // 'wallpaper' | 'widget'
  view: 'month',                // 'month' | 'week'
  displayId: null,              // 표시할 모니터 (null = 주 모니터)
  iconGutter: 400,              // 배경 모드: 왼쪽 아이콘 공간(px)
  widget: { x: null, y: null, width: 1324, height: 914, opacity: 0.54, locked: true, underIcons: true }, // 위치 null = 주 모니터 오른쪽 위
  opacity: 0.66,
  appearance: {
    theme: 'season-auto',       // renderer/themes.js 의 테마 id
    bgColor: '',                // 직접 고른 배경색 ('' = 테마 그대로)
    textColor: '',              // 직접 고른 글자색
    deco: true,                 // Linaverse 테마 장식
    decoChar: true,             // 오른쪽 아래 컨셉 동물 (Linaverse 테마)
    clickSound: true,           // 버튼 누를 때 딸깍 소리
    typo: { preset: 'custom', date: 1.1, dateWeight: 500, chip: 0.82, list: 0.98, clock: 4.8, icon: 1.2, weekday: 0.89, title: 1.6 }, // 달력 스타일 (글자 크기)
    listSide: 'left',           // 목록 패널 위치
    shape: 'soft',              // 모양: square(각지게) | soft(둥글게) | cozy(포근하게)
    accent: '#E06A8E',
    font: 'pretendard',         // pretendard | noto | ibm | gowun | myeongjo | malgun | custom
    customFont: '',
    fontScale: 0.85,
    weekStart: 0,               // 0 = 일요일, 1 = 월요일
    timeFormat: '24',           // '24' | '12'
    wallpaperAlign: 'full',     // full | right | center | left
    wallpaperWidth: 45,         // % (full이 아닐 때)
    dimPast: true,
    timeZone: 'system',         // 앱 시간대: 'system' = Windows 설정을 따름
    worldZones: [],             // 함께 볼 시간대 (예: ['Asia/Riyadh'])
    buddySize: 1.05             // 왼쪽 위 캐릭터 크기
  },
  refreshMinutes: 3,
  autoStart: true,
  hotkeyQuickAdd: 'CommandOrControl+Alt+Space',
  hotkeyEdit: 'CommandOrControl+Alt+E',
  lastWriteSource: 'local',
  colorBy: 'category',          // 'category' | 'source' : 일정 카드 색 기준
  categories: [
    { id: 'work', name: '업무', color: '#5B7DB1', keywords: '회의, 면접, 보고, 마감, 출장, 미팅' },
    { id: 'meet', name: '약속', color: '#C49A3A', keywords: '약속, 점심, 저녁, 모임, 식사' },
    { id: 'personal', name: '개인', color: '#8E6BA6', keywords: '병원, 운동, 치과' },
    { id: 'anniv', name: '기념일', color: '#C2637A', keywords: '기념일, 결혼' },
    { id: 'bday', name: '생일', color: '#6E9B5E', keywords: '생일' }
  ],
  minimal: false,                // 미니 달력 모드
  clickToEdit: true,             // 바탕화면에 박힌 캘린더를 바로 클릭해 쓰기
  characters: {                  // Linaverse 12지신
    enabled: true,
    clock: true,                 // 시계 옆 캐릭터 친구 (누르면 반응)
    buddy: 'theme',
    seasonPet: 'mix',            // 시즌 혼합 컬렉션의 동물 ('mix' 섞어서 랜덤 · 'daily' 매일 한 마리 · 동물 id 고정)
    outfit: true,                // 계절 따라 옷 갈아입기
    greeting: true,              // 새해·설날·추석 인사 배너              // 친구 캐릭터: 'theme' = Linaverse 테마 동물 (아니면 토끼)
    deliverer: true,             // 알림을 가져오는 담당 동물
    stickers: true,              // 메모 완료 스티커
    birthday: true,              // 생일에 나이·띠
    map: { work: 'hour', meet: 'hour', personal: 'hour', anniv: 'hour', bday: 'hour' }, // 카테고리 → 담당 ('hour' = 그 시각 동물)
    autoTalk: true, autoTalkMin: 5, bubbleSec: 0,
    lines: { en: true, ko: true, cheer: true, mood: true, tip: true, fact: true }
  },
  panels: {
    wallpaper: { list: true, clock: true, next: false, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true },
    widget: { list: false, clock: true, next: false, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true }
  },
  reminders: { month: true, week: true, day: true, sameDay: true, sameDayHour: 9, before: 60 },
  uiVersion: 17,
  sources: [
    { id: 'local', type: 'local', name: '내 PC', color: '#A78BFA', enabled: true }
  ]
};

function readJSON(name, fallback) {
  try { return JSON.parse(fs.readFileSync(file(name), 'utf8')); } catch { return fallback; }
}
// 저장할 때마다 알려 주기 (계정 동기화가 '무엇이 언제 바뀌었는지' 기록하는 데 씀)
const saveHooks = [];
let hooksPaused = 0;
function writeJSON(name, data) {
  if (saveHooks.length && !hooksPaused) {
    const old = readJSON(name, undefined);
    for (const h of saveHooks) { try { h(name, data, old); } catch (e) { console.error('save hook', e); } }
  }
  fs.mkdirSync(DIR, { recursive: true });
  const tmp = file(name + '.tmp');
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file(name));
}

function merge(base, extra) {
  const out = { ...base, ...extra };
  out.widget = { ...base.widget, ...(extra.widget || {}) };
  out.reminders = { ...base.reminders, ...(extra.reminders || {}) };
  out.appearance = { ...base.appearance, ...(extra.appearance || {}) };
  const xc = extra.characters || {};
  out.characters = { ...base.characters, ...xc, map: { ...base.characters.map, ...(xc.map || {}) } };
  if (String(out.appearance.accent).toUpperCase() === '#7C9CFF') out.appearance.accent = base.appearance.accent; // 예전 기본색 → 새 기본색
  out.panels = {
    wallpaper: { ...base.panels.wallpaper, ...((extra.panels || {}).wallpaper || {}) },
    widget: { ...base.panels.widget, ...((extra.panels || {}).widget || {}) }
  };
  // v1.4: 맨 위 '다음 일정' 카드는 기본으로 끔 (보이는 화면에서 다시 켤 수 있음)
  if ((extra.uiVersion || 0) < 14) { out.panels.wallpaper.next = false; out.panels.widget.next = false; out.uiVersion = 14; }
  if ((extra.uiVersion || 0) < 16) { out.panels.wallpaper.memo = false; out.panels.widget.memo = false; out.migrateNotes = true; }
  if ((extra.uiVersion || 0) < 15) { if (out.characters && (!out.characters.seasonPet || out.characters.seasonPet === 'daily')) out.characters.seasonPet = 'mix'; }
  if ((extra.uiVersion || 0) < 17) { out.autoStart = true; out.uiVersion = 17; } // 컴퓨터 켜면 항상 실행 (요청)
  if (!Array.isArray(out.categories)) out.categories = base.categories;
  // 예전 기본 색(형광 계열)을 그대로 쓰고 있으면 새 차분한 색으로 바꿈
  const OLD = { work: '#4F8BFF', meet: '#F59E0B', personal: '#A78BFA', anniv: '#F472B6', bday: '#22C55E' };
  out.categories = out.categories.map((c) => {
    const nb = base.categories.find((b) => b.id === c.id);
    return nb && OLD[c.id] && String(c.color).toUpperCase() === OLD[c.id] ? { ...c, color: nb.color } : c;
  });
  if (!Array.isArray(out.sources) || !out.sources.length) out.sources = base.sources;
  if (!out.sources.find((s) => s.type === 'local')) out.sources.unshift(base.sources[0]);
  return out;
}

// ---- 비밀번호 암호화 (Windows 사용자 계정에 묶임) ----
function encrypt(plain) {
  if (!plain) return '';
  if (safeStorage.isEncryptionAvailable()) return 'enc:' + safeStorage.encryptString(plain).toString('base64');
  return 'raw:' + Buffer.from(plain, 'utf8').toString('base64');
}
function decrypt(stored) {
  if (!stored) return '';
  try {
    if (stored.startsWith('enc:')) return safeStorage.decryptString(Buffer.from(stored.slice(4), 'base64'));
    if (stored.startsWith('raw:')) return Buffer.from(stored.slice(4), 'base64').toString('utf8');
  } catch { /* 다른 PC에서 복사된 설정 등 */ }
  return '';
}

module.exports = {
  DIR,
  getSettings: () => (fs.existsSync(file('settings.json')) ? merge(DEFAULT_SETTINGS, readJSON('settings.json', {})) : merge(FRESH_SETTINGS, {})),
  saveSettings: (s) => writeJSON('settings.json', s),
  getLocalEvents: () => readJSON('local-events.json', []),
  saveLocalEvents: (list) => writeJSON('local-events.json', list),
  getNotes: () => readJSON('notes.json', []),               // 날짜 없는 메모
  saveNotes: (list) => writeJSON('notes.json', list),
  getRemindMap: () => readJSON('event-reminders.json', {}), // 일정 uid → [{n, unit, time}] (없으면 기본 알림)
  saveRemindMap: (m) => writeJSON('event-reminders.json', m),
  getCategoryMap: () => readJSON('categories.json', {}),   // 일정 uid → 카테고리 id ('none' = 지정 안 함)
  saveCategoryMap: (m) => writeJSON('categories.json', m),
  getStickers: () => ({ owned: {}, days: {}, total: 0, unlocked: false, ...readJSON('stickers.json', {}) }), // 스티커 도감
  saveStickers: (s) => writeJSON('stickers.json', s),
  getBirthYears: () => readJSON('birthyears.json', {}),     // 일정 uid → 태어난 해
  saveBirthYears: (m) => writeJSON('birthyears.json', m),
  getStickies: () => readJSON('stickies.json', []),          // 바탕화면 메모지
  saveStickies: (l) => writeJSON('stickies.json', l),
  getReminderState: () => readJSON('reminders.json', { fired: {}, snoozes: [] }),
  saveReminderState: (s) => writeJSON('reminders.json', s),
  encrypt,
  decrypt,
  readJSON,
  writeJSON,
  onSave: (fn) => saveHooks.push(fn),
  // 동기화가 받아온 내용을 저장할 때는 '바뀜' 기록을 남기지 않음
  quiet: (fn) => { hooksPaused++; try { return fn(); } finally { hooksPaused--; } }
};
