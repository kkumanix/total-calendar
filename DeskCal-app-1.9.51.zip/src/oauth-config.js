// 계정 연결용 앱 등록 정보 — 비밀값은 여기에 넣지 않음
// gcal.tokenProxy: Google 로그인을 마무리해 주는 중계 서버 주소 (Cloudflare Worker · 비밀값은 그 서버에만 있음)
module.exports = {
  gcal: { clientId: '685201861703-n1jnpi1clb6ek676t1e2u4782nm4n638.apps.googleusercontent.com', tokenProxy: '' },
  msgraph: { clientId: '' }   // Microsoft Entra > 앱 등록 (공용 클라이언트, 리디렉션 http://localhost)
};
