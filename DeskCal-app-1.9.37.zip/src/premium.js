// 프리미엄 이용 권한 (한곳에서만 판단)
// 우선순위: 결제(구독) > 관리자가 준 이용권 > 베타 무료 체험 > 무료
// - 이용권: Firestore grants/{이메일 소문자} { until:'YYYY-MM-DD', days, by, at, note }
//   관리자만 쓰고 지울 수 있고, 본인은 자기 이메일 것만 읽을 수 있음 (서버 규칙)
// - 결제: 나중에 결제 서버(구글 플레이·MS 스토어 영수증 확인)가 entitlements/{uid} 에 기록 → 앱은 읽기만
// - 베타: BETA_FREE_UNTIL 이 비어 있으면 모든 프리미엄을 계속 무료로 체험
const CFG = require('./cloud-config');
const BETA_FREE_UNTIL = '';   // 예: '2027-03-31' (이날까지 무료 체험, 그 뒤엔 이용권·결제가 있어야 함)
const FS = () => `${CFG.fsBase || 'https://firestore.googleapis.com/v1'}/projects/${CFG.projectId}/databases/(default)/documents`;
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return ymd(d); };
const norm = (e) => String(e || '').trim().toLowerCase();
const okEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

let store = null, fetchFn = null, cloud = null, onChange = () => {};
function init(o) { store = o.store; fetchFn = o.fetch || fetch; cloud = o.cloud; onChange = o.onChange || onChange; }
const cache = () => (store && store.readJSON('premium.json', null)) || {};

const str = (v) => ({ stringValue: String(v) });
const int = (v) => ({ integerValue: String(Math.round(+v || 0)) });
const val = (f, k) => { const x = f && f[k]; return x ? (x.stringValue ?? (x.integerValue != null ? +x.integerValue : x.booleanValue)) : undefined; };
const toGrant = (doc) => {
  const f = doc.fields || {};
  return { email: decodeURIComponent(doc.name.split('/').pop()), until: val(f, 'until') || '', days: val(f, 'days') || 0, by: val(f, 'by') || '', at: val(f, 'at') || '', note: val(f, 'note') || '' };
};
async function req(path, token, opt = {}) {
  const r = await fetchFn(`${FS()}/${path}`, { ...opt, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, ...(opt.headers || {}) } });
  let j = null; try { j = await r.json(); } catch {}
  return { r, j };
}
function fail(r, j) {
  if (r.status === 403) return new Error('서버 권한이 아직 없어요 (Firestore 규칙에 grants 부분을 넣고 게시해 주세요)');
  return new Error((j && j.error && j.error.message) || `서버 오류 (${r.status})`);
}

// ---- 지금 이 사용자의 상태 ----
function status(now = new Date()) {
  const today = ymd(now), c = cache(), st = cloud ? cloud.getState() : {};
  const left = (u) => Math.max(0, Math.round((new Date(u + 'T00:00:00') - new Date(today + 'T00:00:00')) / 864e5) + 1);   // 오늘 포함
  const mine = (x) => x && x.email && norm(x.email) === norm(st.email);
  if (st.signedIn && mine(c.paid) && c.paid.until >= today) return { premium: true, kind: 'paid', until: c.paid.until, left: left(c.paid.until), label: `프리미엄 구독 중 · ${c.paid.until}까지` };
  if (st.signedIn && mine(c.grant) && c.grant.until >= today) return { premium: true, kind: 'grant', until: c.grant.until, left: left(c.grant.until), note: c.grant.note || '', label: `프리미엄 이용권 · ${c.grant.until}까지 (${left(c.grant.until)}일 남음)` };
  if (!BETA_FREE_UNTIL || today <= BETA_FREE_UNTIL) return { premium: true, kind: 'beta', until: BETA_FREE_UNTIL, label: BETA_FREE_UNTIL ? `베타 무료 체험 · ${BETA_FREE_UNTIL}까지` : '베타 기간 · 모든 프리미엄 무료 체험 중' };
  const expired = st.signedIn && mine(c.grant) ? c.grant.until : '';
  return { premium: false, kind: 'free', label: expired ? `무료 이용 중 (이용권이 ${expired}에 끝났어요)` : '무료 이용 중' };
}
const isPremium = () => status().premium;

// 로그인한 뒤 · 하루 몇 번: 내 이용권 확인해서 저장
async function refresh() {
  if (!cloud || !CFG.apiKey) return status();
  const st = cloud.getState();
  if (!st.signedIn || !st.email) return status();
  const token = await cloud.idToken();
  const { r, j } = await req(`grants/${encodeURIComponent(norm(st.email))}`, token);
  const c = cache();
  if (r.ok) c.grant = toGrant(j);
  else if (r.status === 404) c.grant = null;
  else return status();   // 오프라인·권한 문제면 저장해 둔 것 그대로
  c.checked = new Date().toISOString();
  store.quiet(() => store.writeJSON('premium.json', c));
  onChange(status());
  return status();
}

// ---- 관리자 ----
async function listGrants(token) {
  const out = []; let page = '';
  for (let i = 0; i < 20; i++) {
    const { r, j } = await req(`grants?pageSize=300${page ? '&pageToken=' + encodeURIComponent(page) : ''}`, token);
    if (!r.ok) throw fail(r, j);
    out.push(...((j && j.documents) || []).map(toGrant));
    page = j && j.nextPageToken; if (!page) break;
  }
  return out.sort((a, b) => (b.at || '').localeCompare(a.at || ''));
}
// days만큼 주기 (아직 남은 이용권이 있으면 그 끝에서 이어서 늘림)
async function grant(token, { email, days, note, by }) {
  const e = norm(email), n = Math.round(+days);
  if (!okEmail(e)) throw new Error('이메일 주소를 확인해 주세요');
  if (!(n >= 1 && n <= 3650)) throw new Error('기간은 1일 ~ 3650일로 적어 주세요');
  const path = `grants/${encodeURIComponent(e)}`, today = ymd(new Date());
  const cur = await req(path, token);
  if (!cur.r.ok && cur.r.status !== 404) throw fail(cur.r, cur.j);
  const prev = cur.r.ok ? toGrant(cur.j) : null;
  const base = prev && prev.until >= today ? addDays(prev.until, 1) : today;
  const until = addDays(base, n - 1);
  const total = (prev && prev.until >= today ? +prev.days || 0 : 0) + n;
  const fields = { until: str(until), days: int(total), by: str(norm(by)), at: str(new Date().toISOString()), note: str(String(note || (prev && prev.note) || '').slice(0, 100)) };
  const { r, j } = await req(path, token, { method: 'PATCH', body: JSON.stringify({ fields }) });
  if (!r.ok) throw fail(r, j);
  if (cloud && norm(cloud.getState().email) === e) refresh().catch(() => {});
  return { ...toGrant(j), extended: !!(prev && prev.until >= today) };
}
async function revoke(token, email) {
  const e = norm(email);
  const { r, j } = await req(`grants/${encodeURIComponent(e)}`, token, { method: 'DELETE' });
  if (!r.ok && r.status !== 404) throw fail(r, j);
  if (cloud && norm(cloud.getState().email) === e) refresh().catch(() => {});
  return true;
}

module.exports = { init, status, isPremium, refresh, listGrants, grant, revoke, BETA_FREE_UNTIL };
