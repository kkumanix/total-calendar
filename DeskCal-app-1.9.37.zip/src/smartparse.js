// 말하듯 적은 글 → 일정 목록 (규칙 기반, 인터넷·AI 없이 바로)
// 예) "내일 14시에 병원 진료 등록해줘"
//     "다음 주 화요일 오후 2시 치과, 수요일 10시 주간 회의 (3층 회의실)"
//     "매주 월요일 9시 팀 회의", "음력 9월 29일 어머니 생신", "금요일 저녁 7시 강남역에서 동기 모임 2시간"
//     안내 메일 ("일시: … / 장소: … / 주제: …")
const DateSense = require('../renderer/datesense.js');
let Lunar = null;
try { Lunar = require('../renderer/lunar.js'); } catch {}

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addMin = (hm, min) => { const [h, m] = hm.split(':').map(Number); const t = Math.min(23 * 60 + 59, h * 60 + m + min); return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`; };

// 일정 이름에서 빼낼 말 (부탁·명령 말투, 군더더기)
const ASK = /\s*(?:일정\s*(?:으로|을|를)?\s*)?(?:캘린더에\s*|달력에\s*)?(?:등록|추가|저장|입력|기록|예약|메모)\s*(?:좀\s*)?(?:해\s*줘|해\s*주세요|해\s*줄래|해\s*주라|해\s*줘요|하기|해|할래|함|부탁(?:해|드려요|합니다)?)?[.!~ ]*$/;
const ASK2 = /\s*(?:잡아|넣어|적어|알려|기억해|남겨)\s*(?:줘|주세요|줄래|줘요|주라|둬|두세요)[.!~ ]*$/;
const TAIL = /\s*(?:있어|있음|있어요|있습니다|예정|예정이야|예정이에요|이야|이에요|입니다|해야\s*함|해야\s*해|가야\s*함|가야\s*해)[.!~ ]*$/;
const REP = [[/매일|날마다/, 'daily'], [/매주|주마다|매\s*주/, 'weekly'], [/매달|매월|달마다/, 'monthly'], [/매년|해마다|매해/, 'yearly']];
const LABEL = /^\s*[-•·*▶■□○●◦]?\s*(일시|일자|날짜|시간|예약일|예약\s*일시|수거일|방문일|기간|장소|위치|주소|주제|제목|과정|안건|행사|행사명|내용|대상|인원)\s*[:：]\s*(.+)$/;

// 글자 정리
function tidy(s) {
  return String(s || '')
    .replace(/\(\s*\)/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[\s~\-–·,:：.]+|[\s~\-–·,:：]+$/g, '')
    .replace(/\s*(?:에|에는|은|는|을|를|이|가|도|부터|까지|쯤|경|정도)$/g, '')
    .trim();
}

// 알림: "하루 전 알림", "30분 전에 알려줘", "1시간 전 알람"
function reminders(s) {
  const out = [];
  const re = /(?:(\d+|한|두|세)\s*(달|개월|주|주일|일|시간|분)|(하루|이틀))\s*전(?:에)?\s*(?:알림|알람|알려\s*(?:줘|주세요)?|리마인드)/g;
  const num = { 하루: 1, 이틀: 2, 한: 1, 두: 2, 세: 3 };
  let m;
  while ((m = re.exec(s))) {
    let n, unit;
    if (m[3]) { n = num[m[3]]; unit = 'day'; }
    else { n = num[m[1]] || +m[1]; unit = { 달: 'month', 개월: 'month', 주: 'week', 주일: 'week', 일: 'day', 시간: 'hour', 분: 'minute' }[m[2]]; }
    out.push({ n, unit, s: m[0] });
  }
  return out;
}

// 한 줄(한 일정) 해석
function one(seg, now, prev) {
  let s = String(seg || '').trim();
  if (!s) return null;
  const used = [];
  // 반복
  let repeat = '';
  for (const [re, v] of REP) { const m = s.match(re); if (m) { repeat = v; used.push(m[0]); break; } }
  // 음력 생일·기념일
  let lunar = null, date = '', start = '', end = '';
  const lm = s.match(/음력\s*(윤)?\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일?/);
  if (lm && Lunar) {
    lunar = { m: +lm[2], d: +lm[3], leap: !!lm[1] };
    const y = now.getFullYear();
    let sol = Lunar.toSolar(y, lunar.m, lunar.d, lunar.leap);
    if (!sol || sol < ymd(now)) sol = Lunar.toSolar(y + 1, lunar.m, lunar.d, lunar.leap);
    if (sol) date = sol;
    used.push(lm[0]);
    if (!repeat) repeat = 'yearly';
  }
  // 알림
  const rem = reminders(s);
  for (const r of rem) used.push(r.s);
  let sNoRem = s; for (const r of rem) sNoRem = sNoRem.replace(r.s, ' ');
  // 날짜·시간 (기존 규칙 엔진)
  const r = DateSense.parse(lunar ? sNoRem.replace(lm[0], ' ') : sNoRem, now);
  let when = '';
  if (r) {
    if (!date) date = r.date;
    start = r.start || ''; end = r.end || '';
    used.push(...(r.parts || []));
    when = r.found || '';
    // "수요일"처럼 주를 안 적었는데 앞 일정보다 앞서면 → 그다음 주
    if (prev && prev.date && /[월화수목금토일]요일/.test(r.found || '') && !/이번|다음|담주|차주|다다음/.test(r.found || '') && date < prev.date && prev.nextWk) {
      const d = new Date(date + 'T00:00:00'); d.setDate(d.getDate() + 7); date = ymd(d);
    }
  }
  if (lunar) when = lm[0] + (when ? ' ' + when : '');
  if (!date && !start) return null;
  // 기간: "2시간", "1시간 반", "30분 동안"
  if (start && !end) {
    const dm = s.match(/(\d+)\s*시간\s*(반)?(?:\s*(\d+)\s*분)?\s*(?:동안|짜리|정도)?(?!\s*(?:전|후|뒤))/) || s.match(/(?:^|\s)(\d+)\s*분\s*(?:동안|간|짜리)/);
    if (dm) {
      const mins = dm[0].includes('시간') ? (+dm[1]) * 60 + (dm[2] ? 30 : 0) + (+(dm[3] || 0)) : +dm[1];
      if (mins > 0 && mins <= 12 * 60) { end = addMin(start, mins); used.push(dm[0].trim()); }
    }
  }
  // 시간 없는 '점심/저녁 약속'은 흔한 시간으로
  if (!start) {
    if (/점심/.test(s)) start = '12:00';
    else if (/저녁\s*(?:약속|식사|모임|회식)|회식/.test(s)) start = '19:00';
    if (start && !end) end = addMin(start, 90);
  }
  // 장소: "(…)", "…에서", "장소 …"
  let location = '';
  let rest = s;
  for (const u of used.sort((a, b) => b.length - a.length)) if (u) rest = rest.replace(u, ' ');
  const paren = rest.match(/[(\[]\s*([^()\[\]]{2,30})\s*[)\]]/);
  if (paren && !/^\s*\d{1,2}\s*(?:시|:)|오전|오후/.test(paren[1])) { location = paren[1].trim().replace(/^(장소|위치)\s*[:：]?\s*/, ''); rest = rest.replace(paren[0], ' '); }
  if (!location) {
    const at = rest.match(/(?:^|\s)((?:[^\s]+\s){0,1}[^\s]+?)에서(?=\s|$)/);
    if (at && !/(?:오전|오후|저녁|아침|점심|시|분)$/.test(at[1])) { location = at[1].trim(); rest = rest.replace(at[0], ' '); }
  }
  // 이름 정리
  let title = rest.replace(ASK, '').replace(ASK2, '').replace(TAIL, '');
  title = title.replace(/\s(?:에|에는|은|는)\s/g, ' ');
  title = tidy(title).replace(ASK, '').replace(ASK2, '').replace(TAIL, '');
  title = tidy(title);
  if (!title || /^[\d\s:~\-]+$/.test(title)) title = '(제목 없음)';
  return {
    title, when, date, startTime: start, endTime: end, allDay: !start, location, repeat, lunar,
    rem: rem.length ? rem.map(({ n, unit }) => ({ n, unit })) : undefined
  };
}

// "일시: … / 장소: … / 주제: …" 같은 안내문
function form(text, now) {
  const lines = String(text).split(/\n/);
  const f = {};
  let head = '';
  for (const ln of lines) {
    const m = ln.match(LABEL);
    if (m) { const k = m[1].replace(/\s/g, ''); if (!f[k]) f[k] = m[2].trim(); continue; }
    const h = ln.match(/^\s*[\[【<]\s*([^\]】>]{2,30})\s*[\]】>]/);
    if (h && !head) head = h[1].replace(/\s*(?:안내|공지|알림|확정|변경)\s*$/, '').trim();
  }
  const whenTxt = f['일시'] || f['예약일시'] || f['일자'] || f['날짜'] || f['예약일'] || f['수거일'] || f['방문일'] || f['기간'] || '';
  if (!whenTxt) return null;
  const e = one(whenTxt + (f['시간'] ? ' ' + f['시간'] : ''), now);
  if (!e) return null;
  e.title = f['주제'] || f['제목'] || f['과정'] || f['행사명'] || f['행사'] || f['안건'] || head || e.title;
  e.title = tidy(e.title.replace(/^\s*['"“”‘’]|['"“”‘’]\s*$/g, ''));
  e.location = f['장소'] || f['위치'] || f['주소'] || e.location;
  e.when = whenTxt;
  return [e];
}

let En = null;
try { En = require('./smartparse-en.js'); } catch {}
function parse(text, now = new Date()) {
  const src = String(text || '').trim();
  if (!src) return [];
  if (En && !/[가-힣]/.test(src) && /[a-z]/i.test(src)) return En.parseEn(src, now);   // 영어 문장
  const asForm = form(src, now);
  if (asForm) return asForm;
  // 줄·쉼표·"그리고"로 나눔 (단, 날짜가 없는 조각은 앞 일정에 붙임)
  const segs = src.split(/\n+|[;；]|,(?!\s*\d{1,2}\s*(?:시|:))|，|\s그리고\s|\s하고\s(?=.*(?:시|요일|일|내일|모레))/).map((x) => x.trim()).filter(Boolean);
  const out = [];
  let prev = null;
  for (const sgm of segs) {
    const e = one(sgm, now, prev);
    if (e) { e.nextWk = /다음|담주|차주|다다음/.test(e.when || '') || !!(prev && prev.nextWk && !/이번/.test(e.when || '')); out.push(e); prev = e; continue; }
    // 날짜·시간이 없는 조각: 앞 일정의 장소나 이름 보충
    if (prev) {
      const t = tidy(sgm.replace(ASK, '').replace(ASK2, ''));
      if (t && !prev.location && /역|층|호|카페|식당|센터|병원|회의실|사무실|빌딩|타워|홀|점|관/.test(t)) prev.location = t;
    }
  }
  return out.slice(0, 20).map((e) => { delete e.nextWk; return e; });
}

module.exports = { parse, one };
