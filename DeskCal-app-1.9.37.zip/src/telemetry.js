// 익명 사용 통계 (관리자 화면용)
// - 모으는 것: 기기별 무작위 번호, PC/휴대폰, 앱 버전, 처음·마지막 사용 날짜, 하루 1번 '사용함' 표시,
//              기능 켜짐 여부 (로그인·캘린더 연결 종류·알람 수·위젯 사진·캐릭터·화면 모드)
// - 모으지 않는 것: 이름·이메일·일정 내용·메모·캘린더 주소·비밀번호
// - 설정 > 기타 '익명 사용 통계 보내기'를 끄면 아무것도 보내지 않음
// - 관리자(아래 이메일)로 로그인한 경우에만 통계를 읽을 수 있음 (서버 규칙에서도 막음)
const CFG = require('./cloud-config');
const ADMINS = ['flskalsn@gmail.com'];
const FS = () => `${CFG.fsBase || 'https://firestore.googleapis.com/v1'}/projects/${CFG.projectId}/databases/(default)/documents`;
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

let store = null, fetchFn = null, device = 'pc', version = '', getSettings = () => ({}), cloud = null;

function init(o) {
  store = o.store; fetchFn = o.fetch || fetch; device = o.device || 'pc'; version = o.version || '';
  getSettings = o.getSettings || getSettings; cloud = o.cloud || null;
  setTimeout(() => ping().catch(() => {}), 15000);
  setInterval(() => ping().catch(() => {}), 3 * 3600e3);
}
function install() {
  let x = store.readJSON('install.json', null);
  if (!x || !x.id) {
    const r = () => Math.random().toString(36).slice(2, 10);
    x = { id: 'i' + r() + r(), first: ymd(new Date()) };
    store.quiet(() => store.writeJSON('install.json', x));
  }
  return x;
}
function features(s) {
  const kinds = new Set((s.sources || []).filter((x) => x.type !== 'local' && x.enabled !== false).map((x) => {
    const u = String(x.url || x.server || '').toLowerCase();
    if (x.type === 'caldav' || /naver/.test(u)) return 'naver';
    if (/google/.test(u)) return 'google';
    if (/outlook|office|live\.com|microsoft/.test(u)) return 'outlook';
    return 'ical';
  }));
  const hw = s.homeWidget || {};
  return {
    login: !!(cloud && cloud.getState().signedIn),
    src: [...kinds].sort().join(','),
    alarms: (s.alarms || []).filter((a) => a && a.on !== false).length,
    photo: hw.charMode === 'photo',
    chars: !!(s.characters && s.characters.enabled !== false),
    mode: s.mode || '',
    theme: (s.appearance && s.appearance.theme) || ''
  };
}

// 하루 한 번: 이 기기 정보 + 오늘 사용 표시
async function ping(force) {
  if (!CFG.apiKey || !CFG.projectId) return;
  const s = getSettings() || {};
  if (s.telemetry === false) return;
  const ins = install(), today = ymd(new Date());
  if (!force && ins.last === today) return;
  const str = (v) => ({ stringValue: String(v) });
  const body = { fields: { p: str(device), v: str(version), first: str(ins.first), last: str(today), f: str(JSON.stringify(features(s))) } };
  const r1 = await fetchFn(`${FS()}/pings/${ins.id}?key=${CFG.apiKey}&updateMask.fieldPaths=p&updateMask.fieldPaths=v&updateMask.fieldPaths=first&updateMask.fieldPaths=last&updateMask.fieldPaths=f`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const r2 = await fetchFn(`${FS()}/active/${today}?key=${CFG.apiKey}&updateMask.fieldPaths=d.${ins.id}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: { d: { mapValue: { fields: { [ins.id]: str(device) } } } } })
  });
  if (r1.ok && r2.ok) store.quiet(() => store.writeJSON('install.json', { ...ins, last: today }));
}

const isAdmin = (email) => ADMINS.includes(String(email || '').trim().toLowerCase());

// ---- 관리자: 통계 읽기 ----
async function listAll(coll, token, mask) {
  const out = [];
  let page = '';
  for (let i = 0; i < 40; i++) {
    const q = `pageSize=300${page ? '&pageToken=' + encodeURIComponent(page) : ''}${(mask || []).map((m) => '&mask.fieldPaths=' + m).join('')}`;
    const r = await fetchFn(`${FS()}/${coll}?${q}`, { headers: { Authorization: 'Bearer ' + token } });
    let j = null; try { j = await r.json(); } catch {}
    if (r.status === 403) throw new Error('관리자 권한이 서버에 아직 설정되지 않았어요 (Firestore 규칙 확인)');
    if (!r.ok) throw new Error((j && j.error && j.error.message) || `서버 오류 (${r.status})`);
    out.push(...((j && j.documents) || []));
    page = j && j.nextPageToken;
    if (!page) break;
  }
  return out;
}
const sv = (d, k) => (d.fields && d.fields[k] && d.fields[k].stringValue) || '';

async function stats(token) {
  const now = new Date(), today = ymd(now);
  const dayAgo = (n) => ymd(new Date(now.getFullYear(), now.getMonth(), now.getDate() - n));
  const [pings, active, users] = await Promise.all([
    listAll('pings', token),
    listAll('active', token),
    listAll('users', token, ['__name__']).catch(() => null)
  ]);
  // 일별 사용 (최근 30일)
  const byDay = {};
  for (const d of active) {
    const day = d.name.split('/').pop();
    const m = (d.fields && d.fields.d && d.fields.d.mapValue && d.fields.d.mapValue.fields) || {};
    const vals = Object.values(m).map((x) => x.stringValue);
    byDay[day] = { all: vals.length, pc: vals.filter((x) => x === 'pc').length, phone: vals.filter((x) => x === 'phone').length, ids: Object.keys(m) };
  }
  const days = [];
  for (let i = 29; i >= 0; i--) { const k = dayAgo(i); const v = byDay[k] || { all: 0, pc: 0, phone: 0 }; days.push({ day: k, all: v.all, pc: v.pc, phone: v.phone }); }
  const uniq = (n) => { const set = new Set(); for (let i = 0; i < n; i++) for (const id of ((byDay[dayAgo(i)] || {}).ids || [])) set.add(id); return set.size; };
  // 기기·버전·기능
  const P = pings.map((d) => { let f = {}; try { f = JSON.parse(sv(d, 'f') || '{}'); } catch {} return { p: sv(d, 'p'), v: sv(d, 'v'), first: sv(d, 'first'), last: sv(d, 'last'), f }; });
  const recent = P.filter((x) => x.last >= dayAgo(29));
  const count = (arr, fn) => arr.reduce((m, x) => { const k = fn(x); if (k) m[k] = (m[k] || 0) + 1; return m; }, {});
  const pct = (n) => (recent.length ? Math.round((n / recent.length) * 100) : 0);
  const srcCount = {};
  for (const x of recent) for (const k of String(x.f.src || '').split(',').filter(Boolean)) srcCount[k] = (srcCount[k] || 0) + 1;
  const newByDay = count(P, (x) => (x.first >= dayAgo(29) ? x.first : ''));
  return {
    at: now.toISOString(),
    totals: {
      installs: P.length, pc: P.filter((x) => x.p === 'pc').length, phone: P.filter((x) => x.p === 'phone').length,
      dau: (byDay[today] || { all: 0 }).all, wau: uniq(7), mau: uniq(30),
      accounts: users ? users.length : null,
      newToday: P.filter((x) => x.first === today).length, new7: P.filter((x) => x.first >= dayAgo(6)).length
    },
    days: days.map((d) => ({ ...d, new: newByDay[d.day] || 0 })),
    versions: { pc: count(recent.filter((x) => x.p === 'pc'), (x) => x.v), phone: count(recent.filter((x) => x.p === 'phone'), (x) => x.v) },
    features: {
      recent: recent.length,
      login: pct(recent.filter((x) => x.f.login).length),
      alarms: pct(recent.filter((x) => x.f.alarms > 0).length),
      photo: pct(recent.filter((x) => x.f.photo).length),
      chars: pct(recent.filter((x) => x.f.chars).length),
      wallpaper: pct(recent.filter((x) => x.f.mode === 'wallpaper').length),
      widget: pct(recent.filter((x) => x.f.mode === 'widget').length),
      src: Object.fromEntries(Object.entries(srcCount).map(([k, n]) => [k, pct(n)]))
    },
    themes: Object.entries(count(recent, (x) => x.f.theme)).sort((a, b) => b[1] - a[1]).slice(0, 5)
  };
}

module.exports = { init, ping, isAdmin, stats, ADMINS };
