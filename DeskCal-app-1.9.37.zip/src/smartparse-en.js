// English sentences → events (rule based, no AI). Same output shape as smartparse.js
// e.g. "Dentist next Tuesday 2pm", "Team meeting every Monday 9am, remind me 30 minutes before",
//      "Friday 7pm dinner with friends at Gangnam Station for 2 hours", "Nov 25 4pm report due"
//      notice emails ("When: … / Where: … / Topic: …")
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addMin = (hm, min) => { const [h, m] = hm.split(':').map(Number); const t = Math.min(23 * 60 + 59, h * 60 + m + min); return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`; };
const MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const WDS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const NUM = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, ten: 10, fifteen: 15, thirty: 30 };
const WD_RE = '(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)(?:day|nesday|sday|urday|rsday)?\\.?';
const MON_RE = '(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\\.?';
const wdIdx = (s) => WDS.indexOf(String(s).toLowerCase().slice(0, 3));
const num = (s) => (NUM[String(s).toLowerCase()] != null ? NUM[String(s).toLowerCase()] : parseFloat(s));

function to24(h, m, ap, hint) {
  h = +h; m = +(m || 0);
  if (ap) { ap = ap.toLowerCase(); if (ap.startsWith('p') && h < 12) h += 12; if (ap.startsWith('a') && h === 12) h = 0; }
  else if (hint === 'pm' && h < 12) h += 12;
  else if (!ap && h >= 1 && h <= 6 && hint !== 'am') h += 12;   // "at 3" = 3pm
  if (h > 23 || m > 59) return '';
  return `${pad(h)}:${pad(m)}`;
}

function oneEn(seg, now, prev) {
  let s = ' ' + String(seg || '').trim() + ' ';
  if (!s.trim()) return null;
  const used = [];
  const take = (m) => { if (m) { used.push(m[0]); s = s.replace(m[0], ' '); } return m; };
  const L = () => s.toLowerCase();
  // repeat
  let repeat = '';
  let m = take(s.match(/\bevery\s*day\b|,?\s*\bdaily\s*$/i)); if (m) repeat = 'daily';
  let weeklyDay = -1;
  if (!repeat) { m = s.match(new RegExp('\\bevery\\s+' + WD_RE, 'i')); if (m) { repeat = 'weekly'; weeklyDay = wdIdx(m[1]); take(m); } }
  if (!repeat) { m = take(s.match(/\bevery\s+week\b|,?\s*\bweekly\s*$/i)); if (m) repeat = 'weekly'; }
  if (!repeat) { m = take(s.match(/\bevery\s+month\b|,?\s*\bmonthly\s*$/i)); if (m) repeat = 'monthly'; }
  if (!repeat) { m = take(s.match(/\bevery\s+year\b|,?\s*\b(?:yearly|annually)\s*$/i)); if (m) repeat = 'yearly'; }
  // reminders: "remind me 30 minutes before", "1 day before", "a day before reminder"
  const rem = [];
  const RR = /(?:,?\s*(?:and\s+)?remind(?:\s+me)?\s*)?\b(\d+|a|an|one|two|three)\s*(minutes?|mins?|hours?|hrs?|days?|weeks?|months?)\s+(?:before|prior|ahead|earlier)(?:\s+reminder)?/i;
  while ((m = s.match(RR))) {
    const u = m[2].toLowerCase();
    rem.push({ n: num(m[1]), unit: u.startsWith('min') ? 'minute' : u.startsWith('h') ? 'hour' : u.startsWith('d') ? 'day' : u.startsWith('w') ? 'week' : 'month' });
    take(m);
  }
  take(s.match(/\bremind\s+me\b/i));
  // time range / single time
  let start = '', end = '', when = [];
  const T = '(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?';
  m = s.match(new RegExp('\\b(?:from\\s+)?' + T + '\\s*(?:-|–|~|to|until|till)\\s*' + T + '(?=\\W)', 'i'));
  if (m && (m[2] || m[3] || m[5] || m[6])) {
    const ap2 = m[6] && m[6].toLowerCase().startsWith('p') ? 'pm' : m[6] ? 'am' : '';
    start = to24(m[1], m[2], m[3], m[3] ? '' : (ap2 === 'pm' && +m[1] <= +m[4] ? 'pm' : ap2));
    end = to24(m[4], m[5], m[6], m[3] && m[3].toLowerCase().startsWith('p') ? 'pm' : '');
    when.push(m[0].trim()); take(m);
  }
  if (!start) {
    m = s.match(/\b(?:at\s+)?(\d{1,2}):(\d{2})\s*(a\.?m\.?|p\.?m\.?)?(?=\W)/i) || s.match(/\b(?:at\s+)?(\d{1,2})()\s*(a\.?m\.?|p\.?m\.?)(?=\W)/i);
    if (m) { start = to24(m[1], m[2], m[3]); when.push(m[0].trim()); take(m); }
    else if ((m = s.match(/\bnoon\b/i))) { start = '12:00'; when.push(m[0]); take(m); }
    else if ((m = s.match(/\bmidnight\b/i))) { start = '00:00'; when.push(m[0]); take(m); }
    else if ((m = s.match(/\bat\s+(\d{1,2})(?=\s|$|,)/i))) { start = to24(m[1], 0, ''); when.push(m[0].trim()); take(m); }
  }
  // date
  let date = '';
  const base = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const plus = (n) => { const d = new Date(base); d.setDate(d.getDate() + n); return d; };
  if ((m = s.match(/\b(?:the\s+)?day\s+after\s+tomorrow\b/i))) { date = ymd(plus(2)); when.unshift(m[0].trim()); take(m); }
  else if ((m = s.match(/\b(?:tomorrow|tmrw|tmr)\b/i))) { date = ymd(plus(1)); when.unshift(m[0]); take(m); }
  else if ((m = s.match(/\b(?:today|tonight|this\s+(?:morning|afternoon|evening))\b/i))) { date = ymd(base); when.unshift(m[0]); if (/tonight|evening/i.test(m[0]) && start && +start.slice(0, 2) < 12) start = addMin(start, 12 * 60); take(m); }
  else if ((m = s.match(/\bin\s+(\d+|a|an|one|two|three)\s+(days?|weeks?)\b/i))) { date = ymd(plus(num(m[1]) * (/w/i.test(m[2]) ? 7 : 1))); when.unshift(m[0]); take(m); }
  else if ((m = s.match(/\b(\d{4})-(\d{1,2})-(\d{1,2})\b/))) { date = `${m[1]}-${pad(m[2])}-${pad(m[3])}`; when.unshift(m[0]); take(m); }
  else if ((m = s.match(new RegExp('\\b' + MON_RE + '\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b(?:,?\\s*(\\d{4}))?', 'i'))) || (m = s.match(new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?' + MON_RE + '(?:,?\\s*(\\d{4}))?', 'i')))) {
    const isDayFirst = /^\d/.test(m[1]);
    const mi = MON.indexOf((isDayFirst ? m[2] : m[1]).toLowerCase().slice(0, 3)), dd = +(isDayFirst ? m[1] : m[2]);
    let y = m[3] ? +m[3] : now.getFullYear();
    let d = new Date(y, mi, dd);
    if (!m[3] && d < base) d = new Date(y + 1, mi, dd);
    date = ymd(d); when.unshift(m[0].trim()); take(m);
  }
  else if ((m = s.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/))) {
    let y = m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : now.getFullYear();
    let d = new Date(y, +m[1] - 1, +m[2]);
    if (!m[3] && d < base) d = new Date(y + 1, +m[1] - 1, +m[2]);
    date = ymd(d); when.unshift(m[0]); take(m);
  }
  else if ((m = s.match(new RegExp('\\b(?:(this|next|coming)\\s+)?(?:on\\s+)?' + WD_RE + '(?=\\W)', 'i'))) && wdIdx(m[2]) >= 0) {
    const want = wdIdx(m[2]), q = (m[1] || '').toLowerCase();
    let diff = (want - base.getDay() + 7) % 7;
    if (q === 'next') { const mondayNext = 7 - ((base.getDay() + 6) % 7); diff = mondayNext + ((want + 6) % 7); }
    else if (diff === 0 && start && start <= `${pad(now.getHours())}:${pad(now.getMinutes())}`) diff = 7;
    let d = plus(diff);
    if (!q && prev && prev.date && ymd(d) < prev.date && prev.nextWk) d = plus(diff + 7);
    date = ymd(d); when.unshift(m[0].trim()); take(m);
  }
  else if ((m = s.match(/\b(?:on\s+)?(?:the\s+)?(\d{1,2})(st|nd|rd|th)\b/i))) {
    let d = new Date(base.getFullYear(), base.getMonth(), +m[1]);
    if (d < base) d = new Date(base.getFullYear(), base.getMonth() + 1, +m[1]);
    date = ymd(d); when.unshift(m[0].trim()); take(m);
  }
  else if ((m = s.match(/\bnext\s+week\b/i))) { date = ymd(plus(7 - ((base.getDay() + 6) % 7))); when.unshift(m[0]); take(m); }
  if (repeat === 'weekly' && weeklyDay >= 0 && !date) { let df = (weeklyDay - base.getDay() + 7) % 7; if (df === 0 && start && start <= `${pad(now.getHours())}:${pad(now.getMinutes())}`) df = 7; date = ymd(plus(df)); }
  if (!date && start) date = start > `${pad(now.getHours())}:${pad(now.getMinutes())}` ? ymd(base) : ymd(plus(1));
  if (!date && repeat === 'daily') date = ymd(base);
  if (!date && !start) return null;
  // duration
  if (start && !end && (m = s.match(/\b(?:for\s+)?(\d+(?:\.\d+)?|an?|one|two|three)\s*(hours?|hrs?|h|minutes?|mins?)\b(?!\s+(?:before|ago|later))/i))) {
    const n = num(m[1]), mins = /^h/i.test(m[2]) ? Math.round(n * 60) : Math.round(n);
    if (mins > 0 && mins <= 12 * 60) { end = addMin(start, mins); take(m); }
  }
  // meal words without time
  if (!start) {
    if (/\blunch\b/i.test(s)) start = '12:00';
    else if (/\bdinner\b/i.test(s)) start = '19:00';
    else if (/\bbreakfast\b/i.test(s)) start = '08:00';
    if (start && !end) end = addMin(start, 90);
  }
  // location: "(…)", "@ X", "at Capitalized Place"
  let location = '';
  if ((m = s.match(/[(\[]\s*([^()\[\]]{2,40})\s*[)\]]/))) { location = m[1].trim(); take(m); }
  else if ((m = s.match(/@\s*([^,;]{2,40})/))) { location = m[1].trim(); take(m); }
  else if ((m = s.match(/\b(?:at|in)\s+((?:the\s+)?[A-Z0-9][\w'&.-]*(?:\s+(?:[A-Z0-9][\w'&.-]*|of|the|and|&))*)/))) { location = m[1].replace(/\s+(?:of|the|and|&)$/, '').trim(); take(m); }
  // title
  let title = s
    .replace(/\b(?:please|pls|add|schedule|create|put|set\s+up|an?\s+event|event|appointment\s+for|remind\s+me\s+(?:to|of|about))\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[\s,.;:–—-]+|[\s,.;:–—-]+$/g, '')
    .replace(/^(?:on|at|for|in|and|from|to|the)\s+|\s+(?:on|at|for|in|and|from|to|with)$/gi, '')
    .trim();
  if (!title) title = '(untitled)';
  title = title.charAt(0).toUpperCase() + title.slice(1);
  return { title, when: when.join(' '), date, startTime: start, endTime: end, allDay: !start, location, repeat: repeat === 'none' ? '' : repeat, lunar: null, rem: rem.length ? rem : undefined };
}

// "When: … / Where: … / Topic: …"
const LABEL = /^\s*[-•·*▶■□○●◦]?\s*(when|date|time|pickup|reservation|day|where|location|venue|place|address|topic|subject|title|course|agenda|event|session)\s*[:：]\s*(.+)$/i;
function form(text, now) {
  const f = {}; let head = '';
  for (const ln of String(text).split(/\n/)) {
    const m = ln.match(LABEL);
    if (m) { const k = m[1].toLowerCase(); if (!f[k]) f[k] = m[2].trim(); continue; }
    const h = ln.match(/^\s*[\[【<]\s*([^\]】>]{2,40})\s*[\]】>]/);
    if (h && !head) head = h[1].replace(/\s*(?:notice|announcement|info|reminder|confirmed|update)\s*$/i, '').trim();
  }
  const whenTxt = f.when || f.date || f.pickup || f.reservation || f.day || '';
  if (!whenTxt) return null;
  const e = oneEn(whenTxt + (f.time ? ' ' + f.time : ''), now);
  if (!e) return null;
  const guess = /reservation|booking/i.test(text) ? 'Reservation' : /pick-?up|parcel|delivery|courier/i.test(text) ? 'Parcel pickup' : '';
  e.title = f.topic || f.subject || f.title || f.course || f.event || f.session || f.agenda || head || guess || e.title;
  e.location = f.where || f.location || f.venue || f.place || f.address || e.location;
  e.when = whenTxt;
  return [e];
}

function parseEn(text, now = new Date()) {
  const src = String(text || '').trim();
  if (!src) return [];
  const asForm = form(src, now);
  if (asForm) return asForm;
  const segs = src.split(/\n+|[;]|,(?!\s*\d{4})(?!\s*(?:and\s+)?remind)(?!\s*\d+\s*(?:minutes?|mins?|hours?|days?|weeks?)\s+before)|\s+and\s+(?=(?:\w+\s+){0,4}(?:today|tomorrow|tonight|next|on|this|every|\d))/i).map((x) => x.trim()).filter(Boolean);
  const out = []; let prev = null;
  for (const sg of segs) {
    const e = oneEn(sg, now, prev);
    if (e) { e.nextWk = /next/i.test(e.when) || !!(prev && prev.nextWk && !/this/i.test(e.when)); out.push(e); prev = e; continue; }
    if (prev && !prev.location && /\b(?:station|room|floor|hall|cafe|café|office|hospital|center|centre|building|tower|restaurant|park)\b/i.test(sg)) prev.location = sg.replace(/^(?:at|in)\s+/i, '');
  }
  return out.slice(0, 20).map((e) => { delete e.nextWk; return e; });
}

module.exports = { parseEn, oneEn };
