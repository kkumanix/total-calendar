// 알람: 달력에 넣지 않고 정해 둔 시각에 알려 주기 (한 번 / 매일 / 평일 / 매주 요일 / 매달 며칠)
// { id, title, msg, time:'09:00', repeat:'once'|'daily'|'weekdays'|'weekly'|'monthly', days:[0~6], mday:1~31, date:'YYYY-MM-DD', on:true }
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const WD = ['일', '월', '화', '수', '목', '금', '토'];
const GRACE = 3 * 60000;        // 3분 안이면 울림 (PC가 잠깐 바빴어도)
const DAY = 864e5;

const DEFAULTS = [
  { id: 'a_start', title: '하루 시작', msg: '오늘 하루도 힘내 봐요! 좋은 하루 될 거예요 ☀️', time: '09:00', repeat: 'daily', on: true },
  { id: 'a_end', title: '하루 마무리', msg: '오늘도 정말 고생 많으셨어요. 이제 푹 쉬어요 🌙', time: '18:00', repeat: 'daily', on: true }
];

function hm(t) { const m = String(t || '').match(/^(\d{1,2}):(\d{2})$/); return m ? [Math.min(23, +m[1]), Math.min(59, +m[2])] : [9, 0]; }
// 그 날짜에 울리는 알람인지
function onDay(a, d) {
  switch (a.repeat) {
    case 'once': return a.date === ymd(d);
    case 'daily': return true;
    case 'weekdays': return d.getDay() >= 1 && d.getDay() <= 5;
    case 'weekly': return (a.days || []).includes(d.getDay());
    case 'monthly': {
      const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      return d.getDate() === Math.min(+a.mday || 1, last);   // 31일 알람은 30일까지인 달엔 말일에
    }
    default: return false;
  }
}
function at(a, d) { const [h, m] = hm(a.time); return new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m, 0, 0); }

// from 이후로 울릴 시각들 (최대 n개, days일 안)
function upcoming(a, from = new Date(), n = 20, days = 14) {
  const out = [];
  if (!a || a.on === false) return out;
  const base = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  for (let i = 0; i <= days && out.length < n; i++) {
    const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + i);
    if (!onDay(a, d)) continue;
    const t = at(a, d);
    if (t > from) out.push(t);
  }
  return out;
}

// 지금 울릴 알람 (PC) — state.fired로 같은 알람을 두 번 울리지 않음
function due(alarms, state, now = new Date()) {
  const out = [];
  state.fired = state.fired || {};
  for (const a of alarms || []) {
    if (!a || a.on === false) continue;
    for (const back of [0, -1]) {   // 오늘, 자정 직후면 어제 것까지
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + back);
      if (!onDay(a, d)) continue;
      const t = at(a, d), key = `alarm:${a.id}@${ymd(d)}T${a.time}`;
      if (state.fired[key]) continue;
      const diff = now - t;
      if (diff >= 0 && diff <= GRACE) { state.fired[key] = now.getTime(); out.push({ key, alarm: a, at: t }); }
      else if (diff > GRACE) state.fired[key] = -now.getTime();   // 꺼져 있던 동안 지난 알람은 조용히
    }
  }
  // 10분 뒤 다시
  state.alarmSnoozes = (state.alarmSnoozes || []).filter((sn) => {
    if (sn.at > now.getTime()) return true;
    const a = (alarms || []).find((x) => x.id === sn.id);
    if (a) out.push({ key: `alarm:${a.id}#snooze#${sn.at}`, alarm: a, at: new Date(sn.at), snoozed: true });
    return false;
  });
  return out;
}

// 짧은 표시: "매일 9시", "평일 8:30", "매주 목 10시", "매달 15일 9시", "11/20 14시"
function label(a) {
  const [h, m] = hm(a.time);
  const t = m ? `${h}:${pad(m)}` : `${h}시`;
  switch (a.repeat) {
    case 'once': { const p = String(a.date || '').split('-'); return `${p.length === 3 ? `${+p[1]}/${+p[2]}` : '한 번'} ${t}`; }
    case 'daily': return `매일 ${t}`;
    case 'weekdays': return `평일 ${t}`;
    case 'weekly': {
      const ds = (a.days || []).slice().sort((x, y) => ((x + 6) % 7) - ((y + 6) % 7));
      if (ds.length === 7) return `매일 ${t}`;
      if (ds.length === 2 && ds.includes(0) && ds.includes(6)) return `주말 ${t}`;
      return `매주 ${ds.map((x) => WD[x]).join('·') || '-'} ${t}`;
    }
    case 'monthly': return `매달 ${+a.mday || 1}일 ${t}`;
    default: return t;
  }
}
// 한 번만 울리는 알람이 이미 지났는지
function expired(a, now = new Date()) { return a.repeat === 'once' && (!a.date || at(a, new Date(a.date + 'T00:00:00')) < now); }

module.exports = { DEFAULTS, due, upcoming, label, expired, onDay, hm };
