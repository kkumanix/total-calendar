// 다국어: 화면에 보이는 한국어 문구를 고른 언어로 바꿔 줌 (한국어 원문이 열쇠)
// - 사전: i18n-data.js (자동 생성) — 똑같은 문구 + "{0}개 등록"처럼 숫자·이름이 끼는 문구
// - 화면: 글자·placeholder·title 을 지켜보다가 한국어가 나오면 바로 바꿈 (translate="no" 안쪽은 그대로)
// - 메인 프로세스(트레이 메뉴·대화상자)에서는 I18N.t('…')로 씀
(function (root) {
  const DATA = (typeof module !== 'undefined' && module.exports) ? require('./i18n-data.js') : (root.I18N_DATA || { dict: {}, ctx: {} });
  const LANGS = [['auto', '자동 (시스템 언어) · Auto'], ['ko', '한국어'], ['en', 'English'], ['ja', '日本語'], ['zh', '简体中文'], ['es', 'Español']];
  const LOCALE = { ko: 'ko-KR', en: 'en-US', ja: 'ja-JP', zh: 'zh-CN', es: 'es-ES' };
  const HANGUL = /[가-힣]/;
  const KWD = '일월화수목금토';
  let lang = 'ko', C = null;

  function resolve(pref, sys) {
    if (pref && pref !== 'auto' && LOCALE[pref]) return pref;
    const s = String(sys || '').toLowerCase();
    for (const l of ['ko', 'ja', 'zh', 'es', 'en']) if (s.startsWith(l)) return l;
    return 'en';
  }
  function compile(l) {
    const d = (DATA.dict && DATA.dict[l]) || {};
    const exact = new Map(), pats = [];
    for (const [k, v] of Object.entries(d)) {
      if (!/\{\d+\}/.test(k)) { exact.set(k, v); continue; }
      const parts = k.split(/(\{\d+\})/);
      const lits = parts.filter((p) => p && !/^\{\d+\}$/.test(p));
      if (!lits.some((p) => HANGUL.test(p))) continue;          // 한국어 글자가 없는 틀은 너무 넓어서 뺌
      if (/\{\d+\}\{\d+\}/.test(k) && lits.join('').replace(/[^가-힣]/g, '').length < 4 && !/\{\d+:/.test(v)) continue;   // {0}{1}처럼 붙은 빈칸 + 짧은 글자 = 아무 데나 걸려서 뺌
      const idx = [];
      const kind = (n) => { const m = v.match(new RegExp('\\{' + n + ':(\\w+)\\}')); return m ? m[1] : ''; };
      const src = parts.map((p) => {
        const m = p.match(/^\{(\d+)\}$/);
        if (!m) return p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        idx.push(+m[1]);
        const k = kind(m[1]);
        return k === 'wd' || k === 'wdl' ? '([일월화수목금토])' : k === 'mon' || k === 'monl' ? '(\\d{1,2})' : '([\\s\\S]*?)';
      }).join('');
      const lit = lits.sort((a, b) => b.length - a.length)[0];
      const edge = (/^\{\d+\}/.test(k) ? 1 : 0) + (/\{\d+\}$/.test(k) ? 1 : 0);   // 앞뒤가 빈칸이면 덜 구체적
      pats.push({ re: new RegExp('^' + src + '$'), idx, tpl: v, lit, w: lits.join('').length * 2 - edge });
    }
    pats.sort((a, b) => b.w - a.w);
    return { exact, pats, ctx: (DATA.ctx && DATA.ctx[l]) || {}, cache: new Map() };
  }
  function setLang(l) { lang = LOCALE[l] ? l : 'ko'; C = lang === 'ko' ? null : compile(lang); try { if (typeof localStorage !== 'undefined') localStorage.setItem('tc-lang', lang); } catch {} return lang; }

  // ---- 날짜·요일 표기 ----
  const fmt = (o, d) => { try { return new Intl.DateTimeFormat(LOCALE[lang], o).format(d); } catch { return ''; } };
  const monthName = (m, long) => fmt({ month: long ? 'long' : 'short' }, new Date(2026, (+m || 1) - 1, 1));
  const wdName = (ch, long) => { const i = KWD.indexOf(String(ch).trim().charAt(0)); return i < 0 ? ch : fmt({ weekday: long ? 'long' : 'short' }, new Date(2026, 1, 1 + i)); };   // 2026-02-01 = 일요일
  const timeStr = (h, m) => fmt({ hour: 'numeric', minute: '2-digit' }, new Date(2026, 0, 1, h, m));
  function dates(s) {
    return s
      .replace(/(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일/g, (_, y, m, d) => fmt({ year: 'numeric', month: 'short', day: 'numeric' }, new Date(+y, m - 1, +d)))
      .replace(/(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})\.?/g, (_, y, m, d) => fmt({ year: 'numeric', month: 'short', day: 'numeric' }, new Date(+y, m - 1, +d)))
      .replace(/(\d{1,2})월\s*(\d{1,2})일/g, (_, m, d) => fmt({ month: 'short', day: 'numeric' }, new Date(2026, m - 1, +d)))
      .replace(/(\d{4})년\s*(\d{1,2})월/g, (_, y, m) => fmt({ year: 'numeric', month: 'long' }, new Date(+y, m - 1, 1)))
      .replace(/(오전|오후)\s*(\d{1,2}):(\d{2})(?::\d{2})?/g, (_, ap, h, m) => timeStr((+h % 12) + (ap === '오후' ? 12 : 0), +m))
      .replace(/(오전|오후)\s*(\d{1,2})시(?:\s*(\d{1,2})분)?/g, (_, ap, h, m) => timeStr((+h % 12) + (ap === '오후' ? 12 : 0), +(m || 0)))
      .replace(/(^|[^\d:])(\d{1,2})시(?!간)(?:\s*(\d{1,2})분)?/g, (_, a, h, m) => a + (+h) + ':' + String(+(m || 0)).padStart(2, '0'))
      .replace(/(\d+)시간/g, (_, n) => n + ({ en: 'h', ja: '時間', zh: '小时', es: ' h' }[lang] || '시간'))
      .replace(/([일월화수목금토])요일/g, (_, c) => wdName(c, true))
      .replace(/\(([일월화수목금토])\)/g, (_, c) => '(' + wdName(c) + ')')
      .replace(/(\d+)층/g, (_, n) => ({ en: `${n}F`, ja: `${n}階`, zh: `${n}楼`, es: `planta ${n}` }[lang] || _))
      .replace(/(\d+)분 전/g, (_, n) => tr1('{0}분 전', n))
      .replace(/(\d+)분 후/g, (_, n) => ({ en: `in ${n} min`, ja: `${n}分後`, zh: `${n}分钟后`, es: `en ${n} min` }[lang] || _));
  }
  const tr1 = (k, n) => { const tpl = ((DATA.dict || {})[lang] || {})[k]; return (tpl || k).replace('{0}', n); };

  function fill(tpl, groups, idx) {
    return tpl.replace(/\{(\d+)(?::(\w+))?\}/g, (all, n, f) => {
      const at = idx.indexOf(+n);
      if (at < 0) return '';
      const g = groups[at];
      if (f === 'mon') return monthName(g);
      if (f === 'monl') return monthName(g, true);
      if (f === 'wd') return wdName(g);
      if (f === 'wdl') return wdName(g, true);
      return HANGUL.test(g) ? word(g) : g;
    });
  }
  // 끼워 넣는 낱말: 사전 → 문맥 사전(띠 동물 등) → 조사(이/가/은/는…) 떼고 다시
  function word(g) {
    const r = t(g, 1);
    if (!HANGUL.test(r)) return r;
    const k = g.trim();
    for (const m of Object.values(C.ctx)) if (m[k] != null) return g.replace(k, m[k]);
    const j = k.match(/^(.+?)(?:이|가|은|는|을|를|의|와|과|에게|이에요|예요)$/);
    if (j) { const b = t(j[1], 1); if (!HANGUL.test(b)) return b; for (const m of Object.values(C.ctx)) if (m[j[1]] != null) return m[j[1]]; }
    return pieces(dates(r));
  }
  function core(s, depth) {
    const hit = C.exact.get(s);
    if (hit != null) return hit;
    for (const p of C.pats) {
      if (!s.includes(p.lit)) continue;
      const m = p.re.exec(s);
      if (m && m.slice(1).some((g) => g !== '')) return fill(p.tpl, m.slice(1), p.idx);
    }
    const d = dates(s);
    if (d !== s && !HANGUL.test(d)) return d;
    if (depth < 2) {   // " · " ", " 같은 구분자로 나눠서 조각마다
      const parts = d.split(/(\s*·\s*|\s+[—–]\s+|,\s*|:\s+|\n|\s*\/\s*)/);
      if (parts.length > 1) {
        const out = parts.map((x, i) => (i % 2 ? x : (HANGUL.test(x) ? t(x, depth + 1) : x))).join('');
        if (out !== d) return out;
      }
    }
    if (depth === 0) return pieces(d);
    return d;
  }
  // 마지막 수단: 문장 안에 사전에 있는 낱말·구절이 통째로 들어 있으면 그 부분만 바꿈
  function pieces(s) {
    if (!C.pieces) C.pieces = [...C.exact.keys()].filter((k) => k.length >= 2 && HANGUL.test(k)).sort((a, b) => b.length - a.length);
    const B = /[\s(\[«“'"·,.:!?\/~\-—–]/;
    let out = s;
    for (const k of C.pieces) {
      if (!HANGUL.test(out)) break;
      let i = out.indexOf(k);
      while (i >= 0) {
        const a = i === 0 || B.test(out[i - 1]), z = i + k.length >= out.length || B.test(out[i + k.length]);
        if (a && z) { const v = C.exact.get(k); out = out.slice(0, i) + v + out.slice(i + k.length); i = out.indexOf(k, i + v.length); }
        else i = out.indexOf(k, i + 1);
      }
    }
    return out;
  }
  // 한 문구 번역 (공백·앞뒤 여백 보존)
  function t(s, depth = 0) {
    if (!C || s == null) return s;
    s = String(s);
    if (!HANGUL.test(s)) return s;
    const m = s.match(/^(\s*)([\s\S]*?)(\s*)$/);
    const key = m[2].replace(/\s+/g, ' ');
    let r = C.cache.get(key);
    if (r == null) { r = core(key, depth); if (C.cache.size < 5000) C.cache.set(key, r); }
    return m[1] + r + m[3];
  }
  // 문맥 사전 (예: 띠 동물 '개'·'말'처럼 혼자 쓰면 헷갈리는 낱말)
  function tc(ctx, s) {
    if (!C) return s;
    const k = String(s).trim().replace(/\s+/g, ' ');
    if (ctx === 'user') { const v = C.exact.get(k); return v != null ? String(s).replace(String(s).trim(), v) : dates(String(s)); }   // 사용자가 적은 글: 사전과 똑같을 때만 (기본 예시·기본 알람 이름 등)
    const v = C.ctx[ctx] && C.ctx[ctx][k]; return v != null ? v : t(s);
  }

  // ---- 화면 자동 번역 ----
  const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE']);
  const ATTRS = ['placeholder', 'title', 'aria-label', 'alt', 'data-tip'];
  function skip(el) { return !el || (el.closest && el.closest('[translate="no"],[contenteditable="true"]')); }
  function doText(n) {
    const p = n.parentElement;
    if (!p || SKIP.has(p.tagName) || skip(p)) return;
    const v = n.nodeValue;
    if (!HANGUL.test(v)) return;
    const ctx = p.closest('[data-i18n]');
    const nv = ctx ? tc(ctx.getAttribute('data-i18n'), v) : t(v);
    if (nv !== v) n.nodeValue = nv;
  }
  function doEl(el) {
    if (skip(el)) return;
    const cx = el.closest && el.closest('[data-i18n]');
    for (const a of ATTRS) { const v = el.getAttribute(a); if (v && HANGUL.test(v)) { const nv = cx ? tc(cx.getAttribute('data-i18n'), v) : t(v); if (nv !== v) el.setAttribute(a, nv); } }
    if (el.tagName === 'INPUT' && (el.type === 'button' || el.type === 'submit') && HANGUL.test(el.value)) el.value = t(el.value);
  }
  function walk(root) {
    if (!C || !root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) { if (SKIP.has(root.tagName) && root.tagName !== 'TEXTAREA') return; doEl(root); }
    const doc = root.ownerDocument || root;
    const tw = doc.createTreeWalker(root, 5 /* 요소+글자 */);
    let n;
    while ((n = tw.nextNode())) { if (n.nodeType === 3) doText(n); else doEl(n); }
  }
  let obs = null;
  function watch(doc) {
    if (!C || !doc || obs) return;
    walk(doc.documentElement);
    obs = new MutationObserver((list) => {
      for (const m of list) {
        if (m.type === 'characterData') doText(m.target);
        else if (m.type === 'attributes') doEl(m.target);
        else for (const n of m.addedNodes) walk(n);
      }
    });
    obs.observe(doc.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    try { doc.documentElement.lang = lang; } catch {}
  }

  const I18N = {
    LANGS, LOCALE, t, tc, setLang, resolve, walk, watch,
    get lang() { return lang; },
    locale: () => LOCALE[lang],
    wd: (i, long) => (lang === 'ko' ? KWD[i] : wdName(KWD[i], long)),
    month: (m, long) => (lang === 'ko' ? `${m}월` : monthName(m, long))
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = I18N;
  else {
    root.I18N = I18N;
    // 화면(렌더러): 언어 정해서 바로 지켜보기
    let pref = '';
    try { pref = (root.deskcal && root.deskcal.lang) || ''; } catch {}
    if (!pref) try { pref = (root.parent && root.parent !== root && root.parent.I18N && root.parent.I18N.lang) || ''; } catch {}
    if (!pref) try { pref = localStorage.getItem('tc-lang') || ''; } catch {}
    setLang(pref ? resolve(pref) : resolve('auto', root.navigator && navigator.language));
    if (C && root.document) watch(root.document);
  }
})(typeof window !== 'undefined' ? window : this);
