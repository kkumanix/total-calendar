// 지금 상황에 맞는 말 — 오늘 일정·날씨·날짜를 보고 그때그때 만들어요 (기기 안에서만, 정해진 문장 돌려 쓰기가 아님)
// lines({ now, events:[{title,s,e2,allDay,location}], holidays:Map(ymd→이름), wx, openNotes, lang, t12 }) → [{ k, pri, text }]
//   pri 3 = 지금 바로 알려 줄 만한 것 (곧 시작·방금 끝남·비 소식) · 2 = 오늘 이야기 · 1 = 날짜·계절 이야기
(function (root) {
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const day0 = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const add = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const cut = (s, n = 16) => { s = String(s || '').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  // 24절기 (해마다 하루쯤 달라질 수 있어 '무렵'으로 말해요)
  const TERMS = [[1, 5, '소한', '가장 추운 때'], [1, 20, '대한', '큰 추위'], [2, 4, '입춘', '봄의 시작'], [2, 19, '우수', '눈이 비로 바뀌는 때'], [3, 5, '경칩', '개구리가 깨어나는 때'], [3, 20, '춘분', '낮과 밤이 같아지는 날'],
    [4, 5, '청명', '하늘이 맑아지는 때'], [4, 20, '곡우', '봄비가 곡식을 깨우는 때'], [5, 5, '입하', '여름의 시작'], [5, 21, '소만', '햇볕이 풍성해지는 때'], [6, 6, '망종', '씨 뿌리는 때'], [6, 21, '하지', '낮이 가장 긴 날'],
    [7, 7, '소서', '더위의 시작'], [7, 23, '대서', '큰 더위'], [8, 7, '입추', '가을의 시작'], [8, 23, '처서', '더위가 물러가는 때'], [9, 7, '백로', '이슬이 맺히는 때'], [9, 23, '추분', '밤이 길어지기 시작하는 날'],
    [10, 8, '한로', '찬 이슬이 내리는 때'], [10, 23, '상강', '서리가 내리는 때'], [11, 7, '입동', '겨울의 시작'], [11, 22, '소설', '첫눈이 오는 때'], [12, 7, '대설', '큰 눈이 오는 때'], [12, 22, '동지', '밤이 가장 긴 날']];
  // 받침에 맞춘 조사: J('면접','이','가') → '이'
  const J = (w, a, b) => { const c = String(w || '').replace(/[^가-힣A-Za-z0-9]+$/, '').slice(-1); if (!c) return b; const n = c.charCodeAt(0); if (n >= 0xAC00 && n <= 0xD7A3) return (n - 0xAC00) % 28 ? a : b; return /[13678LMNRlmnr]/.test(c) ? a : b; };
  const wet = (s) => /rain|sleet|drizzle|shower/.test(s || '') && !/snow/.test(s || '');
  const snowy = (s) => /snow/.test(s || '');

  function lines(o) {
    const now = o.now || new Date(), ko = !o.lang || o.lang === 'ko';
    const ev = (o.events || []).filter((e) => e && e.s && e.e2 && !e.holiday);
    const hol = o.holidays || new Map(), wx = o.wx || null;
    const out = [], say = (k, pri, koText, enText) => { const text = ko ? koText : enText; if (text) out.push({ k, pri, text }); };
    const t0 = day0(now), t1 = add(t0, 1), t2 = add(t0, 2), h = now.getHours(), dow = now.getDay();
    const hm = (d) => { const H = d.getHours(), M = pad(d.getMinutes()); if (!o.t12) return `${pad(H)}:${M}`; return ko ? `${H < 12 ? '오전' : '오후'} ${H % 12 || 12}:${M}` : `${H % 12 || 12}:${M} ${H < 12 ? 'AM' : 'PM'}`; };
    const on = (a, b) => ev.filter((e) => e.s < b && e.e2 > a).sort((x, y) => x.s - y.s);
    const today = on(t0, t1), timed = today.filter((e) => !e.allDay), allDay = today.filter((e) => e.allDay);
    const mins = (ms) => Math.max(1, Math.round(ms / 6e4));
    const dur = (m) => (ko ? (m >= 60 ? `${Math.floor(m / 60)}시간${m % 60 ? ' ' + (m % 60) + '분' : ''}` : `${m}분`) : (m >= 60 ? `${Math.floor(m / 60)}h${m % 60 ? ' ' + (m % 60) + 'm' : ''}` : `${m} min`));

    // ---- 곧 시작 · 진행 중 · 방금 끝남 ----
    const next = timed.find((e) => e.s > now), going = timed.find((e) => e.s <= now && e.e2 > now);
    const ended = timed.filter((e) => e.e2 <= now).sort((x, y) => y.e2 - x.e2)[0];
    if (next) {
      const m = mins(next.s - now), T = cut(next.title);
      if (m <= 10) say('soon:' + next.uid, 3, pick([`${m}분 뒤 '${T}' 시작이에요. 슬슬 자리 잡아 볼까요?`, `'${T}' ${m}분 전! 물 한 모금 마시고 가요`]), `'${T}' starts in ${m} min. Time to get settled.`);
      else if (m <= 60) say('soon:' + next.uid, 3, pick([`${m}분 뒤 '${T}' 일정이에요. 미리 준비해 둘까요?`, `${hm(next.s)}에 '${T}'${J(T, '이', '가')} 있어요. ${m}분 남았어요`]), `'${T}' is in ${m} min (${hm(next.s)}).`);
      else if (m <= 240) say('next:' + next.uid, 2, `다음 일정은 ${hm(next.s)} '${T}'${J(T, '이에요', '예요')}. 그때까지 ${dur(m)} 남았어요`, `Next up: '${T}' at ${hm(next.s)}, in ${dur(m)}.`);
      if (next.location && m <= 120) say('loc:' + next.uid, m <= 45 ? 3 : 2, `'${T}'${J(T, '은', '는')} ${cut(next.location, 18)}에서 해요. 이동 시간 챙기세요 🚶`, `'${T}' is at ${cut(next.location, 24)}. Leave time to get there.`);
      if (!going && m >= 90 && m <= 300 && h >= 9 && h < 18) say('gap', 2, `다음 일정까지 ${dur(m)} 비어 있어요. 집중하기 좋은 시간이에요 ✍️`, `You have ${dur(m)} free until the next event. Good time to focus.`);
    }
    if (going) { const left = mins(going.e2 - now); say('going:' + going.uid, 2, `지금은 '${cut(going.title)}' 시간이에요. ${dur(left)} 뒤에 끝나요`, `'${cut(going.title)}' is on now, ending in ${dur(left)}.`); }
    if (ended && now - ended.e2 < 40 * 6e4) say('ended:' + ended.uid, 3, pick([`'${cut(ended.title)}' 끝났네요. 수고했어요 👏`, `'${cut(ended.title)}' 마쳤어요! 잠깐 숨 돌리고 가요`]), `'${cut(ended.title)}' is done. Nice work 👏`);

    // ---- 오늘 하루 ----
    const leftN = timed.filter((e) => e.s > now).length, doneN = timed.filter((e) => e.e2 <= now).length;
    if (timed.length >= 4 && leftN) say('busy', 2, `오늘 일정이 ${timed.length}개예요. ${doneN ? `${doneN}개 마쳤고 ` : ''}${leftN}개 남았어요. 사이사이 숨 돌려요`, `${timed.length} events today, ${leftN} to go. Take small breaks.`);
    else if (timed.length && leftN && doneN) say('prog', 2, `오늘 일정 ${timed.length}개 중 ${doneN}개를 마쳤어요. 잘 가고 있어요`, `${doneN} of ${timed.length} events done today.`);
    if (timed.length && !leftN && !going && h >= 12) say('alldone', 2, pick([`오늘 일정을 모두 마쳤어요. 정말 고생했어요 🌙`, `오늘 ${timed.length}개 일정 끝! 남은 시간은 내 거예요`]), `All of today's events are done. Well done 🌙`);
    if (!today.length && h >= 8 && h < 20) say('free', 1, pick(['오늘은 일정이 없는 날이에요. 미뤄 둔 일 하나 해 볼까요?', '달력이 비어 있어요. 오늘은 내 속도로 가요 🍀']), 'Nothing on the calendar today. Go at your own pace 🍀');
    if (allDay[0]) say('allday:' + allDay[0].uid, 2, /생일|birthday/i.test(allDay[0].title) ? `오늘은 '${cut(allDay[0].title)}'${J(cut(allDay[0].title), '이에요', '예요')}. 축하 인사 잊지 마세요 🎂` : `오늘은 '${cut(allDay[0].title)}'${J(cut(allDay[0].title), '이', '가')} 있는 날이에요`, `Today: '${cut(allDay[0].title)}'.`);
    if (timed[0] && h < 10 && timed[0].s > now) say('first', 2, `오늘 첫 일정은 ${hm(timed[0].s)} '${cut(timed[0].title)}'${J(cut(timed[0].title), '이에요', '예요')}`, `First event today: '${cut(timed[0].title)}' at ${hm(timed[0].s)}.`);
    const last = timed[timed.length - 1];
    if (last && h >= 13 && last.s > now && timed.length > 1) say('last', 1, `오늘 마지막 일정은 ${hm(last.s)} '${cut(last.title)}'${J(cut(last.title), '이에요', '예요')}. 그 뒤로는 자유예요`, `Last event today: '${cut(last.title)}' at ${hm(last.s)}.`);
    if (o.openNotes > 0 && h >= 9) say('notes', 1, `메모에 아직 ${o.openNotes}개가 남아 있어요. 하나만 지워 볼까요? ✅`, `${o.openNotes} memo item${o.openNotes > 1 ? 's' : ''} still open. Tick one off? ✅`);

    // ---- 내일 · 이번 주 · 다가오는 날 ----
    const tom = on(t1, t2), tomTimed = tom.filter((e) => !e.allDay);
    if (h >= 17) {
      if (tomTimed[0]) say('tom', 2, `내일 첫 일정은 ${hm(tomTimed[0].s)} '${cut(tomTimed[0].title)}'${J(cut(tomTimed[0].title), '이에요', '예요')}${tom.length > 1 ? ` (모두 ${tom.length}개)` : ''}. 오늘은 일찍 쉬어요`, `Tomorrow starts with '${cut(tomTimed[0].title)}' at ${hm(tomTimed[0].s)}.`);
      else if (!tom.length) say('tomfree', 1, '내일은 일정이 없어요. 마음 편히 쉬어도 돼요', 'Nothing scheduled tomorrow. Rest easy.');
    }
    const weekEnd = add(t0, 7 - ((dow + 6) % 7)), rest = on(t1, weekEnd);   // 이번 주 일요일까지
    if (dow >= 1 && dow <= 4 && rest.length && h < 12) say('week', 1, `이번 주에 남은 일정은 ${rest.length}개예요`, `${rest.length} more event${rest.length > 1 ? 's' : ''} this week.`);
    if (dow === 5 && h >= 12) { const wk = on(t1, add(t0, 3)); say('weekend', 1, wk.length ? `주말에는 '${cut(wk[0].title)}'${J(cut(wk[0].title), '이', '가')} 기다리고 있어요 🎈` : '주말 일정이 비어 있어요. 푹 쉬어요 🎈', wk.length ? `This weekend: '${cut(wk[0].title)}' 🎈` : 'A free weekend ahead 🎈'); }
    // 며칠 뒤의 하루 종일 일정 (여행·기념일·마감 같은 것)
    const far = ev.filter((e) => e.allDay && e.s >= t2 && e.s < add(t0, 31)).sort((x, y) => x.s - y.s)[0];
    if (far) { const d = Math.round((day0(far.s) - t0) / 864e5); say('dday:' + far.uid, 1, `'${cut(far.title)}'까지 ${d}일 남았어요`, `${d} days until '${cut(far.title)}'.`); }
    // 다음 쉬는 날
    if (hol.size) {
      if (hol.get(ymd(now))) say('hol0', 2, `오늘은 ${hol.get(ymd(now))}${J(hol.get(ymd(now)), '이에요', '예요')}. 편안한 하루 보내요`, `Today is ${hol.get(ymd(now))}. Enjoy the day.`);
      else for (let i = 1; i <= 60; i++) { const d = add(t0, i), n = hol.get(ymd(d)); if (n && d.getDay() !== 0 && d.getDay() !== 6) { say('hol', 1, i === 1 ? `내일은 ${n}, 쉬는 날이에요 🎉` : `다음 쉬는 날은 ${d.getMonth() + 1}월 ${d.getDate()}일 ${n}${J(n, '이에요', '예요')}. ${i}일 남았어요`, i === 1 ? `Tomorrow is ${n}, a day off 🎉` : `Next day off: ${n}, in ${i} days.`); break; } }
    }

    // ---- 날씨 ----
    if (wx && typeof wx.temp === 'number') {
      const T = Math.round(wx.temp), c = wx.city ? wx.city + ' ' : '';
      if (wx.rainHour != null && wx.rainHour >= h) say('rain', 3, wx.rainHour <= h + 1 ? '곧 비가 올 것 같아요. 우산 챙기세요 ☔' : `${wx.rainHour}시쯤 비 소식이 있어요. 우산 챙겨 가요 ☔`, wx.rainHour <= h + 1 ? 'Rain is on the way. Take an umbrella ☔' : `Rain expected around ${wx.rainHour}:00. Take an umbrella ☔`);
      else if (wx.snowHour != null && wx.snowHour >= h) say('snow', 3, `${wx.snowHour <= h + 1 ? '곧' : wx.snowHour + '시쯤'} 눈이 올 것 같아요. 길 미끄러우니 조심해요 ❄️`, 'Snow is expected. Watch your step ❄️');
      else if (wet(wx.sym)) say('rainnow', 2, '밖에 비가 와요. 따뜻한 차 한 잔 어때요? ☔', "It's raining outside. Warm tea? ☔");
      else if (/clearsky|fair/.test(wx.sym || '') && h >= 9 && h < 17) say('clear', 1, `${c}하늘이 맑아요 (${T}°). 점심에 잠깐 걸어 볼까요? ☀️`, `Clear skies (${T}°). A short walk at lunch? ☀️`);
      if (T <= -5) say('cold', 2, `지금 ${T}°예요. 목도리까지 단단히 챙겨요 🧣`, `It's ${T}° out. Bundle up 🧣`);
      else if (T <= 3) say('chilly', 1, `지금 ${T}°, 쌀쌀해요. 따뜻하게 입고 나가요`, `It's ${T}°. Dress warm.`);
      else if (T >= 31) say('hot', 2, `지금 ${T}°예요. 물 자주 마시고 그늘로 다녀요 🥤`, `It's ${T}°. Drink water and stay in the shade 🥤`);
      if (typeof wx.tmax === 'number' && typeof wx.tmin === 'number' && wx.tmax - wx.tmin >= 10 && h < 12) say('gapT', 1, `오늘 일교차가 ${Math.round(wx.tmax - wx.tmin)}°나 돼요 (${Math.round(wx.tmin)}°~${Math.round(wx.tmax)}°). 겉옷 하나 챙겨요`, `Big temperature swing today (${Math.round(wx.tmin)}°–${Math.round(wx.tmax)}°). Bring a layer.`);
      const tw = wx.tomorrow;
      if (tw && h >= 18) {
        if (wet(tw.sym)) say('tomrain', 2, '내일은 비 소식이 있어요. 우산을 현관에 꺼내 둬요 ☔', 'Rain tomorrow. Leave an umbrella by the door ☔');
        else if (snowy(tw.sym)) say('tomsnow', 2, '내일은 눈 소식이 있어요. 조금 일찍 나서요 ❄️', 'Snow tomorrow. Leave a little early ❄️');
        else if (typeof tw.tmin === 'number' && typeof wx.tmin === 'number' && tw.tmin <= wx.tmin - 5) say('tomcold', 2, `내일 아침은 오늘보다 ${Math.round(wx.tmin - tw.tmin)}° 더 추워요 (${Math.round(tw.tmin)}°)`, `Tomorrow morning is ${Math.round(wx.tmin - tw.tmin)}° colder (${Math.round(tw.tmin)}°).`);
      }
      // 야외 일정이 있는 날의 날씨
      const outdoor = timed.find((e) => e.s > now && /산책|등산|골프|운동|러닝|캠핑|소풍|야구|축구|나들이|picnic|hike|golf|run/i.test(e.title));
      if (outdoor && wx.rainHour == null && wx.snowHour == null) say('outdoor:' + outdoor.uid, 2, `'${cut(outdoor.title)}' 하기 좋은 날씨예요 (${T}°) 🌤️`, `Good weather for '${cut(outdoor.title)}' (${T}°) 🌤️`);
    }

    // ---- 시간 · 날짜 ----
    if (h < 6) say('t', 1, '아직 새벽이에요. 무리하지 말아요 🌌', "It's still before dawn. Go easy 🌌");
    else if (h < 11) say('t', 1, pick(['좋은 아침이에요! 오늘도 같이 힘내요 ☀️', '아침 공기 한 번 크게 마시고 시작해요']), 'Good morning! ☀️');
    else if (h < 14) say('t', 1, pick(['점심은 맛있게 드셨어요? 🍚', '점심 먹고 5분만 걸어도 오후가 달라져요']), 'Had a good lunch? 🍚');
    else if (h < 18) say('t', 1, pick(['오후도 조금만 더 힘내요!', '이 시간엔 누구나 졸려요. 기지개 한 번 켜요 🙆']), 'Keep going this afternoon!');
    else if (h < 22) say('t', 1, '오늘도 정말 수고 많으셨어요 🌙', 'You did well today 🌙');
    else say('t', 1, '늦었어요, 이제 푹 쉬어요 💤', "It's late. Get some rest 💤");
    if (dow === 1 && h < 13) say('dow', 1, '월요일 시작! 천천히 시동 걸어요 🚗', 'Monday. Ease into it 🚗');
    if (dow === 3 && h >= 12) say('dow', 1, '수요일 오후, 이번 주의 절반을 넘었어요', 'Wednesday afternoon. Over the hump.');
    if (dow === 5) say('dow', 1, '금요일이에요! 조금만 더 힘내요 🎉', "It's Friday! 🎉");
    if (dow === 0 || dow === 6) say('dow', 1, '주말이에요, 푹 쉬는 것도 일이에요!', "It's the weekend. Resting counts too!");
    const term = TERMS.find(([m, d]) => m === now.getMonth() + 1 && Math.abs(d - now.getDate()) <= 1);
    if (term) say('term', 1, `${term[2]} 무렵이에요. ${term[3]}래요`, '');
    const dim = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate(), D = now.getDate();
    if (D === 1) say('date', 1, `${now.getMonth() + 1}월의 첫날이에요. 이번 달도 잘 부탁해요`, 'First day of the month. Fresh start.');
    else if (D === dim) say('date', 1, `${now.getMonth() + 1}월의 마지막 날이에요. 한 달 동안 고생했어요`, 'Last day of the month. You made it.');
    else if (dim - D <= 3) say('date', 1, `이번 달이 ${dim - D}일 남았어요. 마무리할 것만 챙겨요`, `${dim - D} days left this month.`);
    const yEnd = new Date(now.getFullYear() + 1, 0, 1), dLeft = Math.ceil((yEnd - t0) / 864e5) - 1, yDays = Math.round((yEnd - new Date(now.getFullYear(), 0, 1)) / 864e5);
    if (dLeft <= 45 && dLeft > 0) say('year', 1, `올해가 ${dLeft}일 남았어요. 올해의 나, 꽤 잘했어요`, `${dLeft} days left this year.`);
    else if (D % 10 === 0) say('year', 1, `올해의 ${Math.round((yDays - dLeft) / yDays * 100)}%가 지났어요. 남은 날도 천천히 가요`, `${Math.round((yDays - dLeft) / yDays * 100)}% of the year has passed.`);
    return out;
  }
  // 최근에 한 말은 피해서 하나 고르기 (pri가 높을수록 자주)
  function choose(list, recent, minPri) {
    const fresh = list.filter((x) => x.pri >= (minPri || 1) && !(recent || []).includes(x.k));
    if (!fresh.length) return null;
    const bag = []; fresh.forEach((x) => { for (let i = 0; i < x.pri * x.pri; i++) bag.push(x); });
    return pick(bag);
  }
  const api = { lines, choose };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') root.DeskNow = api;
})(typeof window !== 'undefined' ? window : globalThis);
