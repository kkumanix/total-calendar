// 한국어 글 속 날짜·시간 표현 찾기 (규칙 기반)
// 예: "금요일 오후 3시 치과" → { date:'2026-11-06', start:'15:00', end:null, found:'금요일 오후 3시' }
(function (root) {
  const WDK = '일월화수목금토';
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  function parse(text, now = new Date()) {
    const t = String(text || '').replace(/\s+/g, ' ').replace(/(^|[^\d:./-])(\d{1,2})\s*[-~]\s*(\d{1,2})\s*시/g, '$1$2시~$3시');   // '3-4시' → '3시~4시'
    const base = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const add = (n) => new Date(base.getFullYear(), base.getMonth(), base.getDate() + n);
    const valid = (mo, d) => mo >= 1 && mo <= 12 && d >= 1 && d <= 31;
    // 연도가 없으면 올해 그 날짜 (이미 지난 날도 올해로). 단, 반년 넘게 지난 날짜면 내년으로 봄 (12월에 적는 '1/5' 같은 경우)
    const nextMD = (mo, d) => {
      let x = new Date(base.getFullYear(), mo - 1, d);
      if ((base - x) / 864e5 > 180) x = new Date(base.getFullYear() + 1, mo - 1, d);
      return x;
    };
    const WDP = '(?:\\s*\\(\\s*[일월화수목금토]\\s*(?:요일)?\\s*\\))?';   // 날짜 뒤 (목) 같은 요일 표시
    const nearYear = (y) => Math.abs(y - base.getFullYear()) <= 5;
    const lead = (x) => x.replace(/^[^\d]/, '').trim();
    let date = null;
    const found = [];
    let m;

    // ---- 날짜 ----
    if ((m = t.match(new RegExp('(\\d{4})\\s*[-./년]\\s*(\\d{1,2})\\s*[-./월]\\s*(\\d{1,2})\\s*일?' + WDP))) && valid(+m[2], +m[3])) {
      date = new Date(+m[1], +m[2] - 1, +m[3]); found.push(m[0]);                                   // 2026-11-20 · 2026.11.20 · 2026/11/20 · 2026년 11월 20일
    } else if ((m = t.match(new RegExp('(?:^|[^\\d])(20\\d{2})(\\d{2})(\\d{2})(?!\\d)' + WDP))) && valid(+m[2], +m[3])) {
      date = new Date(+m[1], +m[2] - 1, +m[3]); found.push(lead(m[0]));                             // 20261120
    } else if ((m = t.match(new RegExp("(?:^|[^\\d./-])'?(\\d{2})\\s*[-./년]\\s*(\\d{1,2})\\s*[-./월]\\s*(\\d{1,2})\\s*일?(?![\\d:/.-])" + WDP))) && valid(+m[2], +m[3]) && nearYear(2000 + +m[1])) {
      date = new Date(2000 + +m[1], +m[2] - 1, +m[3]); found.push(lead(m[0]));                      // 26.11.20 · 26/11/20 · '26-11-20
    } else if ((m = t.match(new RegExp('(?:^|[^\\d.,:/-])(\\d{2})(\\d{2})(\\d{2})(?![\\d.,:/-]|\\s*(?:원|명|개|만|천|억|번|호|층|권|kg|km|%))' + WDP))) && valid(+m[2], +m[3]) && nearYear(2000 + +m[1])) {
      date = new Date(2000 + +m[1], +m[2] - 1, +m[3]); found.push(lead(m[0]));                      // 261120
    } else if ((m = t.match(new RegExp('(\\d{1,2})\\s*월\\s*(\\d{1,2})\\s*일' + WDP))) && valid(+m[1], +m[2])) {
      date = nextMD(+m[1], +m[2]); found.push(m[0]);
    } else if ((m = t.match(new RegExp('(?:^|[^\\d:/.])(\\d{1,2})\\s*[/.]\\s*(\\d{1,2})(?![\\d:/.]|\\s*분기)' + WDP))) && valid(+m[1], +m[2])) {
      date = nextMD(+m[1], +m[2]); found.push(lead(m[0]));                                          // 11/20 · 11.20
    } else if ((m = t.match(new RegExp('(?:^|[^\\d:/.~-])(\\d{1,2})-(\\d{1,2})(?![\\d:/.-]|\\s*(?:시|분|명|개|층|번|호|일|주|월|년|회|차|인|세|살|kg|km|%|원))' + WDP))) && valid(+m[1], +m[2])) {
      date = nextMD(+m[1], +m[2]); found.push(lead(m[0]));                                          // 11-20
    } else if ((m = t.match(/(오늘|내일|낼|모레|글피)/))) {
      date = add({ 오늘: 0, 내일: 1, 낼: 1, 모레: 2, 글피: 3 }[m[1]]); found.push(m[0]);
    } else if ((m = t.match(/(\d{1,2})\s*일\s*(?:후|뒤)/))) {
      date = add(+m[1]); found.push(m[0]);
    } else if ((m = t.match(/(이번\s*주|다음\s*주|담주|차주|다다음\s*주)?\s*([일월화수목금토])요일/))) {
      const wd = WDK.indexOf(m[2]);
      const which = (m[1] || '').replace(/\s/g, '');
      if (!which) {
        date = add((wd - base.getDay() + 7) % 7);
      } else {
        const mondayIdx = (d) => (d + 6) % 7; // 월=0 … 일=6
        const thisMon = add(-mondayIdx(base.getDay()));
        const weeks = which === '이번주' ? 0 : which === '다다음주' ? 2 : 1;
        date = new Date(thisMon.getFullYear(), thisMon.getMonth(), thisMon.getDate() + weeks * 7 + mondayIdx(wd));
      }
      found.push(m[0].trim());
    } else if ((m = t.match(/(?:^|[^\d])(\d{1,2})\s*일(?!\s*(?:후|뒤|간|동안|째))/)) && +m[1] >= 1 && +m[1] <= 31) {
      let x = new Date(base.getFullYear(), base.getMonth(), +m[1]);
      if (x < base) x = new Date(base.getFullYear(), base.getMonth() + 1, +m[1]);
      date = x; found.push(m[0].replace(/^[^\d]/, '').trim());
    }

    // ---- 시간 ----
    let start = null, end = null;
    const toH = (mer, h) => {
      h = +h;
      if (/오후|저녁|밤/.test(mer || '') && h < 12) h += 12;
      else if (/낮/.test(mer || '') && h < 7) h += 12;
      else if (/오전|아침|새벽/.test(mer || '') && h === 12) h = 0;
      else if (!mer && h >= 1 && h <= 6) h += 12; // "3시 회의"는 보통 오후
      return h;
    };
    const tre = /(오전|오후|아침|낮|저녁|밤|새벽)?\s*(?:(\d{1,2})\s*시\s*(?:(\d{1,2})\s*분|(반))?|(\d{1,2}):(\d{2})(?!\d))|(정오)/g;
    const times = [];
    let x;
    while ((x = tre.exec(t)) && times.length < 2) {
      if (x[7]) times.push({ h: 12, m: 0, s: x[0].trim() });
      else if (x[5] !== undefined) {
        if (+x[5] < 24 && +x[6] < 60) times.push({ h: x[1] ? toH(x[1], x[5]) : +x[5], m: +x[6], s: x[0].trim(), mer: x[1] });
      } else if (x[2] !== undefined && +x[2] <= 24) times.push({ h: toH(x[1], x[2]), m: x[4] ? 30 : +(x[3] || 0), s: x[0].trim(), mer: x[1] });
    }
    if (times.length) {
      const a = times[0];
      start = `${pad(a.h % 24)}:${pad(a.m)}`; found.push(a.s);
      if (times[1]) {
        let b = times[1];
        let bh = b.h;
        if (!b.mer && a.h >= 12 && bh < 12) bh += 12; // "오후 2시~4시"
        if (bh * 60 + b.m > a.h * 60 + a.m) { end = `${pad(bh % 24)}:${pad(b.m)}`; found.push(b.s); }
      }
      if (!date) { // 시간만 있으면: 아직 안 지났으면 오늘, 지났으면 내일
        const today = new Date(base); today.setHours(a.h, a.m);
        date = today > now ? base : add(1);
      }
    }
    if (!date) return null;
    return { date: ymd(date), start, end, found: found.join(' '), parts: found.slice() };
  }

  const api = { parse };
  if (typeof module !== 'undefined') module.exports = api; else root.DateSense = api;
})(typeof window !== 'undefined' ? window : globalThis);
