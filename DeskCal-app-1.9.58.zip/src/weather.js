// 날씨 (MET Norway · 노르웨이 기상청, CC BY 4.0) — 응원 친구가 날씨에 맞춰 말할 때 씀. 한 시간에 한 번만 받아 와요.
// 보내는 것: 고른 도시의 위도·경도(소수 둘째 자리)뿐. 계정·일정 내용은 보내지 않음.
const CITIES = [["auto"],["서울",37.5665,126.978],["인천",37.4563,126.7052],["수원",37.2636,127.0286],["성남",37.42,127.1265],["고양",37.6584,126.832],["용인",37.2411,127.1776],["부산",35.1796,129.0756],["대구",35.8714,128.6014],["광주",35.1595,126.8526],["대전",36.3504,127.3845],["울산",35.5384,129.3114],["세종",36.48,127.289],["창원",35.2281,128.6811],["청주",36.6424,127.489],["천안",36.8151,127.1139],["전주",35.8242,127.148],["포항",36.019,129.3435],["춘천",37.8813,127.7298],["강릉",37.7519,128.8761],["제주",33.4996,126.5312]];
const FRESH = 60 * 60 * 1000;
let cache = null; // { key, at, data }
let pending = null;

function coords(city) {
  const c = CITIES.find((x) => x[0] === city && x.length >= 3) || CITIES.find((x) => x[0] === '서울');
  return { name: c[0], lat: c[1], lon: c[2] };
}
const symOf = (d) => { const n = d && (d.next_1_hours || d.next_6_hours || d.next_12_hours); return (n && n.summary && n.summary.symbol_code) || ''; };
const isRain = (s) => /rain|sleet|drizzle/.test(s) && !/snow/.test(s);
const isSnow = (s) => /snow/.test(s);

function digest(json, name, now = new Date()) {
  const ts = (json && json.properties && json.properties.timeseries) || [];
  if (!ts.length) return null;
  const day = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  const today = day(now), tom = day(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));
  const rows = ts.map((x) => ({ t: new Date(x.time), temp: x.data && x.data.instant && x.data.instant.details ? x.data.instant.details.air_temperature : null, sym: symOf(x.data) }));
  const cur = rows.find((r) => r.t.getTime() + 3600e3 > now.getTime()) || rows[0];
  const out = { city: name, temp: cur.temp, sym: cur.sym, rainHour: null, snowHour: null, tmax: null, tmin: null, tomorrow: null, at: now.getTime() };
  const T = rows.filter((r) => day(r.t) === today && typeof r.temp === 'number');
  if (T.length) { out.tmax = Math.max(...T.map((r) => r.temp)); out.tmin = Math.min(...T.map((r) => r.temp)); }
  for (const r of rows) {
    if (day(r.t) !== today || r.t.getTime() + 3600e3 <= now.getTime()) continue;
    if (out.rainHour == null && isRain(r.sym)) out.rainHour = r.t.getHours();
    if (out.snowHour == null && isSnow(r.sym)) out.snowHour = r.t.getHours();
  }
  const M = rows.filter((r) => day(r.t) === tom && typeof r.temp === 'number');
  if (M.length) {
    const dayRows = M.filter((r) => r.t.getHours() >= 7 && r.t.getHours() <= 20);
    const bad = dayRows.find((r) => isSnow(r.sym)) || dayRows.find((r) => isRain(r.sym));
    const noon = M.find((r) => r.t.getHours() >= 12) || M[0];
    out.tomorrow = { sym: bad ? bad.sym : noon.sym, tmax: Math.max(...M.map((r) => r.temp)), tmin: Math.min(...M.map((r) => r.temp)) };
  }
  return out;
}

async function get(city) {
  const c = coords(city), key = c.name;
  if (cache && cache.key === key && Date.now() - cache.at < FRESH) return cache.data;
  if (pending && pending.key === key) return pending.p;
  const p = (async () => {
    try {
      const res = await fetch(`https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=${c.lat.toFixed(2)}&lon=${c.lon.toFixed(2)}`, { headers: { 'User-Agent': 'TotalCalendar/3 kkumanix.github.io/total-calendar' } });
      if (!res.ok) throw new Error('weather ' + res.status);
      const data = digest(await res.json(), c.name);
      if (data) cache = { key, at: Date.now(), data };
      return data || (cache && cache.key === key ? cache.data : null);
    } catch { return cache && cache.key === key ? cache.data : null; }   // 못 받아 오면 날씨 이야기만 빠짐
    finally { pending = null; }
  })();
  pending = { key, p };
  return p;
}
module.exports = { get, digest, coords, CITIES };
