// 캘린더 파일(.ics) 가져오기 — 다른 캘린더에서 내보낸 파일의 일정을 '내 기기' 캘린더에 넣어요.
// 같은 파일을 다시 넣어도 겹치지 않게, 가져온 일정에는 원래 고유번호로 만든 이름표를 붙여 둠.
const sync = require('./sync');
const MAX = 3000;

function run(text, existing) {
  text = String(text || '').replace(/^﻿/, '');
  if (!/BEGIN:VCALENDAR/i.test(text) || !/BEGIN:VEVENT/i.test(text)) throw new Error('일정이 들어 있는 캘린더 파일(.ics)이 아니에요');
  const now = new Date();
  const start = new Date(now.getFullYear() - 5, 0, 1), end = new Date(now.getFullYear() + 5, 11, 31);
  let items;
  try { items = sync.expandIcs(text, { id: 'import', name: '', color: '' }, start, end); }
  catch (e) { throw new Error('파일을 읽지 못했어요. 다른 캘린더에서 "내보내기"로 받은 .ics 파일인지 확인해 주세요'); }
  const have = new Set((existing || []).map((e) => e.uid));
  const seen = new Set(), added = [];
  let skipped = 0, cut = 0;
  for (const it of items) {
    const series = it.recurring && it.repeat && it.seriesStart;
    const uid = series ? `imp:${it.uid}` : `imp:${it.uid}:${it.start}`;
    if (seen.has(uid)) continue;
    seen.add(uid);
    if (have.has(uid)) { skipped++; continue; }
    if (added.length >= MAX) { cut++; continue; }
    let s = series ? it.seriesStart : it.start, e = series ? it.seriesEnd : it.end;
    if (it.allDay) { if (!(e > s)) { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + 1); e = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; } }
    else if (!(new Date(e) > new Date(s))) e = new Date(new Date(s).getTime() + 3600e3).toISOString();
    const ev = { uid, title: it.title || '(제목 없음)', allDay: !!it.allDay, start: s, end: e, location: it.location || '', notes: it.notes || '', categoryName: '', tz: it.tz || '' };
    if (series) { ev.repeat = it.repeat; ev.repeatUntil = it.repeatUntil || ''; }
    added.push(ev);
  }
  return { added, skipped, cut, total: seen.size };
}
module.exports = { run };
