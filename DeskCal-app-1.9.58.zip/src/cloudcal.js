// Google 캘린더 · Outlook(Microsoft) 계정 연결 — 공식 로그인(OAuth)으로 읽고 쓰기
// - 로그인: 기본 브라우저에서 Google/Microsoft 로그인 → 이 PC의 임시 주소(127.0.0.1)로 돌아옴 (PKCE)
// - 저장: 받은 '다시 쓰는 열쇠(refresh token)'만 암호화해서 이 기기 설정에 보관 (서버로 올리지 않음)
// - 일정: 읽기 · 만들기 · 고치기 · 지우기 모두 원래 캘린더에 바로 반영
const http = require('http');
const crypto = require('crypto');
const CFG = require('./oauth-config');

const PROVIDERS = {
  gcal: {
    auth: 'https://accounts.google.com/o/oauth2/v2/auth',
    token: 'https://oauth2.googleapis.com/token',
    scope: 'openid email https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.calendarlist',   // 캘린더 목록 보기·고치기 (구독한 달력 빼기·공휴일 추가)
    extra: { access_type: 'offline', prompt: 'consent' },
    host: '127.0.0.1'
  },
  msgraph: {
    auth: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    token: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scope: 'openid email offline_access User.Read Calendars.ReadWrite',
    extra: { prompt: 'select_account' },
    host: 'localhost'
  }
};
const b64u = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
// Google은 로그인 마무리에 '앱 비밀값'이 필요함 → 앱에는 넣지 않고 중계 서버(tokenProxy)가 붙여서 Google에 전달
const configured = (type) => { const c = CFG[type]; return !!(c && c.clientId && (type !== 'gcal' || c.tokenProxy || c.clientSecret)); };

let fetchFn = (...a) => fetch(...a);
function setFetch(f) { if (f) fetchFn = f; }

// ---- 로그인 (브라우저 → 이 PC로 돌아옴) ----
function signIn(type, openExternal, { timeoutMs = 5 * 60 * 1000, page } = {}) {
  const P = PROVIDERS[type], C = CFG[type];
  if (!P || !configured(type)) return Promise.reject(new Error('아직 이 계정 연결을 쓸 수 없어요 (앱 등록 필요)'));
  const verifier = b64u(crypto.randomBytes(48));
  const challenge = b64u(crypto.createHash('sha256').update(verifier).digest());
  const state = b64u(crypto.randomBytes(16));
  return new Promise((resolve, reject) => {
    const srv = http.createServer(async (req, res) => {
      const u = new URL(req.url, `http://${P.host}`);
      if (u.pathname !== '/cb') { res.writeHead(404); res.end(); return; }
      const done = (ok, msg) => { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end((page || defaultPage)(ok, msg)); };
      try {
        if (u.searchParams.get('state') !== state) throw new Error('잘못된 응답이에요');
        const err = u.searchParams.get('error'); if (err) throw new Error(err === 'access_denied' ? '로그인을 취소했어요' : err);
        const code = u.searchParams.get('code');
        const tok = await tokenReq(type, { grant_type: 'authorization_code', code, code_verifier: verifier, redirect_uri: redirect });
        const who = await account(type, tok.access_token, tok.id_token);
        done(true); finish(null, { refresh: tok.refresh_token, access: tok.access_token, exp: Date.now() + (tok.expires_in || 3000) * 1000, email: who });
      } catch (e) { done(false, e.message); finish(e); }
    });
    let redirect = '', timer = null;
    const finish = (e, v) => { clearTimeout(timer); setTimeout(() => srv.close(), 300); e ? reject(e) : resolve(v); };
    srv.on('error', (e) => finish(e));
    srv.listen(0, '127.0.0.1', () => {
      redirect = `http://${P.host}:${srv.address().port}/cb`;
      const q = new URLSearchParams({ client_id: C.clientId, redirect_uri: redirect, response_type: 'code', scope: P.scope, state, code_challenge: challenge, code_challenge_method: 'S256', ...P.extra });
      openExternal(`${P.auth}?${q}`);
      timer = setTimeout(() => finish(new Error('로그인 시간이 지났어요. 다시 눌러 주세요')), timeoutMs);
    });
  });
}
const defaultPage = (ok, msg) => `<!doctype html><meta charset="utf-8"><title>Total Calendar</title><body style="font-family:sans-serif;display:grid;place-items:center;height:90vh;background:#FFF8F0;color:#2E241F"><div style="text-align:center"><div style="font-size:48px">${ok ? '✅' : '⚠️'}</div><h2>${ok ? '연결됐어요!' : '연결하지 못했어요'}</h2><p>${ok ? '이 창을 닫고 Total Calendar로 돌아가세요.' : String(msg || '').replace(/[<>&]/g, '')}</p></div>`;

async function tokenReq(type, params) {
  const P = PROVIDERS[type], C = CFG[type];
  const body = new URLSearchParams({ client_id: C.clientId, ...(C.clientSecret ? { client_secret: C.clientSecret } : {}), ...params });
  if (type === 'msgraph') body.set('scope', P.scope);
  const r = await fetchFn(C.tokenProxy || P.token, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error_description || j.error || `로그인 서버 오류 (${r.status})`); e.code = j.error; throw e; }
  return j;
}
async function account(type, access, idToken) {
  try { if (idToken) { const p = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64').toString('utf8')); if (p.email || p.preferred_username) return p.email || p.preferred_username; } } catch {}
  try {
    const r = await fetchFn(type === 'gcal' ? 'https://openidconnect.googleapis.com/v1/userinfo' : 'https://graph.microsoft.com/v1.0/me', { headers: { Authorization: 'Bearer ' + access } });
    const j = await r.json(); return j.email || j.mail || j.userPrincipalName || '';
  } catch { return ''; }
}

// ---- 접속 열쇠 (1시간짜리, 메모리에만) ----
const access = new Map();   // src.id → { token, exp }
async function tokenFor(src, refresh) {
  const c = access.get(src.id);
  if (c && c.exp > Date.now() + 60e3) return c.token;
  if (!refresh) throw new Error('다시 로그인해 주세요 (설정 > 4. 캘린더 연결)');
  try {
    const t = await tokenReq(src.type, { grant_type: 'refresh_token', refresh_token: refresh });
    access.set(src.id, { token: t.access_token, exp: Date.now() + (t.expires_in || 3000) * 1000 });
    if (t.refresh_token && t.refresh_token !== refresh && onNewRefresh) onNewRefresh(src.id, t.refresh_token);
    return t.access_token;
  } catch (e) {
    if (e.code === 'invalid_grant') throw new Error('로그인이 만료됐어요. 설정 > 4. 캘린더 연결에서 다시 로그인해 주세요');
    throw e;
  }
}
let onNewRefresh = null;
function onRefreshRotated(fn) { onNewRefresh = fn; }
function prime(src, tok) { if (tok && tok.access) access.set(src.id, { token: tok.access, exp: tok.exp || Date.now() + 3000e3 }); }
function forget(id) { access.delete(id); }

async function api(src, refresh, url, opt = {}) {
  const token = await tokenFor(src, refresh);
  const r = await fetchFn(url, { ...opt, headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opt.headers || {}) } });
  if (r.status === 204) return null;
  const j = await r.json().catch(() => null);
  if (!r.ok) {
    if (r.status === 401) access.delete(src.id);
    const m = (j && j.error && (j.error.message || j.error)) || `서버 오류 (${r.status})`;
    throw new Error(typeof m === 'string' ? m : JSON.stringify(m));
  }
  return j;
}

// ---- 변환 ----
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const isoUtc = (s) => new Date(s).toISOString();
const REPEAT_G = { daily: 'DAILY', weekly: 'WEEKLY', monthly: 'MONTHLY', yearly: 'YEARLY' };
const REPEAT_FROM_G = { DAILY: 'daily', WEEKLY: 'weekly', MONTHLY: 'monthly', YEARLY: 'yearly' };

function fromGoogle(src, e) {
  const all = !!(e.start && e.start.date);
  const rr = (e._series && e._series.recurrence || []).find((x) => /^RRULE:/.test(x)) || '';
  const fr = (rr.match(/FREQ=(\w+)/) || [])[1]; const simple = rr && !/INTERVAL=(?!1;|1$)|COUNT=/.test(rr);
  const until = (rr.match(/UNTIL=(\d{4})(\d{2})(\d{2})/) || []);
  const repeat = e.recurringEventId && simple ? (REPEAT_FROM_G[fr] || '') : '';
  return {
    id: `${src.id}|${e.id}|${all ? e.start.date : e.start.dateTime}`, uid: e.id, sourceId: src.id, source: src.name, color: src.color,
    title: e.summary || '(제목 없음)', start: all ? e.start.date : isoUtc(e.start.dateTime), end: all ? e.end.date : isoUtc(e.end.dateTime), allDay: all,
    location: e.location || '', notes: e.description || '', categoryName: '', tz: (!all && e.start.timeZone) || '',
    recurring: !!e.recurringEventId, repeat, repeatUntil: until[1] ? `${until[1]}-${until[2]}-${until[3]}` : '', seriesId: e.recurringEventId || '',
    seriesStart: '', seriesEnd: '', lunar: null, writable: true
  };
}
function toGoogle(d) {
  const o = { summary: d.title, location: d.location || '', description: d.notes || '' };
  if (d.allDay) { o.start = { date: d.start }; o.end = { date: d.end }; }
  else { const tz = d.tz || Intl.DateTimeFormat().resolvedOptions().timeZone; o.start = { dateTime: isoUtc(d.start), timeZone: tz }; o.end = { dateTime: isoUtc(d.end), timeZone: tz }; }
  if (REPEAT_G[d.repeat] && !d.lunar) o.recurrence = [`RRULE:FREQ=${REPEAT_G[d.repeat]}${d.repeatUntil ? ';UNTIL=' + d.repeatUntil.replace(/-/g, '') + 'T235959Z' : ''}`];
  return o;
}
const MS_PAT = { daily: 'daily', weekly: 'weekly', monthly: 'absoluteMonthly', yearly: 'absoluteYearly' };
const WD = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
function fromMs(src, e) {
  const all = !!e.isAllDay;
  const s = all ? e.start.dateTime.slice(0, 10) : new Date(e.start.dateTime + 'Z').toISOString();
  const en = all ? e.end.dateTime.slice(0, 10) : new Date(e.end.dateTime + 'Z').toISOString();
  return {
    id: `${src.id}|${e.id}|${s}`, uid: e.id, sourceId: src.id, source: src.name, color: src.color,
    title: e.subject || '(제목 없음)', start: s, end: en, allDay: all,
    location: (e.location && e.location.displayName) || '', notes: (e.bodyPreview || ''), categoryName: (e.categories || [])[0] || '', tz: '',
    recurring: e.type === 'occurrence' || e.type === 'exception', repeat: '', repeatUntil: '', seriesId: e.seriesMasterId || '',
    seriesStart: '', seriesEnd: '', lunar: null, writable: e.type !== 'occurrence' && e.type !== 'exception'
  };
}
function toMs(d) {
  const tz = 'UTC';
  const o = { subject: d.title, body: { contentType: 'text', content: d.notes || '' }, location: { displayName: d.location || '' }, isAllDay: !!d.allDay };
  if (d.allDay) { o.start = { dateTime: d.start + 'T00:00:00', timeZone: tz }; o.end = { dateTime: d.end + 'T00:00:00', timeZone: tz }; }
  else { o.start = { dateTime: isoUtc(d.start).replace('Z', ''), timeZone: tz }; o.end = { dateTime: isoUtc(d.end).replace('Z', ''), timeZone: tz }; }
  if (MS_PAT[d.repeat] && !d.lunar) {
    const sd = new Date(d.allDay ? d.start + 'T00:00:00' : d.start);
    const pattern = { type: MS_PAT[d.repeat], interval: 1 };
    if (d.repeat === 'weekly') pattern.daysOfWeek = [WD[sd.getDay()]];
    if (d.repeat === 'monthly' || d.repeat === 'yearly') pattern.dayOfMonth = sd.getDate();
    if (d.repeat === 'yearly') pattern.month = sd.getMonth() + 1;
    o.recurrence = { pattern, range: d.repeatUntil ? { type: 'endDate', startDate: ymd(sd), endDate: d.repeatUntil } : { type: 'noEnd', startDate: ymd(sd) } };
  }
  return o;
}

// ---- 일정 읽기 · 쓰기 ----
const G = 'https://www.googleapis.com/calendar/v3', M = 'https://graph.microsoft.com/v1.0';
const calId = (src) => encodeURIComponent(src.calendarId || 'primary');
async function list(src, refresh, start, end) {
  const out = [];
  if (src.type === 'gcal') {
    let page = '';
    for (let i = 0; i < 10; i++) {
      const q = new URLSearchParams({ timeMin: start.toISOString(), timeMax: end.toISOString(), singleEvents: 'true', orderBy: 'startTime', maxResults: '2500', ...(page ? { pageToken: page } : {}) });
      const j = await api(src, refresh, `${G}/calendars/${calId(src)}/events?${q}`);
      for (const e of j.items || []) if (e.status !== 'cancelled' && e.start) out.push(fromGoogle(src, e));
      page = j.nextPageToken; if (!page) break;
    }
  } else if (src.type === 'msgraph') {
    let url = `${M}/me/calendarView?${new URLSearchParams({ startDateTime: start.toISOString(), endDateTime: end.toISOString(), $top: '500', $select: 'id,subject,start,end,isAllDay,location,bodyPreview,categories,type,seriesMasterId,isCancelled' })}`;
    for (let i = 0; i < 20 && url; i++) {
      const j = await api(src, refresh, url, { headers: { Prefer: 'outlook.timezone="UTC"' } });
      for (const e of j.value || []) if (!e.isCancelled) out.push(fromMs(src, e));
      url = j['@odata.nextLink'] || '';
    }
  }
  return out;
}
async function create(src, refresh, d) {
  if (src.type === 'gcal') { const j = await api(src, refresh, `${G}/calendars/${calId(src)}/events`, { method: 'POST', body: JSON.stringify(toGoogle(d)) }); return j.id; }
  const j = await api(src, refresh, `${M}/me/events`, { method: 'POST', body: JSON.stringify(toMs(d)) }); return j.id;
}
async function update(src, refresh, ev, d) {
  const id = encodeURIComponent(ev.recurring && ev.repeat && ev.seriesId ? ev.seriesId : ev.uid);
  if (src.type === 'gcal') return api(src, refresh, `${G}/calendars/${calId(src)}/events/${id}`, { method: 'PATCH', body: JSON.stringify(toGoogle(d)) });
  return api(src, refresh, `${M}/me/events/${id}`, { method: 'PATCH', body: JSON.stringify(toMs(d)) });
}
async function remove(src, refresh, ev) {
  const id = encodeURIComponent(ev.recurring && ev.repeat && ev.seriesId ? ev.seriesId : ev.uid);
  if (src.type === 'gcal') return api(src, refresh, `${G}/calendars/${calId(src)}/events/${id}`, { method: 'DELETE' });
  return api(src, refresh, `${M}/me/events/${id}`, { method: 'DELETE' });
}
async function calendars(src, refresh) {
  if (src.type === 'gcal') { const j = await api(src, refresh, `${G}/users/me/calendarList?minAccessRole=writer`); return (j.items || []).map((c) => ({ id: c.id, name: c.summaryOverride || c.summary, primary: !!c.primary })); }
  const j = await api(src, refresh, `${M}/me/calendars?$select=id,name,isDefaultCalendar,canEdit`); return (j.value || []).filter((c) => c.canEdit !== false).map((c) => ({ id: c.id, name: c.name, primary: !!c.isDefaultCalendar }));
}

// ---- Google 캘린더 목록 (구독한 달력 추가·빼기) ----
// 예전에 연결한 계정은 목록 고치기 권한이 없어서 '다시 연결해 주세요'라고 알려 줌
const scopeErr = (e) => { const m = String((e && e.message) || e); return /insufficient|scope|permission|forbidden|403/i.test(m) ? new Error('Google 연결을 한 번 더 해 주세요 (설정 > 4. 캘린더 연결 > 다시 로그인 · 새 권한이 필요해요)') : e; };
async function gList(src, refresh) {
  const out = []; let page = '';
  for (let i = 0; i < 5; i++) {
    const j = await api(src, refresh, `${G}/users/me/calendarList?${new URLSearchParams({ maxResults: '250', showHidden: 'true', ...(page ? { pageToken: page } : {}) })}`);
    for (const c of j.items || []) out.push({ id: c.id, name: c.summaryOverride || c.summary || '', primary: !!c.primary });
    page = j.nextPageToken; if (!page) break;
  }
  return out;
}
async function gAdd(src, refresh, id) { try { return await api(src, refresh, `${G}/users/me/calendarList`, { method: 'POST', body: JSON.stringify({ id }) }); } catch (e) { throw scopeErr(e); } }
async function gRemove(src, refresh, id) { try { return await api(src, refresh, `${G}/users/me/calendarList/${encodeURIComponent(id)}`, { method: 'DELETE' }); } catch (e) { throw scopeErr(e); } }

module.exports = { gList, gAdd, gRemove, PROVIDERS, configured, setFetch, signIn, list, create, update, remove, calendars, prime, forget, onRefreshRotated, toGoogle, toMs, fromGoogle, fromMs };
