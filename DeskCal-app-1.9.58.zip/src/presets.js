// 골라 넣는 달력 (설정 > 캘린더 연결 > 더 넣을 수 있는 달력)
// - 인터넷에서 받지 않고 앱 안에서 날짜를 계산해 만들어요 (세무·인사·경영·건설 업무 일정, 기념일, 24절기)
// - 법정 기한은 주말·공휴일이면 다음 날로 옮겨 표시 (국세기본법 등 '기한의 특례'와 같은 방식)
// - 참고용 달력이에요. 법·회사 사정에 따라 달라질 수 있으니 중요한 기한은 해당 기관 안내를 함께 확인
const Lunar = require('../renderer/lunar.js');

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const D = (y, m, d) => new Date(y, m - 1, d);
const addDays = (s, n) => { const d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return ymd(d); };
const lastDay = (y, m) => new Date(y, m, 0).getDate();
const dow = (s) => new Date(s + 'T12:00:00').getDay();

// ---------- 대한민국 공휴일 (기한을 옮길 때 씀 · 대체공휴일 포함) ----------
const holCache = new Map();
function krHolidays(y) {
  if (holCache.has(y)) return holCache.get(y);
  const set = new Set();
  const fixed = [`${y}-01-01`, `${y}-06-06`];
  const subst = [`${y}-03-01`, `${y}-08-15`, `${y}-10-03`, `${y}-10-09`, `${y}-12-25`];   // 토·일이면 대체공휴일
  const buddha = Lunar.toSolar(y, 4, 8, false);
  if (buddha) subst.push(buddha);
  const child = `${y}-05-05`;
  const lunarSet = [];
  for (const base of [Lunar.seollal(y), Lunar.chuseok(y)]) if (base) lunarSet.push([addDays(base, -1), base, addDays(base, 1)]);
  fixed.forEach((d) => set.add(d)); subst.forEach((d) => set.add(d)); set.add(child); lunarSet.flat().forEach((d) => set.add(d));
  const nextFree = (d) => { let x = addDays(d, 1); while (set.has(x) || dow(x) === 0 || dow(x) === 6) x = addDays(x, 1); return x; };
  const count = (d) => [...fixed, ...subst, child, ...lunarSet.flat()].filter((x) => x === d).length;
  for (const d of subst) if (dow(d) === 0 || dow(d) === 6 || count(d) > 1) set.add(nextFree(d));
  if (dow(child) === 0 || dow(child) === 6 || count(child) > 1) set.add(nextFree(child));
  for (const days of lunarSet) if (days.some((d) => dow(d) === 0 || count(d) > 1)) {   // 설·추석 연휴가 일요일이나 다른 공휴일과 겹치면
    let x = addDays(days[2], 1); while (set.has(x) || dow(x) === 0) x = addDays(x, 1); set.add(x);
  }
  holCache.set(y, set);
  return set;
}

// ---------- 24절기 (태양 황경으로 계산 · 한국 시간 기준) ----------
const rad = Math.PI / 180;
function sunLon(date) {
  const jd = date.getTime() / 864e5 + 2440587.5, T = (jd - 2451545) / 36525;
  const L0 = 280.46646 + 36000.76983 * T + 0.0003032 * T * T;
  const M = (357.52911 + 35999.05029 * T - 0.0001537 * T * T) * rad;
  const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M) + (0.019993 - 0.000101 * T) * Math.sin(2 * M) + 0.000289 * Math.sin(3 * M);
  const lam = L0 + C - 0.00569 - 0.00478 * Math.sin((125.04 - 1934.136 * T) * rad);
  return ((lam % 360) + 360) % 360;
}
const TERMS = [['소한', 285, '가장 추운 때'], ['대한', 300, '큰 추위'], ['입춘', 315, '봄의 시작'], ['우수', 330, '눈이 녹아 비가 되는 때'], ['경칩', 345, '개구리가 깨어나는 때'], ['춘분', 0, '낮과 밤의 길이가 같아지는 날'],
  ['청명', 15, '하늘이 맑아지는 때'], ['곡우', 30, '봄비가 곡식을 깨우는 때'], ['입하', 45, '여름의 시작'], ['소만', 60, '햇볕이 풍성해지는 때'], ['망종', 75, '씨 뿌리기 좋은 때'], ['하지', 90, '낮이 가장 긴 날'],
  ['소서', 105, '더위의 시작'], ['대서', 120, '가장 더운 때'], ['입추', 135, '가을의 시작'], ['처서', 150, '더위가 물러가는 때'], ['백로', 165, '이슬이 맺히는 때'], ['추분', 180, '밤이 길어지기 시작하는 날'],
  ['한로', 195, '찬 이슬이 내리는 때'], ['상강', 210, '서리가 내리는 때'], ['입동', 225, '겨울의 시작'], ['소설', 240, '첫눈이 오는 때'], ['대설', 255, '큰 눈이 오는 때'], ['동지', 270, '밤이 가장 긴 날']];
const kstMidnight = (y, m, d) => new Date(Date.UTC(y, m - 1, d) - 9 * 3600e3);   // 한국 시간 그날 0시
function solarTerms(y) {
  const out = [];
  for (let day = 0; day < 366; day++) {
    const a = kstMidnight(y, 1, 1 + day), b = kstMidnight(y, 1, 2 + day);
    if (a.getUTCFullYear() > y && a.getUTCMonth() > 0) break;
    const la = sunLon(a), lb = sunLon(b);
    for (const [name, deg, desc] of TERMS) {
      const crossed = la <= lb ? (deg > la && deg <= lb) : (deg > la || deg <= lb);
      if (crossed) { const d = new Date(Date.UTC(y, 0, 1 + day)); out.push({ d: `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`, t: name, n: desc }); }
    }
  }
  return out.filter((x) => x.d.startsWith(String(y)));
}

// ---------- 달력 정의 ----------
// 항목: { d:'YYYY-MM-DD', t:제목, n:설명, k:법정 기한이면 true(주말·공휴일이면 다음 날), to:'YYYY-MM-DD'(여러 날) }
const SHIFT_NOTE = '기한이 토·일요일이나 공휴일이면 다음 날로 옮겨 표시했어요.';
const REF = '참고용 일정이에요. 법 개정이나 회사 사정에 따라 다를 수 있으니 중요한 기한은 해당 기관 안내를 함께 확인해 주세요.';
const each = (fn) => { const a = []; for (let m = 1; m <= 12; m++) a.push(...[].concat(fn(m) || [])); return a; };
const md = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
const nth = (y, m, wd, n) => { const f = D(y, m, 1); const off = (wd - f.getDay() + 7) % 7; return md(y, m, 1 + off + (n - 1) * 7); };

const DEFS = [
  // ---- 기념일·계절 ----
  { id: 'kr-days', group: 'day', name: '기념일', color: '#F472B6', desc: '어버이날·스승의 날·정월대보름 같은, 쉬지는 않는 날',
    gen: (y) => {
      const L = (m, d, t, n) => { const s = Lunar.toSolar(y, m, d, false); return s ? [{ d: s, t, n: '음력 ' + m + '월 ' + d + '일' + (n ? ' · ' + n : '') }] : []; };
      return [
        { d: md(y, 2, 14), t: '밸런타인데이' }, { d: md(y, 3, 14), t: '화이트데이' },
        { d: md(y, 4, 5), t: '식목일' }, { d: md(y, 4, 20), t: '장애인의 날' }, { d: md(y, 5, 8), t: '어버이날' }, { d: md(y, 5, 15), t: '스승의 날' },
        { d: nth(y, 5, 1, 3), t: '성년의 날', n: '5월 셋째 월요일' }, { d: md(y, 5, 21), t: '부부의 날' }, { d: md(y, 6, 25), t: '6·25 전쟁일' },
        { d: md(y, 10, 1), t: '국군의 날' }, { d: md(y, 10, 31), t: '핼러윈' }, { d: md(y, 11, 11), t: '빼빼로데이' }, { d: md(y, 12, 24), t: '크리스마스이브' }, { d: md(y, 12, 31), t: '한 해의 마지막 날' },
        ...L(1, 15, '정월대보름', '부럼 깨기'), ...L(3, 3, '삼짇날'), ...L(5, 5, '단오'), ...L(7, 7, '칠석'), ...L(7, 15, '백중'), ...L(9, 9, '중양절'),
      ];
    } },
  { id: 'kr-terms', group: 'day', name: '24절기', color: '#84CC16', desc: '입춘·하지·동지처럼 계절이 바뀌는 날',
    gen: (y) => solarTerms(y) },

  // ---- 업무 일정 ----
  { id: 'job-tax', group: 'job', name: '세무 일정 (법인)', color: '#0EA5E9', desc: '원천세·부가세·법인세·지급명세서·지방세 신고와 납부 마감',
    gen: (y) => [
      ...each((m) => ({ d: md(y, m, 10), t: '원천세 신고·납부', n: `${m === 1 ? 12 : m - 1}월 지급분 원천세와 지방소득세(특별징수). 반기 납부 승인 사업장은 1월·7월에만 내요.`, k: true })),
      ...each((m) => ({ d: md(y, m, lastDay(y, m)), t: '일용근로·사업소득 간이지급명세서 제출', n: `${m === 1 ? 12 : m - 1}월 지급분 (매월 말일까지)`, k: true })),
      // 상용근로소득 간이지급명세서: 2026년 지급분까지는 반기(1월·7월 말), 2027년 1월 지급분부터 매월 제출로 바뀌어요 (2025년 세법 개정으로 1년 미뤄짐)
      ...(y <= 2027 ? [{ d: md(y, 1, 31), t: '근로소득 간이지급명세서 제출 (하반기분)', n: `${y - 1}년 7~12월 지급분`, k: true }] : []),
      ...(y <= 2026 ? [{ d: md(y, 7, 31), t: '근로소득 간이지급명세서 제출 (상반기분)', n: `${y}년 1~6월 지급분`, k: true }] : []),
      ...(y >= 2027 ? each((m) => (y === 2027 && m === 1 ? [] : { d: md(y, m, lastDay(y, m)), t: '근로소득 간이지급명세서 제출 (월별)', n: `${m === 1 ? 12 : m - 1}월 지급분 · 2027년 1월 지급분부터 매월 제출로 바뀌어요 (시행 시기는 한 번 더 확인해 주세요)`, k: true })) : []),
      { d: md(y, 1, 15), t: '연말정산 간소화 자료 공개', n: '홈택스에서 근로자가 공제 자료를 내려받을 수 있어요 (보통 1월 15일 무렵)' },
      { d: md(y, 1, 25), t: '부가가치세 2기 확정 신고·납부', n: `${y - 1}년 7~12월분`, k: true },
      { d: md(y, 1, 31), t: '등록면허세(면허분) 납부', n: '지방세 · 1월 16~31일', k: true },
      { d: md(y, 2, 10), t: '면세사업자 사업장현황신고', n: '부가가치세 면세 개인사업자', k: true },
      { d: md(y, 2, lastDay(y, 2)), t: '이자·배당·기타소득 지급명세서 제출', n: `${y - 1}년 지급분`, k: true },
      { d: md(y, 3, 10), t: '근로·퇴직·사업소득 지급명세서 제출', n: `${y - 1}년 귀속 연말정산분 · 연말정산 환급·추징은 보통 2~3월 급여에 반영`, k: true },
      { d: md(y, 3, 31), t: '법인세 신고·납부 (12월 결산법인)', n: '성실신고확인 대상 법인은 4월 30일까지', k: true },
      { d: md(y, 4, 25), t: '부가가치세 1기 예정 신고·납부', n: '1~3월분 · 법인 (개인은 예정고지 납부)', k: true },
      { d: md(y, 4, 30), t: '법인 지방소득세 신고·납부', n: '12월 결산법인', k: true },
      { d: md(y, 5, 31), t: '종합소득세·개인지방소득세 신고·납부', n: `${y - 1}년 귀속 · 성실신고확인 대상은 6월 30일까지`, k: true },
      { d: md(y, 5, 31), t: '근로·자녀장려금 정기 신청 마감', n: '5월 1일부터 한 달', k: true },
      { d: md(y, 6, 30), t: '종합소득세 신고 (성실신고확인 대상)', k: true },
      { d: md(y, 6, 30), t: '자동차세 1기 납부', n: '지방세 · 6월 16~30일', k: true },
      { d: md(y, 7, 25), t: '부가가치세 1기 확정 신고·납부', n: '1~6월분 (법인은 4~6월분)', k: true },
      { d: md(y, 7, 31), t: '재산세 1기 납부 (건축물·주택 1/2)', n: '지방세 · 7월 16~31일', k: true },
      { d: md(y, 7, 31), t: '주민세(사업소분) 신고·납부', n: '지방세 · 7월 1~31일', k: true },
      { d: md(y, 8, 31), t: '법인세 중간예납 (12월 결산법인)', k: true },
      { d: md(y, 8, 31), t: '주민세(개인분) 납부', n: '지방세 · 8월 16~31일', k: true },
      { d: md(y, 9, 30), t: '재산세 2기 납부 (토지·주택 1/2)', n: '지방세 · 9월 16~30일', k: true },
      { d: md(y, 10, 25), t: '부가가치세 2기 예정 신고·납부', n: '7~9월분 · 법인 (개인은 예정고지 납부)', k: true },
      { d: md(y, 11, 30), t: '종합소득세 중간예납 납부', n: '개인사업자 · 고지서로 납부', k: true },
      { d: md(y, 12, 15), t: '종합부동산세 납부', n: '12월 1~15일', k: true },
      { d: md(y, 12, 31), t: '자동차세 2기 납부', n: '지방세 · 12월 16~31일', k: true },
    ] },
  { id: 'job-hr', group: 'job', name: '인사·노무 일정', color: '#8B5CF6', desc: '4대보험 납부·신고, 연말정산, 보수총액 신고, 연차 사용 촉진, 최저임금, 법정 의무교육',
    gen: (y) => [
      ...each((m) => ({ d: md(y, m, 10), t: '4대보험료 납부', n: '전월분 국민연금·건강·고용·산재보험료', k: true })),
      ...each((m) => ({ d: md(y, m, 15), t: '일용근로자 근로내용확인신고', n: `${m === 1 ? 12 : m - 1}월 일용근로분 (고용·산재보험, 다음 달 15일까지)`, k: true })),
      { d: md(y, 1, 1), t: '새해 최저임금 적용', n: '급여 기준표·계약서의 시급을 확인해요' },
      { d: md(y, 1, 15), t: '연말정산 시작', n: '간소화 자료 공개 → 근로자 공제 자료 제출 → 2월 급여 정산이 흔한 순서예요' },
      { d: md(y, 1, 31), t: '장애인 고용부담금 신고·납부', n: `${y - 1}년분 · 상시근로자 100명 이상 사업주`, k: true },
      { d: md(y, 3, 10), t: '근로소득 지급명세서 제출 (연말정산)', n: '세무서 제출 마감', k: true },
      { d: md(y, 3, 15), t: '고용·산재보험 보수총액 신고', n: `${y - 1}년 보수 · 건설업 등 자진신고 사업장은 3월 31일까지`, k: true },
      { d: md(y, 4, 10), t: '건강보험 정산분 반영', n: '전년도 보수 정산 보험료가 4월분(4월 급여)부터 반영돼요' },
      { d: md(y, 4, 30), t: '고용형태 공시 마감', n: '상시근로자 300명 이상 · 3월 31일 기준 현황', k: true },
      { d: md(y, 7, 1), to: md(y, 7, 10), t: '연차 사용 촉진 1차 (회계연도 기준)', n: '1월 1일 기준 연차라면 7월 1~10일 사이에 남은 연차를 알리고 사용 계획을 받아요' },
      { d: md(y, 7, 10), t: '국민연금 기준소득월액 변경 반영', n: '7월분 보험료부터 새 기준이 적용돼요' },
      { d: md(y, 8, 5), t: '다음 해 최저임금 고시', n: '고용노동부 장관 고시 기한' },
      { d: md(y, 10, 31), t: '연차 사용 촉진 2차 (회계연도 기준)', n: '남은 연차의 사용 시기를 정해 알려 줘요 (만료 2개월 전까지)' },
      { d: md(y, 12, 1), t: '법정 의무교육 연내 완료 확인', n: '직장 내 성희롱 예방·직장 내 장애인 인식 개선·개인정보 보호·퇴직연금 교육은 연 1회 이상' },
      { d: md(y, 12, 31), t: '퇴직연금(DC) 부담금 납입 확인', n: '연 1회 이상 납입' },
    ] },
  { id: 'job-biz', group: 'job', name: '경영·회계·공시 일정', color: '#F59E0B', desc: '분기 결산, 정기주주총회, 사업·분기보고서 (12월 결산 상장회사 기준)',
    gen: (y) => [
      ...[3, 6, 9, 12].map((m) => ({ d: md(y, m, lastDay(y, m)), t: `${m / 3}분기 결산일`, n: m === 12 ? '연말 결산 · 재고 실사와 채권·채무 확인' : '분기 말 결산' })),
      { d: md(y, 3, 31), t: '정기주주총회 · 사업보고서 제출 마감', n: '12월 결산 상장회사 · 사업보고서는 결산일로부터 90일 안 · 주총 일정은 정관을 확인', k: true },
      { d: md(y, 5, 1), t: '공시대상·상호출자제한 기업집단 지정 발표', n: '공정거래위원회 (5월 1일까지)' },
      { d: md(y, 5, 15), t: '1분기 보고서 제출 마감', n: '분기 말로부터 45일', k: true },
      { d: md(y, 8, 14), t: '반기보고서 제출 마감', n: '반기 말로부터 45일', k: true },
      { d: md(y, 11, 14), t: '3분기 보고서 제출 마감', n: '분기 말로부터 45일', k: true },
    ] },
  { id: 'job-con', group: 'job', name: '건설 일정', color: '#EA580C', desc: '안전점검의 날, 퇴직공제 신고, 공사실적·경영상태 신고, 시공능력평가, 계절별 안전관리',
    gen: (y) => [
      ...each((m) => ({ d: md(y, m, 4), t: '안전점검의 날', n: '매월 4일' })),
      ...each((m) => ({ d: md(y, m, 15), t: '건설근로자 퇴직공제 신고·납부', n: `${m === 1 ? 12 : m - 1}월 근로일수 (다음 달 15일까지 · 건설근로자공제회)`, k: true })),
      { d: md(y, 2, 1), t: '해빙기 안전관리 (2~3월)', n: '땅이 녹으며 지반·옹벽·굴착면이 약해지는 때' },
      { d: md(y, 2, 15), t: '건설공사 실적·기술인 신고 마감', n: `${y - 1}년 공사실적 · 대한건설협회 등 · 해마다 접수 기간을 공지해요`, k: true },
      { d: md(y, 3, 31), t: '고용·산재보험 확정·개산보험료 신고 (건설업)', n: '자진신고 사업장', k: true },
      { d: md(y, 4, 15), t: '건설업 경영상태(재무제표) 신고 마감', n: '법인 기준 · 개인은 보통 6월', k: true },
      { d: md(y, 6, 1), t: '장마철·폭염 대비 안전관리 시작', n: '배수·토사 붕괴·감전 점검, 폭염 때 물·그늘·휴식' },
      { d: md(y, 7, 31), t: '시공능력평가 공시', n: '국토교통부 · 매년 7월 말 · 8월 1일부터 적용' },
      { d: md(y, 11, 15), t: '동절기 안전관리 시작 (~3월 15일)', n: '콘크리트 보온 양생, 질식·화재, 결빙 미끄럼 점검' },
    ] },

  { id: 'job-soho', group: 'job', name: '개인사업자·소상공인 세무', color: '#06B6D4', desc: '부가세(일반·간이), 종합소득세, 사업장현황신고, 원천세, 근로·자녀장려금',
    gen: (y) => [
      { d: md(y, 1, 25), t: '부가가치세 확정 신고·납부', n: `일반과세자 ${y - 1}년 7~12월분 · 간이과세자는 ${y - 1}년 1년치를 이때 한 번에`, k: true },
      { d: md(y, 2, 10), t: '면세사업자 사업장현황신고', n: `${y - 1}년 수입금액 신고 (병의원·학원·농축수산물 판매 등)`, k: true },
      { d: md(y, 3, 15), t: '근로·자녀장려금 반기 신청 마감', n: `${y - 1}년 하반기 근로소득분 · 3월 1~15일 (근로소득만 있는 사람)`, k: true },
      { d: md(y, 4, 25), t: '부가가치세 예정고지 납부', n: '일반과세자 · 고지서 금액 납부 (사업이 어려우면 예정신고도 가능)', k: true },
      { d: md(y, 5, 31), t: '종합소득세 신고·납부', n: `${y - 1}년 귀속 · 성실신고확인 대상은 6월 30일까지`, k: true },
      { d: md(y, 5, 31), t: '근로·자녀장려금 정기 신청 마감', n: '5월 1일부터 한 달', k: true },
      { d: md(y, 5, 31), t: '대표자 건강보험 보수총액 신고', n: '직원을 둔 개인사업장 대표자 · 성실신고확인 대상은 6월 30일까지', k: true },
      { d: md(y, 6, 30), t: '종합소득세 신고 (성실신고확인 대상)', k: true },
      { d: md(y, 7, 25), t: '부가가치세 1기 확정 신고·납부', n: '일반과세자 1~6월분', k: true },
      { d: md(y, 9, 15), t: '근로·자녀장려금 반기 신청 마감', n: `${y}년 상반기 근로소득분 · 9월 1~15일`, k: true },
      { d: md(y, 10, 25), t: '부가가치세 예정고지 납부', n: '일반과세자 · 7~9월분 고지서 금액', k: true },
      { d: md(y, 11, 30), t: '종합소득세 중간예납 납부', n: '고지서로 납부', k: true },
      ...each((m) => ({ d: md(y, m, 10), t: '원천세 신고·납부 (직원이 있으면)', n: `${m === 1 ? 12 : m - 1}월 지급분 · 반기 납부 승인이면 1월·7월에만`, k: true })),
      ...each((m) => ({ d: md(y, m, 10), t: '4대보험료 납부 (직원이 있으면)', n: '전월분', k: true })),
    ] },
  { id: 'job-safety', group: 'job', name: '안전보건 (전 업종)', color: '#DC2626', desc: '산업안전보건위원회, 중대재해 예방 점검, 작업환경측정, 건강진단',
    gen: (y) => [
      ...[3, 6, 9, 12].map((m) => ({ d: md(y, m, 20), t: `산업안전보건위원회 ${m / 3}분기 정기회의`, n: '상시근로자 100명 이상(일부 업종 50명 이상) · 분기마다 열고 회의록을 남겨요' })),
      { d: md(y, 6, 30), t: '안전보건관리체계 상반기 점검', n: '중대재해처벌법 · 반기 1회 이상 이행 점검과 경영책임자 보고' },
      { d: md(y, 12, 31), t: '안전보건관리체계 하반기 점검', n: '중대재해처벌법 · 반기 1회 이상 이행 점검과 경영책임자 보고' },
      { d: md(y, 6, 30), t: '작업환경측정 (상반기)', n: '소음·분진·화학물질 등을 다루는 사업장 · 반기 1회' },
      { d: md(y, 12, 31), t: '작업환경측정 (하반기)', n: '소음·분진·화학물질 등을 다루는 사업장 · 반기 1회' },
      { d: md(y, 10, 1), t: '근로자 일반건강진단 연내 완료 확인', n: '사무직 2년에 1회, 그 밖의 근로자 연 1회 · 연말에 몰리기 전에' },
      { d: md(y, 6, 1), t: '폭염 대비 온열질환 예방', n: '물·그늘·휴식, 작업 시간 조정' },
      { d: md(y, 11, 15), t: '한파 대비 안전관리', n: '난방 기구 화재·질식, 빙판 미끄럼' },
    ] },
  { id: 'job-it', group: 'job', name: 'IT·정보보호', color: '#2563EB', desc: '마이크로소프트 정기 보안 업데이트, 정보보호 공시, 정보보호의 날',
    gen: (y) => [
      ...each((m) => { const t = nth(y, m, 2, 2); return { d: addDays(t, 1), t: '마이크로소프트 정기 보안 업데이트', n: `미국 시간 ${Number(t.slice(5, 7))}월 둘째 화요일 발표 · 한국은 수요일 새벽 · Windows·Office 업데이트 확인` }; }),
      { d: md(y, 6, 30), t: '정보보호 공시 마감', n: y >= 2027 ? '2027년부터 모든 상장회사·ISMS 의무 대상 등으로 넓어져요 (중소기업은 2029년부터)' : '매출·이용자 수 기준 해당 기업', k: true },
      { d: nth(y, 7, 3, 2), t: '정보보호의 날', n: '7월 둘째 수요일' },
      { d: md(y, 12, 1), t: '연말 계정·권한 정리', n: '퇴사자 계정, 오래된 권한, 비밀번호 바꾸기 점검' },
    ] },
  { id: 'job-public', group: 'job', name: '공공·예산 일정', color: '#0F766E', desc: '국가 예산 편성·제출·의결, 정기국회, 결산, 공공기관 경영평가',
    gen: (y) => [
      { d: md(y, 3, 31), t: '다음 해 예산안 편성 지침 통보', n: '기획재정부 → 각 중앙관서 (국가재정법)' },
      { d: md(y, 5, 31), t: '예산요구서 제출 · 국가결산보고서 국회 제출', n: '각 중앙관서 → 기획재정부 / 정부 → 국회 (국가재정법)' },
      { d: md(y, 6, 20), t: '공공기관 경영실적 평가 결과 발표', n: '6월 20일까지 (공공기관운영법)' },
      { d: md(y, 9, 1), t: '정기국회 개회', n: '100일 회기 (국회법)', k: true },
      { d: md(y, 9, 2), t: '정부 예산안 국회 제출', n: '회계연도 시작 120일 전까지 (국가재정법)' },
      { d: md(y, 10, 1), t: '국정감사 시즌', n: '보통 10월 중 · 국회가 해마다 기간을 정해요' },
      { d: md(y, 12, 2), t: '다음 해 예산안 국회 의결 기한', n: '회계연도 시작 30일 전까지 (헌법)' },
    ] },

  // ---- 생활·관심사 ----
  { id: 'life-tax', group: 'life', name: '생활 세금·공과금', color: '#10B981', desc: '직장인·가정: 연말정산, 자동차세 연납, 재산세, 종합소득세, 연금 세액공제',
    gen: (y) => [
      { d: md(y, 1, 15), t: '연말정산 간소화 자료 공개', n: '홈택스·손택스에서 공제 자료를 내려받아 회사에 내요' },
      { d: md(y, 1, 16), to: md(y, 1, 31), t: '자동차세 연납 신청·납부', n: '1년치를 미리 내면 할인돼요 (3·6·9월에도 신청 가능, 할인은 줄어요)' },
      { d: md(y, 4, 10), t: '직장인 건강보험료 연말정산', n: '전년도 보수가 오른 만큼 4월 급여에서 더 떼거나 돌려받아요' },
      { d: md(y, 5, 31), t: '종합소득세 신고 (부업·프리랜서·임대 소득)', n: '근로소득만 있으면 보통 신고할 필요가 없어요', k: true },
      { d: md(y, 5, 31), t: '근로·자녀장려금 정기 신청 마감', n: '5월 1일부터 한 달 · 안내문을 받았다면 확인', k: true },
      { d: md(y, 6, 30), t: '자동차세 1기 납부', n: '6월 16~30일 (연납했다면 없음)', k: true },
      { d: md(y, 7, 31), t: '재산세 1기 납부 (주택 1/2·건축물)', n: '7월 16~31일', k: true },
      { d: md(y, 8, 31), t: '주민세(개인분) 납부', n: '8월 16~31일', k: true },
      { d: md(y, 9, 30), t: '재산세 2기 납부 (주택 1/2·토지)', n: '9월 16~30일', k: true },
      { d: md(y, 12, 15), t: '종합부동산세 납부', n: '12월 1~15일 · 해당되는 사람만', k: true },
      { d: md(y, 12, 31), t: '자동차세 2기 납부', n: '12월 16~31일 (연납했다면 없음)', k: true },
      { d: md(y, 12, 31), t: '연금저축·IRP 세액공제 납입 마감', n: '올해 연말정산에 넣으려면 오늘까지 납입' },
    ] },
  { id: 'life-fin', group: 'life', name: '금융·증시', color: '#6366F1', desc: '한국은행 기준금리 결정, 미국 FOMC, 옵션 만기일, 미국 고용지표',
    gen: (y) => {
      const out = [];
      const BOK = { 2026: ['07-16', '08-27', '10-22', '11-26'], 2027: ['01-14', '02-25', '04-09', '05-27', '07-15', '08-26', '10-15', '11-25'] };
      const FOMC = { 2026: ['01-28', '03-18', '04-29', '06-17', '07-29', '09-16', '10-28', '12-09'], 2027: ['01-27', '03-17', '04-28', '06-09', '07-28', '09-15', '10-27', '12-08'] };
      (BOK[y] || []).forEach((d) => out.push({ d: `${y}-${d}`, t: '한국은행 기준금리 결정', n: '금융통화위원회 통화정책방향 회의 · 오전 발표' }));
      (FOMC[y] || []).forEach((d) => out.push({ d: `${y}-${d}`, t: '미국 FOMC 금리 결정', n: '미국 시간 오후 2시 발표 · 한국은 다음 날 새벽 3~4시' }));
      if (!BOK[y] && !FOMC[y]) out.push({ d: md(y, 1, 2), t: '올해 금리 결정 일정은 발표 뒤 업데이트로 채워져요', n: '한국은행·미국 연준은 보통 전년도 가을에 다음 해 일정을 알려요' });
      for (let m = 1; m <= 12; m++) {
        const q = m % 3 === 0;
        out.push({ d: nth(y, m, 4, 2), t: q ? '선물·옵션 동시 만기일 (한국)' : '옵션 만기일 (한국)', n: '매월 둘째 목요일 · 휴장일이면 앞당겨져요', kb: true });
        out.push({ d: nth(y, m, 5, 3), t: q ? '미국 선물·옵션 동시 만기일 (네 마녀의 날)' : '미국 옵션 만기일', n: '매월 셋째 금요일 (미국 시간)' });
        const jobs = nth(y, m, 5, 1) === md(y, 1, 1) ? md(y, 1, 8) : nth(y, m, 5, 1);   // 새해 첫날이면 다음 주로
        out.push({ d: jobs, t: '미국 고용보고서 발표', n: '보통 매월 첫째 금요일 · 한국 시간 밤 9시 반~10시 반 · 사정에 따라 바뀔 수 있어요' });
      }
      out.push({ d: md(y, 12, 31), t: '한국 증시 연말 휴장', n: '한국거래소 · 새해 첫 거래일은 보통 1시간 늦게 열어요' });
      return out;
    } },
  { id: 'life-retail', group: 'life', name: '쇼핑·마케팅 대목', color: '#E11D48', desc: '명절 선물 시즌, 가정의 달, 블랙프라이데이, 광군제, 연말 시즌',
    gen: (y) => {
      const s = Lunar.seollal(y), c = Lunar.chuseok(y);
      const thanks = nth(y, 11, 4, 4);
      return [
        ...(s ? [{ d: addDays(s, -21), t: '설 선물 시즌 시작', n: '설 3주 전 무렵 · 선물 세트 예약 판매' }] : []),
        { d: md(y, 2, 14), t: '밸런타인데이' }, { d: md(y, 2, 15), t: '신학기 준비 시즌', n: '입학·개학 선물, 문구·전자기기' }, { d: md(y, 3, 14), t: '화이트데이' },
        { d: md(y, 4, 20), t: '가정의 달 준비', n: '어린이날·어버이날·스승의 날 기획전' },
        { d: md(y, 6, 25), t: '여름휴가 시즌 준비', n: '7~8월 여행·바캉스 기획' },
        ...(c ? [{ d: addDays(c, -21), t: '추석 선물 시즌 시작', n: '추석 3주 전 무렵' }] : []),
        { d: md(y, 10, 31), t: '핼러윈' },
        { d: md(y, 11, 11), t: '광군제·빼빼로데이', n: '중국 최대 쇼핑 행사와 같은 날' },
        { d: addDays(thanks, 1), t: '블랙프라이데이', n: '미국 추수감사절(11월 넷째 목요일) 다음 날 · 해외 직구' },
        { d: addDays(thanks, 4), t: '사이버먼데이' },
        { d: md(y, 12, 1), t: '연말 선물·송년회 시즌' }, { d: md(y, 12, 26), t: '연말 재고 정리·새해 맞이 세일' },
      ];
    } },
  { id: 'life-edu', group: 'life', name: '입시·학사', color: '#A855F7', desc: '수능, 성적 통지, 새 학기 시작',
    gen: (y) => {
      const SAT = { 2026: ['11-19', ''], 2027: ['11-18', '12-10'] };   // [수능, 성적 통지] — 교육부·평가원 발표
      const out = [{ d: md(y, 3, 2), t: '새 학기 시작 (초·중·고)', n: '보통 3월 2일 · 학교마다 다를 수 있어요', k: true }];
      const x = SAT[y];
      if (x) { out.push({ d: `${y}-${x[0]}`, t: `${y + 1}학년도 대학수학능력시험`, n: '교육부·한국교육과정평가원 발표' }); if (x[1]) out.push({ d: `${y}-${x[1]}`, t: '수능 성적 통지' }); }
      return out;
    } },
];

// 다른 나라 공휴일 (Google 공개 공휴일 캘린더 · 이름은 한국어로 받고, 안 되면 영어로)
const WORLD = [['us', '미국', 'usa'], ['jp', '일본', 'japanese'], ['cn', '중국', 'china'], ['vn', '베트남', 'vietnamese'], ['sa', '사우디아라비아', 'saudiarabian'],
  ['in', '인도', 'indian'], ['ph', '필리핀', 'philippines'], ['id', '인도네시아', 'indonesian'], ['ae', '아랍에미리트', 'ae'], ['gb', '영국', 'uk'], ['de', '독일', 'german'], ['au', '호주', 'australian']];
const gUrl = (lang, key) => `https://calendar.google.com/calendar/ical/${lang}.${key}%23holiday%40group.v.calendar.google.com/public/basic.ics`;
const worldSource = (code) => { const w = WORLD.find((x) => x[0] === code); return w && { type: 'ics', preset: 'world-' + code, name: `${w[1]} 공휴일`, color: '#64748B', url: gUrl('ko', w[2]), fallbackUrl: gUrl('en', w[2]) }; };

// 설정 화면에 보여 줄 목록
function catalog() {
  return {
    groups: [['day', '기념일·계절'], ['job', '업무 일정'], ['life', '생활·관심사'], ['world', '다른 나라 공휴일']],
    items: [
      { id: 'kr-holiday', group: 'day', name: '대한민국 공휴일', color: '#E5484D', desc: '공휴일·대체공휴일 · 날짜를 빨갛게 표시해요' },
      ...DEFS.map(({ id, group, name, color, desc }) => ({ id, group, name, color, desc })),
      ...WORLD.map(([code, name]) => ({ id: 'world-' + code, group: 'world', name, color: '#64748B', desc: '' })),
    ],
  };
}

// 고른 달력의 일정 만들기 → 다른 캘린더와 같은 모양의 하루 종일 일정
function expand(src, start, end, extraHolidays) {
  const def = DEFS.find((x) => x.id === src.preset);
  if (!def) return [];
  const extra = new Set(extraHolidays || []);
  const isOff = (s) => { const d = dow(s); return d === 0 || d === 6 || krHolidays(Number(s.slice(0, 4))).has(s) || extra.has(s) || s.slice(5) === '05-01'; };   // 5월 1일(노동절)도 국세 기한 연장 사유
  const from = ymd(start), to = ymd(end), out = [];
  for (let y = start.getFullYear(); y <= end.getFullYear(); y++) {
    let list = [];
    try { list = def.gen(y) || []; } catch { list = []; }
    const seen = new Map();
    for (const it of list) {
      let d = it.d, moved = false;
      if (it.k) { while (isOff(d)) { d = addDays(d, 1); moved = true; } }
      if (it.kb) { while (isOff(d)) { d = addDays(d, -1); moved = true; } }
      const last = it.to || d;
      if (last < from || d > to) continue;
      const key = `${it.d}|${it.t}`, n = (seen.get(key) || 0) + 1; seen.set(key, n);
      const notes = [it.n, moved ? (it.kb ? `원래는 ${Number(it.d.slice(5, 7))}월 ${Number(it.d.slice(8))}일인데 휴장일이라 앞당겨 표시했어요.` : `원래 기한은 ${Number(it.d.slice(5, 7))}월 ${Number(it.d.slice(8))}일인데, ` + SHIFT_NOTE) : '', def.group === 'job' || def.group === 'life' ? REF : ''].filter(Boolean).join('\n');
      const uid = `${def.id}:${key}${n > 1 ? ':' + n : ''}`;
      out.push({ id: `${src.id}|${uid}|${d}`, uid, sourceId: src.id, source: src.name, color: src.color, title: it.t, allDay: true, start: d, end: addDays(last, 1),
        location: '', notes, recurring: false, repeat: '', writable: false, preset: def.id });
    }
  }
  return out;
}

module.exports = { catalog, expand, worldSource, DEFS, WORLD, krHolidays, solarTerms };
