// 12지신 캐릭터 공용 규칙 (메인·화면 양쪽에서 사용)
// 순서: 쥐(子)부터 돼지(亥)까지
const LIST = [
  { id: 'rat', name: '쥐' }, { id: 'ox', name: '소' }, { id: 'tiger', name: '호랑이' },
  { id: 'rabbit', name: '토끼' }, { id: 'dragon', name: '용' }, { id: 'snake', name: '뱀' },
  { id: 'horse', name: '말' }, { id: 'goat', name: '양' }, { id: 'monkey', name: '원숭이' },
  { id: 'rooster', name: '닭' }, { id: 'dog', name: '개' }, { id: 'pig', name: '돼지' }
];
const PACK = 'characters/linaverse-12/';

// 십이시: 23~01시 쥐, 01~03시 소 … 21~23시 돼지
const hourIndex = (h) => Math.floor(((h + 1) % 24) / 2);
const ofHour = (h) => LIST[hourIndex(h)];
const hourRange = (h) => {
  const i = hourIndex(h), s = (i * 2 + 23) % 24, e = (s + 2) % 24;
  const p = (n) => String(n).padStart(2, '0');
  return `${p(s)}~${p(e)}시`;
};
// 띠: 양력 연도 기준 (1~2월생은 설 전이면 전년도 띠일 수 있음)
const ofYear = (y) => LIST[((((y - 4) % 12) + 12) % 12)];
const byId = (id) => LIST.find((c) => c.id === id) || null;
const img = (id) => PACK + id + '.png';
// 받침 유무에 따른 조사 (이/가, 은/는, 을/를, 과/와)
const josa = (word, a, b) => {
  const c = String(word).charCodeAt(String(word).length - 1);
  return word + ((c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28) ? a : b);
};

const DEFAULT_MAP = { work: 'ox', meet: 'horse', personal: 'pig', anniv: 'dragon', bday: 'rabbit' };

// ---- 시즌 컬렉션 그림 ----
// seasons/<계절>/<동물>.webp (여름은 -2 그림이 하나 더), banners/<newyear|seollal|chuseok>/<동물>.webp
const SEASON_ART = ['spring', 'summer', 'autumn', 'winter', 'halloween', 'christmas'];
// 그림 팩(seasons.pack.js)이 로드돼 있으면 그 안의 그림을, 아니면 폴더의 파일을 씀
const packed = () => (typeof window !== 'undefined' && window.LinaPack) || null;
function seasonImg(id, season, v) {
  if (!(season && SEASON_ART.includes(season))) return img(id);
  const key = id + (season === 'summer' && v === 2 ? '-2' : ''), P = packed();
  return (P && P.seasons[season] && P.seasons[season][key]) || PACK + 'seasons/' + season + '/' + key + '.webp';
}
function bannerImg(id, kind) {
  const P = packed();
  return (P && P.banners[kind] && P.banners[kind][id]) || PACK + 'banners/' + kind + '/' + id + '.webp';
}
const dayOfYear = (d) => Math.floor((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(d.getFullYear(), 0, 0)) / 864e5);
// 시즌 테마에서 오늘의 동물: 고정했으면 그 동물, 아니면 날마다 차례로
function dailyPet(date, fixed) {
  if (fixed && fixed !== 'daily' && byId(fixed)) return fixed;
  return LIST[dayOfYear(date || new Date()) % 12].id;
}
// 시즌 혼합: 12지신이 섞여서 랜덤으로 (한 시간마다 바뀌고, 자리마다 다른 동물)
function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function mixPet(date, slot, salt) {
  const d = date || new Date();
  return LIST[hash(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}|${slot || ''}|${salt || 0}`) % 12].id;
}
function petFor(date, mode, slot, salt) {
  if (mode && mode !== 'daily' && mode !== 'mix' && byId(mode)) return mode;
  if (mode === 'daily') return dailyPet(date);
  return mixPet(date, slot, salt);
}
// 테마·날짜·설정 → 지금 보여 줄 캐릭터 그림 {id, src, banner, corner}
// a: 꾸미기 설정, ch: 캐릭터 설정, force: 특정 동물(알림 배달부 등)
function lookFor(a, ch, date, force, opt) {
  opt = opt || {};
  const T = (typeof window !== 'undefined' && window.DeskThemes) || (typeof require === 'function' ? require('./themes.js') : null);
  if (!T) return null;
  const d = date || new Date(), key = T.seasonKey(d), t = T.actual(a && a.theme, d);
  ch = ch || {};
  let id = force || null, season = null;
  let corner = null;
  if (t && t.char) { id = id || t.char; season = t.outfit || null; }
  else if (t && t.season) {
    const mode = ch.seasonPet || 'mix';
    id = id || petFor(d, mode, 'buddy', opt.salt); season = T.outfitOf(t.season);
    if (mode === 'mix') { let c2 = petFor(d, mode, 'corner', opt.salt), k = 1; while (c2 === id && k < 12) c2 = petFor(d, mode, 'corner' + k++, opt.salt); corner = c2; }
  }
  else if (force) { if (ch.outfit !== false) season = T.outfitOf(key); }
  else return null;
  const v = dayOfYear(d) % 2 ? 2 : 1;
  // 명절(새해·설날·추석): 겨울·가을 옷 대신 그 명절 그림(동물이 들어 있는 인사 그림)을 그대로 씀
  const bk = (t && t.banner) || (ch.greeting !== false && (t && (t.char || t.season)) ? T.bannerOf(key) : null);
  if (bk) {
    const other = corner || id;
    return { id, src: bannerImg(id, bk), season, v, holiday: bk, banner: null,
      corner: { id: other, src: (t && t.banner) ? bannerImg(other, bk) : seasonImg(other, season, v) } };
  }
  return { id, src: seasonImg(id, season, v), season, v, banner: null,
    corner: corner ? { id: corner, src: seasonImg(corner, season, v === 2 ? 1 : 2) } : null };
}

const api = { LIST, PACK, hourIndex, ofHour, hourRange, ofYear, byId, img, josa, DEFAULT_MAP, SEASON_ART, seasonImg, bannerImg, dailyPet, mixPet, petFor, lookFor };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.Chars = api;
