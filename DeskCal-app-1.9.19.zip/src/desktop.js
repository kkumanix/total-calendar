// Windows 바탕화면 레이어(아이콘 뒤)에 창을 붙이는 기능
// Lively Wallpaper 등과 같은 방식: Progman에 0x052C 메시지 → WorkerW 생성 → 그 안에 창을 넣음
let api = null;

function load() {
  if (api !== null) return api;
  if (process.platform !== 'win32') { api = false; return api; }
  try {
    const koffi = require('koffi');
    const u = koffi.load('user32.dll');
    const EnumProc = koffi.proto('bool __stdcall DeskCalEnumProc(intptr_t hwnd, intptr_t lParam)');
    const POINT = koffi.struct('DeskCalPOINT', { x: 'int32_t', y: 'int32_t' });
    api = {
      koffi,
      EnumProc,
      FindWindowW: u.func('intptr_t __stdcall FindWindowW(const char16_t *cls, const char16_t *name)'),
      FindWindowExW: u.func('intptr_t __stdcall FindWindowExW(intptr_t parent, intptr_t after, const char16_t *cls, const char16_t *name)'),
      SendMessageTimeoutW: u.func('intptr_t __stdcall SendMessageTimeoutW(intptr_t hwnd, uint32_t msg, uintptr_t w, intptr_t l, uint32_t flags, uint32_t timeout, _Out_ uintptr_t *res)'),
      EnumWindows: u.func('bool __stdcall EnumWindows(DeskCalEnumProc *cb, intptr_t lParam)'),
      SetParent: u.func('intptr_t __stdcall SetParent(intptr_t child, intptr_t parent)'),
      SetWindowPos: u.func('bool __stdcall SetWindowPos(intptr_t hwnd, intptr_t after, int x, int y, int cx, int cy, uint32_t flags)'),
      GetAsyncKeyState: u.func('int16_t __stdcall GetAsyncKeyState(int vKey)'),
      GetCursorPos: u.func('bool __stdcall GetCursorPos(_Out_ DeskCalPOINT *p)'),
      WindowFromPoint: u.func('intptr_t __stdcall WindowFromPoint(DeskCalPOINT p)'),
      GetParent: u.func('intptr_t __stdcall GetParent(intptr_t hwnd)'),
      GetClassNameW: u.func('int __stdcall GetClassNameW(intptr_t hwnd, void *buf, int max)'),
      GetSystemMetrics: u.func('int __stdcall GetSystemMetrics(int index)')
    };
  } catch (e) {
    console.error('바탕화면 고정 기능을 불러오지 못했습니다:', e);
    api = false;
  }
  return api;
}

const SWP_NOSIZE = 0x1, SWP_NOMOVE = 0x2, SWP_NOZORDER = 0x4, SWP_NOACTIVATE = 0x10, SWP_SHOWWINDOW = 0x40;
const HWND_BOTTOM = 1;

const hwndOf = (win) => Number(win.getNativeWindowHandle().readBigUInt64LE(0));

function findDesktopLayer() {
  const a = load();
  if (!a) return 0;
  const progman = a.FindWindowW('Progman', null);
  if (!progman) return 0;
  const res = [0];
  a.SendMessageTimeoutW(progman, 0x052C, 0xD, 0x1, 0, 1000, res);
  a.SendMessageTimeoutW(progman, 0x052C, 0, 0, 0, 1000, res);

  // Windows 11 24H2 이후: WorkerW가 Progman의 자식으로 생김
  let worker = a.FindWindowExW(progman, 0, 'WorkerW', null);
  if (worker) return worker;

  // 이전 버전: 아이콘(SHELLDLL_DefView)을 가진 창 바로 다음의 WorkerW
  const cb = a.koffi.register((hwnd) => {
    const defView = a.FindWindowExW(hwnd, 0, 'SHELLDLL_DefView', null);
    if (defView) worker = a.FindWindowExW(0, hwnd, 'WorkerW', null);
    return true;
  }, a.koffi.pointer(a.EnumProc));
  try { a.EnumWindows(cb, 0); } finally { a.koffi.unregister(cb); }
  return worker || progman;
}

// rect: 물리 픽셀, 가상 화면(모든 모니터) 왼쪽 위 기준
function pinToDesktop(win, rect) {
  const a = load();
  if (!a) return false;
  const layer = findDesktopLayer();
  if (!layer) return false;
  const h = hwndOf(win);
  a.SetParent(h, layer);
  a.SetWindowPos(h, 0, rect.x, rect.y, rect.width, rect.height, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
  return true;
}

function unpin(win) {
  const a = load();
  if (!a) return;
  a.SetParent(hwndOf(win), 0);
}

function sendToBottom(win) {
  const a = load();
  if (!a || win.isDestroyed()) return;
  a.SetWindowPos(hwndOf(win), HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

// ---------------------------------------------------------------- 바탕화면 클릭 감지
// 캘린더가 아이콘 뒤에 있으면 클릭이 바탕화면(아이콘 목록 창)으로 갑니다.
// 마우스 버튼 상태를 짧게 살펴서 '아이콘이 없는 빈 곳'을 클릭했을 때만 알려 줍니다.
function className(a, hwnd) {
  const buf = Buffer.alloc(512);
  const n = a.GetClassNameW(hwnd, buf, 256);
  return n > 0 ? buf.toString('utf16le', 0, n * 2) : '';
}
function isDesktopList(a, hwnd) {
  if (!hwnd || className(a, hwnd) !== 'SysListView32') return false;
  const parent = a.GetParent(hwnd);
  return !!parent && className(a, parent) === 'SHELLDLL_DefView';
}
const LVM_GETSELECTEDCOUNT = 0x1032;
const SMTO_ABORTIFHUNG = 0x2;

function watchDesktopClicks(onClick) {
  const a = load();
  if (!a) return () => {};
  // 왼쪽·오른쪽 버튼이 바뀌어 있으면(왼손잡이 설정) 오른쪽 버튼이 주 버튼
  const VK = a.GetSystemMetrics(23) ? 0x02 : 0x01; // SM_SWAPBUTTON
  let down = null;
  const timer = setInterval(() => {
    let pressed = false;
    try { pressed = (a.GetAsyncKeyState(VK) & 0x8000) !== 0; } catch { return; }
    if (pressed && !down) {
      const p = {}; a.GetCursorPos(p);
      const h = a.WindowFromPoint({ x: p.x, y: p.y });
      down = { x: p.x, y: p.y, lv: isDesktopList(a, h) ? h : 0 };
    } else if (!pressed && down) {
      const d = down; down = null;
      if (!d.lv) return;
      const p = {}; a.GetCursorPos(p);
      if (Math.abs(p.x - d.x) > 6 || Math.abs(p.y - d.y) > 6) return; // 끌기(범위 선택)는 무시
      // 빈 곳을 누르면 아이콘 선택이 모두 풀림 → 선택된 아이콘이 0개면 빈 곳 클릭
      setTimeout(() => {
        const res = [0];
        try { a.SendMessageTimeoutW(d.lv, LVM_GETSELECTEDCOUNT, 0, 0, SMTO_ABORTIFHUNG, 200, res); } catch { return; }
        if (Number(res[0]) === 0) onClick({ x: p.x, y: p.y });
      }, 40);
    }
  }, 25);
  return () => clearInterval(timer);
}

module.exports = { available: () => !!load(), pinToDesktop, unpin, sendToBottom, watchDesktopClicks };
