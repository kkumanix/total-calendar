// DeskCal — 바탕화면 캘린더 (메인 프로세스 본체 · main.js가 최신 버전 폴더를 골라 이 파일을 실행)
const { app, BrowserWindow, ipcMain, Tray, Menu, globalShortcut, screen, nativeImage, shell, powerMonitor, dialog, Notification } = require('electron');
const path = require('path');
const VERSION = require('./package.json').version; // 실제로 실행 중인 버전 (업데이트 폴더 기준)

if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.setAppUserModelId('com.deskcal.app');

const store = require('./src/store');
const sync = require('./src/sync');
const Alarms = require('./src/alarms.js');
const Telemetry = require('./src/telemetry.js');
const AI = require('./src/ai');
const Updater = require('./src/updater');
const desktop = require('./src/desktop');
const reminders = require('./src/reminders');
const cloud = require('./src/cloud');
const Chars = require('./renderer/chars.js');
const TZ = require('./renderer/tz.js');
const Themes = require('./renderer/themes.js');

const ASSET = (n) => path.join(__dirname, 'assets', n);
const PAGE = (n) => path.join(__dirname, 'renderer', n);
const PRELOAD = path.join(__dirname, 'preload.js');

let settings;
let calWin = null, editorWin = null, settingsWin = null, popupWin = null, tray = null;
let editing = false;      // 배경 모드에서 잠시 앞으로 꺼낸 상태
let autoEdit = false;     // 바탕화면을 클릭해서 꺼낸 상태 (다른 곳을 누르면 자동으로 돌아감)
let lastSyncAt = 0;
let pinned = false;
let cache = { events: [], errors: [], updated: null, syncing: false };
let popupQueue = [];
let syncTimer = null;

const ctx = {
  decrypt: store.decrypt,
  getLocal: store.getLocalEvents,
  saveLocal: store.saveLocalEvents
};

// ---------------------------------------------------------------- 꾸미기(테마·글꼴)
let appearancePreview = null;
const appearance = () => appearancePreview || settings.appearance;
function broadcastAppearance() {
  setTimeout(refreshStickies, 50);
  const a = appearance();
  BrowserWindow.getAllWindows().forEach((w) => { if (!w.isDestroyed()) w.webContents.send('appearance', a); });
  pushState();
}
const bgFor = () => { try { return Themes.resolve(appearance()).vars['--bg-solid']; } catch { return '#141414'; } };

// ---------------------------------------------------------------- 화면 위치
function targetDisplay() {
  const all = screen.getAllDisplays();
  return all.find((d) => d.id === settings.displayId) || screen.getPrimaryDisplay();
}

function physicalRect(bounds) {
  // 가상 화면(모든 모니터) 왼쪽 위 기준의 물리 픽셀 좌표
  const toPx = (r) => (process.platform === 'win32' ? screen.dipToScreenRect(null, r) : r);
  const all = screen.getAllDisplays().map((d) => toPx(d.bounds));
  const minX = Math.min(...all.map((r) => r.x));
  const minY = Math.min(...all.map((r) => r.y));
  const r = toPx(bounds);
  return { x: r.x - minX, y: r.y - minY, width: r.width, height: r.height };
}
const physicalRectFor = (display) => physicalRect(display.bounds);
// 위젯을 '아이콘 아래 층'에 둘지
const widgetUnder = () => settings.mode === 'widget' && !!settings.widget.underIcons;

// ---------------------------------------------------------------- 캘린더 창
function createCalendarWindow() {
  if (calWin && !calWin.isDestroyed()) { calWin.removeAllListeners('closed'); calWin.destroy(); }
  editing = false; pinned = false;
  const d = targetDisplay();
  const isWidget = settings.mode === 'widget';
  const w = settings.widget;
  // 처음 실행(위치 없음)이면 화면보다 크지 않게 줄여서 주 모니터 오른쪽 위에 둠
  const fitW = w.x == null ? Math.min(w.width, d.workArea.width - 48) : w.width;
  const fitH = w.y == null ? Math.min(w.height, d.workArea.height - 48) : w.height;
  const bounds = isWidget
    ? { x: w.x ?? d.workArea.x + d.workArea.width - fitW - 24, y: w.y ?? d.workArea.y + 24, width: fitW, height: fitH }
    : d.bounds;

  calWin = new BrowserWindow({
    ...bounds,
    frame: false,
    show: false,
    skipTaskbar: true,
    resizable: isWidget && !w.locked,
    movable: !isWidget || !w.locked,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    transparent: isWidget && !w.underIcons,   // 아이콘 아래 층에서는 투명 창이 깨질 수 있어 불투명으로
    backgroundColor: isWidget && !w.underIcons ? '#00000000' : bgFor(),
    hasShadow: false,
    title: 'Total Calendar',
    webPreferences: { preload: PRELOAD, backgroundThrottling: false }
  });
  calWin.loadFile(PAGE('calendar.html'));
  calWin.once('ready-to-show', () => {
    applyOpacity();
    if (isWidget && w.underIcons) {
      calWin.showInactive();
      attachWidgetToDesktop();
    } else if (isWidget) {
      calWin.showInactive();
      desktop.sendToBottom(calWin);
    } else {
      calWin.showInactive();
      attachToDesktop();
    }
    pushState();
  });

  // 위젯·고정 실패 시: 다른 창 뒤로 물러나 있기
  calWin.on('blur', () => {
    if (editing) { maybeReturn(); return; }
    if (!pinned) setTimeout(() => calWin && !calWin.isDestroyed() && desktop.sendToBottom(calWin), 50);
  });
  if (isWidget) {
    let t = null;
    const save = () => {
      clearTimeout(t);
      t = setTimeout(() => {
        if (!calWin || calWin.isDestroyed() || settings.minimal || pinned) return;
        const b = calWin.getBounds();
        settings.widget = { ...settings.widget, x: b.x, y: b.y, width: b.width, height: b.height };
        store.saveSettings(settings);
      }, 400);
    };
    calWin.on('moved', save);
    calWin.on('resized', save);
  }
  calWin.on('closed', () => { calWin = null; });
}

function attachToDesktop() {
  if (!calWin || calWin.isDestroyed() || settings.mode !== 'wallpaper') return;
  const d = targetDisplay();
  pinned = desktop.pinToDesktop(calWin, physicalRectFor(d));
  if (!pinned) {
    calWin.setBounds(d.bounds);
    desktop.sendToBottom(calWin);
  }
}

// 위젯을 바탕화면 층(아이콘 뒤)에 붙임 — 아이콘이 위젯 위에 보임
function attachWidgetToDesktop() {
  if (!calWin || calWin.isDestroyed() || !widgetUnder()) return;
  pinned = desktop.pinToDesktop(calWin, physicalRect(calWin.getBounds()));
  if (!pinned) desktop.sendToBottom(calWin); // 실패하면 일반 위젯처럼 맨 뒤로
}

function setEditing(on, opts = {}) {
  if (!calWin || calWin.isDestroyed()) return;
  if (on && editing) { calWin.show(); calWin.focus(); return; }
  if (!on && !editing && settings.mode !== 'widget') return;
  if (widgetUnder()) {
    // 아이콘 아래 위젯: 잠시 앞으로 꺼내 옮기기·수정, 끝나면 다시 아이콘 아래로
    editing = on;
    const w = settings.widget;
    if (on) {
      autoEdit = !!opts.auto;
      if (pinned) desktop.unpin(calWin);
      pinned = false;
      if (w.x != null && !settings.minimal) calWin.setBounds({ x: w.x, y: w.y, width: w.width, height: w.height });
      calWin.setMovable(!w.locked); calWin.setResizable(!w.locked);
      calWin.setAlwaysOnTop(true, 'floating');
      calWin.show(); calWin.focus();
    } else {
      autoEdit = false;
      const b = calWin.getBounds();
      if (!settings.minimal) settings.widget = { ...settings.widget, x: b.x, y: b.y, width: b.width, height: b.height };
      store.saveSettings(settings);
      calWin.setAlwaysOnTop(false);
      attachWidgetToDesktop();
    }
    pushState();
    return;
  }
  if (settings.mode === 'widget') {
    // 일반 위젯은 늘 클릭 가능: 앞으로 가져오기만
    if (on) { calWin.show(); calWin.focus(); } else desktop.sendToBottom(calWin);
    editing = false; autoEdit = false;
    return;
  }
  editing = on;
  if (on) {
    autoEdit = !!opts.auto;
    if (pinned) desktop.unpin(calWin);
    pinned = false;
    calWin.setBounds(targetDisplay().workArea);
    calWin.setAlwaysOnTop(true, 'floating');
    calWin.show();
    calWin.focus();
  } else {
    autoEdit = false;
    calWin.setAlwaysOnTop(false);
    attachToDesktop();
  }
  pushState();
}

// ---------------------------------------------------------------- 새 버전 업데이트
let lastAvail = false;
function onUpdateState(s) {
  BrowserWindow.getAllWindows().forEach((w) => { if (!w.isDestroyed()) w.webContents.send('update:state', s); });
  if (s.available !== lastAvail) { lastAvail = s.available; buildTray(); pushState(); }
}
ipcMain.handle('update:state', () => Updater.getState());

// ---------------------------------------------------------------- 계정 · 동기화 (PC ↔ 휴대폰)
function onCloudState(s) {
  BrowserWindow.getAllWindows().forEach((w) => { if (!w.isDestroyed()) w.webContents.send('account:state', s); });
}
// 다른 기기에서 바뀐 내용을 받았을 때 화면에 반영
function onRemoteChange(ch) {
  if ((ch.settings && typeof ch.settings === 'object') || Array.isArray(ch.sources)) {
    let next = { ...settings };
    if (ch.settings && typeof ch.settings === 'object') {
      next = { ...next, ...ch.settings };
      if (ch.settings.appearance) next.appearance = { ...settings.appearance, ...ch.settings.appearance, wallpaperAlign: settings.appearance.wallpaperAlign, wallpaperWidth: settings.appearance.wallpaperWidth };
    }
    if (Array.isArray(ch.sources)) {
      // 다른 기기의 캘린더 연결 목록 반영: 이 기기 '내 PC/휴대폰' 캘린더와, 이미 넣어 둔 비밀번호는 그대로
      const mine = settings.sources.filter((x) => x.type === 'local');
      next.sources = [...mine, ...ch.sources.map((x) => { const old = settings.sources.find((o) => o.id === x.id); return { ...x, password: old ? old.password : '' }; })];
    }
    store.quiet(() => applySettings(next));
  }
  if (ch.events || ch.remind || ch.cats || ch.birth) runSync(true);
  if (ch.notes || ch.stickers) pushState();
  if (ch.stickies) { try { refreshStickies(); openAllStickies(); } catch {} }
}
ipcMain.handle('account:get', () => cloud.getState());
ipcMain.handle('account:signin', (_e, { email, pw, create }) => cloud.signIn(email, pw, create));
ipcMain.handle('account:reset', (_e, email) => cloud.resetPassword(email));
ipcMain.handle('account:signout', () => { cloud.signOut(); buildTray(); return cloud.getState(); });
ipcMain.handle('account:sync', () => cloud.sync());

// ---------------------------------------------------------------- 문제 신고 · 의견 보내기
// 메일 프로그램을 열어 받는 사람·제목·기본 정보를 채워 줌 (비밀번호·일정 내용·메일 주소는 넣지 않음)
const SUPPORT_EMAIL = 'flskalsn@gmail.com';
function diagInfo() {
  const os = require('os');
  const d = screen.getPrimaryDisplay();
  const kinds = (settings.sources || []).filter((s) => s.enabled !== false)
    .map((s) => (s.type === 'google' ? 'Google' : s.type === 'outlook' || s.type === 'msgraph' ? 'Outlook' : s.type === 'caldav' ? (/naver/i.test(String(s.url || '') + s.name) ? 'Naver' : 'CalDAV') : s.type === 'ics' ? 'iCal' : s.type === 'local' ? '내 PC' : s.type));
  return [
    `앱 버전: ${VERSION}`,
    `Windows: ${os.release()} (${process.arch})`,
    `Electron: ${process.versions.electron}`,
    `화면: ${d.size.width}x${d.size.height} @${d.scaleFactor}x`,
    `모드: ${settings.mode}${settings.minimal ? ' · 미니' : ''}`,
    `테마: ${(settings.appearance && settings.appearance.theme) || settings.theme || '-'}`,
    `연결된 캘린더: ${kinds.length ? [...new Set(kinds)].join(', ') : '없음'}`,
    `AI: ${(() => { try { const st = AI.status(aiSettings()); return st && st.modelSize ? `모델 있음 (${st.model})` : '모델 없음'; } catch { return '-'; } })()}`
  ].join('\n');
}
function sendReport(kind) {
  const subject = `[Total Calendar] ${kind === 'idea' ? '의견' : '문제 신고'} (v${VERSION})`;
  const body = (kind === 'idea'
    ? '■ 이런 기능이 있으면 좋겠어요:\n\n\n■ 이유나 쓰는 상황:\n\n\n'
    : '■ 어떤 문제가 있었나요?\n\n\n■ 어떻게 하면 다시 생기나요? (순서대로)\n1.\n2.\n\n■ 화면 캡처가 있으면 붙여 주세요.\n\n\n')
    + '---- 아래는 자동으로 채워진 정보예요 (지워도 돼요) ----\n' + diagInfo();
  const url = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  return shell.openExternal(url).then(() => true).catch(() => false);
}
ipcMain.handle('app:report', (_e, kind) => sendReport(kind));
const HOMEPAGE = 'https://kkumanix.github.io/total-calendar/';
ipcMain.handle('app:homepage', () => shell.openExternal(HOMEPAGE).then(() => true).catch(() => false));
ipcMain.handle('app:diag', () => { const text = diagInfo(); try { require('electron').clipboard.writeText(`받는 사람: ${SUPPORT_EMAIL}\n\n${text}`); } catch {} return { email: SUPPORT_EMAIL, text }; });
ipcMain.handle('update:check', () => Updater.check());
// 바탕화면 클릭 등으로 바뀐 설정은 바로 저장돼 있음 · 종료할 때도 한 번 더 저장
app.on('before-quit', () => { try { if (settings) store.saveSettings(settings); } catch {} });
ipcMain.handle('update:prepare', async () => {
  if (!app.isPackaged && !process.env.DESKCAL_UPDATE_TEST) throw new Error('개발 실행에서는 업데이트를 적용할 수 없어요');
  return Updater.prepare();
});
ipcMain.handle('update:apply', () => { if (app.isPackaged && Updater.getState().phase === 'ready') Updater.applyAndRestart(app); });
async function updateFromTray() {
  openSettings();
  setTimeout(() => { if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:goto', 'update'); }, 700);
}

// ---------------------------------------------------------------- Outlook·Google 캘린더로도 보내기 (계정 연결 없이)
// Outlook: .ics 파일을 열면 Outlook 일정 창이 뜸 → 저장 / Google: 내용이 채워진 웹 화면이 열림 → 저장
const GREP = { daily: 'DAILY', weekly: 'WEEKLY', monthly: 'MONTHLY', yearly: 'YEARLY' };
const utcZ = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
function remMinutes(r) { const m = { minute: 1, hour: 60, day: 1440, week: 10080, month: 43200 }[r.unit] || 0; return (Number(r.n) || 0) * m; }
function exportEvents(inputs, targets) {
  const fs = require('fs');
  const safe = (t) => String(t || '일정').replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 40) || '일정';
  let k = 0;
  for (const input of inputs || []) {
    const ev = { ...sync.normalizeInput(input), uid: `${require('crypto').randomUUID()}@deskcal` };
    const rems = Array.isArray(input.reminders) ? input.reminders.map(remMinutes).filter((m) => m > 0).sort((a, b) => a - b) : null;
    if (targets.outlook) {
      let ics = sync.buildIcs(ev);
      if (rems && rems.length) ics = ics.replace('END:VEVENT', `BEGIN:VALARM\r\nACTION:DISPLAY\r\nDESCRIPTION:${ev.title}\r\nTRIGGER:-PT${rems[0]}M\r\nEND:VALARM\r\nEND:VEVENT`);
      const file = path.join(app.getPath('temp'), `DeskCal_${Date.now()}_${k}_${safe(ev.title)}.ics`);
      fs.writeFileSync(file, ics, 'utf8');
      setTimeout(() => shell.openPath(file), k * 900);
    }
    if (targets.google) {
      const dates = ev.allDay ? `${ev.start.replace(/-/g, '')}/${ev.end.replace(/-/g, '')}` : `${utcZ(new Date(ev.start))}/${utcZ(new Date(ev.end))}`;
      const q = new URLSearchParams({ action: 'TEMPLATE', text: ev.title, dates });
      if (ev.location) q.set('location', ev.location);
      if (ev.notes) q.set('details', ev.notes);
      if (ev.repeat && GREP[ev.repeat] && !ev.lunar) q.set('recur', `RRULE:FREQ=${GREP[ev.repeat]}`);
      setTimeout(() => shell.openExternal('https://calendar.google.com/calendar/render?' + q.toString()), k * 900 + (targets.outlook ? 400 : 0));
    }
    k++;
  }
  return k;
}
// 네이버: 연결된 네이버 캘린더(CalDAV)에 바로 저장
const naverSource = () => (settings.sources || []).find((s) => s.type === 'caldav' && /naver/i.test(String(s.url || '') + s.name) && !s.holiday);
async function sendToNaver(inputs, mainSourceId) {
  const src = naverSource(); if (!src || src.id === mainSourceId) return 0;
  let n = 0;
  for (const input of inputs || []) {
    const { lunar, ...rest } = input; // 음력 반복은 내 PC 전용
    const uid = await sync.createEvent(src, { ...rest, categoryName: catName(input.categoryChoice || 'auto') }, ctx);
    if (Array.isArray(input.reminders)) setRemind(uid, input.reminders);
    n++;
  }
  if (n) runSync();
  return n;
}
ipcMain.handle('export:send', async (_e, { inputs, targets, sourceId }) => {
  targets = targets || {};
  settings.exportTargets = { outlook: !!targets.outlook, google: !!targets.google, naver: !!targets.naver }; store.saveSettings(settings);
  let n = 0;
  if (targets.outlook || targets.google) n += exportEvents(inputs, targets);
  if (targets.naver) n += await sendToNaver(inputs, sourceId);
  return n;
});
ipcMain.handle('source:test', async (_e, s) => {
  try {
    const old = (settings.sources || []).find((o) => o.id === s.id) || {};
    const pw = s.password || (old.password ? store.decrypt(old.password) : '');
    if (!s.username || !pw) return { ok: false, error: '아이디와 애플리케이션 비밀번호를 넣어 주세요' };
    const names = await sync.testSource({ ...old, ...s }, pw);
    return { ok: true, calendars: names };
  } catch (e) {
    const m = String(e && e.message || e);
    return { ok: false, error: /fetch failed|ENOTFOUND|ECONN|ETIMEDOUT|ERR_/i.test(m) ? `서버에 연결하지 못했어요 (인터넷 연결이나 회사 방화벽 확인) · 자세히: ${m.slice(0, 300)}` : m };
  }
});
ipcMain.handle('export:get', () => ({ outlook: false, google: false, naver: false, ...(settings.exportTargets || {}), naverReady: !!naverSource(), naverId: (naverSource() || {}).id || '' }));

// ---------------------------------------------------------------- AI 비서 (내 PC 안에서만 동작)
let aiWin = null;
function openAI(text) {
  if (aiWin && !aiWin.isDestroyed()) { aiWin.show(); aiWin.focus(); if (text) aiWin.webContents.send('ai:text', text); return; }
  const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const W = 620, H = 820;
  aiWin = new BrowserWindow({
    width: W, height: H, minWidth: 520, minHeight: 600, x: Math.round(d.workArea.x + (d.workArea.width - W) / 2), y: Math.round(d.workArea.y + (d.workArea.height - H) / 2),
    frame: false, resizable: true, alwaysOnTop: true, skipTaskbar: false, show: false, backgroundColor: bgFor(), title: 'AI로 일정 등록',
    webPreferences: { preload: PRELOAD }
  });
  aiWin.__text = text || '';
  aiWin.loadFile(PAGE('ai.html'));
  aiWin.once('ready-to-show', () => { aiWin.show(); aiWin.focus(); });
  aiWin.on('closed', () => { aiWin = null; if (autoEdit && calWin && !calWin.isDestroyed() && !calWin.isFocused()) maybeReturn(); });
}
const aiSettings = () => settings.ai || {};
const aiSend = (s) => { if (aiWin && !aiWin.isDestroyed()) aiWin.webContents.send('ai:progress', s); };
ipcMain.handle('ai:open', (_e, text) => openAI(text));
ipcMain.handle('ai:init', (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  return { text: (win && win.__text) || '', sources: publicSources(), categories: settings.categories || [], lastWriteSource: settings.lastWriteSource, status: AI.status(aiSettings()) };
});
ipcMain.handle('ai:status', () => AI.status(aiSettings()));
ipcMain.handle('ai:setModel', (_e, id) => { settings.ai = { ...aiSettings(), model: id, modelPath: '' }; store.saveSettings(settings); AI.unload(); return AI.status(aiSettings()); });
ipcMain.handle('ai:download', async () => { await AI.download(aiSettings().model || 'qwen3-4b'); return AI.status(aiSettings()); });
ipcMain.handle('ai:cancel', () => AI.cancelDownload());
ipcMain.handle('ai:delete', () => { AI.deleteModels(); settings.ai = { ...aiSettings(), modelPath: '' }; store.saveSettings(settings); return AI.status(aiSettings()); });
ipcMain.handle('ai:pickFile', async (e) => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'AI 모델 파일 (.gguf) 고르기', filters: [{ name: 'GGUF 모델', extensions: ['gguf'] }], properties: ['openFile'] });
  if (r.canceled || !r.filePaths[0]) return AI.status(aiSettings());
  settings.ai = { ...aiSettings(), modelPath: r.filePaths[0] }; store.saveSettings(settings); AI.unload();
  return AI.status(aiSettings());
});
ipcMain.handle('ai:analyze', (_e, text) => AI.analyze(text, aiSettings()));
ipcMain.handle('ai:saveMany', async (_e, { sourceId, items }) => {
  const target = findSource(sourceId);
  if (!target) throw new Error('캘린더를 선택해 주세요');
  let n = 0;
  for (const input of items || []) {
    const choice = input.categoryChoice || 'auto';
    const uid = await sync.createEvent(target, { ...input, categoryName: catName(choice) }, ctx);
    setCategory(uid, choice);
    if (Array.isArray(input.reminders)) setRemind(uid, input.reminders); // 일정별 알림 (없으면 기본 알림)
    n++;
  }
  settings.lastWriteSource = sourceId; store.saveSettings(settings);
  await runSync();
  return n;
});

// ---------------------------------------------------------------- 투명도 (달력 맨 아래 막대)
// 투명 위젯: 배경만 흐리게(글자는 또렷) · 아이콘 아래·바탕화면 모드: 창 전체 투명도
const curOpacity = () => Math.min(1, Math.max(0.2, settings.opacity ?? (settings.mode === 'widget' ? (settings.widget.opacity ?? 1) : 1)));
const opacityByCss = () => settings.mode === 'widget' && !settings.widget.underIcons;
function applyOpacity() {
  if (!calWin || calWin.isDestroyed()) return;
  try { calWin.setOpacity(opacityByCss() ? 1 : curOpacity()); } catch {}
}
ipcMain.handle('opacity:set', (_e, v, done) => {
  settings.opacity = Math.min(1, Math.max(0.2, Number(v) || 1));
  applyOpacity();
  if (done) { store.saveSettings(settings); pushState(); }
});

// ---------------------------------------------------------------- 바탕화면 메모지
// 달력과 따로, 원하는 곳에 붙여 두는 메모지. 맨 뒤(다른 창 아래)에 머물고 바로 클릭해서 씀
const stickyWins = new Map();
const STICKY_COLORS = [['yellow', '노랑'], ['pink', '분홍'], ['mint', '민트'], ['sky', '하늘'], ['lavender', '라벤더'], ['peach', '복숭아'], ['white', '흰색'], ['ink', '먹색']];
const STICKY_MODES = [['basic', '기본 메모장'], ['lined', '줄노트'], ['check', '체크리스트 (할 일)'], ['char', '✦ 캐릭터 메모장 (무료 체험 중!)']];
function stickyById(id) { return store.getStickies().find((n) => n.id === id); }
function updateSticky(id, patch) {
  const list = store.getStickies();
  const n = list.find((x) => x.id === id);
  if (!n) return null;
  Object.assign(n, patch, { updated: Date.now() });
  store.saveStickies(list);
  return n;
}
function stickyPayload(n) { return { note: n, appearance: appearance(), characters: settings.characters }; }
// 메모장도 달력처럼 바탕화면 아이콘 아래에 박아 둠 → 누르면 잠깐 앞으로 꺼내서 쓰고, 다른 곳 누르면 다시 박힘
const stickyPinMode = () => process.platform === 'win32' && desktop.available() && settings.stickyPin !== false;
function stickyRect(id) { const n = stickyById(id); return n ? { x: n.x, y: n.y, width: n.w || 280, height: n.h || 260 } : null; }
function pinSticky(win) {
  if (!win || win.isDestroyed()) return;
  win.__editing = false;
  win.webContents.send('sticky:edit', false);
  if (!stickyPinMode()) { win.showInactive(); desktop.sendToBottom(win); return; }
  const r = stickyRect(win.__sticky); if (!r) return;
  win.setAlwaysOnTop(false);
  win.__pinned = desktop.pinToDesktop(win, physicalRect(r));
  if (!win.__pinned) { win.showInactive(); desktop.sendToBottom(win); }
}
function editSticky(win, focus = true) {
  if (!win || win.isDestroyed()) return;
  if (win.__pinned) { desktop.unpin(win); win.__pinned = false; const r = stickyRect(win.__sticky); if (r) win.setBounds(r); }
  win.__editing = true;
  win.setAlwaysOnTop(true, 'floating');
  win.show(); if (focus) win.focus();
  win.webContents.send('sticky:edit', true);
}
function stickyAt(dip) {
  for (const [id, w] of stickyWins) {
    if (w.isDestroyed() || w.__editing) continue;
    const r = stickyRect(id);
    if (r && dip.x >= r.x && dip.y >= r.y && dip.x < r.x + r.width && dip.y < r.y + r.height) return w;
  }
  return null;
}
function openSticky(n, edit) {
  if (stickyWins.has(n.id)) { const w = stickyWins.get(n.id); if (!w.isDestroyed()) { edit ? editSticky(w) : pinSticky(w); return w; } }
  const wa = targetDisplay().workArea;
  const solid = stickyPinMode(); // 아이콘 아래 층에서는 투명 창이 깨질 수 있어 불투명(네모난 종이)으로
  if (n.x == null) { n.x = Math.round(wa.x + wa.width / 2 - 140); n.y = Math.round(wa.y + wa.height / 3); updateSticky(n.id, { x: n.x, y: n.y }); }
  const win = new BrowserWindow({
    x: n.x, y: n.y, width: n.w || 280, height: n.h || 260,
    frame: false, transparent: !solid, backgroundColor: solid ? '#FFF3B0' : '#00000000', resizable: false, skipTaskbar: true, minimizable: false, maximizable: false,
    fullscreenable: false, hasShadow: false, show: false, title: '메모장', webPreferences: { preload: PRELOAD, backgroundThrottling: false }
  });
  win.__sticky = n.id;
  stickyWins.set(n.id, win);
  win.loadFile(PAGE('sticky.html'), { query: solid ? { solid: '1' } : {} });
  win.once('ready-to-show', () => { if (edit) editSticky(win); else pinSticky(win); });
  win.on('blur', () => setTimeout(() => {
    if (win.isDestroyed() || win.isFocused() || win.__busy) return;
    if (win.__editing || !stickyPinMode()) pinSticky(win);
  }, 250));
  let t = null;
  win.on('moved', () => { clearTimeout(t); t = setTimeout(() => { if (win.isDestroyed() || win.__pinned) return; const b = win.getBounds(); updateSticky(n.id, { x: b.x, y: b.y }); }, 300); });
  win.on('closed', () => stickyWins.delete(n.id));
  return win;
}
function newSticky(text, near) {
  const list = store.getStickies();
  const wa = targetDisplay().workArea;
  const k = list.length % 6;
  const n = { id: require('crypto').randomUUID(), text: text || '', mode: 'basic', color: STICKY_COLORS[list.length % 6][0], fs: 1,
    x: near ? near.x + 30 : Math.round(wa.x + wa.width / 2 - 140 + k * 26), y: near ? near.y + 30 : Math.round(wa.y + wa.height / 3 + k * 26), w: 280, h: 260, created: Date.now() };
  list.push(n); store.saveStickies(list);
  openSticky(n, true); // 새 메모장은 바로 써야 하니 앞으로 꺼낸 채로
  return n;
}
function broadcastSticky(id) {
  const w = stickyWins.get(id), n = stickyById(id);
  if (w && n && !w.isDestroyed()) w.webContents.send('sticky', stickyPayload(n));
}
const senderSticky = (e) => { const w = BrowserWindow.fromWebContents(e.sender); return w && w.__sticky; };
ipcMain.handle('sticky:get', (e) => { const n = stickyById(senderSticky(e)); return n ? stickyPayload(n) : null; });
ipcMain.handle('sticky:save', (e, patch) => { const ok = ['text', 'mode', 'color', 'char', 'fs']; const clean = {}; for (const k of ok) if (patch && k in patch) clean[k] = patch[k]; updateSticky(senderSticky(e), clean); });
ipcMain.handle('sticky:bounds', (e, b, done) => {
  const id = senderSticky(e), w = stickyWins.get(id); if (!w || w.isDestroyed()) return;
  if (w.__pinned) editSticky(w);
  const nb = { x: Math.round(b.x), y: Math.round(b.y), width: Math.max(180, Math.round(b.width)), height: Math.max(140, Math.round(b.height)) };
  w.setBounds(nb);
  if (done) updateSticky(id, { x: nb.x, y: nb.y, w: nb.width, h: nb.height });
});
ipcMain.handle('sticky:new', (e, text) => { const w = BrowserWindow.fromWebContents(e.sender); newSticky(text, w && w.__sticky ? w.getBounds() : null); });
ipcMain.handle('sticky:menu', (e) => {
  const id = senderSticky(e), n = stickyById(id), win = stickyWins.get(id);
  if (!n || !win) return;
  const set = (patch) => { updateSticky(id, patch); broadcastSticky(id); };
  win.__busy = true; setTimeout(() => { win.__busy = false; }, 400);
  const pick = n.char || 'daily';
  Menu.buildFromTemplate([
    { label: '모양', submenu: STICKY_MODES.map(([k, l]) => ({ label: l, type: 'radio', checked: (n.mode || 'basic') === k, click: () => set({ mode: k }) })) },
    { label: '종이 색', enabled: n.mode !== 'char', submenu: STICKY_COLORS.map(([k, l]) => ({ label: l, type: 'radio', checked: n.color === k, click: () => set({ color: k }) })) },
    { label: '캐릭터', submenu: [{ label: '매일 바뀌기', type: 'radio', checked: pick === 'daily', click: () => set({ char: null, mode: 'char' }) }, { type: 'separator' },
      ...Chars.LIST.map((c) => ({ label: c.name, type: 'radio', checked: pick === c.id, click: () => set({ char: c.id, mode: 'char' }) }))] },
    { label: '글자 크기', submenu: [[0.85, '작게'], [1, '보통'], [1.2, '크게'], [1.45, '아주 크게']].map(([v, l]) => ({ label: l, type: 'radio', checked: (n.fs || 1) === v, click: () => set({ fs: v }) })) },
    { type: 'separator' },
    { label: '이 메모로 일정 만들기 (AI)', enabled: !!String(n.text || '').trim(), click: () => openAI(String(n.text || '').replace(/^\[[ x]\] /gm, '')) },
    { type: 'separator' },
    { label: '새 메모지', click: () => newSticky('', win.getBounds()) },
    { label: '이 메모지 떼기 (삭제)', click: async () => {
      if (String(n.text || '').trim()) {
        win.__busy = true;
        const r = await dialog.showMessageBox(win, { type: 'question', buttons: ['떼기', '취소'], defaultId: 1, cancelId: 1, message: '이 메모지를 뗄까요? 적어 둔 내용도 지워져요.' });
        win.__busy = false;
        if (r.response !== 0) return;
      }
      store.saveStickies(store.getStickies().filter((x) => x.id !== id));
      win.destroy();
    } }
  ]).popup({ window: win, callback: () => { win.__busy = false; } });
});
function openAllStickies() { store.getStickies().forEach(openSticky); }
function refreshStickies() { for (const [id] of stickyWins) broadcastSticky(id); }

// ---------------------------------------------------------------- 바탕화면에서 바로 클릭
// 아이콘 뒤에 박힌 캘린더의 빈 곳(아이콘 없는 곳)을 누르면 → 화면에 알려서
// 가벼운 동작(동기화·달 넘기기·메모 체크)은 그대로 처리, 나머지는 바로 편집 상태로 꺼냄
function calendarRectDip() {
  if (settings.mode === 'wallpaper') return targetDisplay().bounds;
  if (widgetUnder()) {
    const w = settings.widget;
    if (settings.minimal) { const b = calWin.getBounds(); return b; }
    return { x: w.x, y: w.y, width: w.width, height: w.height };
  }
  return null;
}
function onDesktopClick(p) {
  const dip0 = process.platform === 'win32' ? screen.screenToDipPoint(p) : p;
  const sw = stickyAt(dip0);
  if (sw) { editSticky(sw); return; }
  if (!calWin || calWin.isDestroyed() || editing || !pinned) return;
  if (settings.clickToEdit === false) return;
  const r = calendarRectDip();
  if (!r) return;
  const dip = process.platform === 'win32' ? screen.screenToDipPoint(p) : p;
  if (dip.x < r.x || dip.y < r.y || dip.x >= r.x + r.width || dip.y >= r.y + r.height) return;
  calWin.webContents.send('desk-click', { x: dip.x - r.x, y: dip.y - r.y, t: Date.now() });
}
// 바탕화면에 붙어 있을 때: 마우스 위치를 알려서 아이콘 설명을 띄움
let hoverKey = '';
setInterval(() => {
  if (!calWin || calWin.isDestroyed() || editing || !pinned) { if (hoverKey) { hoverKey = ''; calWin && !calWin.isDestroyed() && calWin.webContents.send('desk-hover', null); } return; }
  const r = calendarRectDip(); if (!r) return;
  const p = screen.getCursorScreenPoint();
  const inside = p.x >= r.x && p.y >= r.y && p.x < r.x + r.width && p.y < r.y + r.height;
  const key = inside ? `${p.x},${p.y}` : '';
  if (key === hoverKey) return;
  hoverKey = key;
  calWin.webContents.send('desk-hover', inside ? { x: p.x - r.x, y: p.y - r.y } : null);
}, 180);
// 꺼낸 상태에서 다른 창을 누르면 바탕화면으로 돌아감
function maybeReturn() {
  if (!autoEdit || !editing || !calWin || calWin.isDestroyed()) return;
  setTimeout(() => {
    if (!autoEdit || !editing || !calWin || calWin.isDestroyed()) return;
    const f = BrowserWindow.getFocusedWindow();
    if (f === calWin) return;
    if (editorWin && !editorWin.isDestroyed()) return; // 일정 창을 쓰는 중
    if (f && f !== calWin && f !== popupWin) return;  // 설정 창 등 우리 창 → 그대로 둠
    setEditing(false);
  }, 250);
}

// 위젯 위치 맞추기·잠금
function widgetAction(action) {
  if (settings.mode !== 'widget' || !calWin || calWin.isDestroyed()) return;
  const wa = targetDisplay().workArea;
  const b = calWin.getBounds();
  const M = 20;
  const pos = {
    'top-right': { x: wa.x + wa.width - b.width - M, y: wa.y + M },
    'bottom-right': { x: wa.x + wa.width - b.width - M, y: wa.y + wa.height - b.height - M },
    'top-left': { x: wa.x + M, y: wa.y + M },
    'bottom-left': { x: wa.x + M, y: wa.y + wa.height - b.height - M },
    center: { x: Math.round(wa.x + (wa.width - b.width) / 2), y: Math.round(wa.y + (wa.height - b.height) / 2) }
  }[action];
  if (pos) {
    if (pinned) { desktop.unpin(calWin); pinned = false; }
    calWin.setBounds({ ...b, ...pos });
    settings.widget = { ...settings.widget, ...pos };
    if (widgetUnder() && !editing) attachWidgetToDesktop();
  }
  if (action === 'lock' || action === 'unlock') {
    settings.widget.locked = action === 'lock';
    calWin.setMovable(!settings.widget.locked);
    calWin.setResizable(!settings.widget.locked);
  }
  store.saveSettings(settings);
  pushState(); buildTray();
}

// 미니 달력 모드: 위젯이면 작은 창으로 줄였다가 해제 시 원래 크기로
function setMinimal(on) {
  on = !!on;
  if (settings.minimal === on) return;
  settings.minimal = on;
  if (settings.mode === 'widget' && calWin && !calWin.isDestroyed()) {
    const b = calWin.getBounds();
    const scale = (settings.appearance && settings.appearance.fontScale) || 1;
    if (on) {
      settings.widgetFull = { x: b.x, y: b.y, width: b.width, height: b.height };
      const w = Math.round(304 * scale), h = Math.round(330 * scale);
      calWin.setBounds({ x: b.x + b.width - w, y: b.y, width: w, height: h });
    } else if (settings.widgetFull) {
      const f = settings.widgetFull, now = calWin.getBounds();
      calWin.setBounds({ x: now.x + now.width - f.width, y: now.y, width: f.width, height: f.height });
    }
    if (pinned) { desktop.unpin(calWin); pinned = false; attachWidgetToDesktop(); }
  }
  store.saveSettings(settings);
  pushState(); buildTray();
}

// ---------------------------------------------------------------- 보조 창
function openEditor(payload) {
  const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  if (editorWin && !editorWin.isDestroyed()) editorWin.destroy();
  const W = 480, H = 820;
  editorWin = new BrowserWindow({
    width: W, height: H,
    x: Math.round(d.workArea.x + (d.workArea.width - W) / 2),
    y: Math.round(d.workArea.y + (d.workArea.height - H) / 2),
    frame: false, resizable: false, alwaysOnTop: true, skipTaskbar: false, show: false,
    backgroundColor: bgFor(), title: '일정',
    webPreferences: { preload: PRELOAD }
  });
  editorWin.__payload = payload || {};
  editorWin.loadFile(PAGE('editor.html'));
  editorWin.once('ready-to-show', () => { editorWin.show(); editorWin.focus(); });
  editorWin.on('closed', () => { editorWin = null; if (autoEdit && calWin && !calWin.isDestroyed() && !calWin.isFocused()) maybeReturn(); });
}

// 소개 · 무료/프리미엄 안내 화면
let aboutWin = null;
function openAbout() {
  if (aboutWin && !aboutWin.isDestroyed()) { aboutWin.show(); aboutWin.focus(); return; }
  aboutWin = new BrowserWindow({
    width: 560, height: 860, minWidth: 380, minHeight: 560,
    show: false, autoHideMenuBar: true, backgroundColor: '#FFF8F0', title: 'Total Calendar 소개',
    icon: ASSET('icon.png'),
    webPreferences: { preload: PRELOAD }
  });
  aboutWin.loadFile(PAGE('about.html'));
  aboutWin.once('ready-to-show', () => aboutWin.show());
  aboutWin.on('closed', () => { aboutWin = null; });
}
function openSettingsAt(where) {
  openSettings();
  setTimeout(() => { if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:goto', where); }, 700);
}

function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.show(); settingsWin.focus(); return; }
  settingsWin = new BrowserWindow({
    width: 1040, height: 860, minWidth: 820, minHeight: 600,
    show: false, autoHideMenuBar: true, backgroundColor: bgFor(), title: 'Total Calendar 설정',
    icon: ASSET('icon.png'),
    webPreferences: { preload: PRELOAD }
  });
  settingsWin.loadFile(PAGE('settings.html'));
  settingsWin.once('ready-to-show', () => settingsWin.show());
  settingsWin.on('closed', () => {
    settingsWin = null;
    if (appearancePreview) { appearancePreview = null; broadcastAppearance(); } // 저장 안 하고 닫으면 원래대로
  });
}

function showPopup() {
  if (!popupQueue.length) { if (popupWin && !popupWin.isDestroyed()) popupWin.close(); return; }
  const wa = screen.getPrimaryDisplay().workArea;
  const W = 440;
  if (!popupWin || popupWin.isDestroyed()) {
    popupWin = new BrowserWindow({
      width: W, height: 160, x: wa.x + wa.width - W - 16, y: wa.y + wa.height - 176,
      frame: false, resizable: false, skipTaskbar: true, alwaysOnTop: true, show: false,
      transparent: true, backgroundColor: '#00000000', focusable: true,
      webPreferences: { preload: PRELOAD }
    });
    popupWin.setAlwaysOnTop(true, 'screen-saver');
    popupWin.loadFile(PAGE('popup.html'));
    popupWin.once('ready-to-show', () => popupWin.showInactive());
    popupWin.on('closed', () => { popupWin = null; });
  } else {
    popupWin.webContents.send('popup', popupQueue);
    popupWin.showInactive();
  }
}

// ---------------------------------------------------------------- 상태·동기화
function publicSources() {
  return settings.sources.filter((s) => s.enabled !== false).map((s) => ({
    id: s.id, name: s.name, color: s.color, type: s.type, holiday: !!s.holiday, writable: !s.holiday && (s.type === 'local' || s.type === 'caldav')
  }));
}

function stateForRenderer() {
  return {
    updateAvailable: Updater.getState().available ? Updater.getState().latest.version : '',
    events: cache.events, errors: cache.errors, updated: cache.updated, syncing: cache.syncing,
    sources: publicSources(), view: settings.view, mode: settings.mode, editing,
    iconGutter: settings.iconGutter, hotkeyEdit: settings.hotkeyEdit, hotkeyQuickAdd: settings.hotkeyQuickAdd,
    panels: settings.panels[settings.mode] || {}, colorBy: settings.colorBy,
    appearance: appearance(), locked: !!settings.widget.locked, minimal: !!settings.minimal,
    underIcons: widgetUnder(), pinned, autoEdit,
    opacity: curOpacity(), opacityCss: opacityByCss(),
    lastWriteSource: settings.lastWriteSource,
    notes: decoratedNotes(),
    characters: settings.characters,
    stickerDays: settings.characters?.enabled && settings.characters?.stickers ? store.getStickers().days : {},
    categories: (settings.categories || []).map((c) => ({ id: c.id, name: c.name, color: c.color })),
    alarms: (settings.alarms || []).filter((a) => a.on !== false && !Alarms.expired(a))
      .sort((x, y) => String(x.time).localeCompare(String(y.time)))
      .map((a) => ({ id: a.id, text: `${Alarms.label(a)} ${a.title || '알람'}` }))
  };
}

function pushState() {
  if (calWin && !calWin.isDestroyed()) calWin.webContents.send('state', stateForRenderer());
}

// 일정마다 카테고리를 정하고 카드 색을 입힘
// 우선순위: 직접 지정(앱에 기억) > 캘린더의 CATEGORIES 값 > 제목 속 자동 분류 단어
function decorate(events) {
  const map = store.getCategoryMap();
  const rmap = store.getRemindMap();
  const bmap = store.getBirthYears();
  const cats = settings.categories || [];
  const byName = new Map(cats.map((c) => [c.name.trim(), c]));
  const rules = cats.map((c) => ({ c, words: String(c.keywords || '').split(',').map((w) => w.trim()).filter(Boolean) }));
  return events.map((e) => {
    if (e.holiday) return { ...e, sourceColor: e.color, categoryChoice: 'none', categoryId: null, category: '', remind: [] };
    const choice = map[e.uid] || 'auto';
    let cat = null;
    if (choice !== 'auto' && choice !== 'none') cat = cats.find((c) => c.id === choice) || null;
    if (choice === 'auto') {
      cat = (e.categoryName && byName.get(e.categoryName.trim())) || null;
      if (!cat) {
        const t = String(e.title || '');
        const hit = rules.find((r) => r.words.some((w) => t.includes(w)));
        cat = hit ? hit.c : null;
      }
    }
    const sourceColor = e.color;
    return {
      ...e,
      sourceColor,
      categoryChoice: choice,
      remind: Array.isArray(rmap[e.uid]) ? rmap[e.uid] : undefined,
      birthYear: bmap[e.uid] || null,
      categoryId: cat ? cat.id : null,
      category: cat ? cat.name : '',
      color: settings.colorBy === 'category' && cat ? cat.color : sourceColor
    };
  });
}

// 메모(날짜 없음)에 카테고리 색 입히기 — 일정과 같은 규칙
function decoratedNotes() {
  const cats = settings.categories || [];
  const rules = cats.map((c) => ({ c, words: String(c.keywords || '').split(',').map((w) => w.trim()).filter(Boolean) }));
  return store.getNotes().map((n) => {
    const choice = n.categoryChoice || 'auto';
    let cat = null;
    if (choice !== 'auto' && choice !== 'none') cat = cats.find((c) => c.id === choice) || null;
    if (choice === 'auto') { const hit = rules.find((r) => r.words.some((w) => n.text.includes(w))); cat = hit ? hit.c : null; }
    return { ...n, category: cat ? cat.name : '', color: cat ? cat.color : 'var(--accent)' };
  }).sort((a, b) => (a.done - b.done) || (b.updated || 0) - (a.updated || 0));
}

function setRemind(uid, list) {
  if (!uid) return;
  const m = store.getRemindMap();
  if (Array.isArray(list)) m[uid] = list.slice(0, 20); else delete m[uid];
  store.saveRemindMap(m);
}

function setBirthYear(uid, y) {
  if (!uid) return;
  const m = store.getBirthYears();
  const n = Number(y);
  if (n >= 1900 && n <= 2100) m[uid] = n; else delete m[uid];
  store.saveBirthYears(m);
}

// 시각(앱 시간대 기준) → 그 시각 동물
function hourIn(date) {
  const tz = settings.appearance.timeZone;
  const opt = { hour: 'numeric', hourCycle: 'h23' };
  if (tz && tz !== 'system') opt.timeZone = tz;
  try { return Number(new Intl.DateTimeFormat('en-US', opt).format(date)) % 24; } catch { return date.getHours(); }
}
// 알림을 가져올 동물: 카테고리 담당 > 일정 시각의 동물
function delivererFor(ev) {
  const C = settings.characters || {};
  if (!C.enabled || !C.deliverer) return null;
  const t = Themes.actual(settings.appearance.theme);
  if (t && (t.char || t.season)) {
    const lk = Chars.lookFor(settings.appearance, C, new Date());
    if (lk) return { id: lk.id, by: 'theme', concept: t.concept || t.name, season: lk.season, v: lk.v };
  }
  const pick = ev.categoryId && C.map ? C.map[ev.categoryId] : null;
  const id = pick && pick !== 'hour' && Chars.byId(pick) ? pick : (C.buddy && C.buddy !== 'theme' && Chars.byId(C.buddy) ? C.buddy : 'rabbit');
  const lk = Chars.lookFor(settings.appearance, C, new Date(), id);
  return { id, by: pick && pick !== 'hour' ? 'category' : 'buddy', season: lk ? lk.season : null, v: lk ? lk.v : 1 };
}

// 메모 완료 → 스티커 한 장 (같은 메모는 한 번만). 아직 없는 동물이 조금 더 잘 나옴
function awardSticker(note) {
  const C = settings.characters || {};
  if (!C.enabled || !C.stickers || note.sticker) return null;
  const st = store.getStickers();
  const missing = Chars.LIST.filter((c) => !st.owned[c.id]);
  const pool = missing.length && Math.random() < 0.6 ? missing : Chars.LIST;
  const c = pool[Math.floor(Math.random() * pool.length)];
  const isNew = !st.owned[c.id];
  st.owned[c.id] = (st.owned[c.id] || 0) + 1;
  st.total = (st.total || 0) + 1;
  const d = new Date(), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  st.days[key] = [...(st.days[key] || []), c.id].slice(-12);
  store.saveStickers(st);
  note.sticker = c.id;
  return { id: c.id, name: c.name, isNew, count: Object.keys(st.owned).length };
}

function setCategory(uid, choice) {
  if (!uid) return;
  const map = store.getCategoryMap();
  if (!choice || choice === 'auto') delete map[uid]; else map[uid] = choice;
  store.saveCategoryMap(map);
}

const catName = (choice) => (settings.categories || []).find((c) => c.id === choice)?.name || '';

async function runSync(fromCloud) {
  if (fromCloud !== true) cloud.sync().catch(() => {}); // 다른 기기와 맞추기 (바뀐 게 없으면 목록 1개만 확인)
  if (cache.syncing) return;
  cache.syncing = true; lastSyncAt = Date.now(); pushState();
  try {
    const { events, errors } = await sync.fetchAll(settings, ctx);
    cache.raw = events;
    cache.events = decorate(events); cache.errors = errors; cache.updated = new Date().toISOString();
  } catch (e) {
    cache.errors = [String(e.message || e)];
  } finally {
    cache.syncing = false;
    pushState();
    checkReminders();
  }
}

function scheduleSync() {
  clearInterval(syncTimer);
  syncTimer = setInterval(runSync, Math.max(1, settings.refreshMinutes || 3) * 60000);
}

function checkReminders() {
  const state = store.getReminderState();
  const due = reminders.due(cache.events, settings, state);
  // 알람 (달력에 넣지 않는 알림)
  const adue = Alarms.due(settings.alarms || [], state);
  store.saveReminderState(state);
  for (const x of adue) {
    const a = x.alarm;
    due.push({ key: x.key, label: (x.snoozed ? '다시 알림 · ' : '⏰ ') + Alarms.label(a), event: { id: 'alarm:' + a.id, alarmId: a.id, isAlarm: true, title: a.title || '알람', msg: a.msg || '', color: appearance().accent || '#E06A8E', start: x.at.toISOString(), allDay: false } });
  }
  // 한 번만 울리는 알람은 울린 뒤 저절로 꺼짐
  if (adue.some((x) => x.alarm.repeat === 'once' && !x.snoozed)) {
    const ids = new Set(adue.filter((x) => x.alarm.repeat === 'once').map((x) => x.alarm.id));
    settings.alarms = (settings.alarms || []).map((a) => (ids.has(a.id) ? { ...a, on: false } : a));
    store.saveSettings(settings); pushState();
  }
  if (!due.length) return;
  const keys = new Set(popupQueue.map((p) => p.key));
  due.forEach((d) => { if (!keys.has(d.key)) { const c = delivererFor(d.event); popupQueue.push({ ...d, char: c && c.id, charBy: c && c.by, concept: c && c.concept, season: c && c.season, v: c && c.v }); } });
  showPopup();
}

// ---------------------------------------------------------------- 트레이·단축키
function buildTray() {
  if (!tray) {
    tray = new Tray(nativeImage.createFromPath(ASSET('tray.png')));
    tray.setToolTip('Total Calendar');
    tray.on('double-click', () => setEditing(true));
  }
  const up = Updater.getState();
  tray.setContextMenu(Menu.buildFromTemplate([
    ...(up.available ? [{ label: `★ 새 버전 ${up.latest.version} 업데이트하기`, click: updateFromTray }, { type: 'separator' }] : []),
    { label: '새 일정', accelerator: settings.hotkeyQuickAdd, click: () => openEditor({}) },
    { label: 'AI로 일정 등록 (글·메일 붙여넣기)', click: () => openAI('') },
    { label: '새 메모장 꺼내기 (바탕화면에 따로)', click: () => newSticky('') },
    { label: '미니 달력 모드', type: 'checkbox', checked: !!settings.minimal, click: () => setMinimal(!settings.minimal) },
    { label: settings.mode === 'widget' && !settings.widget.underIcons ? '캘린더 앞으로 가져오기' : '편집 모드 (앞으로 꺼내기)', accelerator: settings.hotkeyEdit, click: () => setEditing(!editing) },
    { label: '지금 동기화', click: runSync },
    { type: 'separator' },
    { label: '바탕화면 모드', type: 'radio', checked: settings.mode === 'wallpaper', click: () => applySettings({ ...settings, mode: 'wallpaper' }) },
    { label: '위젯 모드', type: 'radio', checked: settings.mode === 'widget', click: () => applySettings({ ...settings, mode: 'widget' }) },
    { label: `보이는 화면 (${settings.mode === 'widget' ? '위젯' : '바탕화면'} 모드)`, submenu: PANEL_LABELS.map(([k, label]) => ({
      label, type: 'checkbox', checked: settings.panels[settings.mode][k] !== false, click: () => togglePanel(k)
    })) },
    { label: '위젯 위치', visible: settings.mode === 'widget', submenu: [
      { label: '오른쪽 위', click: () => widgetAction('top-right') },
      { label: '오른쪽 아래', click: () => widgetAction('bottom-right') },
      { label: '왼쪽 위', click: () => widgetAction('top-left') },
      { label: '왼쪽 아래', click: () => widgetAction('bottom-left') },
      { label: '가운데', click: () => widgetAction('center') },
      { type: 'separator' },
      { label: '아이콘 아래에 두기 (아이콘이 위젯 위에 보임)', type: 'checkbox', checked: !!settings.widget.underIcons, click: () => applySettings({ ...settings, widget: { ...settings.widget, underIcons: !settings.widget.underIcons } }) },
      { label: '위치·크기 잠금', type: 'checkbox', checked: !!settings.widget.locked, click: () => widgetAction(settings.widget.locked ? 'unlock' : 'lock') }
    ] },
    { label: '바탕화면에 다시 붙이기', visible: settings.mode === 'wallpaper', click: () => createCalendarWindow() },
    { type: 'separator' },
    { label: cloud.getState().signedIn ? `계정 · 동기화 (${cloud.getState().email})` : '로그인 · PC↔휴대폰 동기화…', click: () => { openSettings(); setTimeout(() => { if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:goto', 'account'); }, 700); } },
    { label: '알람 설정…', click: () => openSettingsAt('alarm') },
    { label: '설정…', click: openSettings },
    { label: 'Total Calendar 소개 · 프리미엄', click: openAbout },
    { label: '데이터 폴더 열기', click: () => shell.openPath(store.DIR) },
    { label: '문제 신고 · 의견 보내기…', click: () => sendReport('bug') },
    { label: '종료', click: () => { app.isQuitting = true; app.quit(); } }
  ]));
}

const PANEL_LABELS = [['list', '왼쪽 목록 패널 전체'], ['clock', '시계·날짜'], ['next', '다음 일정'], ['toolbar', '도구 버튼'], ['today', '오늘 일정'], ['tomorrow', '내일 일정'], ['memo', '메모 (날짜 없는 글)'], ['calendar', '달력 (월·주)'], ['footer', '하단 정보']];

function togglePanel(key) {
  const p = settings.panels[settings.mode];
  p[key] = p[key] === false;
  // 목록·달력이 둘 다 꺼지면 빈 화면이 되므로 다른 하나를 다시 켬
  if ((key === 'list' || key === 'calendar') && p.list === false && p.calendar === false) p[key === 'list' ? 'calendar' : 'list'] = true;
  store.saveSettings(settings);
  pushState();
  buildTray();
}

function registerHotkeys() {
  globalShortcut.unregisterAll();
  const tryReg = (acc, fn) => { try { if (acc) globalShortcut.register(acc, fn); } catch { /* 잘못된 단축키 */ } };
  tryReg(settings.hotkeyQuickAdd, () => openEditor({}));
  tryReg(settings.hotkeyEdit, () => setEditing(!editing));
}

// 컴퓨터 켜면 자동 실행 (작업 관리자에서 꺼 둔 것도 다시 켬)
function applyAutoStart() {
  if (!app.isPackaged) return;
  // 예전 이름(DeskCal)으로 등록된 자동 실행 항목은 지워서 두 번 켜지지 않게 함
  try { app.setLoginItemSettings({ openAtLogin: false, name: 'DeskCal', path: process.execPath, args: [] }); } catch {}
  try { app.setLoginItemSettings({ openAtLogin: !!settings.autoStart, enabled: !!settings.autoStart, name: 'Total Calendar', path: process.execPath, args: [] }); } catch {}
}
function applySettings(next) {
  const prev = settings;
  settings = next;
  appearancePreview = null;
  store.saveSettings(settings);
  sync.forgetClients();
  applyAutoStart();
  cache.events = decorate(cache.raw || []);
  const layoutChanged = prev.mode !== next.mode || prev.displayId !== next.displayId || !!(prev.widget || {}).underIcons !== !!(next.widget || {}).underIcons;
  if (layoutChanged) createCalendarWindow(); else pushState();
  broadcastAppearance();
  buildTray();
  registerHotkeys();
  scheduleSync();
  runSync();
}

// ---------------------------------------------------------------- IPC
const findEvent = (id) => cache.events.find((e) => e.id === id);
const findSource = (id) => settings.sources.find((s) => s.id === id);

ipcMain.handle('state:get', () => stateForRenderer());
ipcMain.handle('sync:now', () => runSync());
ipcMain.handle('appearance:get', () => appearance());
ipcMain.handle('appearance:preview', (_e, a) => { appearancePreview = { ...settings.appearance, ...a }; broadcastAppearance(); });
ipcMain.handle('widget:action', (_e, a) => widgetAction(a));
ipcMain.handle('minimal:set', (_e, on) => setMinimal(on));
ipcMain.handle('panel:toggle', (_e, key) => togglePanel(key));
ipcMain.handle('view:set', (_e, view) => { settings.view = view; store.saveSettings(settings); pushState(); });
ipcMain.handle('edit:set', (_e, on) => setEditing(!!on));
// 바탕화면에서 클릭 → 바로 편집 상태로 (꺼내면서 오래된 일정이면 동기화도)
ipcMain.handle('edit:activate', () => {
  setEditing(true, { auto: true });
  if (Date.now() - lastSyncAt > 60000) runSync();
  return true;
});

// 마우스로 크기·위치 바꾸기 (투명 창은 Windows에서 가장자리 크기 조절이 안 되어 직접 처리)
ipcMain.handle('win:bounds', (_e, b, done) => {
  if (!calWin || calWin.isDestroyed() || settings.mode !== 'widget' || settings.widget.locked) return;
  if (pinned) return; // 바탕화면에 박힌 상태에서는 꺼낸 뒤에
  const minW = settings.minimal ? 220 : 320, minH = settings.minimal ? 220 : 260;
  const nb = { x: Math.round(b.x), y: Math.round(b.y), width: Math.max(minW, Math.round(b.width)), height: Math.max(minH, Math.round(b.height)) };
  calWin.setBounds(nb);
  if (done && !settings.minimal) {
    settings.widget = { ...settings.widget, ...nb };
    store.saveSettings(settings);
  }
});
// 바탕화면 모드(가운데·오른쪽·왼쪽 정렬): 가장자리를 끌어 폭 바꾸기
ipcMain.handle('wall:width', (_e, pct, done) => {
  const v = Math.max(30, Math.min(100, Math.round(pct)));
  settings.appearance = { ...settings.appearance, wallpaperWidth: v };
  if (done) store.saveSettings(settings);
  broadcastAppearance();
});

// 화면에서 바로 바꾸는 꾸미기 값 (목록 너비 등)
ipcMain.handle('appearance:patch', (_e, patch) => {
  const ok = ['listWidthWidget', 'listWidthWall'];
  const clean = {};
  for (const k of ok) if (patch && k in patch) clean[k] = Math.max(0, Math.round(Number(patch[k]) || 0));
  settings.appearance = { ...settings.appearance, ...clean };
  store.saveSettings(settings);
  broadcastAppearance();
});

// 일정을 다른 날로 끌어다 놓기 (시각·길이는 그대로)
ipcMain.handle('event:move', async (_e, { eventId, days }) => {
  const ev = findEvent(eventId);
  if (!ev) throw new Error('일정을 찾지 못했습니다');
  if (!ev.writable) throw new Error('이 캘린더는 읽기 전용이라 옮길 수 없어요');
  if (ev.recurring) throw new Error('반복 일정은 원래 캘린더에서 옮겨 주세요');
  const n = Math.round(days);
  if (!n) return true;
  const shiftYmd = (s, k) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + k); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  let input;
  if (ev.allDay) {
    input = { allDay: true, date: shiftYmd(ev.start, n), endDate: shiftYmd(shiftYmd(ev.end, -1), n) };
  } else {
    const zone = ev.tz && TZ.valid(ev.tz) ? ev.tz : null;
    const part = (iso) => {
      const d = new Date(new Date(iso).getTime() + n * 86400000);
      const w = zone ? TZ.wall(d, zone) : d;
      const p2 = (x) => String(x).padStart(2, '0');
      return { date: `${w.getFullYear()}-${p2(w.getMonth() + 1)}-${p2(w.getDate())}`, time: `${p2(w.getHours())}:${p2(w.getMinutes())}` };
    };
    const a = part(ev.start), b = part(ev.end);
    input = { allDay: false, date: a.date, startTime: a.time, endDate: b.date, endTime: b.time, tz: zone || '' };
  }
  const data = { ...input, title: ev.title, location: ev.location || '', notes: ev.notes || '', categoryName: catName(ev.categoryChoice) || ev.categoryName || '' };
  await sync.updateEvent(findSource(ev.sourceId), ev, data, ctx);
  await runSync();
  return true;
});

// 오른쪽 클릭 메뉴
ipcMain.handle('ctx:menu', (e, info) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const send = (action, extra) => win && !win.isDestroyed() && win.webContents.send('ctx-action', { action, ...info, ...extra });
  const items = [];
  if (info.kind === 'event') {
    const ev = findEvent(info.id);
    if (!ev) return;
    items.push({ label: '열기·수정', click: () => openEditor({ eventId: ev.id }) });
    items.push({ label: '카테고리', submenu: [
      { label: '자동', type: 'radio', checked: ev.categoryChoice === 'auto', click: () => { setCategory(ev.uid, 'auto'); cache.events = decorate(cache.raw || []); pushState(); } },
      ...(settings.categories || []).map((c) => ({ label: c.name, type: 'radio', checked: ev.categoryChoice === c.id, click: () => { setCategory(ev.uid, c.id); cache.events = decorate(cache.raw || []); pushState(); } })),
      { label: '없음', type: 'radio', checked: ev.categoryChoice === 'none', click: () => { setCategory(ev.uid, 'none'); cache.events = decorate(cache.raw || []); pushState(); } }
    ] });
    if (ev.writable && !ev.recurring) {
      items.push({ type: 'separator' });
      items.push({ label: '하루 뒤로', click: () => send('move', { days: 1 }) });
      items.push({ label: '일주일 뒤로', click: () => send('move', { days: 7 }) });
      items.push({ type: 'separator' });
      items.push({ label: '삭제', click: async () => {
        const r = await dialog.showMessageBox(win, { type: 'question', buttons: ['삭제', '취소'], defaultId: 1, cancelId: 1, title: '일정 삭제', message: `'${ev.title}' 일정을 삭제할까요?` });
        if (r.response !== 0) return;
        try { await sync.deleteEvent(findSource(ev.sourceId), ev, ctx); setCategory(ev.uid, 'auto'); await runSync(); }
        catch (err) { send('error', { message: String(err.message || err) }); }
      } });
    }
  } else if (info.kind === 'note') {
    const n = store.getNotes().find((x) => x.id === info.id);
    if (!n) return;
    items.push({ label: n.done ? '완료 취소' : '완료', click: () => send('toggle') });
    items.push({ label: '수정·날짜 넣기', click: () => openEditor({ noteId: n.id }) });
    items.push({ label: '바탕화면 메모장으로 붙이기', click: () => newSticky(n.text) });
    items.push({ type: 'separator' });
    items.push({ label: '삭제', click: () => { store.saveNotes(store.getNotes().filter((x) => x.id !== n.id)); pushState(); } });
  } else if (info.kind === 'day') {
    items.push({ label: '여기에 빠르게 추가', click: () => send('quick') });
    items.push({ label: '자세히 추가 (일정 창)', click: () => openEditor({ date: info.date }) });
    items.push({ label: '이날 일정 모아 보기', click: () => send('daypop') });
  }
  if (items.length) items.push({ type: 'separator' });
  items.push({ label: '바탕화면에 메모장 붙이기', click: () => newSticky('') });
  items.push({ label: '오늘로', click: () => send('today') });
  items.push({ label: '지금 동기화', click: () => runSync() });
  if (editing) items.push({ label: '바탕화면으로 돌아가기', click: () => setEditing(false) });
  Menu.buildFromTemplate(items).popup({ window: win });
});
ipcMain.handle('editor:open', (_e, payload) => openEditor(payload));
ipcMain.handle('settings:open', () => openSettings());
ipcMain.handle('win:close', (e) => BrowserWindow.fromWebContents(e.sender)?.close());
ipcMain.handle('about:open', () => openAbout());
ipcMain.handle('alarm:open', () => openSettingsAt('alarm'));
// 관리자: 사용 통계 (관리자 계정으로 로그인했을 때만)
ipcMain.handle('admin:is', () => Telemetry.isAdmin(cloud.getState().email));
ipcMain.handle('admin:stats', async () => {
  if (!Telemetry.isAdmin(cloud.getState().email)) throw new Error('관리자 계정으로 로그인해야 볼 수 있어요');
  await Telemetry.ping(true).catch(() => {});
  return Telemetry.stats(await cloud.idToken());
});
ipcMain.handle('about:go', (e, where) => { BrowserWindow.fromWebContents(e.sender)?.close(); openSettingsAt(where === 'skin' ? 'skin' : where === 'alarm' ? 'alarm' : 'account'); });

ipcMain.handle('editor:init', (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const p = (win && win.__payload) || {};
  const ev = p.eventId ? findEvent(p.eventId) : null;
  const note = p.noteId ? store.getNotes().find((n) => n.id === p.noteId) || null : null;
  return {
    event: ev, note, date: p.date || null, text: p.text || '',
    sources: publicSources(),
    categories: settings.categories || [],
    defaultReminders: settings.reminders,
    characters: settings.characters,
    lastWriteSource: settings.lastWriteSource
  };
});

ipcMain.handle('event:save', async (_e, { eventId, noteId, sourceId, input }) => {
  const target = findSource(sourceId);
  if (!target) throw new Error('캘린더를 선택해 주세요');
  const choice = input.categoryChoice || 'auto';
  const data = { ...input, categoryName: catName(choice) };
  let uid;
  if (eventId) {
    const ev = findEvent(eventId);
    if (!ev) throw new Error('일정을 찾지 못했습니다. 동기화 후 다시 시도해 주세요');
    if (!ev.writable) {
      // 읽기 전용 일정: 카테고리·알림만 앱에 기억
      setCategory(ev.uid, choice);
      setRemind(ev.uid, input.reminders);
      setBirthYear(ev.uid, input.birthYear);
      cache.events = decorate(cache.raw || []); pushState();
      return true;
    }
    if (ev.sourceId === sourceId) {
      await sync.updateEvent(target, ev, data, ctx);
      uid = ev.uid;
    } else { // 다른 캘린더로 옮기기
      uid = await sync.createEvent(target, data, ctx);
      await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
      setCategory(ev.uid, 'auto'); setRemind(ev.uid, undefined);
    }
  } else {
    uid = await sync.createEvent(target, data, ctx);
  }
  setCategory(uid, choice);
  setRemind(uid, input.reminders);
  setBirthYear(uid, input.birthYear);
  if (noteId) store.saveNotes(store.getNotes().filter((n) => n.id !== noteId)); // 메모 → 일정으로 옮김
  settings.lastWriteSource = sourceId;
  store.saveSettings(settings);
  await runSync();
  return true;
});

ipcMain.handle('event:delete', async (_e, eventId) => {
  const ev = findEvent(eventId);
  if (!ev) throw new Error('일정을 찾지 못했습니다');
  await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
  setCategory(ev.uid, 'auto');
  await runSync();
  return true;
});

ipcMain.handle('note:save', async (_e, { noteId, eventId, text, categoryChoice }) => {
  const list = store.getNotes();
  const now = Date.now();
  if (noteId) {
    const n = list.find((x) => x.id === noteId);
    if (n) Object.assign(n, { text, categoryChoice, updated: now });
  } else {
    list.push({ id: require('crypto').randomUUID(), text, categoryChoice, done: false, created: now, updated: now });
  }
  if (eventId) { // 일정 → 메모로 옮김: 원래 일정 삭제
    const ev = findEvent(eventId);
    if (ev) {
      if (!ev.writable) throw new Error('이 일정은 원래 캘린더에서만 지울 수 있어요');
      await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
      setCategory(ev.uid, 'auto');
    }
  }
  store.saveNotes(list);
  if (eventId) await runSync(); else pushState();
  return true;
});
ipcMain.handle('note:delete', (_e, id) => { store.saveNotes(store.getNotes().filter((n) => n.id !== id)); pushState(); return true; });
ipcMain.handle('note:toggle', (_e, id) => {
  const list = store.getNotes();
  const n = list.find((x) => x.id === id);
  let sticker = null;
  if (n) { n.done = !n.done; n.updated = Date.now(); if (n.done) sticker = awardSticker(n); store.saveNotes(list); }
  pushState();
  return { sticker };
});

ipcMain.handle('settings:get', () => ({
  ...settings,
  displays: screen.getAllDisplays().map((d, i) => ({ id: d.id, label: `모니터 ${i + 1} (${d.size.width}×${d.size.height})${d.id === screen.getPrimaryDisplay().id ? ' · 주 모니터' : ''}` })),
  sources: settings.sources.map((s) => ({ ...s, password: '', hasPassword: !!s.password })),
  dataDir: store.DIR,
  stickers: store.getStickers(),
  desktopPinAvailable: desktop.available()
}));

ipcMain.handle('settings:save', (_e, incoming) => {
  const sources = (incoming.sources || []).map((s) => {
    const old = settings.sources.find((o) => o.id === s.id) || {};
    const out = { ...s };
    delete out.hasPassword;
    out.password = s.password ? store.encrypt(s.password) : (old.password || '');
    return out;
  });
  // 설정 창에서 '바꾼 값'만 반영 (창을 연 뒤 달력에서 바꾼 목록·크기·보기 등은 그대로 유지)
  const base = incoming.__base; delete incoming.__base;
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
  const mergeChanged = (cur, out, b) => {
    const res = { ...(cur || {}) };
    for (const k of Object.keys(out || {})) {
      if (isObj(out[k]) && isObj(res[k])) res[k] = mergeChanged(res[k], out[k], b && b[k]);
      else if (!b || !same(out[k], b[k])) res[k] = out[k];
    }
    return res;
  };
  // 캘린더 연결·카테고리: 이 창에서 '바꾼 것만' 반영 (창을 연 뒤 다른 기기에서 넘어온 연결이 지워지지 않게)
  const always = {};
  if (base && Array.isArray(base.sources)) {
    const baseIds = new Set(base.sources.map((x) => x.id));
    const inIds = new Set(sources.map((x) => x.id));
    const removed = [...baseIds].filter((id) => !inIds.has(id));
    const cur = settings.sources.filter((x) => !removed.includes(x.id));
    for (const x of sources) {
      const b0 = base.sources.find((o) => o.id === x.id);
      const strip = (o) => { const c = { ...o }; delete c.password; delete c.hasPassword; return JSON.stringify(c); };
      const changed = !b0 || strip(b0) !== strip(x) || x.password !== (settings.sources.find((o) => o.id === x.id) || {}).password;
      const i = cur.findIndex((o) => o.id === x.id);
      if (i < 0) cur.push(x); else if (changed) cur[i] = x;
    }
    always.sources = cur;
    if (removed.length) cloud.markRemoved('sources', removed); // 사용자가 직접 지운 것만 다른 기기에서도 지움
  } else always.sources = sources;
  if (!base || JSON.stringify(base.categories) !== JSON.stringify(incoming.categories)) always.categories = incoming.categories;
  delete incoming.sources; delete incoming.categories;
  const next = { ...mergeChanged(settings, incoming, base), ...always };
  if (base && base.widget && incoming.widget && !same(incoming.widget.opacity, base.widget.opacity)) next.opacity = incoming.widget.opacity;
  if (!next.categories) next.categories = settings.categories;
  delete next.displays; delete next.dataDir; delete next.desktopPinAvailable; delete next.stickers;

  applySettings(next);
  return true;
});

ipcMain.handle('popup:get', () => popupQueue);
ipcMain.handle('popup:resize', (_e, h) => {
  if (!popupWin || popupWin.isDestroyed()) return;
  const wa = screen.getPrimaryDisplay().workArea;
  const height = Math.min(Math.max(120, Math.round(h)), wa.height - 32);
  popupWin.setBounds({ x: wa.x + wa.width - 440 - 16, y: wa.y + wa.height - height - 16, width: 440, height });
});
ipcMain.handle('popup:action', (_e, { key, action }) => {
  const item = popupQueue.find((p) => p.key === key);
  popupQueue = popupQueue.filter((p) => p.key !== key);
  if (item && item.event.isAlarm) {
    if (action === 'snooze') { const st = store.getReminderState(); st.alarmSnoozes = [...(st.alarmSnoozes || []), { id: item.event.alarmId, at: Date.now() + 10 * 60000 }]; store.saveReminderState(st); }
    if (action === 'open') openSettingsAt('alarm');
    showPopup();
    return;
  }
  if (item && action === 'snooze') {
    const st = store.getReminderState();
    st.snoozes = [...(st.snoozes || []), { eventId: item.event.id, at: Date.now() + 10 * 60000 }];
    store.saveReminderState(st);
  }
  if (item && action === 'open') openEditor({ eventId: item.event.id });
  showPopup();
});

// ---------------------------------------------------------------- 시작
app.on('second-instance', () => setEditing(true));
app.on('window-all-closed', (e) => e.preventDefault());
app.on('will-quit', () => globalShortcut.unregisterAll());

app.whenReady().then(() => {
  settings = store.getSettings();
  const { net } = require('electron');
  cloud.init({ store, fetch: (net && net.fetch) ? net.fetch.bind(net) : fetch, device: process.platform === 'android' ? 'phone' : 'pc', hooks: { onState: onCloudState, onRemoteChange } });
  Telemetry.init({ store, fetch: (net && net.fetch) ? net.fetch.bind(net) : fetch, device: process.platform === 'android' ? 'phone' : 'pc', version: VERSION, getSettings: () => settings, cloud });
  AI.init({ userData: app.getPath('userData'), appDir: __dirname, onProgress: aiSend });
  Updater.init({ version: VERSION, bootDir: (global.__DESKCAL_BOOT || {}).bundledDir || __dirname, appDir: __dirname, userData: app.getPath('userData'), onState: onUpdateState });
  setTimeout(() => Updater.check(), 20 * 1000);                 // 켠 뒤 20초 후 한 번
  // 업데이트 직후 첫 실행: 알려 주기
  if (settings.lastRunVersion && settings.lastRunVersion !== VERSION && Updater.newer(VERSION, settings.lastRunVersion)) {
    const v = VERSION;
    setTimeout(() => { try { new Notification({ title: 'Total Calendar 업데이트 완료', body: `v${v}로 업데이트됐어요. 바뀐 점은 설정 > 업데이트에서 볼 수 있어요.`, icon: ASSET('icon.png') }).show(); } catch {} }, 4000);
  }
  // 잘 켜졌다고 표시 (업데이트 폴더에서 실행 중이면, 다음 실행 때 실패로 보지 않음)
  setTimeout(() => { try { require('fs').writeFileSync(path.join(__dirname, '.boot'), '0'); } catch {} }, 8000);
  if (settings.lastRunVersion !== VERSION) { settings.lastRunVersion = VERSION; store.saveSettings(settings); }
  setInterval(() => Updater.check(), 6 * 60 * 60 * 1000);       // 그 뒤 6시간마다
  applyAutoStart();
  createCalendarWindow();
  buildTray();
  registerHotkeys();
  scheduleSync();
  runSync();
  setInterval(checkReminders, 30000);
  desktop.watchDesktopClicks(onDesktopClick);
  if (settings.migrateNotes) {
    // 예전 달력 안 메모(완료 안 한 것) → 바탕화면 메모장 하나로 옮김
    delete settings.migrateNotes; store.saveSettings(settings);
    const open = store.getNotes().filter((n) => !n.done && String(n.text || '').trim());
    if (open.length && !store.getStickies().length) {
      const list = [{ id: require('crypto').randomUUID(), mode: 'check', color: 'yellow', fs: 1, w: 300, h: 320, created: Date.now(),
        text: open.map((n) => '[ ] ' + String(n.text).split('\n').filter(Boolean).join(' · ')).join('\n') }];
      store.saveStickies(list);
    }
  }
  openAllStickies();
  // 자동 동기화: 절전 해제·잠금 해제 때 바로 한 번
  powerMonitor.on('resume', () => setTimeout(runSync, 4000));
  powerMonitor.on('unlock-screen', () => runSync());
  // 꺼낸 채로 1분 넘게 손대지 않으면 바탕화면으로
  setInterval(() => { if (autoEdit && editing && powerMonitor.getSystemIdleTime() >= 60 && !(editorWin && !editorWin.isDestroyed())) setEditing(false); }, 10000);
  setInterval(pushState, 60000); // 시간이 지나며 바뀌는 표시(지난 일정 등) 갱신

  let t = null;
  const relayout = () => { clearTimeout(t); t = setTimeout(createCalendarWindow, 800); };
  screen.on('display-metrics-changed', relayout);
  screen.on('display-added', relayout);
  screen.on('display-removed', relayout);

  // 개발 점검용: 화면을 이미지로 저장하고 종료
  if (process.env.DESKCAL_SHOT) {
    setTimeout(async () => {
      const img = await calWin.webContents.capturePage();
      require('fs').writeFileSync(process.env.DESKCAL_SHOT, img.toPNG());
      app.exit(0);
    }, 6000);
    return;
  }
  // 처음 실행이면 설정 창 열기
  if (settings.sources.length === 1) openSettings();
  // 이 버전에서 소개 화면을 아직 안 봤으면 한 번 보여 주기
  if (!settings.seenAbout) { settings.seenAbout = 1; store.saveSettings(settings); setTimeout(openAbout, settings.sources.length === 1 ? 4000 : 2500); }
});
