/* 업데이트 내역 (설정 > 10. 업데이트에 누적해서 보여 줌) — 새 버전을 낼 때마다 맨 위에 한 줄씩 추가
   pc: PC 버전 · phone: 휴대폰 버전 (그 업데이트가 없는 쪽은 비워 둠) · ko/en: 바뀐 점 (일본어·중국어·스페인어는 영어로 보여 줌) */
(function (r) {
  var LOG = [
    { date: '2026-11-11', pc: '', phone: '3.1.8',
      ko: ['AI 고르기: 휴대폰 내장 AI(Gemini Nano, 지원 기기) 또는 내려받는 AI 모델', '말로 일정 등록: \'장소는 ○○\', \'장소: ○○\', \'만날 곳은 ○○\'을 장소로 넣어요', '\'7시 저녁 약속\'은 저녁 7시로 잡아요', '안드로이드 8.0 이상에서 동작'],
      en: ['Choose your AI: the phone\'s built-in AI (Gemini Nano, supported devices) or a downloadable model', 'Typed events: \'place is …\' / \'place: …\' now fills the location', '\'7 o\'clock dinner\' is now 7 PM', 'Requires Android 8.0 or later'] },
    { date: '2026-11-11', pc: '', phone: '3.1.7',
      ko: ['휴대폰에서도 AI 모델을 내려받아 쓸 수 있어요 (말로 일정 등록 > AI 모델) · 글은 휴대폰 밖으로 나가지 않아요', '모델 두 가지: 정확하게(약 1.1GB) · 빠르게(약 0.5GB) · 끊기면 이어 받기', '새 앱(APK) 설치가 필요해요'],
      en: ['Download an AI model on your phone too (Add by typing > AI model) · your text never leaves the phone', 'Two models: Accurate (~1.1GB) · Fast (~0.5GB) · resumes if interrupted', 'Requires installing the new app (APK)'] },
    { date: '2026-11-11', pc: '1.9.45', phone: '3.1.6',
      ko: ['휴대폰 화면 오른쪽·아래에 보이던 흰 줄 없앰', '설정 메뉴 정렬 정리 (프리미엄 표시 ✦를 번호 옆으로)', '스킨 카드 제목·배지 줄바꿈, 카테고리 삭제 버튼 글자 깨짐 수정', '휴대폰 \'말로 일정 등록\'에서 PC용 AI 모델 안내 숨김'],
      en: ['Removed the white lines on the right and bottom of phone screens', 'Tidier settings menu (Premium ✦ mark moved next to the number)', 'Fixed wrapping in skin card titles and the category delete button', 'Hid the PC-only AI model box in the phone event assistant'] },
    { date: '2026-11-11', pc: '1.9.44', phone: '3.1.5',
      ko: ['설정 > 10. 업데이트에서 지난 업데이트 내역을 모두 볼 수 있어요'],
      en: ['See every past update in Settings > 10. Updates'] },
    { date: '2026-11-11', pc: '1.9.43', phone: '3.1.4',
      ko: ['설정 순서 정리: 1. 기본 설정 → 2. 꾸미기 → 3. 캘린더 스킨 …', '처음 설치하면 4단계 시작 안내 (언어 → 캘린더 → 기기 연동 → 사용법)', '메뉴 번호가 제목 번호와 똑같이 나와요'],
      en: ['Settings reordered: 1. General → 2. Appearance → 3. Calendar skins …', 'New 4-step welcome guide on first install (language → calendars → sync → tips)', 'Menu numbers now match the section titles'] },
    { date: '2026-11-11', pc: '1.9.42', phone: '3.1.3',
      ko: ['매일 자동 백업 (최근 7일) · 설정 > 12. 백업에서 \'어제로 되돌리기\'', '다른 기기 내용으로 바뀌기 직전에도 자동 백업', '확인 창 문구도 고른 언어로 나와요'],
      en: ['Automatic daily backups (last 7 days) · \'Restore to yesterday\' in Settings > 12. Backup', 'Also backs up right before changes from another device are applied', 'Confirmation dialogs now follow your language'] },
    { date: '2026-11-11', pc: '1.9.41', phone: '3.1.2',
      ko: ['\'내 계정으로 동기화\'를 설정 > 4. 캘린더 연결 맨 위로 옮겼어요'],
      en: ['Moved \'Sync with my account\' to the top of Settings > 4. Calendars'] },
    { date: '2026-11-11', pc: '1.9.40', phone: '3.1.1',
      ko: ['켜면 PC에서 연결한 Google·Outlook 캘린더가 휴대폰에도 떠요 (캘린더 주소 동기화, 선택)'],
      en: ['Optional calendar address sync: Google and Outlook calendars added on PC show up on your phone too'] },
    { date: '2026-11-10', pc: '1.9.39', phone: '3.1.0',
      ko: ['개인정보 처리방침·이용약관·계정 삭제 안내 추가', '앱에서 바로 계정 삭제 · 언제든 쉽게 해지', '익명 사용 통계는 기본 꺼짐'],
      en: ['Added Privacy Policy, Terms and account deletion pages', 'Delete your account right in the app · cancel anytime', 'Anonymous usage stats are now off by default'] },
    { date: '2026-11-10', pc: '1.9.38', phone: '3.0.2',
      ko: ['새 아이콘 (주황 달력)'],
      en: ['New icon (orange calendar)'] },
    { date: '2026-11-09', pc: '1.9.36', phone: '3.0.0',
      ko: ['5개 언어 지원: 한국어 · English · 日本語 · 中文 · Español', '영어 문장으로도 일정 등록'],
      en: ['5 languages: Korean · English · Japanese · Chinese · Spanish', 'Add events by typing English sentences'] }
  ];
  if (typeof module !== 'undefined' && module.exports) module.exports = LOG; else r.TC_CHANGELOG = LOG;
})(typeof window !== 'undefined' ? window : this);
