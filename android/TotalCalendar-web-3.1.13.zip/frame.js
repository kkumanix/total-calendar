// 각 화면(iframe) 안에서: 휴대폰용 표시 + PC 전용 버튼 숨김 + 길게 누르기 = 오른쪽 클릭
(function () {
  document.documentElement.classList.add('mobile');
  // 진짜 가로 화면일 때만 'land' (키보드가 떠서 화면 높이가 낮아진 것은 가로로 보지 않음)
  const land = () => { const sw = screen.width, sh = screen.height; document.documentElement.classList.toggle('land', sw > sh); };
  land();
  try { screen.orientation.addEventListener('change', land); } catch (e) {}
  window.addEventListener('orientationchange', () => setTimeout(land, 200));
  // 길게 누르면 오른쪽 클릭 메뉴(일정 미루기·삭제 등)
  let t = null, sx = 0, sy = 0;
  document.addEventListener('touchstart', (e) => {
    const p = e.touches[0]; sx = p.clientX; sy = p.clientY;
    clearTimeout(t);
    t = setTimeout(() => {
      const el = document.elementFromPoint(sx, sy);
      if (el) el.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: sx, clientY: sy, screenX: sx, screenY: sy }));
    }, 550);
  }, { passive: true });
  const cancel = (e) => { if (e.type !== 'touchmove' || Math.hypot(e.touches[0].clientX - sx, e.touches[0].clientY - sy) > 10) clearTimeout(t); };
  document.addEventListener('touchmove', cancel, { passive: true });
  document.addEventListener('touchend', cancel, { passive: true });
  // PC 말투를 휴대폰에 맞게 (설정·일정 창 글자)
  const WORDS = [[/내 PC에 저장/g, '이 기기에 저장'], [/바탕화면에 바로 미리 보여요/g, '바로 미리 보여요'], [/캘린더를 연결하고 바탕화면에 보이는 방식을 정해요/g, '캘린더를 연결하고 보이는 방식을 정해요']];
  // 다른 언어일 때도 같은 뜻으로 (번역된 PC 문구 → 휴대폰 문구)
  window.addEventListener('DOMContentLoaded', () => { try {
    const I = window.I18N;
    if (I && I.lang !== 'ko') [['내 PC에 저장', '이 기기에 저장'], ['내 PC', '내 휴대폰']].forEach(([a, b]) => { const x = I.t(a), y = I.t(b); if (x !== y) WORDS.push([new RegExp(x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), y]); });
  } catch {} });
  const fixText = (root) => {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n; while ((n = w.nextNode())) { let t = n.nodeValue, o = t; for (const [a, b] of WORDS) t = t.replace(a, b); if (t !== o) n.nodeValue = t; }
  };
  window.addEventListener('DOMContentLoaded', () => { fixText(document.body); new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((x) => x.nodeType === 1 && fixText(x)))).observe(document.body, { childList: true, subtree: true }); });
  // 달력 화면에 '더보기(⋯)' 버튼 — PC의 트레이 메뉴
  window.addEventListener('DOMContentLoaded', () => {
    if (!/calendar\.html/.test(location.pathname)) return;
    const b = document.createElement('button');
    b.id = 'mMore'; b.type = 'button'; b.className = 'ib'; b.setAttribute('aria-label', window.I18N ? window.I18N.t('더보기') : '더보기'); b.textContent = '⋯';
    b.onclick = () => parent.__showMoreMenu && parent.__showMoreMenu();
    const tb = document.getElementById('toolbar');
    (tb || document.body).appendChild(b);
  });
})();
