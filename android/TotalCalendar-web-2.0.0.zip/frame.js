// 각 화면(iframe) 안에서: 휴대폰용 표시 + PC 전용 버튼 숨김 + 길게 누르기 = 오른쪽 클릭
(function () {
  document.documentElement.classList.add('mobile');
  // 길게 누르면 오른쪽 클릭 메뉴(일정 미루기·삭제 등)
  let t = null, sx = 0, sy = 0;
  document.addEventListener('touchstart', (e) => {
    const p = e.touches[0]; sx = p.clientX; sy = p.clientY;
    clearTimeout(t);
    t = setTimeout(() => {
      const el = document.elementFromPoint(sx, sy);
      if (el) el.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: sx, clientY: sy, screenX: sx, screenY: sy }));
    }, 550);
  }, { passive: true });
  const cancel = (e) => { if (e.type !== 'touchmove' || Math.hypot(e.touches[0].clientX - sx, e.touches[0].clientY - sy) > 10) clearTimeout(t); };
  document.addEventListener('touchmove', cancel, { passive: true });
  document.addEventListener('touchend', cancel, { passive: true });
  // 달력 화면에 '더보기(⋯)' 버튼 — PC의 트레이 메뉴
  window.addEventListener('DOMContentLoaded', () => {
    if (!/calendar\.html/.test(location.pathname)) return;
    const b = document.createElement('button');
    b.id = 'mMore'; b.type = 'button'; b.className = 'ib'; b.setAttribute('aria-label', '더보기'); b.textContent = '⋯';
    b.onclick = () => parent.__showMoreMenu && parent.__showMoreMenu();
    const tb = document.getElementById('toolbar');
    (tb || document.body).appendChild(b);
  });
})();
