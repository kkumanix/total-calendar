(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __esm = (fn, res, err2) => function __init() {
    if (err2) throw err2[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err2 = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require3() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/base64-js/index.js
  var require_base64_js = __commonJS({
    "node_modules/base64-js/index.js"(exports) {
      "use strict";
      init_globals();
      exports.byteLength = byteLength;
      exports.toByteArray = toByteArray;
      exports.fromByteArray = fromByteArray;
      var lookup = [];
      var revLookup = [];
      var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
      var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for (i = 0, len = code.length; i < len; ++i) {
        lookup[i] = code[i];
        revLookup[code.charCodeAt(i)] = i;
      }
      var i;
      var len;
      revLookup["-".charCodeAt(0)] = 62;
      revLookup["_".charCodeAt(0)] = 63;
      function getLens(b64) {
        var len2 = b64.length;
        if (len2 % 4 > 0) {
          throw new Error("Invalid string. Length must be a multiple of 4");
        }
        var validLen = b64.indexOf("=");
        if (validLen === -1) validLen = len2;
        var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
        return [validLen, placeHoldersLen];
      }
      function byteLength(b64) {
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function _byteLength(b64, validLen, placeHoldersLen) {
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function toByteArray(b64) {
        var tmp;
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
        var curByte = 0;
        var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
        var i2;
        for (i2 = 0; i2 < len2; i2 += 4) {
          tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
          arr[curByte++] = tmp >> 16 & 255;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 2) {
          tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 1) {
          tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        return arr;
      }
      function tripletToBase64(num) {
        return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
      }
      function encodeChunk(uint8, start, end) {
        var tmp;
        var output = [];
        for (var i2 = start; i2 < end; i2 += 3) {
          tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
          output.push(tripletToBase64(tmp));
        }
        return output.join("");
      }
      function fromByteArray(uint8) {
        var tmp;
        var len2 = uint8.length;
        var extraBytes = len2 % 3;
        var parts = [];
        var maxChunkLength = 16383;
        for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
          parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
        }
        if (extraBytes === 1) {
          tmp = uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
          );
        } else if (extraBytes === 2) {
          tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
          parts.push(
            lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
          );
        }
        return parts.join("");
      }
    }
  });

  // node_modules/ieee754/index.js
  var require_ieee754 = __commonJS({
    "node_modules/ieee754/index.js"(exports) {
      init_globals();
      exports.read = function(buffer, offset, isLE, mLen, nBytes) {
        var e, m2;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var nBits = -7;
        var i = isLE ? nBytes - 1 : 0;
        var d = isLE ? -1 : 1;
        var s = buffer[offset + i];
        i += d;
        e = s & (1 << -nBits) - 1;
        s >>= -nBits;
        nBits += eLen;
        for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        m2 = e & (1 << -nBits) - 1;
        e >>= -nBits;
        nBits += mLen;
        for (; nBits > 0; m2 = m2 * 256 + buffer[offset + i], i += d, nBits -= 8) {
        }
        if (e === 0) {
          e = 1 - eBias;
        } else if (e === eMax) {
          return m2 ? NaN : (s ? -1 : 1) * Infinity;
        } else {
          m2 = m2 + Math.pow(2, mLen);
          e = e - eBias;
        }
        return (s ? -1 : 1) * m2 * Math.pow(2, e - mLen);
      };
      exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
        var e, m2, c;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
        var i = isLE ? 0 : nBytes - 1;
        var d = isLE ? 1 : -1;
        var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
        value = Math.abs(value);
        if (isNaN(value) || value === Infinity) {
          m2 = isNaN(value) ? 1 : 0;
          e = eMax;
        } else {
          e = Math.floor(Math.log(value) / Math.LN2);
          if (value * (c = Math.pow(2, -e)) < 1) {
            e--;
            c *= 2;
          }
          if (e + eBias >= 1) {
            value += rt / c;
          } else {
            value += rt * Math.pow(2, 1 - eBias);
          }
          if (value * c >= 2) {
            e++;
            c /= 2;
          }
          if (e + eBias >= eMax) {
            m2 = 0;
            e = eMax;
          } else if (e + eBias >= 1) {
            m2 = (value * c - 1) * Math.pow(2, mLen);
            e = e + eBias;
          } else {
            m2 = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e = 0;
          }
        }
        for (; mLen >= 8; buffer[offset + i] = m2 & 255, i += d, m2 /= 256, mLen -= 8) {
        }
        e = e << mLen | m2;
        eLen += mLen;
        for (; eLen > 0; buffer[offset + i] = e & 255, i += d, e /= 256, eLen -= 8) {
        }
        buffer[offset + i - d] |= s * 128;
      };
    }
  });

  // node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "node_modules/buffer/index.js"(exports) {
      "use strict";
      init_globals();
      var base64 = require_base64_js();
      var ieee754 = require_ieee754();
      var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer3;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      var K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer3.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer3.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error(
          "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
        );
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e) {
          return false;
        }
      }
      Object.defineProperty(Buffer3.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer3.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this)) return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function Buffer3(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError(
              'The "string" argument must be of type string. Received type number'
            );
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer3.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
          );
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError(
            'The "value" argument must not be of type number. Received type number'
          );
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer3.from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b) return b;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer3.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      Buffer3.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer3.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer3, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer3.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer3.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer3.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer3.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i = 0; i < length; i += 1) {
          buf[i] = array[i] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer3.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer3.alloc(+length);
      }
      Buffer3.isBuffer = function isBuffer(b) {
        return b != null && b._isBuffer === true && b !== Buffer3.prototype;
      };
      Buffer3.compare = function compare(a, b) {
        if (isInstance(a, Uint8Array)) a = Buffer3.from(a, a.offset, a.byteLength);
        if (isInstance(b, Uint8Array)) b = Buffer3.from(b, b.offset, b.byteLength);
        if (!Buffer3.isBuffer(a) || !Buffer3.isBuffer(b)) {
          throw new TypeError(
            'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
          );
        }
        if (a === b) return 0;
        let x = a.length;
        let y = b.length;
        for (let i = 0, len = Math.min(x, y); i < len; ++i) {
          if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      Buffer3.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer3.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer3.alloc(0);
        }
        let i;
        if (length === void 0) {
          length = 0;
          for (i = 0; i < list.length; ++i) {
            length += list[i].length;
          }
        }
        const buffer = Buffer3.allocUnsafe(length);
        let pos = 0;
        for (i = 0; i < list.length; ++i) {
          let buf = list[i];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer.length) {
              if (!Buffer3.isBuffer(buf)) buf = Buffer3.from(buf);
              buf.copy(buffer, pos);
            } else {
              Uint8Array.prototype.set.call(
                buffer,
                buf,
                pos
              );
            }
          } else if (!Buffer3.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer, pos);
          }
          pos += buf.length;
        }
        return buffer;
      };
      function byteLength(string, encoding) {
        if (Buffer3.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError(
            'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
          );
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0) return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.byteLength = byteLength;
      function slowToString(encoding, start, end) {
        let loweredCase = false;
        if (start === void 0 || start < 0) {
          start = 0;
        }
        if (start > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start >>>= 0;
        if (end <= start) {
          return "";
        }
        if (!encoding) encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start, end);
            case "ascii":
              return asciiSlice(this, start, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start, end);
            case "base64":
              return base64Slice(this, start, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start, end);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.prototype._isBuffer = true;
      function swap(b, n, m2) {
        const i = b[n];
        b[n] = b[m2];
        b[m2] = i;
      }
      Buffer3.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i = 0; i < len; i += 2) {
          swap(this, i, i + 1);
        }
        return this;
      };
      Buffer3.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i = 0; i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      };
      Buffer3.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i = 0; i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      };
      Buffer3.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0) return "";
        if (arguments.length === 0) return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer3.prototype.toLocaleString = Buffer3.prototype.toString;
      Buffer3.prototype.equals = function equals(b) {
        if (!Buffer3.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
        if (this === b) return true;
        return Buffer3.compare(this, b) === 0;
      };
      Buffer3.prototype.inspect = function inspect() {
        let str = "";
        const max = exports.INSPECT_MAX_BYTES;
        str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max) str += " ... ";
        return "<Buffer " + str + ">";
      };
      if (customInspectSymbol) {
        Buffer3.prototype[customInspectSymbol] = Buffer3.prototype.inspect;
      }
      Buffer3.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer3.from(target, target.offset, target.byteLength);
        }
        if (!Buffer3.isBuffer(target)) {
          throw new TypeError(
            'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
          );
        }
        if (start === void 0) {
          start = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start >= end) {
          return 1;
        }
        start >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target) return 0;
        let x = thisEnd - thisStart;
        let y = end - start;
        const len = Math.min(x, y);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start, end);
        for (let i = 0; i < len; ++i) {
          if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
        if (buffer.length === 0) return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer.length - 1;
        }
        if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
        if (byteOffset >= buffer.length) {
          if (dir) return -1;
          else byteOffset = buffer.length - 1;
        } else if (byteOffset < 0) {
          if (dir) byteOffset = 0;
          else return -1;
        }
        if (typeof val === "string") {
          val = Buffer3.from(val, encoding);
        }
        if (Buffer3.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i2) {
          if (indexSize === 1) {
            return buf[i2];
          } else {
            return buf.readUInt16BE(i2 * indexSize);
          }
        }
        let i;
        if (dir) {
          let foundIndex = -1;
          for (i = byteOffset; i < arrLength; i++) {
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
              if (foundIndex === -1) foundIndex = i;
              if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1) i -= i - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
          for (i = byteOffset; i >= 0; i--) {
            let found = true;
            for (let j = 0; j < valLength; j++) {
              if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
              }
            }
            if (found) return i;
          }
        }
        return -1;
      }
      Buffer3.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer3.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer3.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i;
        for (i = 0; i < length; ++i) {
          const parsed = parseInt(string.substr(i * 2, 2), 16);
          if (numberIsNaN(parsed)) return i;
          buf[offset + i] = parsed;
        }
        return i;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer3.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0) encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error(
            "Buffer.write(string, encoding, offset[, length]) is no longer supported"
          );
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining) length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding) encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer3.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start, end) {
        if (start === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start, end));
        }
      }
      function utf8Slice(buf, start, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i = start;
        while (i < end) {
          const firstByte = buf[i];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                fourthByte = buf[i + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      var MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i = 0;
        while (i < len) {
          res += String.fromCharCode.apply(
            String,
            codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
          );
        }
        return res;
      }
      function asciiSlice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i]);
        }
        return ret;
      }
      function hexSlice(buf, start, end) {
        const len = buf.length;
        if (!start || start < 0) start = 0;
        if (!end || end < 0 || end > len) end = len;
        let out = "";
        for (let i = start; i < end; ++i) {
          out += hexSliceLookupTable[buf[i]];
        }
        return out;
      }
      function utf16leSlice(buf, start, end) {
        const bytes = buf.slice(start, end);
        let res = "";
        for (let i = 0; i < bytes.length - 1; i += 2) {
          res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
        }
        return res;
      }
      Buffer3.prototype.slice = function slice(start, end) {
        const len = this.length;
        start = ~~start;
        end = end === void 0 ? len : ~~end;
        if (start < 0) {
          start += len;
          if (start < 0) start = 0;
        } else if (start > len) {
          start = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0) end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start) end = start;
        const newBuf = this.subarray(start, end);
        Object.setPrototypeOf(newBuf, Buffer3.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
        if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer3.prototype.readUintLE = Buffer3.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUintBE = Buffer3.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUint8 = Buffer3.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer3.prototype.readUint16LE = Buffer3.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer3.prototype.readUint16BE = Buffer3.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer3.prototype.readUint32LE = Buffer3.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer3.prototype.readUint32BE = Buffer3.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer3.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last3 = this[offset + 7];
        if (first === void 0 || last3 === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last3 * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer3.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last3 = this[offset + 7];
        if (first === void 0 || last3 === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last3;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer3.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let i = byteLength2;
        let mul = 1;
        let val = this[offset + --i];
        while (i > 0 && (mul *= 256)) {
          val += this[offset + --i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128)) return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer3.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer3.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer3.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last3 = this[offset + 7];
        if (first === void 0 || last3 === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last3 << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer3.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last3 = this[offset + 7];
        if (first === void 0 || last3 === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + // Overflow
        this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last3);
      });
      Buffer3.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, true, 23, 4);
      };
      Buffer3.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, false, 23, 4);
      };
      Buffer3.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, true, 52, 8);
      };
      Buffer3.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer3.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
      }
      Buffer3.prototype.writeUintLE = Buffer3.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUintBE = Buffer3.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUint8 = Buffer3.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeUint16LE = Buffer3.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeUint16BE = Buffer3.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeUint32LE = Buffer3.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeUint32BE = Buffer3.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer3.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
        if (value < 0) value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer3.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0) value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer3.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
        if (offset < 0) throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
        }
        ieee754.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer3.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
        }
        ieee754.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer3.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer3.prototype.copy = function copy(target, targetStart, start, end) {
        if (!Buffer3.isBuffer(target)) throw new TypeError("argument should be a Buffer");
        if (!start) start = 0;
        if (!end && end !== 0) end = this.length;
        if (targetStart >= target.length) targetStart = target.length;
        if (!targetStart) targetStart = 0;
        if (end > 0 && end < start) end = start;
        if (end === start) return 0;
        if (target.length === 0 || this.length === 0) return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
        if (end < 0) throw new RangeError("sourceEnd out of bounds");
        if (end > this.length) end = this.length;
        if (target.length - targetStart < end - start) {
          end = target.length - targetStart + start;
        }
        const len = end - start;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start, end);
        } else {
          Uint8Array.prototype.set.call(
            target,
            this.subarray(start, end),
            targetStart
          );
        }
        return len;
      };
      Buffer3.prototype.fill = function fill(val, start, end, encoding) {
        if (typeof val === "string") {
          if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer3.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start < 0 || this.length < start || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start) {
          return this;
        }
        start = start >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val) val = 0;
        let i;
        if (typeof val === "number") {
          for (i = start; i < end; ++i) {
            this[i] = val;
          }
        } else {
          const bytes = Buffer3.isBuffer(val) ? val : Buffer3.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i = 0; i < end - start; ++i) {
            this[i + start] = bytes[i % len];
          }
        }
        return this;
      };
      var errors = {};
      function E(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E(
        "ERR_BUFFER_OUT_OF_BOUNDS",
        function(name) {
          if (name) {
            return `${name} is outside of buffer bounds`;
          }
          return "Attempt to access memory outside buffer bounds";
        },
        RangeError
      );
      E(
        "ERR_INVALID_ARG_TYPE",
        function(name, actual) {
          return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
        },
        TypeError
      );
      E(
        "ERR_OUT_OF_RANGE",
        function(str, range, input) {
          let msg = `The value of "${str}" is out of range.`;
          let received = input;
          if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
            received = addNumericalSeparator(String(input));
          } else if (typeof input === "bigint") {
            received = String(input);
            if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
              received = addNumericalSeparator(received);
            }
            received += "n";
          }
          msg += ` It must be ${range}. Received ${received}`;
          return msg;
        },
        RangeError
      );
      function addNumericalSeparator(val) {
        let res = "";
        let i = val.length;
        const start = val[0] === "-" ? 1 : 0;
        for (; i >= start + 4; i -= 3) {
          res = `_${val.slice(i - 3, i)}${res}`;
        }
        return `${val.slice(0, i)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n = typeof min === "bigint" ? "n" : "";
          let range;
          if (byteLength2 > 3) {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
            } else {
              range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
            }
          } else {
            range = `>= ${min}${n} and <= ${max}${n}`;
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(
          type || "offset",
          `>= ${type ? 1 : 0} and <= ${length}`,
          value
        );
      }
      var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str) {
        str = str.split("=")[0];
        str = str.trim().replace(INVALID_BASE64_RE, "");
        if (str.length < 2) return "";
        while (str.length % 4 !== 0) {
          str = str + "=";
        }
        return str;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i = 0; i < length; ++i) {
          codePoint = string.charCodeAt(i);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              } else if (i + 1 === length) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0) break;
            bytes.push(
              codePoint >> 6 | 192,
              codePoint & 63 | 128
            );
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0) break;
            bytes.push(
              codePoint >> 12 | 224,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0) break;
            bytes.push(
              codePoint >> 18 | 240,
              codePoint >> 12 & 63 | 128,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str) {
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          byteArray.push(str.charCodeAt(i) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str, units) {
        let c, hi, lo;
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          if ((units -= 2) < 0) break;
          c = str.charCodeAt(i);
          hi = c >> 8;
          lo = c % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str) {
        return base64.toByteArray(base64clean(str));
      }
      function blitBuffer(src, dst, offset, length) {
        let i;
        for (i = 0; i < length; ++i) {
          if (i + offset >= dst.length || i >= src.length) break;
          dst[i + offset] = src[i];
        }
        return i;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      var hexSliceLookupTable = (function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i = 0; i < 16; ++i) {
          const i16 = i * 16;
          for (let j = 0; j < 16; ++j) {
            table[i16 + j] = alphabet[i] + alphabet[j];
          }
        }
        return table;
      })();
      function defineBigIntMethod(fn) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    }
  });

  // mobile/shim/globals.js
  var import_buffer, process, global;
  var init_globals = __esm({
    "mobile/shim/globals.js"() {
      import_buffer = __toESM(require_buffer());
      process = { env: {}, platform: "android", arch: "arm64", versions: { node: "", electron: "mobile" }, execPath: "", argv: [], nextTick: (f2, ...a) => Promise.resolve().then(() => f2(...a)), cwd: () => "/", on() {
      }, exit() {
      } };
      global = globalThis;
    }
  });

  // node_modules/@capacitor/core/dist/index.js
  var ExceptionCode, CapacitorException, getPlatformId, createCapacitor, initCapacitorGlobal, Capacitor, registerPlugin, WebPlugin, encode, decode, CapacitorCookiesPluginWeb, CapacitorCookies, readBlobAsBase64, normalizeHttpHeaders, buildUrlParams, buildRequestInit, CapacitorHttpPluginWeb, CapacitorHttp, SystemBarsStyle, SystemBarType, SystemBarsPluginWeb, SystemBars;
  var init_dist = __esm({
    "node_modules/@capacitor/core/dist/index.js"() {
      init_globals();
      (function(ExceptionCode2) {
        ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
        ExceptionCode2["Unavailable"] = "UNAVAILABLE";
      })(ExceptionCode || (ExceptionCode = {}));
      CapacitorException = class extends Error {
        constructor(message, code, data) {
          super(message);
          this.message = message;
          this.code = code;
          this.data = data;
        }
      };
      getPlatformId = (win) => {
        var _a, _b;
        if (win === null || win === void 0 ? void 0 : win.androidBridge) {
          return "android";
        } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
          return "ios";
        } else {
          return "web";
        }
      };
      createCapacitor = (win) => {
        const capCustomPlatform = win.CapacitorCustomPlatform || null;
        const cap = win.Capacitor || {};
        const Plugins = cap.Plugins = cap.Plugins || {};
        const getPlatform = () => {
          return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
        };
        const isNativePlatform = () => getPlatform() !== "web";
        const isPluginAvailable = (pluginName) => {
          const plugin = registeredPlugins.get(pluginName);
          if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            return true;
          }
          if (getPluginHeader(pluginName)) {
            return true;
          }
          return false;
        };
        const getPluginHeader = (pluginName) => {
          var _a;
          return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
        };
        const handleError = (err2) => win.console.error(err2);
        const registeredPlugins = /* @__PURE__ */ new Map();
        const registerPlugin2 = (pluginName, jsImplementations = {}) => {
          const registeredPlugin = registeredPlugins.get(pluginName);
          if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
          }
          const platform2 = getPlatform();
          const pluginHeader = getPluginHeader(pluginName);
          let jsImplementation;
          const loadPluginImplementation = async () => {
            if (!jsImplementation && platform2 in jsImplementations) {
              jsImplementation = typeof jsImplementations[platform2] === "function" ? jsImplementation = await jsImplementations[platform2]() : jsImplementation = jsImplementations[platform2];
            } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
              jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
            }
            return jsImplementation;
          };
          const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
              const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m2) => prop === m2.name);
              if (methodHeader) {
                if (methodHeader.rtype === "promise") {
                  return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                } else {
                  return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                }
              } else if (impl) {
                return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
              }
            } else if (impl) {
              return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            } else {
              throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform2}`, ExceptionCode.Unimplemented);
            }
          };
          const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
              const p = loadPluginImplementation().then((impl) => {
                const fn = createPluginMethod(impl, prop);
                if (fn) {
                  const p2 = fn(...args);
                  remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
                  return p2;
                } else {
                  throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform2}`, ExceptionCode.Unimplemented);
                }
              });
              if (prop === "addListener") {
                p.remove = async () => remove();
              }
              return p;
            };
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, "name", {
              value: prop,
              writable: false,
              configurable: false
            });
            return wrapper;
          };
          const addListener = createPluginMethodWrapper("addListener");
          const removeListener = createPluginMethodWrapper("removeListener");
          const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback);
            const remove = async () => {
              const callbackId = await call;
              removeListener({
                eventName,
                callbackId
              }, callback);
            };
            const p = new Promise((resolve) => call.then(() => resolve({ remove })));
            p.remove = async () => {
              console.warn(`Using addListener() without 'await' is deprecated.`);
              await remove();
            };
            return p;
          };
          const proxy = new Proxy({}, {
            get(_, prop) {
              switch (prop) {
                // https://github.com/facebook/react/issues/20030
                case "$$typeof":
                  return void 0;
                case "toJSON":
                  return () => ({});
                case "addListener":
                  return pluginHeader ? addListenerNative : addListener;
                case "removeListener":
                  return removeListener;
                default:
                  return createPluginMethodWrapper(prop);
              }
            }
          });
          Plugins[pluginName] = proxy;
          registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform2] : []])
          });
          return proxy;
        };
        if (!cap.convertFileSrc) {
          cap.convertFileSrc = (filePath) => filePath;
        }
        cap.getPlatform = getPlatform;
        cap.handleError = handleError;
        cap.isNativePlatform = isNativePlatform;
        cap.isPluginAvailable = isPluginAvailable;
        cap.registerPlugin = registerPlugin2;
        cap.Exception = CapacitorException;
        cap.DEBUG = !!cap.DEBUG;
        cap.isLoggingEnabled = !!cap.isLoggingEnabled;
        return cap;
      };
      initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
      Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      registerPlugin = Capacitor.registerPlugin;
      WebPlugin = class {
        constructor() {
          this.listeners = {};
          this.retainedEventArguments = {};
          this.windowListeners = {};
        }
        addListener(eventName, listenerFunc) {
          let firstListener = false;
          const listeners2 = this.listeners[eventName];
          if (!listeners2) {
            this.listeners[eventName] = [];
            firstListener = true;
          }
          this.listeners[eventName].push(listenerFunc);
          const windowListener = this.windowListeners[eventName];
          if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
          }
          if (firstListener) {
            this.sendRetainedArgumentsForEvent(eventName);
          }
          const remove = async () => this.removeListener(eventName, listenerFunc);
          const p = Promise.resolve({ remove });
          return p;
        }
        async removeAllListeners() {
          this.listeners = {};
          for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
          }
          this.windowListeners = {};
        }
        notifyListeners(eventName, data, retainUntilConsumed) {
          const listeners2 = this.listeners[eventName];
          if (!listeners2) {
            if (retainUntilConsumed) {
              let args = this.retainedEventArguments[eventName];
              if (!args) {
                args = [];
              }
              args.push(data);
              this.retainedEventArguments[eventName] = args;
            }
            return;
          }
          listeners2.forEach((listener) => listener(data));
        }
        hasListeners(eventName) {
          var _a;
          return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
        }
        registerWindowListener(windowEventName, pluginEventName) {
          this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: (event) => {
              this.notifyListeners(pluginEventName, event);
            }
          };
        }
        unimplemented(msg = "not implemented") {
          return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
        }
        unavailable(msg = "not available") {
          return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
        }
        async removeListener(eventName, listenerFunc) {
          const listeners2 = this.listeners[eventName];
          if (!listeners2) {
            return;
          }
          const index = listeners2.indexOf(listenerFunc);
          if (index !== -1) {
            this.listeners[eventName].splice(index, 1);
          }
          if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
          }
        }
        addWindowListener(handle) {
          window.addEventListener(handle.windowEventName, handle.handler);
          handle.registered = true;
        }
        removeWindowListener(handle) {
          if (!handle) {
            return;
          }
          window.removeEventListener(handle.windowEventName, handle.handler);
          handle.registered = false;
        }
        sendRetainedArgumentsForEvent(eventName) {
          const args = this.retainedEventArguments[eventName];
          if (!args) {
            return;
          }
          delete this.retainedEventArguments[eventName];
          args.forEach((arg) => {
            this.notifyListeners(eventName, arg);
          });
        }
      };
      encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
      decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
      CapacitorCookiesPluginWeb = class extends WebPlugin {
        async getCookies() {
          const cookies = document.cookie;
          const cookieMap = {};
          cookies.split(";").forEach((cookie) => {
            if (cookie.length <= 0)
              return;
            let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
            key = decode(key).trim();
            value = decode(value).trim();
            cookieMap[key] = value;
          });
          return cookieMap;
        }
        async setCookie(options) {
          try {
            const encodedKey = encode(options.key);
            const encodedValue = encode(options.value);
            const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
            const path = (options.path || "/").replace("path=", "");
            const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
            document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async deleteCookie(options) {
          try {
            document.cookie = `${options.key}=; Max-Age=0`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearCookies() {
          try {
            const cookies = document.cookie.split(";") || [];
            for (const cookie of cookies) {
              document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
            }
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearAllCookies() {
          try {
            await this.clearCookies();
          } catch (error) {
            return Promise.reject(error);
          }
        }
      };
      CapacitorCookies = registerPlugin("CapacitorCookies", {
        web: () => new CapacitorCookiesPluginWeb()
      });
      readBlobAsBase64 = async (blob) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const base64String = reader.result;
          resolve(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
      });
      normalizeHttpHeaders = (headers = {}) => {
        const originalKeys = Object.keys(headers);
        const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
        const normalized = loweredKeys.reduce((acc, key, index) => {
          acc[key] = headers[originalKeys[index]];
          return acc;
        }, {});
        return normalized;
      };
      buildUrlParams = (params, shouldEncode = true) => {
        if (!params)
          return null;
        const output = Object.entries(params).reduce((accumulator, entry) => {
          const [key, value] = entry;
          let encodedValue;
          let item;
          if (Array.isArray(value)) {
            item = "";
            value.forEach((str) => {
              encodedValue = shouldEncode ? encodeURIComponent(str) : str;
              item += `${key}=${encodedValue}&`;
            });
            item.slice(0, -1);
          } else {
            encodedValue = shouldEncode ? encodeURIComponent(value) : value;
            item = `${key}=${encodedValue}`;
          }
          return `${accumulator}&${item}`;
        }, "");
        return output.substr(1);
      };
      buildRequestInit = (options, extra = {}) => {
        const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
        const headers = normalizeHttpHeaders(options.headers);
        const type = headers["content-type"] || "";
        if (typeof options.data === "string") {
          output.body = options.data;
        } else if (type.includes("application/x-www-form-urlencoded")) {
          const params = new URLSearchParams();
          for (const [key, value] of Object.entries(options.data || {})) {
            params.set(key, value);
          }
          output.body = params.toString();
        } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
          const form = new FormData();
          if (options.data instanceof FormData) {
            options.data.forEach((value, key) => {
              form.append(key, value);
            });
          } else {
            for (const key of Object.keys(options.data)) {
              form.append(key, options.data[key]);
            }
          }
          output.body = form;
          const headers2 = new Headers(output.headers);
          headers2.delete("content-type");
          output.headers = headers2;
        } else if (type.includes("application/json") || typeof options.data === "object") {
          output.body = JSON.stringify(options.data);
        }
        return output;
      };
      CapacitorHttpPluginWeb = class extends WebPlugin {
        /**
         * Perform an Http request given a set of options
         * @param options Options to build the HTTP request
         */
        async request(options) {
          const requestInit = buildRequestInit(options, options.webFetchExtra);
          const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
          const url = urlParams ? `${options.url}?${urlParams}` : options.url;
          const response = await fetch(url, requestInit);
          const contentType = response.headers.get("content-type") || "";
          let { responseType = "text" } = response.ok ? options : {};
          if (contentType.includes("application/json")) {
            responseType = "json";
          }
          let data;
          let blob;
          switch (responseType) {
            case "arraybuffer":
            case "blob":
              blob = await response.blob();
              data = await readBlobAsBase64(blob);
              break;
            case "json":
              data = await response.json();
              break;
            case "document":
            case "text":
            default:
              data = await response.text();
          }
          const headers = {};
          response.headers.forEach((value, key) => {
            headers[key] = value;
          });
          return {
            data,
            headers,
            status: response.status,
            url: response.url
          };
        }
        /**
         * Perform an Http GET request given a set of options
         * @param options Options to build the HTTP request
         */
        async get(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
        }
        /**
         * Perform an Http POST request given a set of options
         * @param options Options to build the HTTP request
         */
        async post(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
        }
        /**
         * Perform an Http PUT request given a set of options
         * @param options Options to build the HTTP request
         */
        async put(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
        }
        /**
         * Perform an Http PATCH request given a set of options
         * @param options Options to build the HTTP request
         */
        async patch(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
        }
        /**
         * Perform an Http DELETE request given a set of options
         * @param options Options to build the HTTP request
         */
        async delete(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
        }
      };
      CapacitorHttp = registerPlugin("CapacitorHttp", {
        web: () => new CapacitorHttpPluginWeb()
      });
      (function(SystemBarsStyle2) {
        SystemBarsStyle2["Dark"] = "DARK";
        SystemBarsStyle2["Light"] = "LIGHT";
        SystemBarsStyle2["Default"] = "DEFAULT";
      })(SystemBarsStyle || (SystemBarsStyle = {}));
      (function(SystemBarType2) {
        SystemBarType2["StatusBar"] = "StatusBar";
        SystemBarType2["NavigationBar"] = "NavigationBar";
      })(SystemBarType || (SystemBarType = {}));
      SystemBarsPluginWeb = class extends WebPlugin {
        async setStyle() {
          this.unavailable("not available for web");
        }
        async setAnimation() {
          this.unavailable("not available for web");
        }
        async show() {
          this.unavailable("not available for web");
        }
        async hide() {
          this.unavailable("not available for web");
        }
      };
      SystemBars = registerPlugin("SystemBars", {
        web: () => new SystemBarsPluginWeb()
      });
    }
  });

  // mobile/http.js
  function bodyText(b) {
    if (b == null) return null;
    if (typeof b === "string") return b;
    if (b instanceof URLSearchParams) return b.toString();
    if (b instanceof ArrayBuffer) return new TextDecoder().decode(new Uint8Array(b));
    if (ArrayBuffer.isView(b)) return new TextDecoder().decode(b);
    return String(b);
  }
  async function nativeFetch(input, init3 = {}) {
    const req = typeof Request !== "undefined" && input instanceof Request ? input : null;
    const url = req ? req.url : String(input);
    if (!/^https?:/i.test(url) || /^https?:\/\/localhost/i.test(url)) return webFetch(input, init3);
    const method = String(init3.method || req && req.method || "GET").toUpperCase();
    const headers = {};
    new Headers(init3.headers || req && req.headers || {}).forEach((v, k) => {
      headers[k] = v;
    });
    let body = bodyText(init3.body);
    if (body == null && req && !["GET", "HEAD"].includes(method)) body = await req.text();
    let r;
    try {
      r = await NativeHttp.request({ url, method, headers, body, followRedirects: init3.redirect !== "manual" });
    } catch (e) {
      throw new TypeError("fetch failed: " + (e && e.message ? e.message : e));
    }
    const h = new Headers();
    Object.entries(r.headers || {}).forEach(([k, v]) => {
      try {
        h.append(k, String(v));
      } catch {
      }
    });
    const status2 = r.status >= 200 && r.status <= 599 ? r.status : 599;
    const res = new Response([204, 205, 304].includes(status2) || method === "HEAD" ? null : r.body || "", { status: status2, statusText: r.statusText || "", headers: h });
    try {
      Object.defineProperty(res, "url", { value: r.url || url });
    } catch {
    }
    return res;
  }
  var NativeHttp, webFetch;
  var init_http = __esm({
    "mobile/http.js"() {
      init_globals();
      init_dist();
      NativeHttp = registerPlugin("NativeHttp");
      webFetch = window.fetch.bind(window);
      if (Capacitor.isNativePlatform()) {
        window.fetch = nativeFetch;
        globalThis.fetch = nativeFetch;
      }
    }
  });

  // node_modules/@capacitor/app/dist/esm/definitions.js
  var init_definitions = __esm({
    "node_modules/@capacitor/app/dist/esm/definitions.js"() {
      init_globals();
    }
  });

  // node_modules/@capacitor/app/dist/esm/web.js
  var web_exports = {};
  __export(web_exports, {
    AppWeb: () => AppWeb
  });
  var AppWeb;
  var init_web = __esm({
    "node_modules/@capacitor/app/dist/esm/web.js"() {
      init_globals();
      init_dist();
      AppWeb = class extends WebPlugin {
        constructor() {
          super();
          this.handleVisibilityChange = () => {
            const data = {
              isActive: document.hidden !== true
            };
            this.notifyListeners("appStateChange", data);
            if (document.hidden) {
              this.notifyListeners("pause", null);
            } else {
              this.notifyListeners("resume", null);
            }
          };
          document.addEventListener("visibilitychange", this.handleVisibilityChange, false);
        }
        exitApp() {
          throw this.unimplemented("Not implemented on web.");
        }
        async getInfo() {
          throw this.unimplemented("Not implemented on web.");
        }
        async getLaunchUrl() {
          return { url: "" };
        }
        async getState() {
          return { isActive: document.hidden !== true };
        }
        async minimizeApp() {
          throw this.unimplemented("Not implemented on web.");
        }
        async toggleBackButtonHandler() {
          throw this.unimplemented("Not implemented on web.");
        }
        async getAppLanguage() {
          return {
            value: navigator.language.split("-")[0].toLowerCase()
          };
        }
      };
    }
  });

  // node_modules/@capacitor/app/dist/esm/index.js
  var App;
  var init_esm = __esm({
    "node_modules/@capacitor/app/dist/esm/index.js"() {
      init_globals();
      init_dist();
      init_definitions();
      App = registerPlugin("App", {
        web: () => Promise.resolve().then(() => (init_web(), web_exports)).then((m2) => new m2.AppWeb())
      });
    }
  });

  // mobile/shim/electron.js
  var electron_exports = {};
  __export(electron_exports, {
    BrowserWindow: () => BrowserWindow,
    Menu: () => Menu,
    MenuItem: () => MenuItem,
    Notification: () => Notification2,
    Tray: () => Tray,
    __appReady: () => __appReady,
    __invoke: () => __invoke,
    app: () => app,
    clipboard: () => clipboard,
    contextBridge: () => contextBridge,
    default: () => electron_default,
    dialog: () => dialog,
    globalShortcut: () => globalShortcut,
    ipcMain: () => ipcMain,
    ipcRenderer: () => ipcRenderer,
    nativeImage: () => nativeImage,
    net: () => net,
    powerMonitor: () => powerMonitor,
    safeStorage: () => safeStorage,
    screen: () => screen,
    shell: () => shell
  });
  async function __invoke(sender, ch, args) {
    const fn = handlers.get(ch);
    if (!fn) {
      console.warn("[ipc] \uCC98\uB9AC \uC5C6\uC74C", ch);
      return void 0;
    }
    return fn({ sender }, ...args);
  }
  function vp() {
    return { x: 0, y: 0, width: window.innerWidth, height: window.innerHeight };
  }
  function BrowserWindow(opts) {
    const w = new Win(opts);
    const p = winProxy(w);
    w.proxy = p;
    return p;
  }
  function topWin() {
    let best = null, z = -1;
    for (const w of wins) if (w.frame && w.visible && !w.destroyed) {
      const zi = Number(w.frame.style.zIndex);
      if (zi > z) {
        z = zi;
        best = w;
      }
    }
    return best;
  }
  function syncBack() {
    document.body.classList.toggle("has-sub", [...wins].some((w) => w.visible && w.page !== "calendar.html" && !w.ignored));
  }
  function __appReady() {
    readyResolve();
  }
  function closeSheet() {
    if (!sheetEl) return false;
    sheetEl.remove();
    sheetEl = null;
    return true;
  }
  function showSheet(items) {
    closeSheet();
    const flat = [];
    const walk = (list, depth) => list.forEach((it) => {
      if (!it || it.visible === false) return;
      if (it.type === "separator") {
        if (flat.length && flat[flat.length - 1] !== "sep") flat.push("sep");
        return;
      }
      if (it.submenu) {
        flat.push({ head: it.label });
        walk(Array.isArray(it.submenu) ? it.submenu : it.submenu.items || [], depth + 1);
        return;
      }
      flat.push({ ...it, depth });
    });
    walk(items, 0);
    if (!flat.length) return;
    const bg = document.createElement("div");
    bg.className = "sheet-bg";
    const box = document.createElement("div");
    box.className = "sheet";
    flat.forEach((it) => {
      if (it === "sep") {
        box.appendChild(Object.assign(document.createElement("hr")));
        return;
      }
      if (it.head) {
        const h = document.createElement("div");
        h.className = "sheet-head";
        h.textContent = it.head;
        box.appendChild(h);
        return;
      }
      const b = document.createElement("button");
      b.type = "button";
      b.className = "sheet-item" + (it.enabled === false ? " off" : "");
      const mark = it.type === "checkbox" || it.type === "radio" ? it.checked ? "\u2713 " : "\u3000" : "";
      b.textContent = mark + String(it.label || "").replace(/&/g, "");
      b.onclick = () => {
        closeSheet();
        if (it.enabled !== false && it.click) setTimeout(() => it.click(it), 30);
      };
      box.appendChild(b);
    });
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "sheet-item cancel";
    cancel.textContent = "\uB2EB\uAE30";
    cancel.onclick = closeSheet;
    box.appendChild(cancel);
    bg.appendChild(box);
    bg.addEventListener("click", (e) => {
      if (e.target === bg) closeSheet();
    });
    document.body.appendChild(bg);
    sheetEl = bg;
  }
  function mobileMenu(items) {
    const list = (items || []).map((it) => it && it.label && /^보이는 화면/.test(it.label) ? { ...it, label: "\uBCF4\uC774\uB294 \uD654\uBA74" } : it).map((it) => it && it.label && /^AI로 일정 등록/.test(it.label) ? { ...it, label: "\uB9D0\uB85C \uC77C\uC815 \uB4F1\uB85D" } : it).filter((it) => !(it && it.label && PC_ONLY.test(it.label)));
    if (!list.some((it) => it && it.label && /업데이트/.test(it.label))) list.push({ type: "separator" }, { label: "\uC5C5\uB370\uC774\uD2B8 \uD655\uC778", click: () => window.__updateNow && window.__updateNow() });
    else list.forEach((it) => {
      if (it && it.label && /새 버전/.test(it.label)) it.click = () => window.__updateNow && window.__updateNow();
    });
    return list;
  }
  function Tray() {
    return { setToolTip: noop, setImage: noop, on: noop, destroy: noop, setContextMenu: (m2) => {
      trayMenu = m2 ? Menu.buildFromTemplate(mobileMenu(m2.items)) : null;
    }, popUpContextMenu: () => trayMenu && trayMenu.popup() };
  }
  function Notification2() {
    return { show: noop, on: noop, close: noop };
  }
  var noop, emitter, handlers, listeners, ipcMain, host, wins, zTop, idSeq, IGNORE_PAGES, WebContents, Win, winProxy, appEv, readyResolve, ready, app, sheetEl, Menu, MenuItem, trayMenu, PC_ONLY, globalShortcut, nativeImage, shell, clipboard, pmEv, powerMonitor, scrEv, display, screen, dialog, safeStorage, net, contextBridge, ipcRenderer, electron_default;
  var init_electron = __esm({
    "mobile/shim/electron.js"() {
      init_globals();
      init_dist();
      init_esm();
      noop = () => {
      };
      emitter = () => {
        const map = /* @__PURE__ */ new Map();
        return {
          on(ev, fn) {
            (map.get(ev) || map.set(ev, []).get(ev)).push(fn);
            return this;
          },
          once(ev, fn) {
            const w = (...a) => {
              this.off(ev, w);
              fn(...a);
            };
            return this.on(ev, w);
          },
          off(ev, fn) {
            const l = map.get(ev);
            if (l) map.set(ev, l.filter((f2) => f2 !== fn));
            return this;
          },
          removeListener(ev, fn) {
            return this.off(ev, fn);
          },
          removeAllListeners(ev) {
            if (ev) map.delete(ev);
            else map.clear();
            return this;
          },
          emit(ev, ...a) {
            (map.get(ev) || []).slice().forEach((f2) => {
              try {
                f2(...a);
              } catch (e) {
                console.error(e);
              }
            });
          }
        };
      };
      handlers = /* @__PURE__ */ new Map();
      listeners = /* @__PURE__ */ new Map();
      ipcMain = {
        handle(ch, fn) {
          handlers.set(ch, fn);
        },
        removeHandler(ch) {
          handlers.delete(ch);
        },
        on(ch, fn) {
          listeners.set(ch, fn);
        }
      };
      host = () => document.getElementById("stage");
      wins = /* @__PURE__ */ new Set();
      zTop = 10;
      idSeq = 1;
      IGNORE_PAGES = ["popup.html", "sticky.html"];
      WebContents = class {
        constructor(win) {
          this.win = win;
          this.id = win.id;
          this.listeners = /* @__PURE__ */ new Map();
          this.ev = emitter();
        }
        send(ch, ...args) {
          if (ch === "state" && this.win.page === "calendar.html" && window.__onCalendarState) {
            try {
              window.__onCalendarState(args[0]);
            } catch (e) {
              console.error(e);
            }
          }
          (this.listeners.get(ch) || []).forEach((cb) => {
            try {
              cb({ sender: this }, ...args);
            } catch (e) {
              console.error(e);
            }
          });
        }
        on(ev, fn) {
          this.ev.on(ev, fn);
          return this;
        }
        once(ev, fn) {
          this.ev.once(ev, fn);
          return this;
        }
        isDestroyed() {
          return this.win.destroyed;
        }
        getURL() {
          return this.win.url || "";
        }
        focus() {
          this.win.focus();
        }
        executeJavaScript(code) {
          try {
            return Promise.resolve(this.win.frame.contentWindow.eval(code));
          } catch (e) {
            return Promise.reject(e);
          }
        }
        setZoomFactor() {
        }
        setVisualZoomLevelLimits() {
        }
        setBackgroundThrottling() {
        }
        openDevTools() {
        }
        setWindowOpenHandler() {
        }
        capturePage() {
          return Promise.resolve({ toPNG: () => new Uint8Array() });
        }
      };
      Win = class {
        constructor(opts = {}) {
          this.id = idSeq++;
          this.opts = opts;
          this.destroyed = false;
          this.visible = false;
          this.ev = emitter();
          this.webContents = new WebContents(this);
          this.frame = null;
          this.url = "";
          wins.add(this);
        }
        loadFile(file, o = {}) {
          const name = String(file).split("/").pop();
          this.page = name;
          if (IGNORE_PAGES.includes(name)) {
            this.ignored = true;
            return Promise.resolve();
          }
          const q = o.query ? "?" + new URLSearchParams(o.query).toString() : "";
          this.url = "renderer/" + name + q;
          const f2 = document.createElement("iframe");
          f2.className = "win";
          f2.dataset.page = name.replace(".html", "");
          f2.setAttribute("allow", "clipboard-write");
          this.isCal = name === "calendar.html";
          f2.style.zIndex = this.isCal ? "1" : String(++zTop);
          f2.style.visibility = "hidden";
          f2.__win = this;
          this.frame = f2;
          f2.addEventListener("load", () => {
            this.webContents.ev.emit("did-finish-load");
            this.ev.emit("ready-to-show");
            if (this.opts.show !== false || this.visible) this.show();
          });
          f2.src = this.url;
          host().appendChild(f2);
          return Promise.resolve();
        }
        loadURL(u) {
          return this.loadFile(u);
        }
        on(ev, fn) {
          this.ev.on(ev, fn);
          return this;
        }
        once(ev, fn) {
          this.ev.once(ev, fn);
          return this;
        }
        removeAllListeners(ev) {
          this.ev.removeAllListeners(ev);
          return this;
        }
        removeListener(ev, fn) {
          this.ev.off(ev, fn);
          return this;
        }
        show() {
          this.visible = true;
          if (this.frame) {
            this.frame.style.visibility = "visible";
            if (!this.isCal) this.frame.style.zIndex = String(++zTop);
          }
          this.ev.emit("show");
          this.ev.emit("focus");
          syncBack();
        }
        showInactive() {
          this.show();
        }
        hide() {
          this.visible = false;
          if (this.frame) this.frame.style.visibility = "hidden";
          this.ev.emit("hide");
          syncBack();
        }
        focus() {
          if (this.frame) {
            if (!this.isCal) this.frame.style.zIndex = String(++zTop);
            try {
              this.frame.contentWindow.focus();
            } catch {
            }
          }
          this.ev.emit("focus");
        }
        blur() {
        }
        close() {
          if (this.destroyed) return;
          const e = { defaultPrevented: false, preventDefault() {
            this.defaultPrevented = true;
          } };
          this.ev.emit("close", e);
          if (e.defaultPrevented) return;
          this.destroy();
        }
        destroy() {
          if (this.destroyed) return;
          this.destroyed = true;
          wins.delete(this);
          if (this.frame) this.frame.remove();
          this.ev.emit("closed");
          syncBack();
        }
        isDestroyed() {
          return this.destroyed;
        }
        isVisible() {
          return this.visible && !this.destroyed;
        }
        isFocused() {
          return topWin() === this;
        }
        isMinimized() {
          return false;
        }
        getBounds() {
          return vp();
        }
        getContentBounds() {
          return vp();
        }
        getPosition() {
          return [0, 0];
        }
        getSize() {
          const v = vp();
          return [v.width, v.height];
        }
        getNativeWindowHandle() {
          return new Uint8Array(8);
        }
      };
      winProxy = (w) => new Proxy(w, {
        get(t, k) {
          if (k in t) {
            const v = t[k];
            return typeof v === "function" ? v.bind(t) : v;
          }
          return typeof k === "string" ? noop : void 0;
        }
      });
      BrowserWindow.getAllWindows = () => [...wins].filter((w) => !w.ignored).map((w) => w.proxy);
      BrowserWindow.fromWebContents = (wc) => wc && wc.win ? wc.win.proxy : null;
      BrowserWindow.getFocusedWindow = () => {
        const w = topWin();
        return w ? w.proxy : null;
      };
      if (Capacitor.isNativePlatform()) {
        App.addListener("backButton", () => {
          if (closeSheet()) return;
          const w = topWin();
          if (w && w.page !== "calendar.html") w.close();
          else App.minimizeApp();
        });
      }
      window.__deskcalBridge = (frameWin) => {
        const f2 = [...document.querySelectorAll("iframe.win")].find((x) => x.contentWindow === frameWin);
        const win = f2 && f2.__win;
        if (!win) return null;
        const wc = win.webContents;
        return {
          invoke: (ch, ...args) => __invoke(wc, ch, args),
          on: (ch, cb) => {
            (wc.listeners.get(ch) || wc.listeners.set(ch, []).get(ch)).push(cb);
          },
          send: (ch, ...args) => {
            const fn = listeners.get(ch);
            if (fn) fn({ sender: wc }, ...args);
          }
        };
      };
      appEv = emitter();
      ready = new Promise((r) => readyResolve = r);
      app = {
        isPackaged: true,
        isQuitting: false,
        whenReady: () => ready,
        on: (ev, fn) => appEv.on(ev, fn),
        once: (ev, fn) => appEv.once(ev, fn),
        getPath: (k) => "/data/" + k,
        getVersion: () => window.__APP_VERSION || "0",
        getName: () => "Total Calendar",
        getLocale: () => navigator.language || "ko-KR",
        requestSingleInstanceLock: () => true,
        setAppUserModelId: noop,
        setLoginItemSettings: noop,
        getLoginItemSettings: () => ({ openAtLogin: false }),
        quit: () => {
          App.minimizeApp().catch(noop);
        },
        exit: noop,
        relaunch: () => location.reload(),
        focus: noop,
        dock: { hide: noop, show: noop }
      };
      sheetEl = null;
      Menu = {
        buildFromTemplate: (items) => ({ items, popup: () => showSheet(items), closePopup: closeSheet }),
        setApplicationMenu: noop
      };
      MenuItem = function(o) {
        return o;
      };
      trayMenu = null;
      PC_ONLY = /AI|메모장|미니 달력|앞으로|바탕화면|위젯 모드|위젯 위치|데이터 폴더|종료|편집 모드/;
      window.__showMoreMenu = () => trayMenu && trayMenu.popup();
      globalShortcut = { register: () => true, unregister: noop, unregisterAll: noop, isRegistered: () => false };
      nativeImage = { createFromPath: () => ({ resize() {
        return this;
      }, isEmpty: () => true }), createEmpty: () => ({}) };
      shell = {
        openExternal: (u) => {
          window.open(u, "_system");
          return Promise.resolve();
        },
        openPath: () => Promise.resolve(""),
        showItemInFolder: noop
      };
      clipboard = {
        writeText: (t) => {
          try {
            navigator.clipboard.writeText(t);
          } catch {
          }
        },
        readText: () => ""
      };
      pmEv = emitter();
      powerMonitor = { on: (e, f2) => pmEv.on(e, f2), getSystemIdleTime: () => 0 };
      if (Capacitor.isNativePlatform()) App.addListener("appStateChange", ({ isActive }) => {
        if (isActive) pmEv.emit("resume");
      });
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden && !Capacitor.isNativePlatform()) pmEv.emit("resume");
      });
      scrEv = emitter();
      display = () => ({ id: 1, bounds: vp(), workArea: vp(), size: { width: window.innerWidth, height: window.innerHeight }, workAreaSize: { width: window.innerWidth, height: window.innerHeight }, scaleFactor: window.devicePixelRatio || 1 });
      screen = {
        getPrimaryDisplay: display,
        getAllDisplays: () => [display()],
        getDisplayNearestPoint: display,
        getDisplayMatching: display,
        getCursorScreenPoint: () => ({ x: 0, y: 0 }),
        dipToScreenPoint: (p) => p,
        screenToDipPoint: (p) => p,
        dipToScreenRect: (_w, r) => r,
        on: (e, f2) => scrEv.on(e, f2)
      };
      dialog = {
        showMessageBox: async (_w, o) => {
          o = o || _w;
          const ok = window.confirm([o.message, o.detail].filter(Boolean).join("\n\n"));
          return { response: ok ? 0 : o.cancelId ?? 1 };
        },
        showMessageBoxSync: (_w, o) => {
          o = o || _w;
          return window.confirm([o.message, o.detail].filter(Boolean).join("\n\n")) ? 0 : o.cancelId ?? 1;
        },
        showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
        showErrorBox: (t, c) => window.alert(t + "\n" + c)
      };
      Notification2.isSupported = () => false;
      safeStorage = { isEncryptionAvailable: () => false, encryptString: (s) => s, decryptString: (b) => String(b) };
      net = { fetch: (...a) => fetch(...a) };
      contextBridge = { exposeInMainWorld: noop };
      ipcRenderer = { invoke: noop, on: noop, send: noop };
      electron_default = { app, BrowserWindow, ipcMain, Menu, MenuItem, Tray, globalShortcut, nativeImage, shell, clipboard, powerMonitor, screen, dialog, Notification: Notification2, safeStorage, net, contextBridge, ipcRenderer };
    }
  });

  // mobile/shim/fs.js
  var fs_exports = {};
  __export(fs_exports, {
    createWriteStream: () => createWriteStream,
    default: () => fs_default,
    existsSync: () => existsSync,
    mkdirSync: () => mkdirSync,
    promises: () => promises,
    readFileSync: () => readFileSync,
    readdirSync: () => readdirSync,
    renameSync: () => renameSync,
    rmSync: () => rmSync,
    statSync: () => statSync,
    unlinkSync: () => unlinkSync,
    writeFileSync: () => writeFileSync
  });
  function existsSync(p) {
    try {
      return localStorage.getItem(K(p)) !== null;
    } catch {
      return false;
    }
  }
  function readFileSync(p, enc) {
    const v = localStorage.getItem(K(p));
    if (v === null) throw err("ENOENT", p);
    return v;
  }
  function writeFileSync(p, data) {
    localStorage.setItem(K(p), typeof data === "string" ? data : new TextDecoder().decode(data));
  }
  function renameSync(a, b) {
    const v = localStorage.getItem(K(a));
    if (v === null) throw err("ENOENT", a);
    localStorage.setItem(K(b), v);
    localStorage.removeItem(K(a));
  }
  function unlinkSync(p) {
    localStorage.removeItem(K(p));
  }
  function rmSync(p) {
    localStorage.removeItem(K(p));
  }
  function mkdirSync() {
  }
  function readdirSync() {
    return [];
  }
  function statSync(p) {
    if (!existsSync(p)) throw err("ENOENT", p);
    return { size: (localStorage.getItem(K(p)) || "").length, isFile: () => true, isDirectory: () => false, mtimeMs: 0 };
  }
  function createWriteStream() {
    throw new Error("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC74C");
  }
  var K, err, promises, fs_default;
  var init_fs = __esm({
    "mobile/shim/fs.js"() {
      init_globals();
      K = (p) => "fs:" + String(p).replace(/\\/g, "/");
      err = (code, p) => Object.assign(new Error(`${code}: ${p}`), { code });
      promises = { readFile: async (p) => readFileSync(p), writeFile: async (p, d) => writeFileSync(p, d) };
      fs_default = { existsSync, readFileSync, writeFileSync, renameSync, unlinkSync, rmSync, mkdirSync, readdirSync, statSync, createWriteStream, promises };
    }
  });

  // node_modules/path-browserify/index.js
  var require_path_browserify = __commonJS({
    "node_modules/path-browserify/index.js"(exports, module) {
      "use strict";
      init_globals();
      function assertPath(path) {
        if (typeof path !== "string") {
          throw new TypeError("Path must be a string. Received " + JSON.stringify(path));
        }
      }
      function normalizeStringPosix(path, allowAboveRoot) {
        var res = "";
        var lastSegmentLength = 0;
        var lastSlash = -1;
        var dots = 0;
        var code;
        for (var i = 0; i <= path.length; ++i) {
          if (i < path.length)
            code = path.charCodeAt(i);
          else if (code === 47)
            break;
          else
            code = 47;
          if (code === 47) {
            if (lastSlash === i - 1 || dots === 1) {
            } else if (lastSlash !== i - 1 && dots === 2) {
              if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 || res.charCodeAt(res.length - 2) !== 46) {
                if (res.length > 2) {
                  var lastSlashIndex = res.lastIndexOf("/");
                  if (lastSlashIndex !== res.length - 1) {
                    if (lastSlashIndex === -1) {
                      res = "";
                      lastSegmentLength = 0;
                    } else {
                      res = res.slice(0, lastSlashIndex);
                      lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
                    }
                    lastSlash = i;
                    dots = 0;
                    continue;
                  }
                } else if (res.length === 2 || res.length === 1) {
                  res = "";
                  lastSegmentLength = 0;
                  lastSlash = i;
                  dots = 0;
                  continue;
                }
              }
              if (allowAboveRoot) {
                if (res.length > 0)
                  res += "/..";
                else
                  res = "..";
                lastSegmentLength = 2;
              }
            } else {
              if (res.length > 0)
                res += "/" + path.slice(lastSlash + 1, i);
              else
                res = path.slice(lastSlash + 1, i);
              lastSegmentLength = i - lastSlash - 1;
            }
            lastSlash = i;
            dots = 0;
          } else if (code === 46 && dots !== -1) {
            ++dots;
          } else {
            dots = -1;
          }
        }
        return res;
      }
      function _format(sep, pathObject) {
        var dir = pathObject.dir || pathObject.root;
        var base = pathObject.base || (pathObject.name || "") + (pathObject.ext || "");
        if (!dir) {
          return base;
        }
        if (dir === pathObject.root) {
          return dir + base;
        }
        return dir + sep + base;
      }
      var posix = {
        // path.resolve([from ...], to)
        resolve: function resolve() {
          var resolvedPath = "";
          var resolvedAbsolute = false;
          var cwd;
          for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
            var path;
            if (i >= 0)
              path = arguments[i];
            else {
              if (cwd === void 0)
                cwd = process.cwd();
              path = cwd;
            }
            assertPath(path);
            if (path.length === 0) {
              continue;
            }
            resolvedPath = path + "/" + resolvedPath;
            resolvedAbsolute = path.charCodeAt(0) === 47;
          }
          resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);
          if (resolvedAbsolute) {
            if (resolvedPath.length > 0)
              return "/" + resolvedPath;
            else
              return "/";
          } else if (resolvedPath.length > 0) {
            return resolvedPath;
          } else {
            return ".";
          }
        },
        normalize: function normalize(path) {
          assertPath(path);
          if (path.length === 0) return ".";
          var isAbsolute = path.charCodeAt(0) === 47;
          var trailingSeparator = path.charCodeAt(path.length - 1) === 47;
          path = normalizeStringPosix(path, !isAbsolute);
          if (path.length === 0 && !isAbsolute) path = ".";
          if (path.length > 0 && trailingSeparator) path += "/";
          if (isAbsolute) return "/" + path;
          return path;
        },
        isAbsolute: function isAbsolute(path) {
          assertPath(path);
          return path.length > 0 && path.charCodeAt(0) === 47;
        },
        join: function join() {
          if (arguments.length === 0)
            return ".";
          var joined;
          for (var i = 0; i < arguments.length; ++i) {
            var arg = arguments[i];
            assertPath(arg);
            if (arg.length > 0) {
              if (joined === void 0)
                joined = arg;
              else
                joined += "/" + arg;
            }
          }
          if (joined === void 0)
            return ".";
          return posix.normalize(joined);
        },
        relative: function relative(from, to) {
          assertPath(from);
          assertPath(to);
          if (from === to) return "";
          from = posix.resolve(from);
          to = posix.resolve(to);
          if (from === to) return "";
          var fromStart = 1;
          for (; fromStart < from.length; ++fromStart) {
            if (from.charCodeAt(fromStart) !== 47)
              break;
          }
          var fromEnd = from.length;
          var fromLen = fromEnd - fromStart;
          var toStart = 1;
          for (; toStart < to.length; ++toStart) {
            if (to.charCodeAt(toStart) !== 47)
              break;
          }
          var toEnd = to.length;
          var toLen = toEnd - toStart;
          var length = fromLen < toLen ? fromLen : toLen;
          var lastCommonSep = -1;
          var i = 0;
          for (; i <= length; ++i) {
            if (i === length) {
              if (toLen > length) {
                if (to.charCodeAt(toStart + i) === 47) {
                  return to.slice(toStart + i + 1);
                } else if (i === 0) {
                  return to.slice(toStart + i);
                }
              } else if (fromLen > length) {
                if (from.charCodeAt(fromStart + i) === 47) {
                  lastCommonSep = i;
                } else if (i === 0) {
                  lastCommonSep = 0;
                }
              }
              break;
            }
            var fromCode = from.charCodeAt(fromStart + i);
            var toCode = to.charCodeAt(toStart + i);
            if (fromCode !== toCode)
              break;
            else if (fromCode === 47)
              lastCommonSep = i;
          }
          var out = "";
          for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
            if (i === fromEnd || from.charCodeAt(i) === 47) {
              if (out.length === 0)
                out += "..";
              else
                out += "/..";
            }
          }
          if (out.length > 0)
            return out + to.slice(toStart + lastCommonSep);
          else {
            toStart += lastCommonSep;
            if (to.charCodeAt(toStart) === 47)
              ++toStart;
            return to.slice(toStart);
          }
        },
        _makeLong: function _makeLong(path) {
          return path;
        },
        dirname: function dirname(path) {
          assertPath(path);
          if (path.length === 0) return ".";
          var code = path.charCodeAt(0);
          var hasRoot = code === 47;
          var end = -1;
          var matchedSlash = true;
          for (var i = path.length - 1; i >= 1; --i) {
            code = path.charCodeAt(i);
            if (code === 47) {
              if (!matchedSlash) {
                end = i;
                break;
              }
            } else {
              matchedSlash = false;
            }
          }
          if (end === -1) return hasRoot ? "/" : ".";
          if (hasRoot && end === 1) return "//";
          return path.slice(0, end);
        },
        basename: function basename(path, ext) {
          if (ext !== void 0 && typeof ext !== "string") throw new TypeError('"ext" argument must be a string');
          assertPath(path);
          var start = 0;
          var end = -1;
          var matchedSlash = true;
          var i;
          if (ext !== void 0 && ext.length > 0 && ext.length <= path.length) {
            if (ext.length === path.length && ext === path) return "";
            var extIdx = ext.length - 1;
            var firstNonSlashEnd = -1;
            for (i = path.length - 1; i >= 0; --i) {
              var code = path.charCodeAt(i);
              if (code === 47) {
                if (!matchedSlash) {
                  start = i + 1;
                  break;
                }
              } else {
                if (firstNonSlashEnd === -1) {
                  matchedSlash = false;
                  firstNonSlashEnd = i + 1;
                }
                if (extIdx >= 0) {
                  if (code === ext.charCodeAt(extIdx)) {
                    if (--extIdx === -1) {
                      end = i;
                    }
                  } else {
                    extIdx = -1;
                    end = firstNonSlashEnd;
                  }
                }
              }
            }
            if (start === end) end = firstNonSlashEnd;
            else if (end === -1) end = path.length;
            return path.slice(start, end);
          } else {
            for (i = path.length - 1; i >= 0; --i) {
              if (path.charCodeAt(i) === 47) {
                if (!matchedSlash) {
                  start = i + 1;
                  break;
                }
              } else if (end === -1) {
                matchedSlash = false;
                end = i + 1;
              }
            }
            if (end === -1) return "";
            return path.slice(start, end);
          }
        },
        extname: function extname(path) {
          assertPath(path);
          var startDot = -1;
          var startPart = 0;
          var end = -1;
          var matchedSlash = true;
          var preDotState = 0;
          for (var i = path.length - 1; i >= 0; --i) {
            var code = path.charCodeAt(i);
            if (code === 47) {
              if (!matchedSlash) {
                startPart = i + 1;
                break;
              }
              continue;
            }
            if (end === -1) {
              matchedSlash = false;
              end = i + 1;
            }
            if (code === 46) {
              if (startDot === -1)
                startDot = i;
              else if (preDotState !== 1)
                preDotState = 1;
            } else if (startDot !== -1) {
              preDotState = -1;
            }
          }
          if (startDot === -1 || end === -1 || // We saw a non-dot character immediately before the dot
          preDotState === 0 || // The (right-most) trimmed path component is exactly '..'
          preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
            return "";
          }
          return path.slice(startDot, end);
        },
        format: function format(pathObject) {
          if (pathObject === null || typeof pathObject !== "object") {
            throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof pathObject);
          }
          return _format("/", pathObject);
        },
        parse: function parse(path) {
          assertPath(path);
          var ret = { root: "", dir: "", base: "", ext: "", name: "" };
          if (path.length === 0) return ret;
          var code = path.charCodeAt(0);
          var isAbsolute = code === 47;
          var start;
          if (isAbsolute) {
            ret.root = "/";
            start = 1;
          } else {
            start = 0;
          }
          var startDot = -1;
          var startPart = 0;
          var end = -1;
          var matchedSlash = true;
          var i = path.length - 1;
          var preDotState = 0;
          for (; i >= start; --i) {
            code = path.charCodeAt(i);
            if (code === 47) {
              if (!matchedSlash) {
                startPart = i + 1;
                break;
              }
              continue;
            }
            if (end === -1) {
              matchedSlash = false;
              end = i + 1;
            }
            if (code === 46) {
              if (startDot === -1) startDot = i;
              else if (preDotState !== 1) preDotState = 1;
            } else if (startDot !== -1) {
              preDotState = -1;
            }
          }
          if (startDot === -1 || end === -1 || // We saw a non-dot character immediately before the dot
          preDotState === 0 || // The (right-most) trimmed path component is exactly '..'
          preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
            if (end !== -1) {
              if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);
              else ret.base = ret.name = path.slice(startPart, end);
            }
          } else {
            if (startPart === 0 && isAbsolute) {
              ret.name = path.slice(1, startDot);
              ret.base = path.slice(1, end);
            } else {
              ret.name = path.slice(startPart, startDot);
              ret.base = path.slice(startPart, end);
            }
            ret.ext = path.slice(startDot, end);
          }
          if (startPart > 0) ret.dir = path.slice(0, startPart - 1);
          else if (isAbsolute) ret.dir = "/";
          return ret;
        },
        sep: "/",
        delimiter: ":",
        win32: null,
        posix: null
      };
      posix.posix = posix;
      module.exports = posix;
    }
  });

  // desktop/src/store.js
  var require_store = __commonJS({
    "desktop/src/store.js"(exports, module) {
      init_globals();
      var fs = (init_fs(), __toCommonJS(fs_exports));
      var path = require_path_browserify();
      var { app: app2, safeStorage: safeStorage2 } = (init_electron(), __toCommonJS(electron_exports));
      var DIR = app2.getPath("userData");
      var file = (n) => path.join(DIR, n);
      var DEFAULT_SETTINGS = {
        mode: "wallpaper",
        // 'wallpaper' | 'widget'
        view: "month",
        // 'month' | 'week'
        displayId: null,
        // 표시할 모니터 (null = 주 모니터)
        iconGutter: 170,
        // 배경 모드: 왼쪽 아이콘 공간(px)
        widget: { x: null, y: null, width: 860, height: 640, opacity: 0.94, locked: false },
        appearance: {
          theme: "midnight",
          // renderer/themes.js 의 테마 id
          bgColor: "",
          // 직접 고른 배경색 ('' = 테마 그대로)
          textColor: "",
          // 직접 고른 글자색
          deco: true,
          // Linaverse 테마 장식
          decoChar: true,
          // 오른쪽 아래 컨셉 동물 (Linaverse 테마)
          clickSound: true,
          // 버튼 누를 때 딸깍 소리
          typo: { preset: "bigdate" },
          // 달력 스타일 (글자 크기) — 'custom'이면 직접 조절한 값
          listSide: "left",
          // 목록 패널 위치
          shape: "square",
          // 모양: square(각지게) | soft(둥글게) | cozy(포근하게)
          accent: "#D27A4A",
          font: "pretendard",
          // pretendard | noto | ibm | gowun | myeongjo | malgun | custom
          customFont: "",
          fontScale: 1,
          weekStart: 0,
          // 0 = 일요일, 1 = 월요일
          timeFormat: "24",
          // '24' | '12'
          wallpaperAlign: "full",
          // full | right | center | left
          wallpaperWidth: 72,
          // % (full이 아닐 때)
          dimPast: true,
          timeZone: "system",
          // 앱 시간대: 'system' = Windows 설정을 따름
          worldZones: []
          // 함께 볼 시간대 (예: ['Asia/Riyadh'])
        },
        refreshMinutes: 3,
        autoStart: true,
        hotkeyQuickAdd: "CommandOrControl+Alt+Space",
        hotkeyEdit: "CommandOrControl+Alt+E",
        lastWriteSource: "local",
        colorBy: "category",
        // 'category' | 'source' : 일정 카드 색 기준
        categories: [
          { id: "work", name: "\uC5C5\uBB34", color: "#5B7DB1", keywords: "\uD68C\uC758, \uBA74\uC811, \uBCF4\uACE0, \uB9C8\uAC10, \uCD9C\uC7A5, \uBBF8\uD305" },
          { id: "meet", name: "\uC57D\uC18D", color: "#C49A3A", keywords: "\uC57D\uC18D, \uC810\uC2EC, \uC800\uB141, \uBAA8\uC784, \uC2DD\uC0AC" },
          { id: "personal", name: "\uAC1C\uC778", color: "#8E6BA6", keywords: "\uBCD1\uC6D0, \uC6B4\uB3D9, \uCE58\uACFC" },
          { id: "anniv", name: "\uAE30\uB150\uC77C", color: "#C2637A", keywords: "\uAE30\uB150\uC77C, \uACB0\uD63C" },
          { id: "bday", name: "\uC0DD\uC77C", color: "#6E9B5E", keywords: "\uC0DD\uC77C" }
        ],
        minimal: false,
        // 미니 달력 모드
        clickToEdit: true,
        // 바탕화면에 박힌 캘린더를 바로 클릭해 쓰기
        characters: {
          // Linaverse 12지신
          enabled: true,
          clock: true,
          // 시계 옆 캐릭터 친구 (누르면 반응)
          buddy: "theme",
          seasonPet: "mix",
          // 시즌 혼합 컬렉션의 동물 ('mix' 섞어서 랜덤 · 'daily' 매일 한 마리 · 동물 id 고정)
          outfit: true,
          // 계절 따라 옷 갈아입기
          greeting: true,
          // 새해·설날·추석 인사 배너              // 친구 캐릭터: 'theme' = Linaverse 테마 동물 (아니면 토끼)
          deliverer: true,
          // 알림을 가져오는 담당 동물
          stickers: true,
          // 메모 완료 스티커
          birthday: true,
          // 생일에 나이·띠
          map: { work: "ox", meet: "horse", personal: "pig", anniv: "dragon", bday: "rabbit" }
          // 카테고리 → 담당 ('hour' = 그 시각 동물)
        },
        panels: {
          wallpaper: { list: true, clock: true, next: true, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true },
          widget: { list: true, clock: true, next: true, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true }
        },
        reminders: { month: true, week: true, day: true, sameDay: true, sameDayHour: 8, before: 10 },
        sources: [
          { id: "local", type: "local", name: "\uB0B4 PC", color: "#A78BFA", enabled: true }
        ]
      };
      var FRESH_SETTINGS = {
        mode: "widget",
        // 'wallpaper' | 'widget'
        view: "month",
        // 'month' | 'week'
        displayId: null,
        // 표시할 모니터 (null = 주 모니터)
        iconGutter: 400,
        // 배경 모드: 왼쪽 아이콘 공간(px)
        widget: { x: null, y: null, width: 1324, height: 914, opacity: 0.54, locked: true, underIcons: true },
        // 위치 null = 주 모니터 오른쪽 위
        opacity: 0.66,
        appearance: {
          theme: "season-auto",
          // renderer/themes.js 의 테마 id
          bgColor: "",
          // 직접 고른 배경색 ('' = 테마 그대로)
          textColor: "",
          // 직접 고른 글자색
          deco: true,
          // Linaverse 테마 장식
          decoChar: true,
          // 오른쪽 아래 컨셉 동물 (Linaverse 테마)
          clickSound: true,
          // 버튼 누를 때 딸깍 소리
          typo: { preset: "custom", date: 1.1, dateWeight: 500, chip: 0.82, list: 0.98, clock: 4.8, icon: 1.2, weekday: 0.89, title: 1.6 },
          // 달력 스타일 (글자 크기)
          listSide: "left",
          // 목록 패널 위치
          shape: "soft",
          // 모양: square(각지게) | soft(둥글게) | cozy(포근하게)
          accent: "#E06A8E",
          font: "pretendard",
          // pretendard | noto | ibm | gowun | myeongjo | malgun | custom
          customFont: "",
          fontScale: 0.85,
          weekStart: 0,
          // 0 = 일요일, 1 = 월요일
          timeFormat: "24",
          // '24' | '12'
          wallpaperAlign: "full",
          // full | right | center | left
          wallpaperWidth: 45,
          // % (full이 아닐 때)
          dimPast: true,
          timeZone: "system",
          // 앱 시간대: 'system' = Windows 설정을 따름
          worldZones: [],
          // 함께 볼 시간대 (예: ['Asia/Riyadh'])
          buddySize: 1.05
          // 왼쪽 위 캐릭터 크기
        },
        refreshMinutes: 3,
        autoStart: true,
        hotkeyQuickAdd: "CommandOrControl+Alt+Space",
        hotkeyEdit: "CommandOrControl+Alt+E",
        lastWriteSource: "local",
        colorBy: "category",
        // 'category' | 'source' : 일정 카드 색 기준
        categories: [
          { id: "work", name: "\uC5C5\uBB34", color: "#5B7DB1", keywords: "\uD68C\uC758, \uBA74\uC811, \uBCF4\uACE0, \uB9C8\uAC10, \uCD9C\uC7A5, \uBBF8\uD305" },
          { id: "meet", name: "\uC57D\uC18D", color: "#C49A3A", keywords: "\uC57D\uC18D, \uC810\uC2EC, \uC800\uB141, \uBAA8\uC784, \uC2DD\uC0AC" },
          { id: "personal", name: "\uAC1C\uC778", color: "#8E6BA6", keywords: "\uBCD1\uC6D0, \uC6B4\uB3D9, \uCE58\uACFC" },
          { id: "anniv", name: "\uAE30\uB150\uC77C", color: "#C2637A", keywords: "\uAE30\uB150\uC77C, \uACB0\uD63C" },
          { id: "bday", name: "\uC0DD\uC77C", color: "#6E9B5E", keywords: "\uC0DD\uC77C" }
        ],
        minimal: false,
        // 미니 달력 모드
        clickToEdit: true,
        // 바탕화면에 박힌 캘린더를 바로 클릭해 쓰기
        characters: {
          // Linaverse 12지신
          enabled: true,
          clock: true,
          // 시계 옆 캐릭터 친구 (누르면 반응)
          buddy: "theme",
          seasonPet: "mix",
          // 시즌 혼합 컬렉션의 동물 ('mix' 섞어서 랜덤 · 'daily' 매일 한 마리 · 동물 id 고정)
          outfit: true,
          // 계절 따라 옷 갈아입기
          greeting: true,
          // 새해·설날·추석 인사 배너              // 친구 캐릭터: 'theme' = Linaverse 테마 동물 (아니면 토끼)
          deliverer: true,
          // 알림을 가져오는 담당 동물
          stickers: true,
          // 메모 완료 스티커
          birthday: true,
          // 생일에 나이·띠
          map: { work: "hour", meet: "hour", personal: "hour", anniv: "hour", bday: "hour" },
          // 카테고리 → 담당 ('hour' = 그 시각 동물)
          autoTalk: true,
          autoTalkMin: 5,
          bubbleSec: 0,
          lines: { en: true, ko: true, cheer: true, mood: true, tip: true, fact: true }
        },
        panels: {
          wallpaper: { list: true, clock: true, next: false, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true },
          widget: { list: false, clock: true, next: false, toolbar: true, today: true, tomorrow: true, memo: false, calendar: true, footer: true }
        },
        reminders: { month: true, week: true, day: true, sameDay: true, sameDayHour: 9, before: 60 },
        uiVersion: 17,
        sources: [
          { id: "local", type: "local", name: "\uB0B4 PC", color: "#A78BFA", enabled: true }
        ]
      };
      function readJSON(name, fallback) {
        try {
          return JSON.parse(fs.readFileSync(file(name), "utf8"));
        } catch {
          return fallback;
        }
      }
      var saveHooks = [];
      var hooksPaused = 0;
      function writeJSON(name, data) {
        if (saveHooks.length && !hooksPaused) {
          const old = readJSON(name, void 0);
          for (const h of saveHooks) {
            try {
              h(name, data, old);
            } catch (e) {
              console.error("save hook", e);
            }
          }
        }
        fs.mkdirSync(DIR, { recursive: true });
        const tmp = file(name + ".tmp");
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
        fs.renameSync(tmp, file(name));
      }
      function merge(base, extra) {
        const out = { ...base, ...extra };
        out.widget = { ...base.widget, ...extra.widget || {} };
        out.reminders = { ...base.reminders, ...extra.reminders || {} };
        out.appearance = { ...base.appearance, ...extra.appearance || {} };
        const xc = extra.characters || {};
        out.characters = { ...base.characters, ...xc, map: { ...base.characters.map, ...xc.map || {} } };
        if (String(out.appearance.accent).toUpperCase() === "#7C9CFF") out.appearance.accent = base.appearance.accent;
        out.panels = {
          wallpaper: { ...base.panels.wallpaper, ...(extra.panels || {}).wallpaper || {} },
          widget: { ...base.panels.widget, ...(extra.panels || {}).widget || {} }
        };
        if ((extra.uiVersion || 0) < 14) {
          out.panels.wallpaper.next = false;
          out.panels.widget.next = false;
          out.uiVersion = 14;
        }
        if ((extra.uiVersion || 0) < 16) {
          out.panels.wallpaper.memo = false;
          out.panels.widget.memo = false;
          out.migrateNotes = true;
        }
        if ((extra.uiVersion || 0) < 15) {
          if (out.characters && (!out.characters.seasonPet || out.characters.seasonPet === "daily")) out.characters.seasonPet = "mix";
        }
        if ((extra.uiVersion || 0) < 17) {
          out.autoStart = true;
          out.uiVersion = 17;
        }
        if (!Array.isArray(out.categories)) out.categories = base.categories;
        const OLD = { work: "#4F8BFF", meet: "#F59E0B", personal: "#A78BFA", anniv: "#F472B6", bday: "#22C55E" };
        out.categories = out.categories.map((c) => {
          const nb = base.categories.find((b) => b.id === c.id);
          return nb && OLD[c.id] && String(c.color).toUpperCase() === OLD[c.id] ? { ...c, color: nb.color } : c;
        });
        if (!Array.isArray(out.sources) || !out.sources.length) out.sources = base.sources;
        if (!out.sources.find((s) => s.type === "local")) out.sources.unshift(base.sources[0]);
        return out;
      }
      function encrypt(plain) {
        if (!plain) return "";
        if (safeStorage2.isEncryptionAvailable()) return "enc:" + safeStorage2.encryptString(plain).toString("base64");
        return "raw:" + import_buffer.Buffer.from(plain, "utf8").toString("base64");
      }
      function decrypt(stored) {
        if (!stored) return "";
        try {
          if (stored.startsWith("enc:")) return safeStorage2.decryptString(import_buffer.Buffer.from(stored.slice(4), "base64"));
          if (stored.startsWith("raw:")) return import_buffer.Buffer.from(stored.slice(4), "base64").toString("utf8");
        } catch {
        }
        return "";
      }
      module.exports = {
        DIR,
        getSettings: () => fs.existsSync(file("settings.json")) ? merge(DEFAULT_SETTINGS, readJSON("settings.json", {})) : merge(FRESH_SETTINGS, {}),
        saveSettings: (s) => writeJSON("settings.json", s),
        getLocalEvents: () => readJSON("local-events.json", []),
        saveLocalEvents: (list) => writeJSON("local-events.json", list),
        getNotes: () => readJSON("notes.json", []),
        // 날짜 없는 메모
        saveNotes: (list) => writeJSON("notes.json", list),
        getRemindMap: () => readJSON("event-reminders.json", {}),
        // 일정 uid → [{n, unit, time}] (없으면 기본 알림)
        saveRemindMap: (m2) => writeJSON("event-reminders.json", m2),
        getCategoryMap: () => readJSON("categories.json", {}),
        // 일정 uid → 카테고리 id ('none' = 지정 안 함)
        saveCategoryMap: (m2) => writeJSON("categories.json", m2),
        getStickers: () => ({ owned: {}, days: {}, total: 0, unlocked: false, ...readJSON("stickers.json", {}) }),
        // 스티커 도감
        saveStickers: (s) => writeJSON("stickers.json", s),
        getBirthYears: () => readJSON("birthyears.json", {}),
        // 일정 uid → 태어난 해
        saveBirthYears: (m2) => writeJSON("birthyears.json", m2),
        getStickies: () => readJSON("stickies.json", []),
        // 바탕화면 메모지
        saveStickies: (l) => writeJSON("stickies.json", l),
        getReminderState: () => readJSON("reminders.json", { fired: {}, snoozes: [] }),
        saveReminderState: (s) => writeJSON("reminders.json", s),
        encrypt,
        decrypt,
        readJSON,
        writeJSON,
        onSave: (fn) => saveHooks.push(fn),
        // 동기화가 받아온 내용을 저장할 때는 '바뀜' 기록을 남기지 않음
        quiet: (fn) => {
          hooksPaused++;
          try {
            return fn();
          } finally {
            hooksPaused--;
          }
        }
      };
    }
  });

  // node_modules/@capacitor/local-notifications/dist/esm/web.js
  var web_exports2 = {};
  __export(web_exports2, {
    LocalNotificationsWeb: () => LocalNotificationsWeb
  });
  var LocalNotificationsWeb;
  var init_web2 = __esm({
    "node_modules/@capacitor/local-notifications/dist/esm/web.js"() {
      init_globals();
      init_dist();
      LocalNotificationsWeb = class extends WebPlugin {
        constructor() {
          super(...arguments);
          this.pending = [];
          this.deliveredNotifications = [];
          this.hasNotificationSupport = () => {
            if (!("Notification" in window) || !Notification.requestPermission) {
              return false;
            }
            if (Notification.permission !== "granted") {
              try {
                new Notification("");
              } catch (e) {
                if (e instanceof Error && e.name === "TypeError") {
                  return false;
                }
              }
            }
            return true;
          };
        }
        async getDeliveredNotifications() {
          const deliveredSchemas = [];
          for (const notification of this.deliveredNotifications) {
            const deliveredSchema = {
              title: notification.title,
              id: parseInt(notification.tag),
              body: notification.body
            };
            deliveredSchemas.push(deliveredSchema);
          }
          return {
            notifications: deliveredSchemas
          };
        }
        async removeDeliveredNotifications(delivered) {
          for (const toRemove of delivered.notifications) {
            const found = this.deliveredNotifications.find((n) => n.tag === String(toRemove.id));
            found === null || found === void 0 ? void 0 : found.close();
            this.deliveredNotifications = this.deliveredNotifications.filter(() => !found);
          }
        }
        async removeDeliveredNotificationsById(options) {
          for (const id of options.ids) {
            const found = this.deliveredNotifications.find((n) => n.tag === String(id));
            found === null || found === void 0 ? void 0 : found.close();
            this.deliveredNotifications = this.deliveredNotifications.filter((n) => n !== found);
          }
        }
        async removeAllDeliveredNotifications() {
          for (const notification of this.deliveredNotifications) {
            notification.close();
          }
          this.deliveredNotifications = [];
        }
        async getByIds(options) {
          const ids = options.ids.map((id) => String(id));
          const scheduled = this.pending.filter((n) => ids.includes(String(n.id)));
          const delivered = this.deliveredNotifications.filter((n) => ids.includes(n.tag)).map((n) => this.deliveredToSchema(n));
          return { notifications: [...scheduled, ...delivered] };
        }
        async getAll(options) {
          const scheduled = [...this.pending];
          const delivered = this.deliveredNotifications.map((n) => this.deliveredToSchema(n));
          if ((options === null || options === void 0 ? void 0 : options.state) === "SCHEDULED") {
            return { notifications: scheduled };
          }
          if ((options === null || options === void 0 ? void 0 : options.state) === "TRIGGERED") {
            return { notifications: delivered };
          }
          return { notifications: [...scheduled, ...delivered] };
        }
        deliveredToSchema(notification) {
          return {
            title: notification.title,
            id: parseInt(notification.tag),
            body: notification.body
          };
        }
        async createChannel() {
          throw this.unimplemented("Not implemented on web.");
        }
        async deleteChannel() {
          throw this.unimplemented("Not implemented on web.");
        }
        async listChannels() {
          throw this.unimplemented("Not implemented on web.");
        }
        async schedule(options) {
          if (!this.hasNotificationSupport()) {
            throw this.unavailable("Notifications not supported in this browser.");
          }
          for (const notification of options.notifications) {
            this.sendNotification(notification);
          }
          return {
            notifications: options.notifications.map((notification) => ({
              id: notification.id
            }))
          };
        }
        async update(options) {
          if (!this.hasNotificationSupport()) {
            throw this.unavailable("Notifications not supported in this browser.");
          }
          const updated = [];
          for (const notification of options.notifications) {
            const index = this.pending.findIndex((n) => n.id === notification.id);
            if (index === -1) {
              continue;
            }
            this.pending.splice(index, 1);
            this.sendNotification(notification);
            updated.push(notification);
          }
          return {
            notifications: updated.map((notification) => ({ id: notification.id }))
          };
        }
        async getPending() {
          return {
            notifications: this.pending
          };
        }
        async cancelAll() {
          this.pending = [];
        }
        async registerActionTypes() {
          throw this.unimplemented("Not implemented on web.");
        }
        async cancel(pending) {
          this.pending = this.pending.filter((notification) => !pending.notifications.find((n) => n.id === notification.id));
        }
        async areEnabled() {
          const { display: display2 } = await this.checkPermissions();
          return {
            value: display2 === "granted"
          };
        }
        async changeExactNotificationSetting() {
          throw this.unimplemented("Not implemented on web.");
        }
        async checkExactNotificationSetting() {
          throw this.unimplemented("Not implemented on web.");
        }
        async requestPermissions() {
          if (!this.hasNotificationSupport()) {
            throw this.unavailable("Notifications not supported in this browser.");
          }
          const display2 = this.transformNotificationPermission(await Notification.requestPermission());
          return { display: display2 };
        }
        async checkPermissions() {
          if (!this.hasNotificationSupport()) {
            throw this.unavailable("Notifications not supported in this browser.");
          }
          const display2 = this.transformNotificationPermission(Notification.permission);
          return { display: display2 };
        }
        transformNotificationPermission(permission) {
          switch (permission) {
            case "granted":
              return "granted";
            case "denied":
              return "denied";
            default:
              return "prompt";
          }
        }
        sendPending() {
          var _a;
          const toRemove = [];
          const now = (/* @__PURE__ */ new Date()).getTime();
          for (const notification of this.pending) {
            if (((_a = notification.schedule) === null || _a === void 0 ? void 0 : _a.at) && notification.schedule.at.getTime() <= now) {
              this.buildNotification(notification);
              toRemove.push(notification);
            }
          }
          this.pending = this.pending.filter((notification) => !toRemove.find((n) => n === notification));
        }
        sendNotification(notification) {
          var _a;
          if ((_a = notification.schedule) === null || _a === void 0 ? void 0 : _a.at) {
            const diff = notification.schedule.at.getTime() - (/* @__PURE__ */ new Date()).getTime();
            this.pending.push(notification);
            setTimeout(() => {
              this.sendPending();
            }, diff);
            return;
          }
          this.buildNotification(notification);
        }
        buildNotification(notification) {
          const localNotification = new Notification(notification.title, {
            body: notification.body,
            tag: String(notification.id)
          });
          localNotification.addEventListener("click", this.onClick.bind(this, notification), false);
          localNotification.addEventListener("show", this.onShow.bind(this, notification), false);
          localNotification.addEventListener("close", () => {
            this.deliveredNotifications = this.deliveredNotifications.filter(() => !this);
          }, false);
          this.deliveredNotifications.push(localNotification);
          return localNotification;
        }
        onClick(notification) {
          const data = {
            actionId: "tap",
            notification
          };
          this.notifyListeners("localNotificationActionPerformed", data);
        }
        onShow(notification) {
          this.notifyListeners("localNotificationReceived", notification);
        }
      };
    }
  });

  // desktop/src/reminders.js
  var require_reminders = __commonJS({
    "desktop/src/reminders.js"(exports, module) {
      init_globals();
      var DAY = 864e5;
      var GRACE = 20 * 60 * 1e3;
      function startOf(ev) {
        return ev.allDay ? /* @__PURE__ */ new Date(ev.start + "T00:00:00") : new Date(ev.start);
      }
      var UNIT = { minute: "\uBD84", hour: "\uC2DC\uAC04", day: "\uC77C", week: "\uC8FC", month: "\uB2EC" };
      function customTriggers(ev, list) {
        const s = startOf(ev);
        const out = [];
        list.forEach((c, i) => {
          const n = Math.max(0, Math.floor(Number(c.n) || 0));
          if (!UNIT[c.unit]) return;
          let at;
          if (c.unit === "minute") at = new Date(s.getTime() - n * 6e4);
          else if (c.unit === "hour") at = new Date(s.getTime() - n * 36e5);
          else {
            at = new Date(s);
            if (c.unit === "month") at.setMonth(at.getMonth() - n);
            else at.setDate(at.getDate() - n * (c.unit === "week" ? 7 : 1));
            if (c.time && /^\d{1,2}:\d{2}$/.test(c.time)) {
              const [h, m2] = c.time.split(":").map(Number);
              at.setHours(h, m2, 0, 0);
            } else if (ev.allDay) at.setHours(9, 0, 0, 0);
          }
          const when = n === 0 ? c.unit === "minute" || c.unit === "hour" ? "\uC9C0\uAE08 \uC2DC\uC791" : "\uB2F9\uC77C" : `${n}${UNIT[c.unit]} \uC804`;
          out.push({ kind: `c${i}-${n}${c.unit}${c.time || ""}`, label: `${when} \uC54C\uB9BC${c.time && !["minute", "hour"].includes(c.unit) ? ` \xB7 ${c.time}` : ""}`, at });
        });
        return out;
      }
      function triggersFor(ev, r) {
        if (Array.isArray(ev.remind)) return customTriggers(ev, ev.remind);
        const s = startOf(ev);
        const list = [];
        const at9 = (d) => {
          const x = new Date(d);
          x.setHours(9, 0, 0, 0);
          return x;
        };
        const base = ev.allDay ? at9(s) : s;
        if (r.month) list.push({ kind: "month", label: "\uD55C \uB2EC \uC804 \uC54C\uB9BC", at: new Date(base.getTime() - 30 * DAY) });
        if (r.week) list.push({ kind: "week", label: "\uC77C\uC8FC\uC77C \uC804 \uC54C\uB9BC", at: new Date(base.getTime() - 7 * DAY) });
        if (r.day) list.push({ kind: "day", label: "\uD558\uB8E8 \uC804 \uC54C\uB9BC", at: new Date(base.getTime() - DAY) });
        if (r.sameDay) {
          const m2 = new Date(s);
          m2.setHours(r.sameDayHour ?? 8, 0, 0, 0);
          if (ev.allDay || m2 < s) list.push({ kind: "sameDay", label: "\uC624\uB298 \uC77C\uC815", at: m2 });
        }
        if (!ev.allDay && r.before > 0) list.push({ kind: "before", label: `${r.before}\uBD84 \uD6C4 \uC2DC\uC791`, at: new Date(s.getTime() - r.before * 6e4) });
        return list;
      }
      function due(events, settings, state2, now = /* @__PURE__ */ new Date()) {
        const out = [];
        const r = settings.reminders || {};
        const byId = new Map(events.map((e) => [e.id, e]));
        for (const ev of events) {
          if (startOf(ev).getTime() + DAY < now.getTime()) continue;
          for (const t of triggersFor(ev, r)) {
            const key = `${ev.id}#${t.kind}`;
            if (state2.fired[key]) continue;
            const diff = now - t.at;
            if (diff >= 0 && diff <= GRACE) {
              state2.fired[key] = now.getTime();
              out.push({ key, label: t.label, event: ev });
            } else if (diff > GRACE) {
              state2.fired[key] = -now.getTime();
            }
          }
        }
        state2.snoozes = (state2.snoozes || []).filter((sn) => {
          if (sn.at > now.getTime()) return true;
          const ev = byId.get(sn.eventId);
          if (ev) out.push({ key: `${sn.eventId}#snooze#${sn.at}`, label: "\uB2E4\uC2DC \uC54C\uB9BC", event: ev });
          return false;
        });
        const cutoff = now.getTime() - 45 * DAY;
        for (const k of Object.keys(state2.fired)) if (Math.abs(state2.fired[k]) < cutoff) delete state2.fired[k];
        return out;
      }
      module.exports = { due, triggersFor, UNIT };
    }
  });

  // mobile/updater.js
  var updater_exports = {};
  __export(updater_exports, {
    applyAndRestart: () => applyAndRestart,
    autoUpdate: () => autoUpdate,
    check: () => check,
    cleanup: () => cleanup,
    default: () => updater_default,
    getState: () => getState,
    init: () => init,
    newer: () => newer,
    prepare: () => prepare,
    updateNow: () => updateNow
  });
  function newer(a, b) {
    const p = (v) => String(v || "").replace(/^v/, "").split(".").map((x2) => parseInt(x2, 10) || 0);
    const x = p(a), y = p(b);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  }
  function init(o) {
    cur = window.__APP_VERSION || o.version;
    onState = o.onState || onState;
    if (Capacitor.isNativePlatform()) App.getInfo().then((i) => {
      native = parseInt(i.build, 10) || 0;
    }).catch(() => {
    });
  }
  async function getJSON(u) {
    const r = await f(u + (u.includes("?") ? "&" : "?") + "t=" + Date.now(), { headers: { "User-Agent": "TotalCalendar-Android", "Cache-Control": "no-cache", Accept: "application/json" } });
    if (!r.ok) throw new Error(`\uC5C5\uB370\uC774\uD2B8 \uC11C\uBC84 \uC751\uB2F5 \uC624\uB958 (${r.status})`);
    return r.json();
  }
  async function check() {
    set({ phase: "checking", message: "\uC0C8 \uBC84\uC804 \uD655\uC778 \uC911\u2026" });
    try {
      let j;
      try {
        j = await getJSON(FEED);
      } catch {
        const c = await getJSON(FEED_API);
        j = JSON.parse(decodeURIComponent(escape(atob(String(c.content).replace(/\s/g, "")))));
      }
      if (!j || !j.version || !j.url) throw new Error("\uC5C5\uB370\uC774\uD2B8 \uC815\uBCF4\uAC00 \uBE44\uC5B4 \uC788\uC5B4\uC694");
      const needApk = newer(j.version, cur) && native > 0 && (j.minNative || 0) > native;
      set({
        phase: "idle",
        latest: j,
        needApk,
        checkedAt: Date.now(),
        message: !newer(j.version, cur) ? "\uCD5C\uC2E0 \uBC84\uC804\uC774\uC5D0\uC694" : needApk ? `\uC0C8 \uBC84\uC804 ${j.version}\uC740 \uC571\uC744 \uC0C8\uB85C \uC124\uCE58\uD574\uC57C \uD574\uC694 (\uAC1C\uBC1C\uC790\uC5D0\uAC8C \uC0C8 APK\uB97C \uBC1B\uC544 \uC8FC\uC138\uC694)` : `\uC0C8 \uBC84\uC804 ${j.version}\uC774 \uC788\uC5B4\uC694`
      });
    } catch (e) {
      set({ phase: "idle", checkedAt: Date.now(), message: "\uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694: " + (e.message || e) });
    }
    return getState();
  }
  async function prepare() {
    if (!state.latest) await check();
    const L = state.latest;
    if (!L || !newer(L.version, cur)) throw new Error("\uC774\uBBF8 \uCD5C\uC2E0 \uBC84\uC804\uC774\uC5D0\uC694");
    if (state.needApk) throw new Error("\uC774 \uBC84\uC804\uC740 \uC571\uC744 \uC0C8\uB85C \uC124\uCE58\uD574\uC57C \uD574\uC694");
    if (!Capacitor.isNativePlatform()) throw new Error("\uD734\uB300\uD3F0 \uC571\uC5D0\uC11C\uB9CC \uC5C5\uB370\uC774\uD2B8\uD560 \uC218 \uC788\uC5B4\uC694");
    set({ phase: "download", progress: 0.3, message: "\uC0C8 \uBC84\uC804 \uB0B4\uB824\uBC1B\uB294 \uC911\u2026 (10~30\uCD08)" });
    const r = await WebUpdate.download({ url: L.url, sha256: L.sha256 || "", version: L.version });
    preparedPath = r.path;
    set({ phase: "ready", progress: 1, message: `${L.version} \uC900\uBE44 \uC644\uB8CC \xB7 \uB2E4\uC2DC \uC2DC\uC791\uD558\uBA74 \uC801\uC6A9\uB3FC\uC694` });
    return getState();
  }
  function applyAndRestart() {
    if (preparedPath) WebUpdate.apply({ path: preparedPath }).catch((e) => set({ message: "\uC801\uC6A9\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694: " + (e.message || e) }));
  }
  async function autoUpdate(toast) {
    await check();
    if (!getState().available) return;
    try {
      toast && toast(`\uC0C8 \uBC84\uC804 ${state.latest.version}\uC744 \uBC1B\uB294 \uC911\uC774\uC5D0\uC694\u2026`);
      await prepare();
      await WebUpdate.persist({ path: preparedPath });
      if (window.confirm(`\uC0C8 \uBC84\uC804 ${state.latest.version}\uC774 \uC900\uBE44\uB410\uC5B4\uC694.

${state.latest.notes || ""}

\uC9C0\uAE08 \uC801\uC6A9\uD560\uAE4C\uC694? (\uBA87 \uCD08 \uB4A4 \uB2E4\uC2DC \uC5F4\uB824\uC694)`)) applyAndRestart();
      else toast && toast("\uB2E4\uC74C\uC5D0 \uC571\uC744 \uC5F4\uBA74 \uC0C8 \uBC84\uC804\uC774 \uC801\uC6A9\uB3FC\uC694");
    } catch (e) {
      console.warn("\uC790\uB3D9 \uC5C5\uB370\uC774\uD2B8 \uC2E4\uD328", e);
      toast && toast("\uC5C5\uB370\uC774\uD2B8 \uBC1B\uAE30 \uC2E4\uD328: " + (e.message || e));
    }
  }
  async function updateNow(toast) {
    toast("\uC0C8 \uBC84\uC804 \uD655\uC778 \uC911\u2026");
    await check();
    const st = getState();
    if (st.needApk) {
      window.alert(st.message);
      return;
    }
    if (!st.available) {
      toast(st.message && /확인하지 못했어요/.test(st.message) ? st.message : `\uCD5C\uC2E0 \uBC84\uC804\uC774\uC5D0\uC694 (v${cur})`);
      return;
    }
    if (!window.confirm(`\uC0C8 \uBC84\uC804 ${st.latest.version}\uC774 \uC788\uC5B4\uC694.

${st.latest.notes || ""}

\uC9C0\uAE08 \uC5C5\uB370\uC774\uD2B8\uD560\uAE4C\uC694?`)) return;
    try {
      toast(`\uC0C8 \uBC84\uC804 ${st.latest.version} \uBC1B\uB294 \uC911\u2026 (10~30\uCD08)`);
      await prepare();
      toast("\uC801\uC6A9\uD558\uB294 \uC911\u2026 \uC7A0\uC2DC \uB4A4 \uB2E4\uC2DC \uC5F4\uB824\uC694");
      setTimeout(applyAndRestart, 600);
    } catch (e) {
      window.alert("\uC5C5\uB370\uC774\uD2B8\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694: " + (e.message || e));
    }
  }
  var WebUpdate, FEED, FEED_API, cur, native, onState, state, set, getState, f, preparedPath, cleanup, updater_default;
  var init_updater = __esm({
    "mobile/updater.js"() {
      init_globals();
      init_dist();
      init_esm();
      init_http();
      WebUpdate = registerPlugin("WebUpdate");
      FEED = "https://raw.githubusercontent.com/kkumanix/total-calendar/main/android/latest.json";
      FEED_API = "https://api.github.com/repos/kkumanix/total-calendar/contents/android/latest.json";
      cur = "0.0.0";
      native = 0;
      onState = () => {
      };
      state = { phase: "idle", latest: null, progress: 0, message: "", checkedAt: 0, needApk: false };
      set = (s) => {
        state = { ...state, ...s };
        onState(getState());
      };
      getState = () => ({ ...state, current: cur, available: !!(state.latest && newer(state.latest.version, cur) && !state.needApk) });
      f = Capacitor.isNativePlatform() ? nativeFetch : fetch;
      preparedPath = "";
      cleanup = () => {
      };
      updater_default = { init, check, prepare, applyAndRestart, getState, newer, autoUpdate, updateNow };
    }
  });

  // desktop/package.json
  var require_package = __commonJS({
    "desktop/package.json"(exports, module) {
      module.exports = {
        name: "deskcal",
        productName: "DeskCal",
        version: "1.9.23",
        description: "\uBC14\uD0D5\uD654\uBA74 \uCE98\uB9B0\uB354",
        main: "main.js",
        author: "Minwoo Jung",
        license: "UNLICENSED",
        scripts: { start: "electron ." },
        dependencies: {
          "ical-expander": "^3.1.0",
          koffi: "^2.9.0",
          tsdav: "^2.1.0"
        },
        devDependencies: {
          electron: "^33.0.0",
          "@electron/packager": "^18.3.0"
        }
      };
    }
  });

  // node_modules/ical.js/build/ical.js
  var require_ical = __commonJS({
    "node_modules/ical.js/build/ical.js"(exports, module) {
      init_globals();
      var ICAL;
      (function() {
        if (typeof module === "object") {
          ICAL = module.exports;
        } else if (typeof HTMLScriptElement !== "undefined" && "noModule" in HTMLScriptElement.prototype) {
          window.ICAL = ICAL = {};
        } else if (typeof ICAL !== "object") {
          ICAL = {};
        }
      })();
      ICAL.foldLength = 75;
      ICAL.newLineChar = "\r\n";
      ICAL.helpers = {
        /**
         * Compiles a list of all referenced TZIDs in all subcomponents and
         * removes any extra VTIMEZONE subcomponents. In addition, if any TZIDs
         * are referenced by a component, but a VTIMEZONE does not exist,
         * an attempt will be made to generate a VTIMEZONE using ICAL.TimezoneService.
         *
         * @param {ICAL.Component} vcal     The top-level VCALENDAR component.
         * @return {ICAL.Component}         The ICAL.Component that was passed in.
         */
        updateTimezones: function(vcal) {
          var allsubs, properties, vtimezones, reqTzid, i, tzid;
          if (!vcal || vcal.name !== "vcalendar") {
            return vcal;
          }
          allsubs = vcal.getAllSubcomponents();
          properties = [];
          vtimezones = {};
          for (i = 0; i < allsubs.length; i++) {
            if (allsubs[i].name === "vtimezone") {
              tzid = allsubs[i].getFirstProperty("tzid").getFirstValue();
              vtimezones[tzid] = allsubs[i];
            } else {
              properties = properties.concat(allsubs[i].getAllProperties());
            }
          }
          reqTzid = {};
          for (i = 0; i < properties.length; i++) {
            if (tzid = properties[i].getParameter("tzid")) {
              reqTzid[tzid] = true;
            }
          }
          for (i in vtimezones) {
            if (vtimezones.hasOwnProperty(i) && !reqTzid[i]) {
              vcal.removeSubcomponent(vtimezones[i]);
            }
          }
          for (i in reqTzid) {
            if (reqTzid.hasOwnProperty(i) && !vtimezones[i] && ICAL.TimezoneService.has(i)) {
              vcal.addSubcomponent(ICAL.TimezoneService.get(i).component);
            }
          }
          return vcal;
        },
        /**
         * Checks if the given type is of the number type and also NaN.
         *
         * @param {Number} number     The number to check
         * @return {Boolean}          True, if the number is strictly NaN
         */
        isStrictlyNaN: function(number) {
          return typeof number === "number" && isNaN(number);
        },
        /**
         * Parses a string value that is expected to be an integer, when the valid is
         * not an integer throws a decoration error.
         *
         * @param {String} string     Raw string input
         * @return {Number}           Parsed integer
         */
        strictParseInt: function(string) {
          var result = parseInt(string, 10);
          if (ICAL.helpers.isStrictlyNaN(result)) {
            throw new Error(
              'Could not extract integer from "' + string + '"'
            );
          }
          return result;
        },
        /**
         * Creates or returns a class instance of a given type with the initialization
         * data if the data is not already an instance of the given type.
         *
         * @example
         * var time = new ICAL.Time(...);
         * var result = ICAL.helpers.formatClassType(time, ICAL.Time);
         *
         * (result instanceof ICAL.Time)
         * // => true
         *
         * result = ICAL.helpers.formatClassType({}, ICAL.Time);
         * (result isntanceof ICAL.Time)
         * // => true
         *
         *
         * @param {Object} data       object initialization data
         * @param {Object} type       object type (like ICAL.Time)
         * @return {?}                An instance of the found type.
         */
        formatClassType: function formatClassType(data, type) {
          if (typeof data === "undefined") {
            return void 0;
          }
          if (data instanceof type) {
            return data;
          }
          return new type(data);
        },
        /**
         * Identical to indexOf but will only match values when they are not preceded
         * by a backslash character.
         *
         * @param {String} buffer         String to search
         * @param {String} search         Value to look for
         * @param {Number} pos            Start position
         * @return {Number}               The position, or -1 if not found
         */
        unescapedIndexOf: function(buffer, search, pos) {
          while ((pos = buffer.indexOf(search, pos)) !== -1) {
            if (pos > 0 && buffer[pos - 1] === "\\") {
              pos += 1;
            } else {
              return pos;
            }
          }
          return -1;
        },
        /**
         * Find the index for insertion using binary search.
         *
         * @param {Array} list            The list to search
         * @param {?} seekVal             The value to insert
         * @param {function(?,?)} cmpfunc The comparison func, that can
         *                                  compare two seekVals
         * @return {Number}               The insert position
         */
        binsearchInsert: function(list, seekVal, cmpfunc) {
          if (!list.length)
            return 0;
          var low = 0, high = list.length - 1, mid, cmpval;
          while (low <= high) {
            mid = low + Math.floor((high - low) / 2);
            cmpval = cmpfunc(seekVal, list[mid]);
            if (cmpval < 0)
              high = mid - 1;
            else if (cmpval > 0)
              low = mid + 1;
            else
              break;
          }
          if (cmpval < 0)
            return mid;
          else if (cmpval > 0)
            return mid + 1;
          else
            return mid;
        },
        /**
         * Convenience function for debug output
         * @private
         */
        dumpn: (
          /* istanbul ignore next */
          function() {
            if (!ICAL.debug) {
              return;
            }
            if (typeof console !== "undefined" && "log" in console) {
              ICAL.helpers.dumpn = function consoleDumpn(input) {
                console.log(input);
              };
            } else {
              ICAL.helpers.dumpn = function geckoDumpn(input) {
                dump(input + "\n");
              };
            }
            ICAL.helpers.dumpn(arguments[0]);
          }
        ),
        /**
         * Clone the passed object or primitive. By default a shallow clone will be
         * executed.
         *
         * @param {*} aSrc            The thing to clone
         * @param {Boolean=} aDeep    If true, a deep clone will be performed
         * @return {*}                The copy of the thing
         */
        clone: function(aSrc, aDeep) {
          if (!aSrc || typeof aSrc != "object") {
            return aSrc;
          } else if (aSrc instanceof Date) {
            return new Date(aSrc.getTime());
          } else if ("clone" in aSrc) {
            return aSrc.clone();
          } else if (Array.isArray(aSrc)) {
            var arr = [];
            for (var i = 0; i < aSrc.length; i++) {
              arr.push(aDeep ? ICAL.helpers.clone(aSrc[i], true) : aSrc[i]);
            }
            return arr;
          } else {
            var obj = {};
            for (var name in aSrc) {
              if (Object.prototype.hasOwnProperty.call(aSrc, name)) {
                if (aDeep) {
                  obj[name] = ICAL.helpers.clone(aSrc[name], true);
                } else {
                  obj[name] = aSrc[name];
                }
              }
            }
            return obj;
          }
        },
        /**
         * Performs iCalendar line folding. A line ending character is inserted and
         * the next line begins with a whitespace.
         *
         * @example
         * SUMMARY:This line will be fold
         *  ed right in the middle of a word.
         *
         * @param {String} aLine      The line to fold
         * @return {String}           The folded line
         */
        foldline: function foldline(aLine) {
          var result = "";
          var line = aLine || "", pos = 0, line_length = 0;
          while (line.length) {
            var cp = line.codePointAt(pos);
            if (cp < 128) ++line_length;
            else if (cp < 2048) line_length += 2;
            else if (cp < 65536) line_length += 3;
            else line_length += 4;
            if (line_length < ICAL.foldLength + 1)
              pos += cp > 65535 ? 2 : 1;
            else {
              result += ICAL.newLineChar + " " + line.substring(0, pos);
              line = line.substring(pos);
              pos = line_length = 0;
            }
          }
          return result.substr(ICAL.newLineChar.length + 1);
        },
        /**
         * Pads the given string or number with zeros so it will have at least two
         * characters.
         *
         * @param {String|Number} data    The string or number to pad
         * @return {String}               The number padded as a string
         */
        pad2: function pad(data) {
          if (typeof data !== "string") {
            if (typeof data === "number") {
              data = parseInt(data);
            }
            data = String(data);
          }
          var len = data.length;
          switch (len) {
            case 0:
              return "00";
            case 1:
              return "0" + data;
            default:
              return data;
          }
        },
        /**
         * Truncates the given number, correctly handling negative numbers.
         *
         * @param {Number} number     The number to truncate
         * @return {Number}           The truncated number
         */
        trunc: function trunc(number) {
          return number < 0 ? Math.ceil(number) : Math.floor(number);
        },
        /**
         * Poor-man's cross-browser inheritance for JavaScript. Doesn't support all
         * the features, but enough for our usage.
         *
         * @param {Function} base     The base class constructor function.
         * @param {Function} child    The child class constructor function.
         * @param {Object} extra      Extends the prototype with extra properties
         *                              and methods
         */
        inherits: function(base, child, extra) {
          function F() {
          }
          F.prototype = base.prototype;
          child.prototype = new F();
          if (extra) {
            ICAL.helpers.extend(extra, child.prototype);
          }
        },
        /**
         * Poor-man's cross-browser object extension. Doesn't support all the
         * features, but enough for our usage. Note that the target's properties are
         * not overwritten with the source properties.
         *
         * @example
         * var child = ICAL.helpers.extend(parent, {
         *   "bar": 123
         * });
         *
         * @param {Object} source     The object to extend
         * @param {Object} target     The object to extend with
         * @return {Object}           Returns the target.
         */
        extend: function(source, target) {
          for (var key in source) {
            var descr = Object.getOwnPropertyDescriptor(source, key);
            if (descr && !Object.getOwnPropertyDescriptor(target, key)) {
              Object.defineProperty(target, key, descr);
            }
          }
          return target;
        }
      };
      ICAL.design = (function() {
        "use strict";
        var FROM_ICAL_NEWLINE = /\\\\|\\;|\\,|\\[Nn]/g;
        var TO_ICAL_NEWLINE = /\\|;|,|\n/g;
        var FROM_VCARD_NEWLINE = /\\\\|\\,|\\[Nn]/g;
        var TO_VCARD_NEWLINE = /\\|,|\n/g;
        function createTextType(fromNewline, toNewline) {
          var result = {
            matches: /.*/,
            fromICAL: function(aValue, structuredEscape) {
              return replaceNewline(aValue, fromNewline, structuredEscape);
            },
            toICAL: function(aValue, structuredEscape) {
              var regEx = toNewline;
              if (structuredEscape)
                regEx = new RegExp(regEx.source + "|" + structuredEscape);
              return aValue.replace(regEx, function(str) {
                switch (str) {
                  case "\\":
                    return "\\\\";
                  case ";":
                    return "\\;";
                  case ",":
                    return "\\,";
                  case "\n":
                    return "\\n";
                  /* istanbul ignore next */
                  default:
                    return str;
                }
              });
            }
          };
          return result;
        }
        var DEFAULT_TYPE_TEXT = { defaultType: "text" };
        var DEFAULT_TYPE_TEXT_MULTI = { defaultType: "text", multiValue: "," };
        var DEFAULT_TYPE_TEXT_STRUCTURED = { defaultType: "text", structuredValue: ";" };
        var DEFAULT_TYPE_INTEGER = { defaultType: "integer" };
        var DEFAULT_TYPE_DATETIME_DATE = { defaultType: "date-time", allowedTypes: ["date-time", "date"] };
        var DEFAULT_TYPE_DATETIME = { defaultType: "date-time" };
        var DEFAULT_TYPE_URI = { defaultType: "uri" };
        var DEFAULT_TYPE_UTCOFFSET = { defaultType: "utc-offset" };
        var DEFAULT_TYPE_RECUR = { defaultType: "recur" };
        var DEFAULT_TYPE_DATE_ANDOR_TIME = { defaultType: "date-and-or-time", allowedTypes: ["date-time", "date", "text"] };
        function replaceNewlineReplace(string) {
          switch (string) {
            case "\\\\":
              return "\\";
            case "\\;":
              return ";";
            case "\\,":
              return ",";
            case "\\n":
            case "\\N":
              return "\n";
            /* istanbul ignore next */
            default:
              return string;
          }
        }
        function replaceNewline(value, newline, structuredEscape) {
          if (value.indexOf("\\") === -1) {
            return value;
          }
          if (structuredEscape)
            newline = new RegExp(newline.source + "|\\\\" + structuredEscape);
          return value.replace(newline, replaceNewlineReplace);
        }
        var commonProperties = {
          "categories": DEFAULT_TYPE_TEXT_MULTI,
          "url": DEFAULT_TYPE_URI,
          "version": DEFAULT_TYPE_TEXT,
          "uid": DEFAULT_TYPE_TEXT
        };
        var commonValues = {
          "boolean": {
            values: ["TRUE", "FALSE"],
            fromICAL: function(aValue) {
              switch (aValue) {
                case "TRUE":
                  return true;
                case "FALSE":
                  return false;
                default:
                  return false;
              }
            },
            toICAL: function(aValue) {
              if (aValue) {
                return "TRUE";
              }
              return "FALSE";
            }
          },
          float: {
            matches: /^[+-]?\d+\.\d+$/,
            fromICAL: function(aValue) {
              var parsed = parseFloat(aValue);
              if (ICAL.helpers.isStrictlyNaN(parsed)) {
                return 0;
              }
              return parsed;
            },
            toICAL: function(aValue) {
              return String(aValue);
            }
          },
          integer: {
            fromICAL: function(aValue) {
              var parsed = parseInt(aValue);
              if (ICAL.helpers.isStrictlyNaN(parsed)) {
                return 0;
              }
              return parsed;
            },
            toICAL: function(aValue) {
              return String(aValue);
            }
          },
          "utc-offset": {
            toICAL: function(aValue) {
              if (aValue.length < 7) {
                return aValue.substr(0, 3) + aValue.substr(4, 2);
              } else {
                return aValue.substr(0, 3) + aValue.substr(4, 2) + aValue.substr(7, 2);
              }
            },
            fromICAL: function(aValue) {
              if (aValue.length < 6) {
                return aValue.substr(0, 3) + ":" + aValue.substr(3, 2);
              } else {
                return aValue.substr(0, 3) + ":" + aValue.substr(3, 2) + ":" + aValue.substr(5, 2);
              }
            },
            decorate: function(aValue) {
              return ICAL.UtcOffset.fromString(aValue);
            },
            undecorate: function(aValue) {
              return aValue.toString();
            }
          }
        };
        var icalParams = {
          // Although the syntax is DQUOTE uri DQUOTE, I don't think we should
          // enfoce anything aside from it being a valid content line.
          //
          // At least some params require - if multi values are used - DQUOTEs
          // for each of its values - e.g. delegated-from="uri1","uri2"
          // To indicate this, I introduced the new k/v pair
          // multiValueSeparateDQuote: true
          //
          // "ALTREP": { ... },
          // CN just wants a param-value
          // "CN": { ... }
          "cutype": {
            values: ["INDIVIDUAL", "GROUP", "RESOURCE", "ROOM", "UNKNOWN"],
            allowXName: true,
            allowIanaToken: true
          },
          "delegated-from": {
            valueType: "cal-address",
            multiValue: ",",
            multiValueSeparateDQuote: true
          },
          "delegated-to": {
            valueType: "cal-address",
            multiValue: ",",
            multiValueSeparateDQuote: true
          },
          // "DIR": { ... }, // See ALTREP
          "encoding": {
            values: ["8BIT", "BASE64"]
          },
          // "FMTTYPE": { ... }, // See ALTREP
          "fbtype": {
            values: ["FREE", "BUSY", "BUSY-UNAVAILABLE", "BUSY-TENTATIVE"],
            allowXName: true,
            allowIanaToken: true
          },
          // "LANGUAGE": { ... }, // See ALTREP
          "member": {
            valueType: "cal-address",
            multiValue: ",",
            multiValueSeparateDQuote: true
          },
          "partstat": {
            // TODO These values are actually different per-component
            values: [
              "NEEDS-ACTION",
              "ACCEPTED",
              "DECLINED",
              "TENTATIVE",
              "DELEGATED",
              "COMPLETED",
              "IN-PROCESS"
            ],
            allowXName: true,
            allowIanaToken: true
          },
          "range": {
            values: ["THISANDFUTURE"]
          },
          "related": {
            values: ["START", "END"]
          },
          "reltype": {
            values: ["PARENT", "CHILD", "SIBLING"],
            allowXName: true,
            allowIanaToken: true
          },
          "role": {
            values: [
              "REQ-PARTICIPANT",
              "CHAIR",
              "OPT-PARTICIPANT",
              "NON-PARTICIPANT"
            ],
            allowXName: true,
            allowIanaToken: true
          },
          "rsvp": {
            values: ["TRUE", "FALSE"]
          },
          "sent-by": {
            valueType: "cal-address"
          },
          "tzid": {
            matches: /^\//
          },
          "value": {
            // since the value here is a 'type' lowercase is used.
            values: [
              "binary",
              "boolean",
              "cal-address",
              "date",
              "date-time",
              "duration",
              "float",
              "integer",
              "period",
              "recur",
              "text",
              "time",
              "uri",
              "utc-offset"
            ],
            allowXName: true,
            allowIanaToken: true
          }
        };
        var icalValues = ICAL.helpers.extend(commonValues, {
          text: createTextType(FROM_ICAL_NEWLINE, TO_ICAL_NEWLINE),
          uri: {
            // TODO
            /* ... */
          },
          "binary": {
            decorate: function(aString) {
              return ICAL.Binary.fromString(aString);
            },
            undecorate: function(aBinary) {
              return aBinary.toString();
            }
          },
          "cal-address": {
            // needs to be an uri
          },
          "date": {
            decorate: function(aValue, aProp) {
              if (design.strict) {
                return ICAL.Time.fromDateString(aValue, aProp);
              } else {
                return ICAL.Time.fromString(aValue, aProp);
              }
            },
            /**
             * undecorates a time object.
             */
            undecorate: function(aValue) {
              return aValue.toString();
            },
            fromICAL: function(aValue) {
              if (!design.strict && aValue.length >= 15) {
                return icalValues["date-time"].fromICAL(aValue);
              } else {
                return aValue.substr(0, 4) + "-" + aValue.substr(4, 2) + "-" + aValue.substr(6, 2);
              }
            },
            toICAL: function(aValue) {
              var len = aValue.length;
              if (len == 10) {
                return aValue.substr(0, 4) + aValue.substr(5, 2) + aValue.substr(8, 2);
              } else if (len >= 19) {
                return icalValues["date-time"].toICAL(aValue);
              } else {
                return aValue;
              }
            }
          },
          "date-time": {
            fromICAL: function(aValue) {
              if (!design.strict && aValue.length == 8) {
                return icalValues.date.fromICAL(aValue);
              } else {
                var result = aValue.substr(0, 4) + "-" + aValue.substr(4, 2) + "-" + aValue.substr(6, 2) + "T" + aValue.substr(9, 2) + ":" + aValue.substr(11, 2) + ":" + aValue.substr(13, 2);
                if (aValue[15] && aValue[15] === "Z") {
                  result += "Z";
                }
                return result;
              }
            },
            toICAL: function(aValue) {
              var len = aValue.length;
              if (len == 10 && !design.strict) {
                return icalValues.date.toICAL(aValue);
              } else if (len >= 19) {
                var result = aValue.substr(0, 4) + aValue.substr(5, 2) + // grab the (DDTHH) segment
                aValue.substr(8, 5) + // MM
                aValue.substr(14, 2) + // SS
                aValue.substr(17, 2);
                if (aValue[19] && aValue[19] === "Z") {
                  result += "Z";
                }
                return result;
              } else {
                return aValue;
              }
            },
            decorate: function(aValue, aProp) {
              if (design.strict) {
                return ICAL.Time.fromDateTimeString(aValue, aProp);
              } else {
                return ICAL.Time.fromString(aValue, aProp);
              }
            },
            undecorate: function(aValue) {
              return aValue.toString();
            }
          },
          duration: {
            decorate: function(aValue) {
              return ICAL.Duration.fromString(aValue);
            },
            undecorate: function(aValue) {
              return aValue.toString();
            }
          },
          period: {
            fromICAL: function(string) {
              var parts = string.split("/");
              parts[0] = icalValues["date-time"].fromICAL(parts[0]);
              if (!ICAL.Duration.isValueString(parts[1])) {
                parts[1] = icalValues["date-time"].fromICAL(parts[1]);
              }
              return parts;
            },
            toICAL: function(parts) {
              if (!design.strict && parts[0].length == 10) {
                parts[0] = icalValues.date.toICAL(parts[0]);
              } else {
                parts[0] = icalValues["date-time"].toICAL(parts[0]);
              }
              if (!ICAL.Duration.isValueString(parts[1])) {
                if (!design.strict && parts[1].length == 10) {
                  parts[1] = icalValues.date.toICAL(parts[1]);
                } else {
                  parts[1] = icalValues["date-time"].toICAL(parts[1]);
                }
              }
              return parts.join("/");
            },
            decorate: function(aValue, aProp) {
              return ICAL.Period.fromJSON(aValue, aProp, !design.strict);
            },
            undecorate: function(aValue) {
              return aValue.toJSON();
            }
          },
          recur: {
            fromICAL: function(string) {
              return ICAL.Recur._stringToData(string, true);
            },
            toICAL: function(data) {
              var str = "";
              for (var k in data) {
                if (!Object.prototype.hasOwnProperty.call(data, k)) {
                  continue;
                }
                var val = data[k];
                if (k == "until") {
                  if (val.length > 10) {
                    val = icalValues["date-time"].toICAL(val);
                  } else {
                    val = icalValues.date.toICAL(val);
                  }
                } else if (k == "wkst") {
                  if (typeof val === "number") {
                    val = ICAL.Recur.numericDayToIcalDay(val);
                  }
                } else if (Array.isArray(val)) {
                  val = val.join(",");
                }
                str += k.toUpperCase() + "=" + val + ";";
              }
              return str.substr(0, str.length - 1);
            },
            decorate: function decorate(aValue) {
              return ICAL.Recur.fromData(aValue);
            },
            undecorate: function(aRecur) {
              return aRecur.toJSON();
            }
          },
          time: {
            fromICAL: function(aValue) {
              if (aValue.length < 6) {
                return aValue;
              }
              var result = aValue.substr(0, 2) + ":" + aValue.substr(2, 2) + ":" + aValue.substr(4, 2);
              if (aValue[6] === "Z") {
                result += "Z";
              }
              return result;
            },
            toICAL: function(aValue) {
              if (aValue.length < 8) {
                return aValue;
              }
              var result = aValue.substr(0, 2) + aValue.substr(3, 2) + aValue.substr(6, 2);
              if (aValue[8] === "Z") {
                result += "Z";
              }
              return result;
            }
          }
        });
        var icalProperties = ICAL.helpers.extend(commonProperties, {
          "action": DEFAULT_TYPE_TEXT,
          "attach": { defaultType: "uri" },
          "attendee": { defaultType: "cal-address" },
          "calscale": DEFAULT_TYPE_TEXT,
          "class": DEFAULT_TYPE_TEXT,
          "comment": DEFAULT_TYPE_TEXT,
          "completed": DEFAULT_TYPE_DATETIME,
          "contact": DEFAULT_TYPE_TEXT,
          "created": DEFAULT_TYPE_DATETIME,
          "description": DEFAULT_TYPE_TEXT,
          "dtend": DEFAULT_TYPE_DATETIME_DATE,
          "dtstamp": DEFAULT_TYPE_DATETIME,
          "dtstart": DEFAULT_TYPE_DATETIME_DATE,
          "due": DEFAULT_TYPE_DATETIME_DATE,
          "duration": { defaultType: "duration" },
          "exdate": {
            defaultType: "date-time",
            allowedTypes: ["date-time", "date"],
            multiValue: ","
          },
          "exrule": DEFAULT_TYPE_RECUR,
          "freebusy": { defaultType: "period", multiValue: "," },
          "geo": { defaultType: "float", structuredValue: ";" },
          "last-modified": DEFAULT_TYPE_DATETIME,
          "location": DEFAULT_TYPE_TEXT,
          "method": DEFAULT_TYPE_TEXT,
          "organizer": { defaultType: "cal-address" },
          "percent-complete": DEFAULT_TYPE_INTEGER,
          "priority": DEFAULT_TYPE_INTEGER,
          "prodid": DEFAULT_TYPE_TEXT,
          "related-to": DEFAULT_TYPE_TEXT,
          "repeat": DEFAULT_TYPE_INTEGER,
          "rdate": {
            defaultType: "date-time",
            allowedTypes: ["date-time", "date", "period"],
            multiValue: ",",
            detectType: function(string) {
              if (string.indexOf("/") !== -1) {
                return "period";
              }
              return string.indexOf("T") === -1 ? "date" : "date-time";
            }
          },
          "recurrence-id": DEFAULT_TYPE_DATETIME_DATE,
          "resources": DEFAULT_TYPE_TEXT_MULTI,
          "request-status": DEFAULT_TYPE_TEXT_STRUCTURED,
          "rrule": DEFAULT_TYPE_RECUR,
          "sequence": DEFAULT_TYPE_INTEGER,
          "status": DEFAULT_TYPE_TEXT,
          "summary": DEFAULT_TYPE_TEXT,
          "transp": DEFAULT_TYPE_TEXT,
          "trigger": { defaultType: "duration", allowedTypes: ["duration", "date-time"] },
          "tzoffsetfrom": DEFAULT_TYPE_UTCOFFSET,
          "tzoffsetto": DEFAULT_TYPE_UTCOFFSET,
          "tzurl": DEFAULT_TYPE_URI,
          "tzid": DEFAULT_TYPE_TEXT,
          "tzname": DEFAULT_TYPE_TEXT
        });
        var vcardValues = ICAL.helpers.extend(commonValues, {
          text: createTextType(FROM_VCARD_NEWLINE, TO_VCARD_NEWLINE),
          uri: createTextType(FROM_VCARD_NEWLINE, TO_VCARD_NEWLINE),
          date: {
            decorate: function(aValue) {
              return ICAL.VCardTime.fromDateAndOrTimeString(aValue, "date");
            },
            undecorate: function(aValue) {
              return aValue.toString();
            },
            fromICAL: function(aValue) {
              if (aValue.length == 8) {
                return icalValues.date.fromICAL(aValue);
              } else if (aValue[0] == "-" && aValue.length == 6) {
                return aValue.substr(0, 4) + "-" + aValue.substr(4);
              } else {
                return aValue;
              }
            },
            toICAL: function(aValue) {
              if (aValue.length == 10) {
                return icalValues.date.toICAL(aValue);
              } else if (aValue[0] == "-" && aValue.length == 7) {
                return aValue.substr(0, 4) + aValue.substr(5);
              } else {
                return aValue;
              }
            }
          },
          time: {
            decorate: function(aValue) {
              return ICAL.VCardTime.fromDateAndOrTimeString("T" + aValue, "time");
            },
            undecorate: function(aValue) {
              return aValue.toString();
            },
            fromICAL: function(aValue) {
              var splitzone = vcardValues.time._splitZone(aValue, true);
              var zone = splitzone[0], value = splitzone[1];
              if (value.length == 6) {
                value = value.substr(0, 2) + ":" + value.substr(2, 2) + ":" + value.substr(4, 2);
              } else if (value.length == 4 && value[0] != "-") {
                value = value.substr(0, 2) + ":" + value.substr(2, 2);
              } else if (value.length == 5) {
                value = value.substr(0, 3) + ":" + value.substr(3, 2);
              }
              if (zone.length == 5 && (zone[0] == "-" || zone[0] == "+")) {
                zone = zone.substr(0, 3) + ":" + zone.substr(3);
              }
              return value + zone;
            },
            toICAL: function(aValue) {
              var splitzone = vcardValues.time._splitZone(aValue);
              var zone = splitzone[0], value = splitzone[1];
              if (value.length == 8) {
                value = value.substr(0, 2) + value.substr(3, 2) + value.substr(6, 2);
              } else if (value.length == 5 && value[0] != "-") {
                value = value.substr(0, 2) + value.substr(3, 2);
              } else if (value.length == 6) {
                value = value.substr(0, 3) + value.substr(4, 2);
              }
              if (zone.length == 6 && (zone[0] == "-" || zone[0] == "+")) {
                zone = zone.substr(0, 3) + zone.substr(4);
              }
              return value + zone;
            },
            _splitZone: function(aValue, isFromIcal) {
              var lastChar = aValue.length - 1;
              var signChar = aValue.length - (isFromIcal ? 5 : 6);
              var sign = aValue[signChar];
              var zone, value;
              if (aValue[lastChar] == "Z") {
                zone = aValue[lastChar];
                value = aValue.substr(0, lastChar);
              } else if (aValue.length > 6 && (sign == "-" || sign == "+")) {
                zone = aValue.substr(signChar);
                value = aValue.substr(0, signChar);
              } else {
                zone = "";
                value = aValue;
              }
              return [zone, value];
            }
          },
          "date-time": {
            decorate: function(aValue) {
              return ICAL.VCardTime.fromDateAndOrTimeString(aValue, "date-time");
            },
            undecorate: function(aValue) {
              return aValue.toString();
            },
            fromICAL: function(aValue) {
              return vcardValues["date-and-or-time"].fromICAL(aValue);
            },
            toICAL: function(aValue) {
              return vcardValues["date-and-or-time"].toICAL(aValue);
            }
          },
          "date-and-or-time": {
            decorate: function(aValue) {
              return ICAL.VCardTime.fromDateAndOrTimeString(aValue, "date-and-or-time");
            },
            undecorate: function(aValue) {
              return aValue.toString();
            },
            fromICAL: function(aValue) {
              var parts = aValue.split("T");
              return (parts[0] ? vcardValues.date.fromICAL(parts[0]) : "") + (parts[1] ? "T" + vcardValues.time.fromICAL(parts[1]) : "");
            },
            toICAL: function(aValue) {
              var parts = aValue.split("T");
              return vcardValues.date.toICAL(parts[0]) + (parts[1] ? "T" + vcardValues.time.toICAL(parts[1]) : "");
            }
          },
          timestamp: icalValues["date-time"],
          "language-tag": {
            matches: /^[a-zA-Z0-9-]+$/
            // Could go with a more strict regex here
          }
        });
        var vcardParams = {
          "type": {
            valueType: "text",
            multiValue: ","
          },
          "value": {
            // since the value here is a 'type' lowercase is used.
            values: [
              "text",
              "uri",
              "date",
              "time",
              "date-time",
              "date-and-or-time",
              "timestamp",
              "boolean",
              "integer",
              "float",
              "utc-offset",
              "language-tag"
            ],
            allowXName: true,
            allowIanaToken: true
          }
        };
        var vcardProperties = ICAL.helpers.extend(commonProperties, {
          "adr": { defaultType: "text", structuredValue: ";", multiValue: "," },
          "anniversary": DEFAULT_TYPE_DATE_ANDOR_TIME,
          "bday": DEFAULT_TYPE_DATE_ANDOR_TIME,
          "caladruri": DEFAULT_TYPE_URI,
          "caluri": DEFAULT_TYPE_URI,
          "clientpidmap": DEFAULT_TYPE_TEXT_STRUCTURED,
          "email": DEFAULT_TYPE_TEXT,
          "fburl": DEFAULT_TYPE_URI,
          "fn": DEFAULT_TYPE_TEXT,
          "gender": DEFAULT_TYPE_TEXT_STRUCTURED,
          "geo": DEFAULT_TYPE_URI,
          "impp": DEFAULT_TYPE_URI,
          "key": DEFAULT_TYPE_URI,
          "kind": DEFAULT_TYPE_TEXT,
          "lang": { defaultType: "language-tag" },
          "logo": DEFAULT_TYPE_URI,
          "member": DEFAULT_TYPE_URI,
          "n": { defaultType: "text", structuredValue: ";", multiValue: "," },
          "nickname": DEFAULT_TYPE_TEXT_MULTI,
          "note": DEFAULT_TYPE_TEXT,
          "org": { defaultType: "text", structuredValue: ";" },
          "photo": DEFAULT_TYPE_URI,
          "related": DEFAULT_TYPE_URI,
          "rev": { defaultType: "timestamp" },
          "role": DEFAULT_TYPE_TEXT,
          "sound": DEFAULT_TYPE_URI,
          "source": DEFAULT_TYPE_URI,
          "tel": { defaultType: "uri", allowedTypes: ["uri", "text"] },
          "title": DEFAULT_TYPE_TEXT,
          "tz": { defaultType: "text", allowedTypes: ["text", "utc-offset", "uri"] },
          "xml": DEFAULT_TYPE_TEXT
        });
        var vcard3Values = ICAL.helpers.extend(commonValues, {
          binary: icalValues.binary,
          date: vcardValues.date,
          "date-time": vcardValues["date-time"],
          "phone-number": {
            // TODO
            /* ... */
          },
          uri: icalValues.uri,
          text: icalValues.text,
          time: icalValues.time,
          vcard: icalValues.text,
          "utc-offset": {
            toICAL: function(aValue) {
              return aValue.substr(0, 7);
            },
            fromICAL: function(aValue) {
              return aValue.substr(0, 7);
            },
            decorate: function(aValue) {
              return ICAL.UtcOffset.fromString(aValue);
            },
            undecorate: function(aValue) {
              return aValue.toString();
            }
          }
        });
        var vcard3Params = {
          "type": {
            valueType: "text",
            multiValue: ","
          },
          "value": {
            // since the value here is a 'type' lowercase is used.
            values: [
              "text",
              "uri",
              "date",
              "date-time",
              "phone-number",
              "time",
              "boolean",
              "integer",
              "float",
              "utc-offset",
              "vcard",
              "binary"
            ],
            allowXName: true,
            allowIanaToken: true
          }
        };
        var vcard3Properties = ICAL.helpers.extend(commonProperties, {
          fn: DEFAULT_TYPE_TEXT,
          n: { defaultType: "text", structuredValue: ";", multiValue: "," },
          nickname: DEFAULT_TYPE_TEXT_MULTI,
          photo: { defaultType: "binary", allowedTypes: ["binary", "uri"] },
          bday: {
            defaultType: "date-time",
            allowedTypes: ["date-time", "date"],
            detectType: function(string) {
              return string.indexOf("T") === -1 ? "date" : "date-time";
            }
          },
          adr: { defaultType: "text", structuredValue: ";", multiValue: "," },
          label: DEFAULT_TYPE_TEXT,
          tel: { defaultType: "phone-number" },
          email: DEFAULT_TYPE_TEXT,
          mailer: DEFAULT_TYPE_TEXT,
          tz: { defaultType: "utc-offset", allowedTypes: ["utc-offset", "text"] },
          geo: { defaultType: "float", structuredValue: ";" },
          title: DEFAULT_TYPE_TEXT,
          role: DEFAULT_TYPE_TEXT,
          logo: { defaultType: "binary", allowedTypes: ["binary", "uri"] },
          agent: { defaultType: "vcard", allowedTypes: ["vcard", "text", "uri"] },
          org: DEFAULT_TYPE_TEXT_STRUCTURED,
          note: DEFAULT_TYPE_TEXT_MULTI,
          prodid: DEFAULT_TYPE_TEXT,
          rev: {
            defaultType: "date-time",
            allowedTypes: ["date-time", "date"],
            detectType: function(string) {
              return string.indexOf("T") === -1 ? "date" : "date-time";
            }
          },
          "sort-string": DEFAULT_TYPE_TEXT,
          sound: { defaultType: "binary", allowedTypes: ["binary", "uri"] },
          class: DEFAULT_TYPE_TEXT,
          key: { defaultType: "binary", allowedTypes: ["binary", "text"] }
        });
        var icalSet = {
          value: icalValues,
          param: icalParams,
          property: icalProperties
        };
        var vcardSet = {
          value: vcardValues,
          param: vcardParams,
          property: vcardProperties
        };
        var vcard3Set = {
          value: vcard3Values,
          param: vcard3Params,
          property: vcard3Properties
        };
        var design = {
          /**
           * A designSet describes value, parameter and property data. It is used by
           * ther parser and stringifier in components and properties to determine they
           * should be represented.
           *
           * @typedef {Object} designSet
           * @memberOf ICAL.design
           * @property {Object} value       Definitions for value types, keys are type names
           * @property {Object} param       Definitions for params, keys are param names
           * @property {Object} property    Defintions for properties, keys are property names
           */
          /**
           * Can be set to false to make the parser more lenient.
           */
          strict: true,
          /**
           * The default set for new properties and components if none is specified.
           * @type {ICAL.design.designSet}
           */
          defaultSet: icalSet,
          /**
           * The default type for unknown properties
           * @type {String}
           */
          defaultType: "unknown",
          /**
           * Holds the design set for known top-level components
           *
           * @type {Object}
           * @property {ICAL.design.designSet} vcard       vCard VCARD
           * @property {ICAL.design.designSet} vevent      iCalendar VEVENT
           * @property {ICAL.design.designSet} vtodo       iCalendar VTODO
           * @property {ICAL.design.designSet} vjournal    iCalendar VJOURNAL
           * @property {ICAL.design.designSet} valarm      iCalendar VALARM
           * @property {ICAL.design.designSet} vtimezone   iCalendar VTIMEZONE
           * @property {ICAL.design.designSet} daylight    iCalendar DAYLIGHT
           * @property {ICAL.design.designSet} standard    iCalendar STANDARD
           *
           * @example
           * var propertyName = 'fn';
           * var componentDesign = ICAL.design.components.vcard;
           * var propertyDetails = componentDesign.property[propertyName];
           * if (propertyDetails.defaultType == 'text') {
           *   // Yep, sure is...
           * }
           */
          components: {
            vcard: vcardSet,
            vcard3: vcard3Set,
            vevent: icalSet,
            vtodo: icalSet,
            vjournal: icalSet,
            valarm: icalSet,
            vtimezone: icalSet,
            daylight: icalSet,
            standard: icalSet
          },
          /**
           * The design set for iCalendar (rfc5545/rfc7265) components.
           * @type {ICAL.design.designSet}
           */
          icalendar: icalSet,
          /**
           * The design set for vCard (rfc6350/rfc7095) components.
           * @type {ICAL.design.designSet}
           */
          vcard: vcardSet,
          /**
           * The design set for vCard (rfc2425/rfc2426/rfc7095) components.
           * @type {ICAL.design.designSet}
           */
          vcard3: vcard3Set,
          /**
           * Gets the design set for the given component name.
           *
           * @param {String} componentName        The name of the component
           * @return {ICAL.design.designSet}      The design set for the component
           */
          getDesignSet: function(componentName) {
            var isInDesign = componentName && componentName in design.components;
            return isInDesign ? design.components[componentName] : design.defaultSet;
          }
        };
        return design;
      })();
      ICAL.stringify = (function() {
        "use strict";
        var LINE_ENDING = "\r\n";
        var DEFAULT_VALUE_TYPE = "unknown";
        var design = ICAL.design;
        var helpers = ICAL.helpers;
        function stringify(jCal) {
          if (typeof jCal[0] == "string") {
            jCal = [jCal];
          }
          var i = 0;
          var len = jCal.length;
          var result = "";
          for (; i < len; i++) {
            result += stringify.component(jCal[i]) + LINE_ENDING;
          }
          return result;
        }
        stringify.component = function(component, designSet) {
          var name = component[0].toUpperCase();
          var result = "BEGIN:" + name + LINE_ENDING;
          var props = component[1];
          var propIdx = 0;
          var propLen = props.length;
          var designSetName = component[0];
          if (designSetName === "vcard" && component[1].length > 0 && !(component[1][0][0] === "version" && component[1][0][3] === "4.0")) {
            designSetName = "vcard3";
          }
          designSet = designSet || design.getDesignSet(designSetName);
          for (; propIdx < propLen; propIdx++) {
            result += stringify.property(props[propIdx], designSet) + LINE_ENDING;
          }
          var comps = component[2] || [];
          var compIdx = 0;
          var compLen = comps.length;
          for (; compIdx < compLen; compIdx++) {
            result += stringify.component(comps[compIdx], designSet) + LINE_ENDING;
          }
          result += "END:" + name;
          return result;
        };
        stringify.property = function(property, designSet, noFold) {
          var name = property[0].toUpperCase();
          var jsName = property[0];
          var params = property[1];
          var line = name;
          var paramName;
          for (paramName in params) {
            var value = params[paramName];
            if (params.hasOwnProperty(paramName)) {
              var multiValue = paramName in designSet.param && designSet.param[paramName].multiValue;
              if (multiValue && Array.isArray(value)) {
                if (designSet.param[paramName].multiValueSeparateDQuote) {
                  multiValue = '"' + multiValue + '"';
                }
                value = value.map(stringify._rfc6868Unescape);
                value = stringify.multiValue(value, multiValue, "unknown", null, designSet);
              } else {
                value = stringify._rfc6868Unescape(value);
              }
              line += ";" + paramName.toUpperCase();
              line += "=" + stringify.propertyValue(value);
            }
          }
          if (property.length === 3) {
            return line + ":";
          }
          var valueType = property[2];
          if (!designSet) {
            designSet = design.defaultSet;
          }
          var propDetails;
          var multiValue = false;
          var structuredValue = false;
          var isDefault = false;
          if (jsName in designSet.property) {
            propDetails = designSet.property[jsName];
            if ("multiValue" in propDetails) {
              multiValue = propDetails.multiValue;
            }
            if ("structuredValue" in propDetails && Array.isArray(property[3])) {
              structuredValue = propDetails.structuredValue;
            }
            if ("defaultType" in propDetails) {
              if (valueType === propDetails.defaultType) {
                isDefault = true;
              }
            } else {
              if (valueType === DEFAULT_VALUE_TYPE) {
                isDefault = true;
              }
            }
          } else {
            if (valueType === DEFAULT_VALUE_TYPE) {
              isDefault = true;
            }
          }
          if (!isDefault) {
            line += ";VALUE=" + valueType.toUpperCase();
          }
          line += ":";
          if (multiValue && structuredValue) {
            line += stringify.multiValue(
              property[3],
              structuredValue,
              valueType,
              multiValue,
              designSet,
              structuredValue
            );
          } else if (multiValue) {
            line += stringify.multiValue(
              property.slice(3),
              multiValue,
              valueType,
              null,
              designSet,
              false
            );
          } else if (structuredValue) {
            line += stringify.multiValue(
              property[3],
              structuredValue,
              valueType,
              null,
              designSet,
              structuredValue
            );
          } else {
            line += stringify.value(property[3], valueType, designSet, false);
          }
          return noFold ? line : ICAL.helpers.foldline(line);
        };
        stringify.propertyValue = function(value) {
          if (helpers.unescapedIndexOf(value, ",") === -1 && helpers.unescapedIndexOf(value, ":") === -1 && helpers.unescapedIndexOf(value, ";") === -1) {
            return value;
          }
          return '"' + value + '"';
        };
        stringify.multiValue = function(values, delim, type, innerMulti, designSet, structuredValue) {
          var result = "";
          var len = values.length;
          var i = 0;
          for (; i < len; i++) {
            if (innerMulti && Array.isArray(values[i])) {
              result += stringify.multiValue(values[i], innerMulti, type, null, designSet, structuredValue);
            } else {
              result += stringify.value(values[i], type, designSet, structuredValue);
            }
            if (i !== len - 1) {
              result += delim;
            }
          }
          return result;
        };
        stringify.value = function(value, type, designSet, structuredValue) {
          if (type in designSet.value && "toICAL" in designSet.value[type]) {
            return designSet.value[type].toICAL(value, structuredValue);
          }
          return value;
        };
        stringify._rfc6868Unescape = function(val) {
          return val.replace(/[\n^"]/g, function(x) {
            return RFC6868_REPLACE_MAP[x];
          });
        };
        var RFC6868_REPLACE_MAP = { '"': "^'", "\n": "^n", "^": "^^" };
        return stringify;
      })();
      ICAL.parse = (function() {
        "use strict";
        var CHAR = /[^ \t]/;
        var MULTIVALUE_DELIMITER = ",";
        var VALUE_DELIMITER = ":";
        var PARAM_DELIMITER = ";";
        var PARAM_NAME_DELIMITER = "=";
        var DEFAULT_VALUE_TYPE = "unknown";
        var DEFAULT_PARAM_TYPE = "text";
        var design = ICAL.design;
        var helpers = ICAL.helpers;
        function ParserError(message) {
          this.message = message;
          this.name = "ParserError";
          try {
            throw new Error();
          } catch (e) {
            if (e.stack) {
              var split = e.stack.split("\n");
              split.shift();
              this.stack = split.join("\n");
            }
          }
        }
        ParserError.prototype = Error.prototype;
        function parser(input) {
          var state2 = {};
          var root = state2.component = [];
          state2.stack = [root];
          parser._eachLine(input, function(err2, line) {
            parser._handleContentLine(line, state2);
          });
          if (state2.stack.length > 1) {
            throw new ParserError(
              "invalid ical body. component began but did not end"
            );
          }
          state2 = null;
          return root.length == 1 ? root[0] : root;
        }
        parser.property = function(str, designSet) {
          var state2 = {
            component: [[], []],
            designSet: designSet || design.defaultSet
          };
          parser._handleContentLine(str, state2);
          return state2.component[1][0];
        };
        parser.component = function(str) {
          return parser(str);
        };
        parser.ParserError = ParserError;
        parser._handleContentLine = function(line, state2) {
          var valuePos = line.indexOf(VALUE_DELIMITER);
          var paramPos = line.indexOf(PARAM_DELIMITER);
          var lastParamIndex;
          var lastValuePos;
          var name;
          var value;
          var params = {};
          if (paramPos !== -1 && valuePos !== -1) {
            if (paramPos > valuePos) {
              paramPos = -1;
            }
          }
          var parsedParams;
          if (paramPos !== -1) {
            name = line.substring(0, paramPos).toLowerCase();
            parsedParams = parser._parseParameters(line.substring(paramPos), 0, state2.designSet);
            if (parsedParams[2] == -1) {
              throw new ParserError("Invalid parameters in '" + line + "'");
            }
            params = parsedParams[0];
            lastParamIndex = parsedParams[1].length + parsedParams[2] + paramPos;
            if ((lastValuePos = line.substring(lastParamIndex).indexOf(VALUE_DELIMITER)) !== -1) {
              value = line.substring(lastParamIndex + lastValuePos + 1);
            } else {
              throw new ParserError("Missing parameter value in '" + line + "'");
            }
          } else if (valuePos !== -1) {
            name = line.substring(0, valuePos).toLowerCase();
            value = line.substring(valuePos + 1);
            if (name === "begin") {
              var newComponent = [value.toLowerCase(), [], []];
              if (state2.stack.length === 1) {
                state2.component.push(newComponent);
              } else {
                state2.component[2].push(newComponent);
              }
              state2.stack.push(state2.component);
              state2.component = newComponent;
              if (!state2.designSet) {
                state2.designSet = design.getDesignSet(state2.component[0]);
              }
              return;
            } else if (name === "end") {
              state2.component = state2.stack.pop();
              return;
            }
          } else {
            throw new ParserError(
              'invalid line (no token ";" or ":") "' + line + '"'
            );
          }
          var valueType;
          var multiValue = false;
          var structuredValue = false;
          var propertyDetails;
          if (name in state2.designSet.property) {
            propertyDetails = state2.designSet.property[name];
            if ("multiValue" in propertyDetails) {
              multiValue = propertyDetails.multiValue;
            }
            if ("structuredValue" in propertyDetails) {
              structuredValue = propertyDetails.structuredValue;
            }
            if (value && "detectType" in propertyDetails) {
              valueType = propertyDetails.detectType(value);
            }
          }
          if (!valueType) {
            if (!("value" in params)) {
              if (propertyDetails) {
                valueType = propertyDetails.defaultType;
              } else {
                valueType = DEFAULT_VALUE_TYPE;
              }
            } else {
              valueType = params.value.toLowerCase();
            }
          }
          delete params.value;
          var result;
          if (multiValue && structuredValue) {
            value = parser._parseMultiValue(value, structuredValue, valueType, [], multiValue, state2.designSet, structuredValue);
            result = [name, params, valueType, value];
          } else if (multiValue) {
            result = [name, params, valueType];
            parser._parseMultiValue(value, multiValue, valueType, result, null, state2.designSet, false);
          } else if (structuredValue) {
            value = parser._parseMultiValue(value, structuredValue, valueType, [], null, state2.designSet, structuredValue);
            result = [name, params, valueType, value];
          } else {
            value = parser._parseValue(value, valueType, state2.designSet, false);
            result = [name, params, valueType, value];
          }
          if (state2.component[0] === "vcard" && state2.component[1].length === 0 && !(name === "version" && value === "4.0")) {
            state2.designSet = design.getDesignSet("vcard3");
          }
          state2.component[1].push(result);
        };
        parser._parseValue = function(value, type, designSet, structuredValue) {
          if (type in designSet.value && "fromICAL" in designSet.value[type]) {
            return designSet.value[type].fromICAL(value, structuredValue);
          }
          return value;
        };
        parser._parseParameters = function(line, start, designSet) {
          var lastParam = start;
          var pos = 0;
          var delim = PARAM_NAME_DELIMITER;
          var result = {};
          var name, lcname;
          var value, valuePos = -1;
          var type, multiValue, mvdelim;
          while (pos !== false && (pos = helpers.unescapedIndexOf(line, delim, pos + 1)) !== -1) {
            name = line.substr(lastParam + 1, pos - lastParam - 1);
            if (name.length == 0) {
              throw new ParserError("Empty parameter name in '" + line + "'");
            }
            lcname = name.toLowerCase();
            mvdelim = false;
            multiValue = false;
            if (lcname in designSet.param && designSet.param[lcname].valueType) {
              type = designSet.param[lcname].valueType;
            } else {
              type = DEFAULT_PARAM_TYPE;
            }
            if (lcname in designSet.param) {
              multiValue = designSet.param[lcname].multiValue;
              if (designSet.param[lcname].multiValueSeparateDQuote) {
                mvdelim = parser._rfc6868Escape('"' + multiValue + '"');
              }
            }
            var nextChar = line[pos + 1];
            if (nextChar === '"') {
              valuePos = pos + 2;
              pos = helpers.unescapedIndexOf(line, '"', valuePos);
              if (multiValue && pos != -1) {
                var extendedValue = true;
                while (extendedValue) {
                  if (line[pos + 1] == multiValue && line[pos + 2] == '"') {
                    pos = helpers.unescapedIndexOf(line, '"', pos + 3);
                  } else {
                    extendedValue = false;
                  }
                }
              }
              if (pos === -1) {
                throw new ParserError(
                  'invalid line (no matching double quote) "' + line + '"'
                );
              }
              value = line.substr(valuePos, pos - valuePos);
              lastParam = helpers.unescapedIndexOf(line, PARAM_DELIMITER, pos);
              if (lastParam === -1) {
                pos = false;
              }
            } else {
              valuePos = pos + 1;
              var nextPos = helpers.unescapedIndexOf(line, PARAM_DELIMITER, valuePos);
              var propValuePos = helpers.unescapedIndexOf(line, VALUE_DELIMITER, valuePos);
              if (propValuePos !== -1 && nextPos > propValuePos) {
                nextPos = propValuePos;
                pos = false;
              } else if (nextPos === -1) {
                if (propValuePos === -1) {
                  nextPos = line.length;
                } else {
                  nextPos = propValuePos;
                }
                pos = false;
              } else {
                lastParam = nextPos;
                pos = nextPos;
              }
              value = line.substr(valuePos, nextPos - valuePos);
            }
            value = parser._rfc6868Escape(value);
            if (multiValue) {
              var delimiter = mvdelim || multiValue;
              value = parser._parseMultiValue(value, delimiter, type, [], null, designSet);
            } else {
              value = parser._parseValue(value, type, designSet);
            }
            if (multiValue && lcname in result) {
              if (Array.isArray(result[lcname])) {
                result[lcname].push(value);
              } else {
                result[lcname] = [
                  result[lcname],
                  value
                ];
              }
            } else {
              result[lcname] = value;
            }
          }
          return [result, value, valuePos];
        };
        parser._rfc6868Escape = function(val) {
          return val.replace(/\^['n^]/g, function(x) {
            return RFC6868_REPLACE_MAP[x];
          });
        };
        var RFC6868_REPLACE_MAP = { "^'": '"', "^n": "\n", "^^": "^" };
        parser._parseMultiValue = function(buffer, delim, type, result, innerMulti, designSet, structuredValue) {
          var pos = 0;
          var lastPos = 0;
          var value;
          if (delim.length === 0) {
            return buffer;
          }
          while ((pos = helpers.unescapedIndexOf(buffer, delim, lastPos)) !== -1) {
            value = buffer.substr(lastPos, pos - lastPos);
            if (innerMulti) {
              value = parser._parseMultiValue(value, innerMulti, type, [], null, designSet, structuredValue);
            } else {
              value = parser._parseValue(value, type, designSet, structuredValue);
            }
            result.push(value);
            lastPos = pos + delim.length;
          }
          value = buffer.substr(lastPos);
          if (innerMulti) {
            value = parser._parseMultiValue(value, innerMulti, type, [], null, designSet, structuredValue);
          } else {
            value = parser._parseValue(value, type, designSet, structuredValue);
          }
          result.push(value);
          return result.length == 1 ? result[0] : result;
        };
        parser._eachLine = function(buffer, callback) {
          var len = buffer.length;
          var lastPos = buffer.search(CHAR);
          var pos = lastPos;
          var line;
          var firstChar;
          var newlineOffset;
          do {
            pos = buffer.indexOf("\n", lastPos) + 1;
            if (pos > 1 && buffer[pos - 2] === "\r") {
              newlineOffset = 2;
            } else {
              newlineOffset = 1;
            }
            if (pos === 0) {
              pos = len;
              newlineOffset = 0;
            }
            firstChar = buffer[lastPos];
            if (firstChar === " " || firstChar === "	") {
              line += buffer.substr(
                lastPos + 1,
                pos - lastPos - (newlineOffset + 1)
              );
            } else {
              if (line)
                callback(null, line);
              line = buffer.substr(
                lastPos,
                pos - lastPos - newlineOffset
              );
            }
            lastPos = pos;
          } while (pos !== len);
          line = line.trim();
          if (line.length)
            callback(null, line);
        };
        return parser;
      })();
      ICAL.Component = (function() {
        "use strict";
        var PROPERTY_INDEX = 1;
        var COMPONENT_INDEX = 2;
        var NAME_INDEX = 0;
        function Component(jCal, parent) {
          if (typeof jCal === "string") {
            jCal = [jCal, [], []];
          }
          this.jCal = jCal;
          this.parent = parent || null;
        }
        Component.prototype = {
          /**
           * Hydrated properties are inserted into the _properties array at the same
           * position as in the jCal array, so it is possible that the array contains
           * undefined values for unhydrdated properties. To avoid iterating the
           * array when checking if all properties have been hydrated, we save the
           * count here.
           *
           * @type {Number}
           * @private
           */
          _hydratedPropertyCount: 0,
          /**
           * The same count as for _hydratedPropertyCount, but for subcomponents
           *
           * @type {Number}
           * @private
           */
          _hydratedComponentCount: 0,
          /**
           * The name of this component
           * @readonly
           */
          get name() {
            return this.jCal[NAME_INDEX];
          },
          /**
           * The design set for this component, e.g. icalendar vs vcard
           *
           * @type {ICAL.design.designSet}
           * @private
           */
          get _designSet() {
            var parentDesign = this.parent && this.parent._designSet;
            return parentDesign || ICAL.design.getDesignSet(this.name);
          },
          _hydrateComponent: function(index) {
            if (!this._components) {
              this._components = [];
              this._hydratedComponentCount = 0;
            }
            if (this._components[index]) {
              return this._components[index];
            }
            var comp = new Component(
              this.jCal[COMPONENT_INDEX][index],
              this
            );
            this._hydratedComponentCount++;
            return this._components[index] = comp;
          },
          _hydrateProperty: function(index) {
            if (!this._properties) {
              this._properties = [];
              this._hydratedPropertyCount = 0;
            }
            if (this._properties[index]) {
              return this._properties[index];
            }
            var prop = new ICAL.Property(
              this.jCal[PROPERTY_INDEX][index],
              this
            );
            this._hydratedPropertyCount++;
            return this._properties[index] = prop;
          },
          /**
           * Finds first sub component, optionally filtered by name.
           *
           * @param {String=} name        Optional name to filter by
           * @return {?ICAL.Component}     The found subcomponent
           */
          getFirstSubcomponent: function(name) {
            if (name) {
              var i = 0;
              var comps = this.jCal[COMPONENT_INDEX];
              var len = comps.length;
              for (; i < len; i++) {
                if (comps[i][NAME_INDEX] === name) {
                  var result = this._hydrateComponent(i);
                  return result;
                }
              }
            } else {
              if (this.jCal[COMPONENT_INDEX].length) {
                return this._hydrateComponent(0);
              }
            }
            return null;
          },
          /**
           * Finds all sub components, optionally filtering by name.
           *
           * @param {String=} name            Optional name to filter by
           * @return {ICAL.Component[]}       The found sub components
           */
          getAllSubcomponents: function(name) {
            var jCalLen = this.jCal[COMPONENT_INDEX].length;
            var i = 0;
            if (name) {
              var comps = this.jCal[COMPONENT_INDEX];
              var result = [];
              for (; i < jCalLen; i++) {
                if (name === comps[i][NAME_INDEX]) {
                  result.push(
                    this._hydrateComponent(i)
                  );
                }
              }
              return result;
            } else {
              if (!this._components || this._hydratedComponentCount !== jCalLen) {
                for (; i < jCalLen; i++) {
                  this._hydrateComponent(i);
                }
              }
              return this._components || [];
            }
          },
          /**
           * Returns true when a named property exists.
           *
           * @param {String} name     The property name
           * @return {Boolean}        True, when property is found
           */
          hasProperty: function(name) {
            var props = this.jCal[PROPERTY_INDEX];
            var len = props.length;
            var i = 0;
            for (; i < len; i++) {
              if (props[i][NAME_INDEX] === name) {
                return true;
              }
            }
            return false;
          },
          /**
           * Finds the first property, optionally with the given name.
           *
           * @param {String=} name        Lowercase property name
           * @return {?ICAL.Property}     The found property
           */
          getFirstProperty: function(name) {
            if (name) {
              var i = 0;
              var props = this.jCal[PROPERTY_INDEX];
              var len = props.length;
              for (; i < len; i++) {
                if (props[i][NAME_INDEX] === name) {
                  var result = this._hydrateProperty(i);
                  return result;
                }
              }
            } else {
              if (this.jCal[PROPERTY_INDEX].length) {
                return this._hydrateProperty(0);
              }
            }
            return null;
          },
          /**
           * Returns first property's value, if available.
           *
           * @param {String=} name    Lowercase property name
           * @return {?String}        The found property value.
           */
          getFirstPropertyValue: function(name) {
            var prop = this.getFirstProperty(name);
            if (prop) {
              return prop.getFirstValue();
            }
            return null;
          },
          /**
           * Get all properties in the component, optionally filtered by name.
           *
           * @param {String=} name        Lowercase property name
           * @return {ICAL.Property[]}    List of properties
           */
          getAllProperties: function(name) {
            var jCalLen = this.jCal[PROPERTY_INDEX].length;
            var i = 0;
            if (name) {
              var props = this.jCal[PROPERTY_INDEX];
              var result = [];
              for (; i < jCalLen; i++) {
                if (name === props[i][NAME_INDEX]) {
                  result.push(
                    this._hydrateProperty(i)
                  );
                }
              }
              return result;
            } else {
              if (!this._properties || this._hydratedPropertyCount !== jCalLen) {
                for (; i < jCalLen; i++) {
                  this._hydrateProperty(i);
                }
              }
              return this._properties || [];
            }
          },
          _removeObjectByIndex: function(jCalIndex, cache, index) {
            cache = cache || [];
            if (cache[index]) {
              var obj = cache[index];
              if ("parent" in obj) {
                obj.parent = null;
              }
            }
            cache.splice(index, 1);
            this.jCal[jCalIndex].splice(index, 1);
          },
          _removeObject: function(jCalIndex, cache, nameOrObject) {
            var i = 0;
            var objects = this.jCal[jCalIndex];
            var len = objects.length;
            var cached = this[cache];
            if (typeof nameOrObject === "string") {
              for (; i < len; i++) {
                if (objects[i][NAME_INDEX] === nameOrObject) {
                  this._removeObjectByIndex(jCalIndex, cached, i);
                  return true;
                }
              }
            } else if (cached) {
              for (; i < len; i++) {
                if (cached[i] && cached[i] === nameOrObject) {
                  this._removeObjectByIndex(jCalIndex, cached, i);
                  return true;
                }
              }
            }
            return false;
          },
          _removeAllObjects: function(jCalIndex, cache, name) {
            var cached = this[cache];
            var objects = this.jCal[jCalIndex];
            var i = objects.length - 1;
            for (; i >= 0; i--) {
              if (!name || objects[i][NAME_INDEX] === name) {
                this._removeObjectByIndex(jCalIndex, cached, i);
              }
            }
          },
          /**
           * Adds a single sub component.
           *
           * @param {ICAL.Component} component        The component to add
           * @return {ICAL.Component}                 The passed in component
           */
          addSubcomponent: function(component) {
            if (!this._components) {
              this._components = [];
              this._hydratedComponentCount = 0;
            }
            if (component.parent) {
              component.parent.removeSubcomponent(component);
            }
            var idx = this.jCal[COMPONENT_INDEX].push(component.jCal);
            this._components[idx - 1] = component;
            this._hydratedComponentCount++;
            component.parent = this;
            return component;
          },
          /**
           * Removes a single component by name or the instance of a specific
           * component.
           *
           * @param {ICAL.Component|String} nameOrComp    Name of component, or component
           * @return {Boolean}                            True when comp is removed
           */
          removeSubcomponent: function(nameOrComp) {
            var removed = this._removeObject(COMPONENT_INDEX, "_components", nameOrComp);
            if (removed) {
              this._hydratedComponentCount--;
            }
            return removed;
          },
          /**
           * Removes all components or (if given) all components by a particular
           * name.
           *
           * @param {String=} name            Lowercase component name
           */
          removeAllSubcomponents: function(name) {
            var removed = this._removeAllObjects(COMPONENT_INDEX, "_components", name);
            this._hydratedComponentCount = 0;
            return removed;
          },
          /**
           * Adds an {@link ICAL.Property} to the component.
           *
           * @param {ICAL.Property} property      The property to add
           * @return {ICAL.Property}              The passed in property
           */
          addProperty: function(property) {
            if (!(property instanceof ICAL.Property)) {
              throw new TypeError("must instance of ICAL.Property");
            }
            if (!this._properties) {
              this._properties = [];
              this._hydratedPropertyCount = 0;
            }
            if (property.parent) {
              property.parent.removeProperty(property);
            }
            var idx = this.jCal[PROPERTY_INDEX].push(property.jCal);
            this._properties[idx - 1] = property;
            this._hydratedPropertyCount++;
            property.parent = this;
            return property;
          },
          /**
           * Helper method to add a property with a value to the component.
           *
           * @param {String}               name         Property name to add
           * @param {String|Number|Object} value        Property value
           * @return {ICAL.Property}                    The created property
           */
          addPropertyWithValue: function(name, value) {
            var prop = new ICAL.Property(name);
            prop.setValue(value);
            this.addProperty(prop);
            return prop;
          },
          /**
           * Helper method that will update or create a property of the given name
           * and sets its value. If multiple properties with the given name exist,
           * only the first is updated.
           *
           * @param {String}               name         Property name to update
           * @param {String|Number|Object} value        Property value
           * @return {ICAL.Property}                    The created property
           */
          updatePropertyWithValue: function(name, value) {
            var prop = this.getFirstProperty(name);
            if (prop) {
              prop.setValue(value);
            } else {
              prop = this.addPropertyWithValue(name, value);
            }
            return prop;
          },
          /**
           * Removes a single property by name or the instance of the specific
           * property.
           *
           * @param {String|ICAL.Property} nameOrProp     Property name or instance to remove
           * @return {Boolean}                            True, when deleted
           */
          removeProperty: function(nameOrProp) {
            var removed = this._removeObject(PROPERTY_INDEX, "_properties", nameOrProp);
            if (removed) {
              this._hydratedPropertyCount--;
            }
            return removed;
          },
          /**
           * Removes all properties associated with this component, optionally
           * filtered by name.
           *
           * @param {String=} name        Lowercase property name
           * @return {Boolean}            True, when deleted
           */
          removeAllProperties: function(name) {
            var removed = this._removeAllObjects(PROPERTY_INDEX, "_properties", name);
            this._hydratedPropertyCount = 0;
            return removed;
          },
          /**
           * Returns the Object representation of this component. The returned object
           * is a live jCal object and should be cloned if modified.
           * @return {Object}
           */
          toJSON: function() {
            return this.jCal;
          },
          /**
           * The string representation of this component.
           * @return {String}
           */
          toString: function() {
            return ICAL.stringify.component(
              this.jCal,
              this._designSet
            );
          }
        };
        Component.fromString = function(str) {
          return new Component(ICAL.parse.component(str));
        };
        return Component;
      })();
      ICAL.Property = (function() {
        "use strict";
        var NAME_INDEX = 0;
        var PROP_INDEX = 1;
        var TYPE_INDEX = 2;
        var VALUE_INDEX = 3;
        var design = ICAL.design;
        function Property(jCal, parent) {
          this._parent = parent || null;
          if (typeof jCal === "string") {
            this.jCal = [jCal, {}, design.defaultType];
            this.jCal[TYPE_INDEX] = this.getDefaultType();
          } else {
            this.jCal = jCal;
          }
          this._updateType();
        }
        Property.prototype = {
          /**
           * The value type for this property
           * @readonly
           * @type {String}
           */
          get type() {
            return this.jCal[TYPE_INDEX];
          },
          /**
           * The name of this property, in lowercase.
           * @readonly
           * @type {String}
           */
          get name() {
            return this.jCal[NAME_INDEX];
          },
          /**
           * The parent component for this property.
           * @type {ICAL.Component}
           */
          get parent() {
            return this._parent;
          },
          set parent(p) {
            var designSetChanged = !this._parent || p && p._designSet != this._parent._designSet;
            this._parent = p;
            if (this.type == design.defaultType && designSetChanged) {
              this.jCal[TYPE_INDEX] = this.getDefaultType();
              this._updateType();
            }
            return p;
          },
          /**
           * The design set for this property, e.g. icalendar vs vcard
           *
           * @type {ICAL.design.designSet}
           * @private
           */
          get _designSet() {
            return this.parent ? this.parent._designSet : design.defaultSet;
          },
          /**
           * Updates the type metadata from the current jCal type and design set.
           *
           * @private
           */
          _updateType: function() {
            var designSet = this._designSet;
            if (this.type in designSet.value) {
              var designType = designSet.value[this.type];
              if ("decorate" in designSet.value[this.type]) {
                this.isDecorated = true;
              } else {
                this.isDecorated = false;
              }
              if (this.name in designSet.property) {
                this.isMultiValue = "multiValue" in designSet.property[this.name];
                this.isStructuredValue = "structuredValue" in designSet.property[this.name];
              }
            }
          },
          /**
           * Hydrate a single value. The act of hydrating means turning the raw jCal
           * value into a potentially wrapped object, for example {@link ICAL.Time}.
           *
           * @private
           * @param {Number} index        The index of the value to hydrate
           * @return {Object}             The decorated value.
           */
          _hydrateValue: function(index) {
            if (this._values && this._values[index]) {
              return this._values[index];
            }
            if (this.jCal.length <= VALUE_INDEX + index) {
              return null;
            }
            if (this.isDecorated) {
              if (!this._values) {
                this._values = [];
              }
              return this._values[index] = this._decorate(
                this.jCal[VALUE_INDEX + index]
              );
            } else {
              return this.jCal[VALUE_INDEX + index];
            }
          },
          /**
           * Decorate a single value, returning its wrapped object. This is used by
           * the hydrate function to actually wrap the value.
           *
           * @private
           * @param {?} value         The value to decorate
           * @return {Object}         The decorated value
           */
          _decorate: function(value) {
            return this._designSet.value[this.type].decorate(value, this);
          },
          /**
           * Undecorate a single value, returning its raw jCal data.
           *
           * @private
           * @param {Object} value         The value to undecorate
           * @return {?}                   The undecorated value
           */
          _undecorate: function(value) {
            return this._designSet.value[this.type].undecorate(value, this);
          },
          /**
           * Sets the value at the given index while also hydrating it. The passed
           * value can either be a decorated or undecorated value.
           *
           * @private
           * @param {?} value             The value to set
           * @param {Number} index        The index to set it at
           */
          _setDecoratedValue: function(value, index) {
            if (!this._values) {
              this._values = [];
            }
            if (typeof value === "object" && "icaltype" in value) {
              this.jCal[VALUE_INDEX + index] = this._undecorate(value);
              this._values[index] = value;
            } else {
              this.jCal[VALUE_INDEX + index] = value;
              this._values[index] = this._decorate(value);
            }
          },
          /**
           * Gets a parameter on the property.
           *
           * @param {String}        name   Parameter name (lowercase)
           * @return {Array|String}        Parameter value
           */
          getParameter: function(name) {
            if (name in this.jCal[PROP_INDEX]) {
              return this.jCal[PROP_INDEX][name];
            } else {
              return void 0;
            }
          },
          /**
           * Gets first parameter on the property.
           *
           * @param {String}        name   Parameter name (lowercase)
           * @return {String}        Parameter value
           */
          getFirstParameter: function(name) {
            var parameters = this.getParameter(name);
            if (Array.isArray(parameters)) {
              return parameters[0];
            }
            return parameters;
          },
          /**
           * Sets a parameter on the property.
           *
           * @param {String}       name     The parameter name
           * @param {Array|String} value    The parameter value
           */
          setParameter: function(name, value) {
            var lcname = name.toLowerCase();
            if (typeof value === "string" && lcname in this._designSet.param && "multiValue" in this._designSet.param[lcname]) {
              value = [value];
            }
            this.jCal[PROP_INDEX][name] = value;
          },
          /**
           * Removes a parameter
           *
           * @param {String} name     The parameter name
           */
          removeParameter: function(name) {
            delete this.jCal[PROP_INDEX][name];
          },
          /**
           * Get the default type based on this property's name.
           *
           * @return {String}     The default type for this property
           */
          getDefaultType: function() {
            var name = this.jCal[NAME_INDEX];
            var designSet = this._designSet;
            if (name in designSet.property) {
              var details = designSet.property[name];
              if ("defaultType" in details) {
                return details.defaultType;
              }
            }
            return design.defaultType;
          },
          /**
           * Sets type of property and clears out any existing values of the current
           * type.
           *
           * @param {String} type     New iCAL type (see design.*.values)
           */
          resetType: function(type) {
            this.removeAllValues();
            this.jCal[TYPE_INDEX] = type;
            this._updateType();
          },
          /**
           * Finds the first property value.
           *
           * @return {String}         First property value
           */
          getFirstValue: function() {
            return this._hydrateValue(0);
          },
          /**
           * Gets all values on the property.
           *
           * NOTE: this creates an array during each call.
           *
           * @return {Array}          List of values
           */
          getValues: function() {
            var len = this.jCal.length - VALUE_INDEX;
            if (len < 1) {
              return [];
            }
            var i = 0;
            var result = [];
            for (; i < len; i++) {
              result[i] = this._hydrateValue(i);
            }
            return result;
          },
          /**
           * Removes all values from this property
           */
          removeAllValues: function() {
            if (this._values) {
              this._values.length = 0;
            }
            this.jCal.length = 3;
          },
          /**
           * Sets the values of the property.  Will overwrite the existing values.
           * This can only be used for multi-value properties.
           *
           * @param {Array} values    An array of values
           */
          setValues: function(values) {
            if (!this.isMultiValue) {
              throw new Error(
                this.name + ": does not not support mulitValue.\noverride isMultiValue"
              );
            }
            var len = values.length;
            var i = 0;
            this.removeAllValues();
            if (len > 0 && typeof values[0] === "object" && "icaltype" in values[0]) {
              this.resetType(values[0].icaltype);
            }
            if (this.isDecorated) {
              for (; i < len; i++) {
                this._setDecoratedValue(values[i], i);
              }
            } else {
              for (; i < len; i++) {
                this.jCal[VALUE_INDEX + i] = values[i];
              }
            }
          },
          /**
           * Sets the current value of the property. If this is a multi-value
           * property, all other values will be removed.
           *
           * @param {String|Object} value     New property value.
           */
          setValue: function(value) {
            this.removeAllValues();
            if (typeof value === "object" && "icaltype" in value) {
              this.resetType(value.icaltype);
            }
            if (this.isDecorated) {
              this._setDecoratedValue(value, 0);
            } else {
              this.jCal[VALUE_INDEX] = value;
            }
          },
          /**
           * Returns the Object representation of this component. The returned object
           * is a live jCal object and should be cloned if modified.
           * @return {Object}
           */
          toJSON: function() {
            return this.jCal;
          },
          /**
           * The string representation of this component.
           * @return {String}
           */
          toICALString: function() {
            return ICAL.stringify.property(
              this.jCal,
              this._designSet,
              true
            );
          }
        };
        Property.fromString = function(str, designSet) {
          return new Property(ICAL.parse.property(str, designSet));
        };
        return Property;
      })();
      ICAL.UtcOffset = (function() {
        function UtcOffset(aData) {
          this.fromData(aData);
        }
        UtcOffset.prototype = {
          /**
           * The hours in the utc-offset
           * @type {Number}
           */
          hours: 0,
          /**
           * The minutes in the utc-offset
           * @type {Number}
           */
          minutes: 0,
          /**
           * The sign of the utc offset, 1 for positive offset, -1 for negative
           * offsets.
           * @type {Number}
           */
          factor: 1,
          /**
           * The type name, to be used in the jCal object.
           * @constant
           * @type {String}
           * @default "utc-offset"
           */
          icaltype: "utc-offset",
          /**
           * Returns a clone of the utc offset object.
           *
           * @return {ICAL.UtcOffset}     The cloned object
           */
          clone: function() {
            return ICAL.UtcOffset.fromSeconds(this.toSeconds());
          },
          /**
           * Sets up the current instance using members from the passed data object.
           *
           * @param {Object} aData          An object with members of the utc offset
           * @param {Number=} aData.hours   The hours for the utc offset
           * @param {Number=} aData.minutes The minutes in the utc offset
           * @param {Number=} aData.factor  The factor for the utc-offset, either -1 or 1
           */
          fromData: function(aData) {
            if (aData) {
              for (var key in aData) {
                if (aData.hasOwnProperty(key)) {
                  this[key] = aData[key];
                }
              }
            }
            this._normalize();
          },
          /**
           * Sets up the current instance from the given seconds value. The seconds
           * value is truncated to the minute. Offsets are wrapped when the world
           * ends, the hour after UTC+14:00 is UTC-12:00.
           *
           * @param {Number} aSeconds         The seconds to convert into an offset
           */
          fromSeconds: function(aSeconds) {
            var secs = Math.abs(aSeconds);
            this.factor = aSeconds < 0 ? -1 : 1;
            this.hours = ICAL.helpers.trunc(secs / 3600);
            secs -= this.hours * 3600;
            this.minutes = ICAL.helpers.trunc(secs / 60);
            return this;
          },
          /**
           * Convert the current offset to a value in seconds
           *
           * @return {Number}                 The offset in seconds
           */
          toSeconds: function() {
            return this.factor * (60 * this.minutes + 3600 * this.hours);
          },
          /**
           * Compare this utc offset with another one.
           *
           * @param {ICAL.UtcOffset} other        The other offset to compare with
           * @return {Number}                     -1, 0 or 1 for less/equal/greater
           */
          compare: function icaltime_compare(other) {
            var a = this.toSeconds();
            var b = other.toSeconds();
            return (a > b) - (b > a);
          },
          _normalize: function() {
            var secs = this.toSeconds();
            var factor = this.factor;
            while (secs < -43200) {
              secs += 97200;
            }
            while (secs > 50400) {
              secs -= 97200;
            }
            this.fromSeconds(secs);
            if (secs == 0) {
              this.factor = factor;
            }
          },
          /**
           * The iCalendar string representation of this utc-offset.
           * @return {String}
           */
          toICALString: function() {
            return ICAL.design.icalendar.value["utc-offset"].toICAL(this.toString());
          },
          /**
           * The string representation of this utc-offset.
           * @return {String}
           */
          toString: function toString() {
            return (this.factor == 1 ? "+" : "-") + ICAL.helpers.pad2(this.hours) + ":" + ICAL.helpers.pad2(this.minutes);
          }
        };
        UtcOffset.fromString = function(aString) {
          var options = {};
          options.factor = aString[0] === "+" ? 1 : -1;
          options.hours = ICAL.helpers.strictParseInt(aString.substr(1, 2));
          options.minutes = ICAL.helpers.strictParseInt(aString.substr(4, 2));
          return new ICAL.UtcOffset(options);
        };
        UtcOffset.fromSeconds = function(aSeconds) {
          var instance = new UtcOffset();
          instance.fromSeconds(aSeconds);
          return instance;
        };
        return UtcOffset;
      })();
      ICAL.Binary = (function() {
        function Binary(aValue) {
          this.value = aValue;
        }
        Binary.prototype = {
          /**
           * The type name, to be used in the jCal object.
           * @default "binary"
           * @constant
           */
          icaltype: "binary",
          /**
           * Base64 decode the current value
           *
           * @return {String}         The base64-decoded value
           */
          decodeValue: function decodeValue() {
            return this._b64_decode(this.value);
          },
          /**
           * Encodes the passed parameter with base64 and sets the internal
           * value to the result.
           *
           * @param {String} aValue      The raw binary value to encode
           */
          setEncodedValue: function setEncodedValue(aValue) {
            this.value = this._b64_encode(aValue);
          },
          _b64_encode: function base64_encode(data) {
            var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, enc = "", tmp_arr = [];
            if (!data) {
              return data;
            }
            do {
              o1 = data.charCodeAt(i++);
              o2 = data.charCodeAt(i++);
              o3 = data.charCodeAt(i++);
              bits = o1 << 16 | o2 << 8 | o3;
              h1 = bits >> 18 & 63;
              h2 = bits >> 12 & 63;
              h3 = bits >> 6 & 63;
              h4 = bits & 63;
              tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
            } while (i < data.length);
            enc = tmp_arr.join("");
            var r = data.length % 3;
            return (r ? enc.slice(0, r - 3) : enc) + "===".slice(r || 3);
          },
          _b64_decode: function base64_decode(data) {
            var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, dec = "", tmp_arr = [];
            if (!data) {
              return data;
            }
            data += "";
            do {
              h1 = b64.indexOf(data.charAt(i++));
              h2 = b64.indexOf(data.charAt(i++));
              h3 = b64.indexOf(data.charAt(i++));
              h4 = b64.indexOf(data.charAt(i++));
              bits = h1 << 18 | h2 << 12 | h3 << 6 | h4;
              o1 = bits >> 16 & 255;
              o2 = bits >> 8 & 255;
              o3 = bits & 255;
              if (h3 == 64) {
                tmp_arr[ac++] = String.fromCharCode(o1);
              } else if (h4 == 64) {
                tmp_arr[ac++] = String.fromCharCode(o1, o2);
              } else {
                tmp_arr[ac++] = String.fromCharCode(o1, o2, o3);
              }
            } while (i < data.length);
            dec = tmp_arr.join("");
            return dec;
          },
          /**
           * The string representation of this value
           * @return {String}
           */
          toString: function() {
            return this.value;
          }
        };
        Binary.fromString = function(aString) {
          return new Binary(aString);
        };
        return Binary;
      })();
      (function() {
        ICAL.Period = function icalperiod(aData) {
          this.wrappedJSObject = this;
          if (aData && "start" in aData) {
            if (aData.start && !(aData.start instanceof ICAL.Time)) {
              throw new TypeError(".start must be an instance of ICAL.Time");
            }
            this.start = aData.start;
          }
          if (aData && aData.end && aData.duration) {
            throw new Error("cannot accept both end and duration");
          }
          if (aData && "end" in aData) {
            if (aData.end && !(aData.end instanceof ICAL.Time)) {
              throw new TypeError(".end must be an instance of ICAL.Time");
            }
            this.end = aData.end;
          }
          if (aData && "duration" in aData) {
            if (aData.duration && !(aData.duration instanceof ICAL.Duration)) {
              throw new TypeError(".duration must be an instance of ICAL.Duration");
            }
            this.duration = aData.duration;
          }
        };
        ICAL.Period.prototype = {
          /**
           * The start of the period
           * @type {ICAL.Time}
           */
          start: null,
          /**
           * The end of the period
           * @type {ICAL.Time}
           */
          end: null,
          /**
           * The duration of the period
           * @type {ICAL.Duration}
           */
          duration: null,
          /**
           * The class identifier.
           * @constant
           * @type {String}
           * @default "icalperiod"
           */
          icalclass: "icalperiod",
          /**
           * The type name, to be used in the jCal object.
           * @constant
           * @type {String}
           * @default "period"
           */
          icaltype: "period",
          /**
           * Returns a clone of the duration object.
           *
           * @return {ICAL.Period}      The cloned object
           */
          clone: function() {
            return ICAL.Period.fromData({
              start: this.start ? this.start.clone() : null,
              end: this.end ? this.end.clone() : null,
              duration: this.duration ? this.duration.clone() : null
            });
          },
          /**
           * Calculates the duration of the period, either directly or by subtracting
           * start from end date.
           *
           * @return {ICAL.Duration}      The calculated duration
           */
          getDuration: function duration() {
            if (this.duration) {
              return this.duration;
            } else {
              return this.end.subtractDate(this.start);
            }
          },
          /**
           * Calculates the end date of the period, either directly or by adding
           * duration to start date.
           *
           * @return {ICAL.Time}          The calculated end date
           */
          getEnd: function() {
            if (this.end) {
              return this.end;
            } else {
              var end = this.start.clone();
              end.addDuration(this.duration);
              return end;
            }
          },
          /**
           * The string representation of this period.
           * @return {String}
           */
          toString: function toString() {
            return this.start + "/" + (this.end || this.duration);
          },
          /**
           * The jCal representation of this period type.
           * @return {Object}
           */
          toJSON: function() {
            return [this.start.toString(), (this.end || this.duration).toString()];
          },
          /**
           * The iCalendar string representation of this period.
           * @return {String}
           */
          toICALString: function() {
            return this.start.toICALString() + "/" + (this.end || this.duration).toICALString();
          }
        };
        ICAL.Period.fromString = function fromString(str, prop) {
          var parts = str.split("/");
          if (parts.length !== 2) {
            throw new Error(
              'Invalid string value: "' + str + '" must contain a "/" char.'
            );
          }
          var options = {
            start: ICAL.Time.fromDateTimeString(parts[0], prop)
          };
          var end = parts[1];
          if (ICAL.Duration.isValueString(end)) {
            options.duration = ICAL.Duration.fromString(end);
          } else {
            options.end = ICAL.Time.fromDateTimeString(end, prop);
          }
          return new ICAL.Period(options);
        };
        ICAL.Period.fromData = function fromData(aData) {
          return new ICAL.Period(aData);
        };
        ICAL.Period.fromJSON = function(aData, aProp, aLenient) {
          function fromDateOrDateTimeString(aValue, aProp2) {
            if (aLenient) {
              return ICAL.Time.fromString(aValue, aProp2);
            } else {
              return ICAL.Time.fromDateTimeString(aValue, aProp2);
            }
          }
          if (ICAL.Duration.isValueString(aData[1])) {
            return ICAL.Period.fromData({
              start: fromDateOrDateTimeString(aData[0], aProp),
              duration: ICAL.Duration.fromString(aData[1])
            });
          } else {
            return ICAL.Period.fromData({
              start: fromDateOrDateTimeString(aData[0], aProp),
              end: fromDateOrDateTimeString(aData[1], aProp)
            });
          }
        };
      })();
      (function() {
        var DURATION_LETTERS = /([PDWHMTS]{1,1})/;
        ICAL.Duration = function icalduration(data) {
          this.wrappedJSObject = this;
          this.fromData(data);
        };
        ICAL.Duration.prototype = {
          /**
           * The weeks in this duration
           * @type {Number}
           * @default 0
           */
          weeks: 0,
          /**
           * The days in this duration
           * @type {Number}
           * @default 0
           */
          days: 0,
          /**
           * The days in this duration
           * @type {Number}
           * @default 0
           */
          hours: 0,
          /**
           * The minutes in this duration
           * @type {Number}
           * @default 0
           */
          minutes: 0,
          /**
           * The seconds in this duration
           * @type {Number}
           * @default 0
           */
          seconds: 0,
          /**
           * The seconds in this duration
           * @type {Boolean}
           * @default false
           */
          isNegative: false,
          /**
           * The class identifier.
           * @constant
           * @type {String}
           * @default "icalduration"
           */
          icalclass: "icalduration",
          /**
           * The type name, to be used in the jCal object.
           * @constant
           * @type {String}
           * @default "duration"
           */
          icaltype: "duration",
          /**
           * Returns a clone of the duration object.
           *
           * @return {ICAL.Duration}      The cloned object
           */
          clone: function clone() {
            return ICAL.Duration.fromData(this);
          },
          /**
           * The duration value expressed as a number of seconds.
           *
           * @return {Number}             The duration value in seconds
           */
          toSeconds: function toSeconds() {
            var seconds = this.seconds + 60 * this.minutes + 3600 * this.hours + 86400 * this.days + 7 * 86400 * this.weeks;
            return this.isNegative ? -seconds : seconds;
          },
          /**
           * Reads the passed seconds value into this duration object. Afterwards,
           * members like {@link ICAL.Duration#days days} and {@link ICAL.Duration#weeks weeks} will be set up
           * accordingly.
           *
           * @param {Number} aSeconds     The duration value in seconds
           * @return {ICAL.Duration}      Returns this instance
           */
          fromSeconds: function fromSeconds(aSeconds) {
            var secs = Math.abs(aSeconds);
            this.isNegative = aSeconds < 0;
            this.days = ICAL.helpers.trunc(secs / 86400);
            if (this.days % 7 == 0) {
              this.weeks = this.days / 7;
              this.days = 0;
            } else {
              this.weeks = 0;
            }
            secs -= (this.days + 7 * this.weeks) * 86400;
            this.hours = ICAL.helpers.trunc(secs / 3600);
            secs -= this.hours * 3600;
            this.minutes = ICAL.helpers.trunc(secs / 60);
            secs -= this.minutes * 60;
            this.seconds = secs;
            return this;
          },
          /**
           * Sets up the current instance using members from the passed data object.
           *
           * @param {Object} aData               An object with members of the duration
           * @param {Number} aData.weeks         Duration in weeks
           * @param {Number} aData.days          Duration in days
           * @param {Number} aData.hours         Duration in hours
           * @param {Number} aData.minutes       Duration in minutes
           * @param {Number} aData.seconds       Duration in seconds
           * @param {Boolean} aData.isNegative   If true, the duration is negative
           */
          fromData: function fromData(aData) {
            var propsToCopy = [
              "weeks",
              "days",
              "hours",
              "minutes",
              "seconds",
              "isNegative"
            ];
            for (var key in propsToCopy) {
              if (!propsToCopy.hasOwnProperty(key)) {
                continue;
              }
              var prop = propsToCopy[key];
              if (aData && prop in aData) {
                this[prop] = aData[prop];
              } else {
                this[prop] = 0;
              }
            }
          },
          /**
           * Resets the duration instance to the default values, i.e. PT0S
           */
          reset: function reset() {
            this.isNegative = false;
            this.weeks = 0;
            this.days = 0;
            this.hours = 0;
            this.minutes = 0;
            this.seconds = 0;
          },
          /**
           * Compares the duration instance with another one.
           *
           * @param {ICAL.Duration} aOther        The instance to compare with
           * @return {Number}                     -1, 0 or 1 for less/equal/greater
           */
          compare: function compare(aOther) {
            var thisSeconds = this.toSeconds();
            var otherSeconds = aOther.toSeconds();
            return (thisSeconds > otherSeconds) - (thisSeconds < otherSeconds);
          },
          /**
           * Normalizes the duration instance. For example, a duration with a value
           * of 61 seconds will be normalized to 1 minute and 1 second.
           */
          normalize: function normalize() {
            this.fromSeconds(this.toSeconds());
          },
          /**
           * The string representation of this duration.
           * @return {String}
           */
          toString: function toString() {
            if (this.toSeconds() == 0) {
              return "PT0S";
            } else {
              var str = "";
              if (this.isNegative) str += "-";
              str += "P";
              if (this.weeks) str += this.weeks + "W";
              if (this.days) str += this.days + "D";
              if (this.hours || this.minutes || this.seconds) {
                str += "T";
                if (this.hours) str += this.hours + "H";
                if (this.minutes) str += this.minutes + "M";
                if (this.seconds) str += this.seconds + "S";
              }
              return str;
            }
          },
          /**
           * The iCalendar string representation of this duration.
           * @return {String}
           */
          toICALString: function() {
            return this.toString();
          }
        };
        ICAL.Duration.fromSeconds = function icalduration_from_seconds(aSeconds) {
          return new ICAL.Duration().fromSeconds(aSeconds);
        };
        function parseDurationChunk(letter, number, object) {
          var type;
          switch (letter) {
            case "P":
              if (number && number === "-") {
                object.isNegative = true;
              } else {
                object.isNegative = false;
              }
              break;
            case "D":
              type = "days";
              break;
            case "W":
              type = "weeks";
              break;
            case "H":
              type = "hours";
              break;
            case "M":
              type = "minutes";
              break;
            case "S":
              type = "seconds";
              break;
            default:
              return 0;
          }
          if (type) {
            if (!number && number !== 0) {
              throw new Error(
                'invalid duration value: Missing number before "' + letter + '"'
              );
            }
            var num = parseInt(number, 10);
            if (ICAL.helpers.isStrictlyNaN(num)) {
              throw new Error(
                'invalid duration value: Invalid number "' + number + '" before "' + letter + '"'
              );
            }
            object[type] = num;
          }
          return 1;
        }
        ICAL.Duration.isValueString = function(string) {
          return string[0] === "P" || string[1] === "P";
        };
        ICAL.Duration.fromString = function icalduration_from_string(aStr) {
          var pos = 0;
          var dict = /* @__PURE__ */ Object.create(null);
          var chunks = 0;
          while ((pos = aStr.search(DURATION_LETTERS)) !== -1) {
            var type = aStr[pos];
            var numeric = aStr.substr(0, pos);
            aStr = aStr.substr(pos + 1);
            chunks += parseDurationChunk(type, numeric, dict);
          }
          if (chunks < 2) {
            throw new Error(
              'invalid duration value: Not enough duration components in "' + aStr + '"'
            );
          }
          return new ICAL.Duration(dict);
        };
        ICAL.Duration.fromData = function icalduration_from_data(aData) {
          return new ICAL.Duration(aData);
        };
      })();
      (function() {
        var OPTIONS = [
          "tzid",
          "location",
          "tznames",
          "latitude",
          "longitude"
        ];
        ICAL.Timezone = function icaltimezone(data) {
          this.wrappedJSObject = this;
          this.fromData(data);
        };
        ICAL.Timezone.prototype = {
          /**
           * Timezone identifier
           * @type {String}
           */
          tzid: "",
          /**
           * Timezone location
           * @type {String}
           */
          location: "",
          /**
           * Alternative timezone name, for the string representation
           * @type {String}
           */
          tznames: "",
          /**
           * The primary latitude for the timezone.
           * @type {Number}
           */
          latitude: 0,
          /**
           * The primary longitude for the timezone.
           * @type {Number}
           */
          longitude: 0,
          /**
           * The vtimezone component for this timezone.
           * @type {ICAL.Component}
           */
          component: null,
          /**
           * The year this timezone has been expanded to. All timezone transition
           * dates until this year are known and can be used for calculation
           *
           * @private
           * @type {Number}
           */
          expandedUntilYear: 0,
          /**
           * The class identifier.
           * @constant
           * @type {String}
           * @default "icaltimezone"
           */
          icalclass: "icaltimezone",
          /**
           * Sets up the current instance using members from the passed data object.
           *
           * @param {ICAL.Component|Object} aData options for class
           * @param {String|ICAL.Component} aData.component
           *        If aData is a simple object, then this member can be set to either a
           *        string containing the component data, or an already parsed
           *        ICAL.Component
           * @param {String} aData.tzid      The timezone identifier
           * @param {String} aData.location  The timezone locationw
           * @param {String} aData.tznames   An alternative string representation of the
           *                                  timezone
           * @param {Number} aData.latitude  The latitude of the timezone
           * @param {Number} aData.longitude The longitude of the timezone
           */
          fromData: function fromData(aData) {
            this.expandedUntilYear = 0;
            this.changes = [];
            if (aData instanceof ICAL.Component) {
              this.component = aData;
            } else {
              if (aData && "component" in aData) {
                if (typeof aData.component == "string") {
                  var jCal = ICAL.parse(aData.component);
                  this.component = new ICAL.Component(jCal);
                } else if (aData.component instanceof ICAL.Component) {
                  this.component = aData.component;
                } else {
                  this.component = null;
                }
              }
              for (var key in OPTIONS) {
                if (OPTIONS.hasOwnProperty(key)) {
                  var prop = OPTIONS[key];
                  if (aData && prop in aData) {
                    this[prop] = aData[prop];
                  }
                }
              }
            }
            if (this.component instanceof ICAL.Component && !this.tzid) {
              this.tzid = this.component.getFirstPropertyValue("tzid");
            }
            return this;
          },
          /**
           * Finds the utcOffset the given time would occur in this timezone.
           *
           * @param {ICAL.Time} tt        The time to check for
           * @return {Number} utc offset in seconds
           */
          utcOffset: function utcOffset(tt) {
            if (this == ICAL.Timezone.utcTimezone || this == ICAL.Timezone.localTimezone) {
              return 0;
            }
            this._ensureCoverage(tt.year);
            if (!this.changes.length) {
              return 0;
            }
            var tt_change = {
              year: tt.year,
              month: tt.month,
              day: tt.day,
              hour: tt.hour,
              minute: tt.minute,
              second: tt.second
            };
            var change_num = this._findNearbyChange(tt_change);
            var change_num_to_use = -1;
            var step = 1;
            for (; ; ) {
              var change = ICAL.helpers.clone(this.changes[change_num], true);
              if (change.utcOffset < change.prevUtcOffset) {
                ICAL.Timezone.adjust_change(change, 0, 0, 0, change.utcOffset);
              } else {
                ICAL.Timezone.adjust_change(
                  change,
                  0,
                  0,
                  0,
                  change.prevUtcOffset
                );
              }
              var cmp = ICAL.Timezone._compare_change_fn(tt_change, change);
              if (cmp >= 0) {
                change_num_to_use = change_num;
              } else {
                step = -1;
              }
              if (step == -1 && change_num_to_use != -1) {
                break;
              }
              change_num += step;
              if (change_num < 0) {
                return 0;
              }
              if (change_num >= this.changes.length) {
                break;
              }
            }
            var zone_change = this.changes[change_num_to_use];
            var utcOffset_change = zone_change.utcOffset - zone_change.prevUtcOffset;
            if (utcOffset_change < 0 && change_num_to_use > 0) {
              var tmp_change = ICAL.helpers.clone(zone_change, true);
              ICAL.Timezone.adjust_change(
                tmp_change,
                0,
                0,
                0,
                tmp_change.prevUtcOffset
              );
              if (ICAL.Timezone._compare_change_fn(tt_change, tmp_change) < 0) {
                var prev_zone_change = this.changes[change_num_to_use - 1];
                var want_daylight = false;
                if (zone_change.is_daylight != want_daylight && prev_zone_change.is_daylight == want_daylight) {
                  zone_change = prev_zone_change;
                }
              }
            }
            return zone_change.utcOffset;
          },
          _findNearbyChange: function icaltimezone_find_nearby_change(change) {
            var idx = ICAL.helpers.binsearchInsert(
              this.changes,
              change,
              ICAL.Timezone._compare_change_fn
            );
            if (idx >= this.changes.length) {
              return this.changes.length - 1;
            }
            return idx;
          },
          _ensureCoverage: function(aYear) {
            if (ICAL.Timezone._minimumExpansionYear == -1) {
              var today = ICAL.Time.now();
              ICAL.Timezone._minimumExpansionYear = today.year;
            }
            var changesEndYear = aYear;
            if (changesEndYear < ICAL.Timezone._minimumExpansionYear) {
              changesEndYear = ICAL.Timezone._minimumExpansionYear;
            }
            changesEndYear += ICAL.Timezone.EXTRA_COVERAGE;
            if (changesEndYear > ICAL.Timezone.MAX_YEAR) {
              changesEndYear = ICAL.Timezone.MAX_YEAR;
            }
            if (!this.changes.length || this.expandedUntilYear < aYear) {
              var subcomps = this.component.getAllSubcomponents();
              var compLen = subcomps.length;
              var compIdx = 0;
              for (; compIdx < compLen; compIdx++) {
                this._expandComponent(
                  subcomps[compIdx],
                  changesEndYear,
                  this.changes
                );
              }
              this.changes.sort(ICAL.Timezone._compare_change_fn);
              this.expandedUntilYear = changesEndYear;
            }
          },
          _expandComponent: function(aComponent, aYear, changes) {
            if (!aComponent.hasProperty("dtstart") || !aComponent.hasProperty("tzoffsetto") || !aComponent.hasProperty("tzoffsetfrom")) {
              return null;
            }
            var dtstart = aComponent.getFirstProperty("dtstart").getFirstValue();
            var change;
            function convert_tzoffset(offset) {
              return offset.factor * (offset.hours * 3600 + offset.minutes * 60);
            }
            function init_changes() {
              var changebase = {};
              changebase.is_daylight = aComponent.name == "daylight";
              changebase.utcOffset = convert_tzoffset(
                aComponent.getFirstProperty("tzoffsetto").getFirstValue()
              );
              changebase.prevUtcOffset = convert_tzoffset(
                aComponent.getFirstProperty("tzoffsetfrom").getFirstValue()
              );
              return changebase;
            }
            if (!aComponent.hasProperty("rrule") && !aComponent.hasProperty("rdate")) {
              change = init_changes();
              change.year = dtstart.year;
              change.month = dtstart.month;
              change.day = dtstart.day;
              change.hour = dtstart.hour;
              change.minute = dtstart.minute;
              change.second = dtstart.second;
              ICAL.Timezone.adjust_change(
                change,
                0,
                0,
                0,
                -change.prevUtcOffset
              );
              changes.push(change);
            } else {
              var props = aComponent.getAllProperties("rdate");
              for (var rdatekey in props) {
                if (!props.hasOwnProperty(rdatekey)) {
                  continue;
                }
                var rdate = props[rdatekey];
                var time = rdate.getFirstValue();
                change = init_changes();
                change.year = time.year;
                change.month = time.month;
                change.day = time.day;
                if (time.isDate) {
                  change.hour = dtstart.hour;
                  change.minute = dtstart.minute;
                  change.second = dtstart.second;
                  if (dtstart.zone != ICAL.Timezone.utcTimezone) {
                    ICAL.Timezone.adjust_change(
                      change,
                      0,
                      0,
                      0,
                      -change.prevUtcOffset
                    );
                  }
                } else {
                  change.hour = time.hour;
                  change.minute = time.minute;
                  change.second = time.second;
                  if (time.zone != ICAL.Timezone.utcTimezone) {
                    ICAL.Timezone.adjust_change(
                      change,
                      0,
                      0,
                      0,
                      -change.prevUtcOffset
                    );
                  }
                }
                changes.push(change);
              }
              var rrule = aComponent.getFirstProperty("rrule");
              if (rrule) {
                rrule = rrule.getFirstValue();
                change = init_changes();
                if (rrule.until && rrule.until.zone == ICAL.Timezone.utcTimezone) {
                  rrule.until.adjust(0, 0, 0, change.prevUtcOffset);
                  rrule.until.zone = ICAL.Timezone.localTimezone;
                }
                var iterator = rrule.iterator(dtstart);
                var occ;
                while (occ = iterator.next()) {
                  change = init_changes();
                  if (occ.year > aYear || !occ) {
                    break;
                  }
                  change.year = occ.year;
                  change.month = occ.month;
                  change.day = occ.day;
                  change.hour = occ.hour;
                  change.minute = occ.minute;
                  change.second = occ.second;
                  change.isDate = occ.isDate;
                  ICAL.Timezone.adjust_change(
                    change,
                    0,
                    0,
                    0,
                    -change.prevUtcOffset
                  );
                  changes.push(change);
                }
              }
            }
            return changes;
          },
          /**
           * The string representation of this timezone.
           * @return {String}
           */
          toString: function toString() {
            return this.tznames ? this.tznames : this.tzid;
          }
        };
        ICAL.Timezone._compare_change_fn = function icaltimezone_compare_change_fn(a, b) {
          if (a.year < b.year) return -1;
          else if (a.year > b.year) return 1;
          if (a.month < b.month) return -1;
          else if (a.month > b.month) return 1;
          if (a.day < b.day) return -1;
          else if (a.day > b.day) return 1;
          if (a.hour < b.hour) return -1;
          else if (a.hour > b.hour) return 1;
          if (a.minute < b.minute) return -1;
          else if (a.minute > b.minute) return 1;
          if (a.second < b.second) return -1;
          else if (a.second > b.second) return 1;
          return 0;
        };
        ICAL.Timezone.convert_time = function icaltimezone_convert_time(tt, from_zone, to_zone) {
          if (tt.isDate || from_zone.tzid == to_zone.tzid || from_zone == ICAL.Timezone.localTimezone || to_zone == ICAL.Timezone.localTimezone) {
            tt.zone = to_zone;
            return tt;
          }
          var utcOffset = from_zone.utcOffset(tt);
          tt.adjust(0, 0, 0, -utcOffset);
          utcOffset = to_zone.utcOffset(tt);
          tt.adjust(0, 0, 0, utcOffset);
          return null;
        };
        ICAL.Timezone.fromData = function icaltimezone_fromData(aData) {
          var tt = new ICAL.Timezone();
          return tt.fromData(aData);
        };
        ICAL.Timezone.utcTimezone = ICAL.Timezone.fromData({
          tzid: "UTC"
        });
        ICAL.Timezone.localTimezone = ICAL.Timezone.fromData({
          tzid: "floating"
        });
        ICAL.Timezone.adjust_change = function icaltimezone_adjust_change(change, days, hours, minutes, seconds) {
          return ICAL.Time.prototype.adjust.call(
            change,
            days,
            hours,
            minutes,
            seconds,
            change
          );
        };
        ICAL.Timezone._minimumExpansionYear = -1;
        ICAL.Timezone.MAX_YEAR = 2035;
        ICAL.Timezone.EXTRA_COVERAGE = 5;
      })();
      ICAL.TimezoneService = (function() {
        var zones;
        var TimezoneService = {
          get count() {
            return Object.keys(zones).length;
          },
          reset: function() {
            zones = /* @__PURE__ */ Object.create(null);
            var utc = ICAL.Timezone.utcTimezone;
            zones.Z = utc;
            zones.UTC = utc;
            zones.GMT = utc;
          },
          /**
           * Checks if timezone id has been registered.
           *
           * @param {String} tzid     Timezone identifier (e.g. America/Los_Angeles)
           * @return {Boolean}        False, when not present
           */
          has: function(tzid) {
            return !!zones[tzid];
          },
          /**
           * Returns a timezone by its tzid if present.
           *
           * @param {String} tzid     Timezone identifier (e.g. America/Los_Angeles)
           * @return {?ICAL.Timezone} The timezone, or null if not found
           */
          get: function(tzid) {
            return zones[tzid];
          },
          /**
           * Registers a timezone object or component.
           *
           * @param {String=} name
           *        The name of the timezone. Defaults to the component's TZID if not
           *        passed.
           * @param {ICAL.Component|ICAL.Timezone} zone
           *        The initialized zone or vtimezone.
           */
          register: function(name, timezone) {
            if (name instanceof ICAL.Component) {
              if (name.name === "vtimezone") {
                timezone = new ICAL.Timezone(name);
                name = timezone.tzid;
              }
            }
            if (timezone instanceof ICAL.Timezone) {
              zones[name] = timezone;
            } else {
              throw new TypeError("timezone must be ICAL.Timezone or ICAL.Component");
            }
          },
          /**
           * Removes a timezone by its tzid from the list.
           *
           * @param {String} tzid     Timezone identifier (e.g. America/Los_Angeles)
           * @return {?ICAL.Timezone} The removed timezone, or null if not registered
           */
          remove: function(tzid) {
            return delete zones[tzid];
          }
        };
        TimezoneService.reset();
        return TimezoneService;
      })();
      (function() {
        ICAL.Time = function icaltime(data, zone) {
          this.wrappedJSObject = this;
          var time = this._time = /* @__PURE__ */ Object.create(null);
          time.year = 0;
          time.month = 1;
          time.day = 1;
          time.hour = 0;
          time.minute = 0;
          time.second = 0;
          time.isDate = false;
          this.fromData(data, zone);
        };
        ICAL.Time._dowCache = {};
        ICAL.Time._wnCache = {};
        ICAL.Time.prototype = {
          /**
           * The class identifier.
           * @constant
           * @type {String}
           * @default "icaltime"
           */
          icalclass: "icaltime",
          _cachedUnixTime: null,
          /**
           * The type name, to be used in the jCal object. This value may change and
           * is strictly defined by the {@link ICAL.Time#isDate isDate} member.
           * @readonly
           * @type {String}
           * @default "date-time"
           */
          get icaltype() {
            return this.isDate ? "date" : "date-time";
          },
          /**
           * The timezone for this time.
           * @type {ICAL.Timezone}
           */
          zone: null,
          /**
           * Internal uses to indicate that a change has been made and the next read
           * operation must attempt to normalize the value (for example changing the
           * day to 33).
           *
           * @type {Boolean}
           * @private
           */
          _pendingNormalization: false,
          /**
           * Returns a clone of the time object.
           *
           * @return {ICAL.Time}              The cloned object
           */
          clone: function() {
            return new ICAL.Time(this._time, this.zone);
          },
          /**
           * Reset the time instance to epoch time
           */
          reset: function icaltime_reset() {
            this.fromData(ICAL.Time.epochTime);
            this.zone = ICAL.Timezone.utcTimezone;
          },
          /**
           * Reset the time instance to the given date/time values.
           *
           * @param {Number} year             The year to set
           * @param {Number} month            The month to set
           * @param {Number} day              The day to set
           * @param {Number} hour             The hour to set
           * @param {Number} minute           The minute to set
           * @param {Number} second           The second to set
           * @param {ICAL.Timezone} timezone  The timezone to set
           */
          resetTo: function icaltime_resetTo(year, month, day, hour, minute, second, timezone) {
            this.fromData({
              year,
              month,
              day,
              hour,
              minute,
              second,
              zone: timezone
            });
          },
          /**
           * Set up the current instance from the Javascript date value.
           *
           * @param {?Date} aDate     The Javascript Date to read, or null to reset
           * @param {Boolean} useUTC  If true, the UTC values of the date will be used
           */
          fromJSDate: function icaltime_fromJSDate(aDate, useUTC) {
            if (!aDate) {
              this.reset();
            } else {
              if (useUTC) {
                this.zone = ICAL.Timezone.utcTimezone;
                this.year = aDate.getUTCFullYear();
                this.month = aDate.getUTCMonth() + 1;
                this.day = aDate.getUTCDate();
                this.hour = aDate.getUTCHours();
                this.minute = aDate.getUTCMinutes();
                this.second = aDate.getUTCSeconds();
              } else {
                this.zone = ICAL.Timezone.localTimezone;
                this.year = aDate.getFullYear();
                this.month = aDate.getMonth() + 1;
                this.day = aDate.getDate();
                this.hour = aDate.getHours();
                this.minute = aDate.getMinutes();
                this.second = aDate.getSeconds();
              }
            }
            this._cachedUnixTime = null;
            return this;
          },
          /**
           * Sets up the current instance using members from the passed data object.
           *
           * @param {Object} aData            Time initialization
           * @param {Number=} aData.year      The year for this date
           * @param {Number=} aData.month     The month for this date
           * @param {Number=} aData.day       The day for this date
           * @param {Number=} aData.hour      The hour for this date
           * @param {Number=} aData.minute    The minute for this date
           * @param {Number=} aData.second    The second for this date
           * @param {Boolean=} aData.isDate   If true, the instance represents a date
           *                                    (as opposed to a date-time)
           * @param {ICAL.Timezone=} aZone    Timezone this position occurs in
           */
          fromData: function fromData(aData, aZone) {
            if (aData) {
              for (var key in aData) {
                if (Object.prototype.hasOwnProperty.call(aData, key)) {
                  if (key === "icaltype") continue;
                  this[key] = aData[key];
                }
              }
            }
            if (aZone) {
              this.zone = aZone;
            }
            if (aData && !("isDate" in aData)) {
              this.isDate = !("hour" in aData);
            } else if (aData && "isDate" in aData) {
              this.isDate = aData.isDate;
            }
            if (aData && "timezone" in aData) {
              var zone = ICAL.TimezoneService.get(
                aData.timezone
              );
              this.zone = zone || ICAL.Timezone.localTimezone;
            }
            if (aData && "zone" in aData) {
              this.zone = aData.zone;
            }
            if (!this.zone) {
              this.zone = ICAL.Timezone.localTimezone;
            }
            this._cachedUnixTime = null;
            return this;
          },
          /**
           * Calculate the day of week.
           * @param {ICAL.Time.weekDay=} aWeekStart
           *        The week start weekday, defaults to SUNDAY
           * @return {ICAL.Time.weekDay}
           */
          dayOfWeek: function icaltime_dayOfWeek(aWeekStart) {
            var firstDow = aWeekStart || ICAL.Time.SUNDAY;
            var dowCacheKey = (this.year << 12) + (this.month << 8) + (this.day << 3) + firstDow;
            if (dowCacheKey in ICAL.Time._dowCache) {
              return ICAL.Time._dowCache[dowCacheKey];
            }
            var q = this.day;
            var m2 = this.month + (this.month < 3 ? 12 : 0);
            var Y = this.year - (this.month < 3 ? 1 : 0);
            var h = q + Y + ICAL.helpers.trunc((m2 + 1) * 26 / 10) + ICAL.helpers.trunc(Y / 4);
            if (true) {
              h += ICAL.helpers.trunc(Y / 100) * 6 + ICAL.helpers.trunc(Y / 400);
            } else {
              h += 5;
            }
            h = (h + 7 - firstDow) % 7 + 1;
            ICAL.Time._dowCache[dowCacheKey] = h;
            return h;
          },
          /**
           * Calculate the day of year.
           * @return {Number}
           */
          dayOfYear: function dayOfYear() {
            var is_leap = ICAL.Time.isLeapYear(this.year) ? 1 : 0;
            var diypm = ICAL.Time.daysInYearPassedMonth;
            return diypm[is_leap][this.month - 1] + this.day;
          },
          /**
           * Returns a copy of the current date/time, rewound to the start of the
           * week. The resulting ICAL.Time instance is of icaltype date, even if this
           * is a date-time.
           *
           * @param {ICAL.Time.weekDay=} aWeekStart
           *        The week start weekday, defaults to SUNDAY
           * @return {ICAL.Time}      The start of the week (cloned)
           */
          startOfWeek: function startOfWeek(aWeekStart) {
            var firstDow = aWeekStart || ICAL.Time.SUNDAY;
            var result = this.clone();
            result.day -= (this.dayOfWeek() + 7 - firstDow) % 7;
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * Returns a copy of the current date/time, shifted to the end of the week.
           * The resulting ICAL.Time instance is of icaltype date, even if this is a
           * date-time.
           *
           * @param {ICAL.Time.weekDay=} aWeekStart
           *        The week start weekday, defaults to SUNDAY
           * @return {ICAL.Time}      The end of the week (cloned)
           */
          endOfWeek: function endOfWeek(aWeekStart) {
            var firstDow = aWeekStart || ICAL.Time.SUNDAY;
            var result = this.clone();
            result.day += (7 - this.dayOfWeek() + firstDow - ICAL.Time.SUNDAY) % 7;
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * Returns a copy of the current date/time, rewound to the start of the
           * month. The resulting ICAL.Time instance is of icaltype date, even if
           * this is a date-time.
           *
           * @return {ICAL.Time}      The start of the month (cloned)
           */
          startOfMonth: function startOfMonth() {
            var result = this.clone();
            result.day = 1;
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * Returns a copy of the current date/time, shifted to the end of the
           * month.  The resulting ICAL.Time instance is of icaltype date, even if
           * this is a date-time.
           *
           * @return {ICAL.Time}      The end of the month (cloned)
           */
          endOfMonth: function endOfMonth() {
            var result = this.clone();
            result.day = ICAL.Time.daysInMonth(result.month, result.year);
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * Returns a copy of the current date/time, rewound to the start of the
           * year. The resulting ICAL.Time instance is of icaltype date, even if
           * this is a date-time.
           *
           * @return {ICAL.Time}      The start of the year (cloned)
           */
          startOfYear: function startOfYear() {
            var result = this.clone();
            result.day = 1;
            result.month = 1;
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * Returns a copy of the current date/time, shifted to the end of the
           * year.  The resulting ICAL.Time instance is of icaltype date, even if
           * this is a date-time.
           *
           * @return {ICAL.Time}      The end of the year (cloned)
           */
          endOfYear: function endOfYear() {
            var result = this.clone();
            result.day = 31;
            result.month = 12;
            result.isDate = true;
            result.hour = 0;
            result.minute = 0;
            result.second = 0;
            return result;
          },
          /**
           * First calculates the start of the week, then returns the day of year for
           * this date. If the day falls into the previous year, the day is zero or negative.
           *
           * @param {ICAL.Time.weekDay=} aFirstDayOfWeek
           *        The week start weekday, defaults to SUNDAY
           * @return {Number}     The calculated day of year
           */
          startDoyWeek: function startDoyWeek(aFirstDayOfWeek) {
            var firstDow = aFirstDayOfWeek || ICAL.Time.SUNDAY;
            var delta = this.dayOfWeek() - firstDow;
            if (delta < 0) delta += 7;
            return this.dayOfYear() - delta;
          },
          /**
           * Get the dominical letter for the current year. Letters range from A - G
           * for common years, and AG to GF for leap years.
           *
           * @param {Number} yr           The year to retrieve the letter for
           * @return {String}             The dominical letter.
           */
          getDominicalLetter: function() {
            return ICAL.Time.getDominicalLetter(this.year);
          },
          /**
           * Finds the nthWeekDay relative to the current month (not day).  The
           * returned value is a day relative the month that this month belongs to so
           * 1 would indicate the first of the month and 40 would indicate a day in
           * the following month.
           *
           * @param {Number} aDayOfWeek   Day of the week see the day name constants
           * @param {Number} aPos         Nth occurrence of a given week day values
           *        of 1 and 0 both indicate the first weekday of that type. aPos may
           *        be either positive or negative
           *
           * @return {Number} numeric value indicating a day relative
           *                   to the current month of this time object
           */
          nthWeekDay: function icaltime_nthWeekDay(aDayOfWeek, aPos) {
            var daysInMonth = ICAL.Time.daysInMonth(this.month, this.year);
            var weekday;
            var pos = aPos;
            var start = 0;
            var otherDay = this.clone();
            if (pos >= 0) {
              otherDay.day = 1;
              if (pos != 0) {
                pos--;
              }
              start = otherDay.day;
              var startDow = otherDay.dayOfWeek();
              var offset = aDayOfWeek - startDow;
              if (offset < 0)
                offset += 7;
              start += offset;
              start -= aDayOfWeek;
              weekday = aDayOfWeek;
            } else {
              otherDay.day = daysInMonth;
              var endDow = otherDay.dayOfWeek();
              pos++;
              weekday = endDow - aDayOfWeek;
              if (weekday < 0) {
                weekday += 7;
              }
              weekday = daysInMonth - weekday;
            }
            weekday += pos * 7;
            return start + weekday;
          },
          /**
           * Checks if current time is the nth weekday, relative to the current
           * month.  Will always return false when rule resolves outside of current
           * month.
           *
           * @param {ICAL.Time.weekDay} aDayOfWeek       Day of week to check
           * @param {Number} aPos                        Relative position
           * @return {Boolean}                           True, if it is the nth weekday
           */
          isNthWeekDay: function(aDayOfWeek, aPos) {
            var dow = this.dayOfWeek();
            if (aPos === 0 && dow === aDayOfWeek) {
              return true;
            }
            var day = this.nthWeekDay(aDayOfWeek, aPos);
            if (day === this.day) {
              return true;
            }
            return false;
          },
          /**
           * Calculates the ISO 8601 week number. The first week of a year is the
           * week that contains the first Thursday. The year can have 53 weeks, if
           * January 1st is a Friday.
           *
           * Note there are regions where the first week of the year is the one that
           * starts on January 1st, which may offset the week number. Also, if a
           * different week start is specified, this will also affect the week
           * number.
           *
           * @see ICAL.Time.weekOneStarts
           * @param {ICAL.Time.weekDay} aWeekStart        The weekday the week starts with
           * @return {Number}                             The ISO week number
           */
          weekNumber: function weekNumber(aWeekStart) {
            var wnCacheKey = (this.year << 12) + (this.month << 8) + (this.day << 3) + aWeekStart;
            if (wnCacheKey in ICAL.Time._wnCache) {
              return ICAL.Time._wnCache[wnCacheKey];
            }
            var week1;
            var dt = this.clone();
            dt.isDate = true;
            var isoyear = this.year;
            if (dt.month == 12 && dt.day > 25) {
              week1 = ICAL.Time.weekOneStarts(isoyear + 1, aWeekStart);
              if (dt.compare(week1) < 0) {
                week1 = ICAL.Time.weekOneStarts(isoyear, aWeekStart);
              } else {
                isoyear++;
              }
            } else {
              week1 = ICAL.Time.weekOneStarts(isoyear, aWeekStart);
              if (dt.compare(week1) < 0) {
                week1 = ICAL.Time.weekOneStarts(--isoyear, aWeekStart);
              }
            }
            var daysBetween = dt.subtractDate(week1).toSeconds() / 86400;
            var answer = ICAL.helpers.trunc(daysBetween / 7) + 1;
            ICAL.Time._wnCache[wnCacheKey] = answer;
            return answer;
          },
          /**
           * Adds the duration to the current time. The instance is modified in
           * place.
           *
           * @param {ICAL.Duration} aDuration         The duration to add
           */
          addDuration: function icaltime_add(aDuration) {
            var mult = aDuration.isNegative ? -1 : 1;
            var second = this.second;
            var minute = this.minute;
            var hour = this.hour;
            var day = this.day;
            second += mult * aDuration.seconds;
            minute += mult * aDuration.minutes;
            hour += mult * aDuration.hours;
            day += mult * aDuration.days;
            day += mult * 7 * aDuration.weeks;
            this.second = second;
            this.minute = minute;
            this.hour = hour;
            this.day = day;
            this._cachedUnixTime = null;
          },
          /**
           * Subtract the date details (_excluding_ timezone).  Useful for finding
           * the relative difference between two time objects excluding their
           * timezone differences.
           *
           * @param {ICAL.Time} aDate     The date to substract
           * @return {ICAL.Duration}      The difference as a duration
           */
          subtractDate: function icaltime_subtract(aDate) {
            var unixTime = this.toUnixTime() + this.utcOffset();
            var other = aDate.toUnixTime() + aDate.utcOffset();
            return ICAL.Duration.fromSeconds(unixTime - other);
          },
          /**
           * Subtract the date details, taking timezones into account.
           *
           * @param {ICAL.Time} aDate  The date to subtract
           * @return {ICAL.Duration}  The difference in duration
           */
          subtractDateTz: function icaltime_subtract_abs(aDate) {
            var unixTime = this.toUnixTime();
            var other = aDate.toUnixTime();
            return ICAL.Duration.fromSeconds(unixTime - other);
          },
          /**
           * Compares the ICAL.Time instance with another one.
           *
           * @param {ICAL.Duration} aOther        The instance to compare with
           * @return {Number}                     -1, 0 or 1 for less/equal/greater
           */
          compare: function icaltime_compare(other) {
            var a = this.toUnixTime();
            var b = other.toUnixTime();
            if (a > b) return 1;
            if (b > a) return -1;
            return 0;
          },
          /**
           * Compares only the date part of this instance with another one.
           *
           * @param {ICAL.Duration} other         The instance to compare with
           * @param {ICAL.Timezone} tz            The timezone to compare in
           * @return {Number}                     -1, 0 or 1 for less/equal/greater
           */
          compareDateOnlyTz: function icaltime_compareDateOnlyTz(other, tz) {
            function cmp(attr) {
              return ICAL.Time._cmp_attr(a, b, attr);
            }
            var a = this.convertToZone(tz);
            var b = other.convertToZone(tz);
            var rc = 0;
            if ((rc = cmp("year")) != 0) return rc;
            if ((rc = cmp("month")) != 0) return rc;
            if ((rc = cmp("day")) != 0) return rc;
            return rc;
          },
          /**
           * Convert the instance into another timezone. The returned ICAL.Time
           * instance is always a copy.
           *
           * @param {ICAL.Timezone} zone      The zone to convert to
           * @return {ICAL.Time}              The copy, converted to the zone
           */
          convertToZone: function convertToZone(zone) {
            var copy = this.clone();
            var zone_equals = this.zone.tzid == zone.tzid;
            if (!this.isDate && !zone_equals) {
              ICAL.Timezone.convert_time(copy, this.zone, zone);
            }
            copy.zone = zone;
            return copy;
          },
          /**
           * Calculates the UTC offset of the current date/time in the timezone it is
           * in.
           *
           * @return {Number}     UTC offset in seconds
           */
          utcOffset: function utc_offset() {
            if (this.zone == ICAL.Timezone.localTimezone || this.zone == ICAL.Timezone.utcTimezone) {
              return 0;
            } else {
              return this.zone.utcOffset(this);
            }
          },
          /**
           * Returns an RFC 5545 compliant ical representation of this object.
           *
           * @return {String} ical date/date-time
           */
          toICALString: function() {
            var string = this.toString();
            if (string.length > 10) {
              return ICAL.design.icalendar.value["date-time"].toICAL(string);
            } else {
              return ICAL.design.icalendar.value.date.toICAL(string);
            }
          },
          /**
           * The string representation of this date/time, in jCal form
           * (including : and - separators).
           * @return {String}
           */
          toString: function toString() {
            var result = this.year + "-" + ICAL.helpers.pad2(this.month) + "-" + ICAL.helpers.pad2(this.day);
            if (!this.isDate) {
              result += "T" + ICAL.helpers.pad2(this.hour) + ":" + ICAL.helpers.pad2(this.minute) + ":" + ICAL.helpers.pad2(this.second);
              if (this.zone === ICAL.Timezone.utcTimezone) {
                result += "Z";
              }
            }
            return result;
          },
          /**
           * Converts the current instance to a Javascript date
           * @return {Date}
           */
          toJSDate: function toJSDate() {
            if (this.zone == ICAL.Timezone.localTimezone) {
              if (this.isDate) {
                return new Date(this.year, this.month - 1, this.day);
              } else {
                return new Date(
                  this.year,
                  this.month - 1,
                  this.day,
                  this.hour,
                  this.minute,
                  this.second,
                  0
                );
              }
            } else {
              return new Date(this.toUnixTime() * 1e3);
            }
          },
          _normalize: function icaltime_normalize() {
            var isDate = this._time.isDate;
            if (this._time.isDate) {
              this._time.hour = 0;
              this._time.minute = 0;
              this._time.second = 0;
            }
            this.adjust(0, 0, 0, 0);
            return this;
          },
          /**
           * Adjust the date/time by the given offset
           *
           * @param {Number} aExtraDays       The extra amount of days
           * @param {Number} aExtraHours      The extra amount of hours
           * @param {Number} aExtraMinutes    The extra amount of minutes
           * @param {Number} aExtraSeconds    The extra amount of seconds
           * @param {Number=} aTime           The time to adjust, defaults to the
           *                                    current instance.
           */
          adjust: function icaltime_adjust(aExtraDays, aExtraHours, aExtraMinutes, aExtraSeconds, aTime) {
            var minutesOverflow, hoursOverflow, daysOverflow = 0, yearsOverflow = 0;
            var second, minute, hour, day;
            var daysInMonth;
            var time = aTime || this._time;
            if (!time.isDate) {
              second = time.second + aExtraSeconds;
              time.second = second % 60;
              minutesOverflow = ICAL.helpers.trunc(second / 60);
              if (time.second < 0) {
                time.second += 60;
                minutesOverflow--;
              }
              minute = time.minute + aExtraMinutes + minutesOverflow;
              time.minute = minute % 60;
              hoursOverflow = ICAL.helpers.trunc(minute / 60);
              if (time.minute < 0) {
                time.minute += 60;
                hoursOverflow--;
              }
              hour = time.hour + aExtraHours + hoursOverflow;
              time.hour = hour % 24;
              daysOverflow = ICAL.helpers.trunc(hour / 24);
              if (time.hour < 0) {
                time.hour += 24;
                daysOverflow--;
              }
            }
            if (time.month > 12) {
              yearsOverflow = ICAL.helpers.trunc((time.month - 1) / 12);
            } else if (time.month < 1) {
              yearsOverflow = ICAL.helpers.trunc(time.month / 12) - 1;
            }
            time.year += yearsOverflow;
            time.month -= 12 * yearsOverflow;
            day = time.day + aExtraDays + daysOverflow;
            if (day > 0) {
              for (; ; ) {
                daysInMonth = ICAL.Time.daysInMonth(time.month, time.year);
                if (day <= daysInMonth) {
                  break;
                }
                time.month++;
                if (time.month > 12) {
                  time.year++;
                  time.month = 1;
                }
                day -= daysInMonth;
              }
            } else {
              while (day <= 0) {
                if (time.month == 1) {
                  time.year--;
                  time.month = 12;
                } else {
                  time.month--;
                }
                day += ICAL.Time.daysInMonth(time.month, time.year);
              }
            }
            time.day = day;
            this._cachedUnixTime = null;
            return this;
          },
          /**
           * Sets up the current instance from unix time, the number of seconds since
           * January 1st, 1970.
           *
           * @param {Number} seconds      The seconds to set up with
           */
          fromUnixTime: function fromUnixTime(seconds) {
            this.zone = ICAL.Timezone.utcTimezone;
            var epoch = ICAL.Time.epochTime.clone();
            epoch.adjust(0, 0, 0, seconds);
            this.year = epoch.year;
            this.month = epoch.month;
            this.day = epoch.day;
            this.hour = epoch.hour;
            this.minute = epoch.minute;
            this.second = Math.floor(epoch.second);
            this._cachedUnixTime = null;
          },
          /**
           * Converts the current instance to seconds since January 1st 1970.
           *
           * @return {Number}         Seconds since 1970
           */
          toUnixTime: function toUnixTime() {
            if (this._cachedUnixTime !== null) {
              return this._cachedUnixTime;
            }
            var offset = this.utcOffset();
            var ms = Date.UTC(
              this.year,
              this.month - 1,
              this.day,
              this.hour,
              this.minute,
              this.second - offset
            );
            this._cachedUnixTime = ms / 1e3;
            return this._cachedUnixTime;
          },
          /**
           * Converts time to into Object which can be serialized then re-created
           * using the constructor.
           *
           * @example
           * // toJSON will automatically be called
           * var json = JSON.stringify(mytime);
           *
           * var deserialized = JSON.parse(json);
           *
           * var time = new ICAL.Time(deserialized);
           *
           * @return {Object}
           */
          toJSON: function() {
            var copy = [
              "year",
              "month",
              "day",
              "hour",
              "minute",
              "second",
              "isDate"
            ];
            var result = /* @__PURE__ */ Object.create(null);
            var i = 0;
            var len = copy.length;
            var prop;
            for (; i < len; i++) {
              prop = copy[i];
              result[prop] = this[prop];
            }
            if (this.zone) {
              result.timezone = this.zone.tzid;
            }
            return result;
          }
        };
        (function setupNormalizeAttributes() {
          function defineAttr(attr) {
            Object.defineProperty(ICAL.Time.prototype, attr, {
              get: function getTimeAttr() {
                if (this._pendingNormalization) {
                  this._normalize();
                  this._pendingNormalization = false;
                }
                return this._time[attr];
              },
              set: function setTimeAttr(val) {
                if (attr === "isDate" && val && !this._time.isDate) {
                  this.adjust(0, 0, 0, 0);
                }
                this._cachedUnixTime = null;
                this._pendingNormalization = true;
                this._time[attr] = val;
                return val;
              }
            });
          }
          if ("defineProperty" in Object) {
            defineAttr("year");
            defineAttr("month");
            defineAttr("day");
            defineAttr("hour");
            defineAttr("minute");
            defineAttr("second");
            defineAttr("isDate");
          }
        })();
        ICAL.Time.daysInMonth = function icaltime_daysInMonth(month, year) {
          var _daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
          var days = 30;
          if (month < 1 || month > 12) return days;
          days = _daysInMonth[month];
          if (month == 2) {
            days += ICAL.Time.isLeapYear(year);
          }
          return days;
        };
        ICAL.Time.isLeapYear = function isLeapYear(year) {
          if (year <= 1752) {
            return year % 4 == 0;
          } else {
            return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
          }
        };
        ICAL.Time.fromDayOfYear = function icaltime_fromDayOfYear(aDayOfYear, aYear) {
          var year = aYear;
          var doy = aDayOfYear;
          var tt = new ICAL.Time();
          tt.auto_normalize = false;
          var is_leap = ICAL.Time.isLeapYear(year) ? 1 : 0;
          if (doy < 1) {
            year--;
            is_leap = ICAL.Time.isLeapYear(year) ? 1 : 0;
            doy += ICAL.Time.daysInYearPassedMonth[is_leap][12];
            return ICAL.Time.fromDayOfYear(doy, year);
          } else if (doy > ICAL.Time.daysInYearPassedMonth[is_leap][12]) {
            is_leap = ICAL.Time.isLeapYear(year) ? 1 : 0;
            doy -= ICAL.Time.daysInYearPassedMonth[is_leap][12];
            year++;
            return ICAL.Time.fromDayOfYear(doy, year);
          }
          tt.year = year;
          tt.isDate = true;
          for (var month = 11; month >= 0; month--) {
            if (doy > ICAL.Time.daysInYearPassedMonth[is_leap][month]) {
              tt.month = month + 1;
              tt.day = doy - ICAL.Time.daysInYearPassedMonth[is_leap][month];
              break;
            }
          }
          tt.auto_normalize = true;
          return tt;
        };
        ICAL.Time.fromStringv2 = function fromString(str) {
          return new ICAL.Time({
            year: parseInt(str.substr(0, 4), 10),
            month: parseInt(str.substr(5, 2), 10),
            day: parseInt(str.substr(8, 2), 10),
            isDate: true
          });
        };
        ICAL.Time.fromDateString = function(aValue) {
          return new ICAL.Time({
            year: ICAL.helpers.strictParseInt(aValue.substr(0, 4)),
            month: ICAL.helpers.strictParseInt(aValue.substr(5, 2)),
            day: ICAL.helpers.strictParseInt(aValue.substr(8, 2)),
            isDate: true
          });
        };
        ICAL.Time.fromDateTimeString = function(aValue, prop) {
          if (aValue.length < 19) {
            throw new Error(
              'invalid date-time value: "' + aValue + '"'
            );
          }
          var zone;
          if (aValue[19] && aValue[19] === "Z") {
            zone = "Z";
          } else if (prop) {
            zone = prop.getParameter("tzid");
          }
          var time = new ICAL.Time({
            year: ICAL.helpers.strictParseInt(aValue.substr(0, 4)),
            month: ICAL.helpers.strictParseInt(aValue.substr(5, 2)),
            day: ICAL.helpers.strictParseInt(aValue.substr(8, 2)),
            hour: ICAL.helpers.strictParseInt(aValue.substr(11, 2)),
            minute: ICAL.helpers.strictParseInt(aValue.substr(14, 2)),
            second: ICAL.helpers.strictParseInt(aValue.substr(17, 2)),
            timezone: zone
          });
          return time;
        };
        ICAL.Time.fromString = function fromString(aValue, aProperty) {
          if (aValue.length > 10) {
            return ICAL.Time.fromDateTimeString(aValue, aProperty);
          } else {
            return ICAL.Time.fromDateString(aValue);
          }
        };
        ICAL.Time.fromJSDate = function fromJSDate(aDate, useUTC) {
          var tt = new ICAL.Time();
          return tt.fromJSDate(aDate, useUTC);
        };
        ICAL.Time.fromData = function fromData(aData, aZone) {
          var t = new ICAL.Time();
          return t.fromData(aData, aZone);
        };
        ICAL.Time.now = function icaltime_now() {
          return ICAL.Time.fromJSDate(/* @__PURE__ */ new Date(), false);
        };
        ICAL.Time.weekOneStarts = function weekOneStarts(aYear, aWeekStart) {
          var t = ICAL.Time.fromData({
            year: aYear,
            month: 1,
            day: 1,
            isDate: true
          });
          var dow = t.dayOfWeek();
          var wkst = aWeekStart || ICAL.Time.DEFAULT_WEEK_START;
          if (dow > ICAL.Time.THURSDAY) {
            t.day += 7;
          }
          if (wkst > ICAL.Time.THURSDAY) {
            t.day -= 7;
          }
          t.day -= dow - wkst;
          return t;
        };
        ICAL.Time.getDominicalLetter = function(yr) {
          var LTRS = "GFEDCBA";
          var dom = (yr + (yr / 4 | 0) + (yr / 400 | 0) - (yr / 100 | 0) - 1) % 7;
          var isLeap = ICAL.Time.isLeapYear(yr);
          if (isLeap) {
            return LTRS[(dom + 6) % 7] + LTRS[dom];
          } else {
            return LTRS[dom];
          }
        };
        ICAL.Time.epochTime = ICAL.Time.fromData({
          year: 1970,
          month: 1,
          day: 1,
          hour: 0,
          minute: 0,
          second: 0,
          isDate: false,
          timezone: "Z"
        });
        ICAL.Time._cmp_attr = function _cmp_attr(a, b, attr) {
          if (a[attr] > b[attr]) return 1;
          if (a[attr] < b[attr]) return -1;
          return 0;
        };
        ICAL.Time.daysInYearPassedMonth = [
          [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365],
          [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366]
        ];
        ICAL.Time.SUNDAY = 1;
        ICAL.Time.MONDAY = 2;
        ICAL.Time.TUESDAY = 3;
        ICAL.Time.WEDNESDAY = 4;
        ICAL.Time.THURSDAY = 5;
        ICAL.Time.FRIDAY = 6;
        ICAL.Time.SATURDAY = 7;
        ICAL.Time.DEFAULT_WEEK_START = ICAL.Time.MONDAY;
      })();
      (function() {
        ICAL.VCardTime = function(data, zone, icaltype) {
          this.wrappedJSObject = this;
          var time = this._time = /* @__PURE__ */ Object.create(null);
          time.year = null;
          time.month = null;
          time.day = null;
          time.hour = null;
          time.minute = null;
          time.second = null;
          this.icaltype = icaltype || "date-and-or-time";
          this.fromData(data, zone);
        };
        ICAL.helpers.inherits(
          ICAL.Time,
          ICAL.VCardTime,
          /** @lends ICAL.VCardTime */
          {
            /**
             * The class identifier.
             * @constant
             * @type {String}
             * @default "vcardtime"
             */
            icalclass: "vcardtime",
            /**
             * The type name, to be used in the jCal object.
             * @type {String}
             * @default "date-and-or-time"
             */
            icaltype: "date-and-or-time",
            /**
             * The timezone. This can either be floating, UTC, or an instance of
             * ICAL.UtcOffset.
             * @type {ICAL.Timezone|ICAL.UtcOFfset}
             */
            zone: null,
            /**
             * Returns a clone of the vcard date/time object.
             *
             * @return {ICAL.VCardTime}     The cloned object
             */
            clone: function() {
              return new ICAL.VCardTime(this._time, this.zone, this.icaltype);
            },
            _normalize: function() {
              return this;
            },
            /**
             * @inheritdoc
             */
            utcOffset: function() {
              if (this.zone instanceof ICAL.UtcOffset) {
                return this.zone.toSeconds();
              } else {
                return ICAL.Time.prototype.utcOffset.apply(this, arguments);
              }
            },
            /**
             * Returns an RFC 6350 compliant representation of this object.
             *
             * @return {String}         vcard date/time string
             */
            toICALString: function() {
              return ICAL.design.vcard.value[this.icaltype].toICAL(this.toString());
            },
            /**
             * The string representation of this date/time, in jCard form
             * (including : and - separators).
             * @return {String}
             */
            toString: function toString() {
              var p2 = ICAL.helpers.pad2;
              var y = this.year, m2 = this.month, d = this.day;
              var h = this.hour, mm = this.minute, s = this.second;
              var hasYear = y !== null, hasMonth = m2 !== null, hasDay = d !== null;
              var hasHour = h !== null, hasMinute = mm !== null, hasSecond = s !== null;
              var datepart = (hasYear ? p2(y) + (hasMonth || hasDay ? "-" : "") : hasMonth || hasDay ? "--" : "") + (hasMonth ? p2(m2) : "") + (hasDay ? "-" + p2(d) : "");
              var timepart = (hasHour ? p2(h) : "-") + (hasHour && hasMinute ? ":" : "") + (hasMinute ? p2(mm) : "") + (!hasHour && !hasMinute ? "-" : "") + (hasMinute && hasSecond ? ":" : "") + (hasSecond ? p2(s) : "");
              var zone;
              if (this.zone === ICAL.Timezone.utcTimezone) {
                zone = "Z";
              } else if (this.zone instanceof ICAL.UtcOffset) {
                zone = this.zone.toString();
              } else if (this.zone === ICAL.Timezone.localTimezone) {
                zone = "";
              } else if (this.zone instanceof ICAL.Timezone) {
                var offset = ICAL.UtcOffset.fromSeconds(this.zone.utcOffset(this));
                zone = offset.toString();
              } else {
                zone = "";
              }
              switch (this.icaltype) {
                case "time":
                  return timepart + zone;
                case "date-and-or-time":
                case "date-time":
                  return datepart + (timepart == "--" ? "" : "T" + timepart + zone);
                case "date":
                  return datepart;
              }
              return null;
            }
          }
        );
        ICAL.VCardTime.fromDateAndOrTimeString = function(aValue, aIcalType) {
          function part(v, s, e) {
            return v ? ICAL.helpers.strictParseInt(v.substr(s, e)) : null;
          }
          var parts = aValue.split("T");
          var dt = parts[0], tmz = parts[1];
          var splitzone = tmz ? ICAL.design.vcard.value.time._splitZone(tmz) : [];
          var zone = splitzone[0], tm = splitzone[1];
          var stoi = ICAL.helpers.strictParseInt;
          var dtlen = dt ? dt.length : 0;
          var tmlen = tm ? tm.length : 0;
          var hasDashDate = dt && dt[0] == "-" && dt[1] == "-";
          var hasDashTime = tm && tm[0] == "-";
          var o = {
            year: hasDashDate ? null : part(dt, 0, 4),
            month: hasDashDate && (dtlen == 4 || dtlen == 7) ? part(dt, 2, 2) : dtlen == 7 ? part(dt, 5, 2) : dtlen == 10 ? part(dt, 5, 2) : null,
            day: dtlen == 5 ? part(dt, 3, 2) : dtlen == 7 && hasDashDate ? part(dt, 5, 2) : dtlen == 10 ? part(dt, 8, 2) : null,
            hour: hasDashTime ? null : part(tm, 0, 2),
            minute: hasDashTime && tmlen == 3 ? part(tm, 1, 2) : tmlen > 4 ? hasDashTime ? part(tm, 1, 2) : part(tm, 3, 2) : null,
            second: tmlen == 4 ? part(tm, 2, 2) : tmlen == 6 ? part(tm, 4, 2) : tmlen == 8 ? part(tm, 6, 2) : null
          };
          if (zone == "Z") {
            zone = ICAL.Timezone.utcTimezone;
          } else if (zone && zone[3] == ":") {
            zone = ICAL.UtcOffset.fromString(zone);
          } else {
            zone = null;
          }
          return new ICAL.VCardTime(o, zone, aIcalType);
        };
      })();
      (function() {
        var DOW_MAP = {
          SU: ICAL.Time.SUNDAY,
          MO: ICAL.Time.MONDAY,
          TU: ICAL.Time.TUESDAY,
          WE: ICAL.Time.WEDNESDAY,
          TH: ICAL.Time.THURSDAY,
          FR: ICAL.Time.FRIDAY,
          SA: ICAL.Time.SATURDAY
        };
        var REVERSE_DOW_MAP = {};
        for (var key in DOW_MAP) {
          if (DOW_MAP.hasOwnProperty(key)) {
            REVERSE_DOW_MAP[DOW_MAP[key]] = key;
          }
        }
        var COPY_PARTS = [
          "BYSECOND",
          "BYMINUTE",
          "BYHOUR",
          "BYDAY",
          "BYMONTHDAY",
          "BYYEARDAY",
          "BYWEEKNO",
          "BYMONTH",
          "BYSETPOS"
        ];
        ICAL.Recur = function icalrecur(data) {
          this.wrappedJSObject = this;
          this.parts = {};
          if (data && typeof data === "object") {
            this.fromData(data);
          }
        };
        ICAL.Recur.prototype = {
          /**
           * An object holding the BY-parts of the recurrence rule
           * @type {Object}
           */
          parts: null,
          /**
           * The interval value for the recurrence rule.
           * @type {Number}
           */
          interval: 1,
          /**
           * The week start day
           *
           * @type {ICAL.Time.weekDay}
           * @default ICAL.Time.MONDAY
           */
          wkst: ICAL.Time.MONDAY,
          /**
           * The end of the recurrence
           * @type {?ICAL.Time}
           */
          until: null,
          /**
           * The maximum number of occurrences
           * @type {?Number}
           */
          count: null,
          /**
           * The frequency value.
           * @type {ICAL.Recur.frequencyValues}
           */
          freq: null,
          /**
           * The class identifier.
           * @constant
           * @type {String}
           * @default "icalrecur"
           */
          icalclass: "icalrecur",
          /**
           * The type name, to be used in the jCal object.
           * @constant
           * @type {String}
           * @default "recur"
           */
          icaltype: "recur",
          /**
           * Create a new iterator for this recurrence rule. The passed start date
           * must be the start date of the event, not the start of the range to
           * search in.
           *
           * @example
           * var recur = comp.getFirstPropertyValue('rrule');
           * var dtstart = comp.getFirstPropertyValue('dtstart');
           * var iter = recur.iterator(dtstart);
           * for (var next = iter.next(); next; next = iter.next()) {
           *   if (next.compare(rangeStart) < 0) {
           *     continue;
           *   }
           *   console.log(next.toString());
           * }
           *
           * @param {ICAL.Time} aStart        The item's start date
           * @return {ICAL.RecurIterator}     The recurrence iterator
           */
          iterator: function(aStart) {
            return new ICAL.RecurIterator({
              rule: this,
              dtstart: aStart
            });
          },
          /**
           * Returns a clone of the recurrence object.
           *
           * @return {ICAL.Recur}      The cloned object
           */
          clone: function clone() {
            return new ICAL.Recur(this.toJSON());
          },
          /**
           * Checks if the current rule is finite, i.e. has a count or until part.
           *
           * @return {Boolean}        True, if the rule is finite
           */
          isFinite: function isfinite() {
            return !!(this.count || this.until);
          },
          /**
           * Checks if the current rule has a count part, and not limited by an until
           * part.
           *
           * @return {Boolean}        True, if the rule is by count
           */
          isByCount: function isbycount() {
            return !!(this.count && !this.until);
          },
          /**
           * Adds a component (part) to the recurrence rule. This is not a component
           * in the sense of {@link ICAL.Component}, but a part of the recurrence
           * rule, i.e. BYMONTH.
           *
           * @param {String} aType            The name of the component part
           * @param {Array|String} aValue     The component value
           */
          addComponent: function addPart(aType, aValue) {
            var ucname = aType.toUpperCase();
            if (ucname in this.parts) {
              this.parts[ucname].push(aValue);
            } else {
              this.parts[ucname] = [aValue];
            }
          },
          /**
           * Sets the component value for the given by-part.
           *
           * @param {String} aType        The component part name
           * @param {Array} aValues       The component values
           */
          setComponent: function setComponent(aType, aValues) {
            this.parts[aType.toUpperCase()] = aValues.slice();
          },
          /**
           * Gets (a copy) of the requested component value.
           *
           * @param {String} aType        The component part name
           * @return {Array}              The component part value
           */
          getComponent: function getComponent(aType) {
            var ucname = aType.toUpperCase();
            return ucname in this.parts ? this.parts[ucname].slice() : [];
          },
          /**
           * Retrieves the next occurrence after the given recurrence id. See the
           * guide on {@tutorial terminology} for more details.
           *
           * NOTE: Currently, this method iterates all occurrences from the start
           * date. It should not be called in a loop for performance reasons. If you
           * would like to get more than one occurrence, you can iterate the
           * occurrences manually, see the example on the
           * {@link ICAL.Recur#iterator iterator} method.
           *
           * @param {ICAL.Time} aStartTime        The start of the event series
           * @param {ICAL.Time} aRecurrenceId     The date of the last occurrence
           * @return {ICAL.Time}                  The next occurrence after
           */
          getNextOccurrence: function getNextOccurrence(aStartTime, aRecurrenceId) {
            var iter = this.iterator(aStartTime);
            var next, cdt;
            do {
              next = iter.next();
            } while (next && next.compare(aRecurrenceId) <= 0);
            if (next && aRecurrenceId.zone) {
              next.zone = aRecurrenceId.zone;
            }
            return next;
          },
          /**
           * Sets up the current instance using members from the passed data object.
           *
           * @param {Object} data                               An object with members of the recurrence
           * @param {ICAL.Recur.frequencyValues=} data.freq     The frequency value
           * @param {Number=} data.interval                     The INTERVAL value
           * @param {ICAL.Time.weekDay=} data.wkst              The week start value
           * @param {ICAL.Time=} data.until                     The end of the recurrence set
           * @param {Number=} data.count                        The number of occurrences
           * @param {Array.<Number>=} data.bysecond             The seconds for the BYSECOND part
           * @param {Array.<Number>=} data.byminute             The minutes for the BYMINUTE part
           * @param {Array.<Number>=} data.byhour               The hours for the BYHOUR part
           * @param {Array.<String>=} data.byday                The BYDAY values
           * @param {Array.<Number>=} data.bymonthday           The days for the BYMONTHDAY part
           * @param {Array.<Number>=} data.byyearday            The days for the BYYEARDAY part
           * @param {Array.<Number>=} data.byweekno             The weeks for the BYWEEKNO part
           * @param {Array.<Number>=} data.bymonth              The month for the BYMONTH part
           * @param {Array.<Number>=} data.bysetpos             The positionals for the BYSETPOS part
           */
          fromData: function(data) {
            for (var key2 in data) {
              var uckey = key2.toUpperCase();
              if (uckey in partDesign) {
                if (Array.isArray(data[key2])) {
                  this.parts[uckey] = data[key2];
                } else {
                  this.parts[uckey] = [data[key2]];
                }
              } else {
                this[key2] = data[key2];
              }
            }
            if (this.interval && typeof this.interval != "number") {
              optionDesign.INTERVAL(this.interval, this);
            }
            if (this.wkst && typeof this.wkst != "number") {
              this.wkst = ICAL.Recur.icalDayToNumericDay(this.wkst);
            }
            if (this.until && !(this.until instanceof ICAL.Time)) {
              this.until = ICAL.Time.fromString(this.until);
            }
          },
          /**
           * The jCal representation of this recurrence type.
           * @return {Object}
           */
          toJSON: function() {
            var res = /* @__PURE__ */ Object.create(null);
            res.freq = this.freq;
            if (this.count) {
              res.count = this.count;
            }
            if (this.interval > 1) {
              res.interval = this.interval;
            }
            for (var k in this.parts) {
              if (!this.parts.hasOwnProperty(k)) {
                continue;
              }
              var kparts = this.parts[k];
              if (Array.isArray(kparts) && kparts.length == 1) {
                res[k.toLowerCase()] = kparts[0];
              } else {
                res[k.toLowerCase()] = ICAL.helpers.clone(this.parts[k]);
              }
            }
            if (this.until) {
              res.until = this.until.toString();
            }
            if ("wkst" in this && this.wkst !== ICAL.Time.DEFAULT_WEEK_START) {
              res.wkst = ICAL.Recur.numericDayToIcalDay(this.wkst);
            }
            return res;
          },
          /**
           * The string representation of this recurrence rule.
           * @return {String}
           */
          toString: function icalrecur_toString() {
            var str = "FREQ=" + this.freq;
            if (this.count) {
              str += ";COUNT=" + this.count;
            }
            if (this.interval > 1) {
              str += ";INTERVAL=" + this.interval;
            }
            for (var k in this.parts) {
              if (this.parts.hasOwnProperty(k)) {
                str += ";" + k + "=" + this.parts[k];
              }
            }
            if (this.until) {
              str += ";UNTIL=" + this.until.toICALString();
            }
            if ("wkst" in this && this.wkst !== ICAL.Time.DEFAULT_WEEK_START) {
              str += ";WKST=" + ICAL.Recur.numericDayToIcalDay(this.wkst);
            }
            return str;
          }
        };
        function parseNumericValue(type, min, max, value) {
          var result = value;
          if (value[0] === "+") {
            result = value.substr(1);
          }
          result = ICAL.helpers.strictParseInt(result);
          if (min !== void 0 && value < min) {
            throw new Error(
              type + ': invalid value "' + value + '" must be > ' + min
            );
          }
          if (max !== void 0 && value > max) {
            throw new Error(
              type + ': invalid value "' + value + '" must be < ' + min
            );
          }
          return result;
        }
        ICAL.Recur.icalDayToNumericDay = function toNumericDay(string, aWeekStart) {
          var firstDow = aWeekStart || ICAL.Time.SUNDAY;
          return (DOW_MAP[string] - firstDow + 7) % 7 + 1;
        };
        ICAL.Recur.numericDayToIcalDay = function toIcalDay(num, aWeekStart) {
          var firstDow = aWeekStart || ICAL.Time.SUNDAY;
          var dow = num + firstDow - ICAL.Time.SUNDAY;
          if (dow > 7) {
            dow -= 7;
          }
          return REVERSE_DOW_MAP[dow];
        };
        var VALID_DAY_NAMES = /^(SU|MO|TU|WE|TH|FR|SA)$/;
        var VALID_BYDAY_PART = /^([+-])?(5[0-3]|[1-4][0-9]|[1-9])?(SU|MO|TU|WE|TH|FR|SA)$/;
        var ALLOWED_FREQ = [
          "SECONDLY",
          "MINUTELY",
          "HOURLY",
          "DAILY",
          "WEEKLY",
          "MONTHLY",
          "YEARLY"
        ];
        var optionDesign = {
          FREQ: function(value, dict, fmtIcal) {
            if (ALLOWED_FREQ.indexOf(value) !== -1) {
              dict.freq = value;
            } else {
              throw new Error(
                'invalid frequency "' + value + '" expected: "' + ALLOWED_FREQ.join(", ") + '"'
              );
            }
          },
          COUNT: function(value, dict, fmtIcal) {
            dict.count = ICAL.helpers.strictParseInt(value);
          },
          INTERVAL: function(value, dict, fmtIcal) {
            dict.interval = ICAL.helpers.strictParseInt(value);
            if (dict.interval < 1) {
              dict.interval = 1;
            }
          },
          UNTIL: function(value, dict, fmtIcal) {
            if (value.length > 10) {
              dict.until = ICAL.design.icalendar.value["date-time"].fromICAL(value);
            } else {
              dict.until = ICAL.design.icalendar.value.date.fromICAL(value);
            }
            if (!fmtIcal) {
              dict.until = ICAL.Time.fromString(dict.until);
            }
          },
          WKST: function(value, dict, fmtIcal) {
            if (VALID_DAY_NAMES.test(value)) {
              dict.wkst = ICAL.Recur.icalDayToNumericDay(value);
            } else {
              throw new Error('invalid WKST value "' + value + '"');
            }
          }
        };
        var partDesign = {
          BYSECOND: parseNumericValue.bind(this, "BYSECOND", 0, 60),
          BYMINUTE: parseNumericValue.bind(this, "BYMINUTE", 0, 59),
          BYHOUR: parseNumericValue.bind(this, "BYHOUR", 0, 23),
          BYDAY: function(value) {
            if (VALID_BYDAY_PART.test(value)) {
              return value;
            } else {
              throw new Error('invalid BYDAY value "' + value + '"');
            }
          },
          BYMONTHDAY: parseNumericValue.bind(this, "BYMONTHDAY", -31, 31),
          BYYEARDAY: parseNumericValue.bind(this, "BYYEARDAY", -366, 366),
          BYWEEKNO: parseNumericValue.bind(this, "BYWEEKNO", -53, 53),
          BYMONTH: parseNumericValue.bind(this, "BYMONTH", 1, 12),
          BYSETPOS: parseNumericValue.bind(this, "BYSETPOS", -366, 366)
        };
        ICAL.Recur.fromString = function(string) {
          var data = ICAL.Recur._stringToData(string, false);
          return new ICAL.Recur(data);
        };
        ICAL.Recur.fromData = function(aData) {
          return new ICAL.Recur(aData);
        };
        ICAL.Recur._stringToData = function(string, fmtIcal) {
          var dict = /* @__PURE__ */ Object.create(null);
          var values = string.split(";");
          var len = values.length;
          for (var i = 0; i < len; i++) {
            var parts = values[i].split("=");
            var ucname = parts[0].toUpperCase();
            var lcname = parts[0].toLowerCase();
            var name = fmtIcal ? lcname : ucname;
            var value = parts[1];
            if (ucname in partDesign) {
              var partArr = value.split(",");
              var partArrIdx = 0;
              var partArrLen = partArr.length;
              for (; partArrIdx < partArrLen; partArrIdx++) {
                partArr[partArrIdx] = partDesign[ucname](partArr[partArrIdx]);
              }
              dict[name] = partArr.length == 1 ? partArr[0] : partArr;
            } else if (ucname in optionDesign) {
              optionDesign[ucname](value, dict, fmtIcal);
            } else {
              dict[lcname] = value;
            }
          }
          return dict;
        };
      })();
      ICAL.RecurIterator = (function() {
        function icalrecur_iterator(options) {
          this.fromData(options);
        }
        icalrecur_iterator.prototype = {
          /**
           * True when iteration is finished.
           * @type {Boolean}
           */
          completed: false,
          /**
           * The rule that is being iterated
           * @type {ICAL.Recur}
           */
          rule: null,
          /**
           * The start date of the event being iterated.
           * @type {ICAL.Time}
           */
          dtstart: null,
          /**
           * The last occurrence that was returned from the
           * {@link ICAL.RecurIterator#next} method.
           * @type {ICAL.Time}
           */
          last: null,
          /**
           * The sequence number from the occurrence
           * @type {Number}
           */
          occurrence_number: 0,
          /**
           * The indices used for the {@link ICAL.RecurIterator#by_data} object.
           * @type {Object}
           * @private
           */
          by_indices: null,
          /**
           * If true, the iterator has already been initialized
           * @type {Boolean}
           * @private
           */
          initialized: false,
          /**
           * The initializd by-data.
           * @type {Object}
           * @private
           */
          by_data: null,
          /**
           * The expanded yeardays
           * @type {Array}
           * @private
           */
          days: null,
          /**
           * The index in the {@link ICAL.RecurIterator#days} array.
           * @type {Number}
           * @private
           */
          days_index: 0,
          /**
           * Initialize the recurrence iterator from the passed data object. This
           * method is usually not called directly, you can initialize the iterator
           * through the constructor.
           *
           * @param {Object} options                The iterator options
           * @param {ICAL.Recur} options.rule       The rule to iterate.
           * @param {ICAL.Time} options.dtstart     The start date of the event.
           * @param {Boolean=} options.initialized  When true, assume that options are
           *        from a previously constructed iterator. Initialization will not be
           *        repeated.
           */
          fromData: function(options) {
            this.rule = ICAL.helpers.formatClassType(options.rule, ICAL.Recur);
            if (!this.rule) {
              throw new Error("iterator requires a (ICAL.Recur) rule");
            }
            this.dtstart = ICAL.helpers.formatClassType(options.dtstart, ICAL.Time);
            if (!this.dtstart) {
              throw new Error("iterator requires a (ICAL.Time) dtstart");
            }
            if (options.by_data) {
              this.by_data = options.by_data;
            } else {
              this.by_data = ICAL.helpers.clone(this.rule.parts, true);
            }
            if (options.occurrence_number)
              this.occurrence_number = options.occurrence_number;
            this.days = options.days || [];
            if (options.last) {
              this.last = ICAL.helpers.formatClassType(options.last, ICAL.Time);
            }
            this.by_indices = options.by_indices;
            if (!this.by_indices) {
              this.by_indices = {
                "BYSECOND": 0,
                "BYMINUTE": 0,
                "BYHOUR": 0,
                "BYDAY": 0,
                "BYMONTH": 0,
                "BYWEEKNO": 0,
                "BYMONTHDAY": 0
              };
            }
            this.initialized = options.initialized || false;
            if (!this.initialized) {
              this.init();
            }
          },
          /**
           * Intialize the iterator
           * @private
           */
          init: function icalrecur_iterator_init() {
            this.initialized = true;
            this.last = this.dtstart.clone();
            var parts = this.by_data;
            if ("BYDAY" in parts) {
              this.sort_byday_rules(parts.BYDAY);
            }
            if ("BYYEARDAY" in parts) {
              if ("BYMONTH" in parts || "BYWEEKNO" in parts || "BYMONTHDAY" in parts || "BYDAY" in parts) {
                throw new Error("Invalid BYYEARDAY rule");
              }
            }
            if ("BYWEEKNO" in parts && "BYMONTHDAY" in parts) {
              throw new Error("BYWEEKNO does not fit to BYMONTHDAY");
            }
            if (this.rule.freq == "MONTHLY" && ("BYYEARDAY" in parts || "BYWEEKNO" in parts)) {
              throw new Error("For MONTHLY recurrences neither BYYEARDAY nor BYWEEKNO may appear");
            }
            if (this.rule.freq == "WEEKLY" && ("BYYEARDAY" in parts || "BYMONTHDAY" in parts)) {
              throw new Error("For WEEKLY recurrences neither BYMONTHDAY nor BYYEARDAY may appear");
            }
            if (this.rule.freq != "YEARLY" && "BYYEARDAY" in parts) {
              throw new Error("BYYEARDAY may only appear in YEARLY rules");
            }
            this.last.second = this.setup_defaults("BYSECOND", "SECONDLY", this.dtstart.second);
            this.last.minute = this.setup_defaults("BYMINUTE", "MINUTELY", this.dtstart.minute);
            this.last.hour = this.setup_defaults("BYHOUR", "HOURLY", this.dtstart.hour);
            this.last.day = this.setup_defaults("BYMONTHDAY", "DAILY", this.dtstart.day);
            this.last.month = this.setup_defaults("BYMONTH", "MONTHLY", this.dtstart.month);
            if (this.rule.freq == "WEEKLY") {
              if ("BYDAY" in parts) {
                var bydayParts = this.ruleDayOfWeek(parts.BYDAY[0], this.rule.wkst);
                var pos = bydayParts[0];
                var dow = bydayParts[1];
                var wkdy = dow - this.last.dayOfWeek(this.rule.wkst);
                if (this.last.dayOfWeek(this.rule.wkst) < dow && wkdy >= 0 || wkdy < 0) {
                  this.last.day += wkdy;
                }
              } else {
                var dayName = ICAL.Recur.numericDayToIcalDay(this.dtstart.dayOfWeek());
                parts.BYDAY = [dayName];
              }
            }
            if (this.rule.freq == "YEARLY") {
              for (; ; ) {
                this.expand_year_days(this.last.year);
                if (this.days.length > 0) {
                  break;
                }
                this.increment_year(this.rule.interval);
              }
              this._nextByYearDay();
            }
            if (this.rule.freq == "MONTHLY" && this.has_by_data("BYDAY")) {
              var tempLast = null;
              var initLast = this.last.clone();
              var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
              for (var i in this.by_data.BYDAY) {
                if (!this.by_data.BYDAY.hasOwnProperty(i)) {
                  continue;
                }
                this.last = initLast.clone();
                var bydayParts = this.ruleDayOfWeek(this.by_data.BYDAY[i]);
                var pos = bydayParts[0];
                var dow = bydayParts[1];
                var dayOfMonth = this.last.nthWeekDay(dow, pos);
                if (pos >= 6 || pos <= -6) {
                  throw new Error("Malformed values in BYDAY part");
                }
                if (dayOfMonth > daysInMonth || dayOfMonth <= 0) {
                  if (tempLast && tempLast.month == initLast.month) {
                    continue;
                  }
                  while (dayOfMonth > daysInMonth || dayOfMonth <= 0) {
                    this.increment_month();
                    daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
                    dayOfMonth = this.last.nthWeekDay(dow, pos);
                  }
                }
                this.last.day = dayOfMonth;
                if (!tempLast || this.last.compare(tempLast) < 0) {
                  tempLast = this.last.clone();
                }
              }
              this.last = tempLast.clone();
              if (this.has_by_data("BYMONTHDAY")) {
                this._byDayAndMonthDay(true);
              }
              if (this.last.day > daysInMonth || this.last.day == 0) {
                throw new Error("Malformed values in BYDAY part");
              }
            } else if (this.has_by_data("BYMONTHDAY")) {
              if (this.last.day < 0) {
                var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
                this.last.day = daysInMonth + this.last.day + 1;
              }
            }
          },
          /**
           * Retrieve the next occurrence from the iterator.
           * @return {ICAL.Time}
           */
          next: function icalrecur_iterator_next() {
            var before = this.last ? this.last.clone() : null;
            if (this.rule.count && this.occurrence_number >= this.rule.count || this.rule.until && this.last.compare(this.rule.until) > 0) {
              this.completed = true;
              return null;
            }
            if (this.occurrence_number == 0 && this.last.compare(this.dtstart) >= 0) {
              this.occurrence_number++;
              return this.last;
            }
            var valid;
            do {
              valid = 1;
              switch (this.rule.freq) {
                case "SECONDLY":
                  this.next_second();
                  break;
                case "MINUTELY":
                  this.next_minute();
                  break;
                case "HOURLY":
                  this.next_hour();
                  break;
                case "DAILY":
                  this.next_day();
                  break;
                case "WEEKLY":
                  this.next_week();
                  break;
                case "MONTHLY":
                  valid = this.next_month();
                  break;
                case "YEARLY":
                  this.next_year();
                  break;
                default:
                  return null;
              }
            } while (!this.check_contracting_rules() || this.last.compare(this.dtstart) < 0 || !valid);
            if (this.last.compare(before) == 0) {
              throw new Error("Same occurrence found twice, protecting you from death by recursion");
            }
            if (this.rule.until && this.last.compare(this.rule.until) > 0) {
              this.completed = true;
              return null;
            } else {
              this.occurrence_number++;
              return this.last;
            }
          },
          next_second: function next_second() {
            return this.next_generic("BYSECOND", "SECONDLY", "second", "minute");
          },
          increment_second: function increment_second(inc) {
            return this.increment_generic(inc, "second", 60, "minute");
          },
          next_minute: function next_minute() {
            return this.next_generic(
              "BYMINUTE",
              "MINUTELY",
              "minute",
              "hour",
              "next_second"
            );
          },
          increment_minute: function increment_minute(inc) {
            return this.increment_generic(inc, "minute", 60, "hour");
          },
          next_hour: function next_hour() {
            return this.next_generic(
              "BYHOUR",
              "HOURLY",
              "hour",
              "monthday",
              "next_minute"
            );
          },
          increment_hour: function increment_hour(inc) {
            this.increment_generic(inc, "hour", 24, "monthday");
          },
          next_day: function next_day() {
            var has_by_day = "BYDAY" in this.by_data;
            var this_freq = this.rule.freq == "DAILY";
            if (this.next_hour() == 0) {
              return 0;
            }
            if (this_freq) {
              this.increment_monthday(this.rule.interval);
            } else {
              this.increment_monthday(1);
            }
            return 0;
          },
          next_week: function next_week() {
            var end_of_data = 0;
            if (this.next_weekday_by_week() == 0) {
              return end_of_data;
            }
            if (this.has_by_data("BYWEEKNO")) {
              var idx = ++this.by_indices.BYWEEKNO;
              if (this.by_indices.BYWEEKNO == this.by_data.BYWEEKNO.length) {
                this.by_indices.BYWEEKNO = 0;
                end_of_data = 1;
              }
              this.last.month = 1;
              this.last.day = 1;
              var week_no = this.by_data.BYWEEKNO[this.by_indices.BYWEEKNO];
              this.last.day += 7 * week_no;
              if (end_of_data) {
                this.increment_year(1);
              }
            } else {
              this.increment_monthday(7 * this.rule.interval);
            }
            return end_of_data;
          },
          /**
           * Normalize each by day rule for a given year/month.
           * Takes into account ordering and negative rules
           *
           * @private
           * @param {Number} year         Current year.
           * @param {Number} month        Current month.
           * @param {Array}  rules        Array of rules.
           *
           * @return {Array} sorted and normalized rules.
           *                 Negative rules will be expanded to their
           *                 correct positive values for easier processing.
           */
          normalizeByMonthDayRules: function(year, month, rules) {
            var daysInMonth = ICAL.Time.daysInMonth(month, year);
            var newRules = [];
            var ruleIdx = 0;
            var len = rules.length;
            var rule;
            for (; ruleIdx < len; ruleIdx++) {
              rule = rules[ruleIdx];
              if (Math.abs(rule) > daysInMonth) {
                continue;
              }
              if (rule < 0) {
                rule = daysInMonth + (rule + 1);
              } else if (rule === 0) {
                continue;
              }
              if (newRules.indexOf(rule) === -1) {
                newRules.push(rule);
              }
            }
            return newRules.sort(function(a, b) {
              return a - b;
            });
          },
          /**
           * NOTES:
           * We are given a list of dates in the month (BYMONTHDAY) (23, etc..)
           * Also we are given a list of days (BYDAY) (MO, 2SU, etc..) when
           * both conditions match a given date (this.last.day) iteration stops.
           *
           * @private
           * @param {Boolean=} isInit     When given true will not increment the
           *                                current day (this.last).
           */
          _byDayAndMonthDay: function(isInit) {
            var byMonthDay;
            var byDay = this.by_data.BYDAY;
            var date;
            var dateIdx = 0;
            var dateLen;
            var dayLen = byDay.length;
            var dataIsValid = 0;
            var daysInMonth;
            var self2 = this;
            var lastDay = this.last.day;
            function initMonth() {
              daysInMonth = ICAL.Time.daysInMonth(
                self2.last.month,
                self2.last.year
              );
              byMonthDay = self2.normalizeByMonthDayRules(
                self2.last.year,
                self2.last.month,
                self2.by_data.BYMONTHDAY
              );
              dateLen = byMonthDay.length;
              while (byMonthDay[dateIdx] <= lastDay && !(isInit && byMonthDay[dateIdx] == lastDay) && dateIdx < dateLen - 1) {
                dateIdx++;
              }
            }
            function nextMonth() {
              lastDay = 0;
              self2.increment_month();
              dateIdx = 0;
              initMonth();
            }
            initMonth();
            if (isInit) {
              lastDay -= 1;
            }
            var monthsCounter = 48;
            while (!dataIsValid && monthsCounter) {
              monthsCounter--;
              date = lastDay + 1;
              if (date > daysInMonth) {
                nextMonth();
                continue;
              }
              var next = byMonthDay[dateIdx++];
              if (next >= date) {
                lastDay = next;
              } else {
                nextMonth();
                continue;
              }
              for (var dayIdx = 0; dayIdx < dayLen; dayIdx++) {
                var parts = this.ruleDayOfWeek(byDay[dayIdx]);
                var pos = parts[0];
                var dow = parts[1];
                this.last.day = lastDay;
                if (this.last.isNthWeekDay(dow, pos)) {
                  dataIsValid = 1;
                  break;
                }
              }
              if (!dataIsValid && dateIdx === dateLen) {
                nextMonth();
                continue;
              }
            }
            if (monthsCounter <= 0) {
              throw new Error("Malformed values in BYDAY combined with BYMONTHDAY parts");
            }
            return dataIsValid;
          },
          next_month: function next_month() {
            var this_freq = this.rule.freq == "MONTHLY";
            var data_valid = 1;
            if (this.next_hour() == 0) {
              return data_valid;
            }
            if (this.has_by_data("BYDAY") && this.has_by_data("BYMONTHDAY")) {
              data_valid = this._byDayAndMonthDay();
            } else if (this.has_by_data("BYDAY")) {
              var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
              var setpos = 0;
              var setpos_total = 0;
              if (this.has_by_data("BYSETPOS")) {
                var last_day = this.last.day;
                for (var day = 1; day <= daysInMonth; day++) {
                  this.last.day = day;
                  if (this.is_day_in_byday(this.last)) {
                    setpos_total++;
                    if (day <= last_day) {
                      setpos++;
                    }
                  }
                }
                this.last.day = last_day;
              }
              data_valid = 0;
              for (var day = this.last.day + 1; day <= daysInMonth; day++) {
                this.last.day = day;
                if (this.is_day_in_byday(this.last)) {
                  if (!this.has_by_data("BYSETPOS") || this.check_set_position(++setpos) || this.check_set_position(setpos - setpos_total - 1)) {
                    data_valid = 1;
                    break;
                  }
                }
              }
              if (day > daysInMonth) {
                this.last.day = 1;
                this.increment_month();
                if (this.is_day_in_byday(this.last)) {
                  if (!this.has_by_data("BYSETPOS") || this.check_set_position(1)) {
                    data_valid = 1;
                  }
                } else {
                  data_valid = 0;
                }
              }
            } else if (this.has_by_data("BYMONTHDAY")) {
              this.by_indices.BYMONTHDAY++;
              if (this.by_indices.BYMONTHDAY >= this.by_data.BYMONTHDAY.length) {
                this.by_indices.BYMONTHDAY = 0;
                this.increment_month();
              }
              var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
              var day = this.by_data.BYMONTHDAY[this.by_indices.BYMONTHDAY];
              if (day < 0) {
                day = daysInMonth + day + 1;
              }
              if (day > daysInMonth) {
                this.last.day = 1;
                data_valid = this.is_day_in_byday(this.last);
              } else {
                this.last.day = day;
              }
            } else {
              this.increment_month();
              var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
              if (this.by_data.BYMONTHDAY[0] > daysInMonth) {
                data_valid = 0;
              } else {
                this.last.day = this.by_data.BYMONTHDAY[0];
              }
            }
            return data_valid;
          },
          next_weekday_by_week: function next_weekday_by_week() {
            var end_of_data = 0;
            if (this.next_hour() == 0) {
              return end_of_data;
            }
            if (!this.has_by_data("BYDAY")) {
              return 1;
            }
            for (; ; ) {
              var tt = new ICAL.Time();
              this.by_indices.BYDAY++;
              if (this.by_indices.BYDAY == Object.keys(this.by_data.BYDAY).length) {
                this.by_indices.BYDAY = 0;
                end_of_data = 1;
              }
              var coded_day = this.by_data.BYDAY[this.by_indices.BYDAY];
              var parts = this.ruleDayOfWeek(coded_day);
              var dow = parts[1];
              dow -= this.rule.wkst;
              if (dow < 0) {
                dow += 7;
              }
              tt.year = this.last.year;
              tt.month = this.last.month;
              tt.day = this.last.day;
              var startOfWeek = tt.startDoyWeek(this.rule.wkst);
              if (dow + startOfWeek < 1) {
                if (!end_of_data) {
                  continue;
                }
              }
              var next = ICAL.Time.fromDayOfYear(
                startOfWeek + dow,
                this.last.year
              );
              this.last.year = next.year;
              this.last.month = next.month;
              this.last.day = next.day;
              return end_of_data;
            }
          },
          next_year: function next_year() {
            if (this.next_hour() == 0) {
              return 0;
            }
            if (++this.days_index == this.days.length) {
              this.days_index = 0;
              do {
                this.increment_year(this.rule.interval);
                this.expand_year_days(this.last.year);
              } while (this.days.length == 0);
            }
            this._nextByYearDay();
            return 1;
          },
          _nextByYearDay: function _nextByYearDay() {
            var doy = this.days[this.days_index];
            var year = this.last.year;
            if (doy < 1) {
              doy += 1;
              year += 1;
            }
            var next = ICAL.Time.fromDayOfYear(doy, year);
            this.last.day = next.day;
            this.last.month = next.month;
          },
          /**
           * @param dow (eg: '1TU', '-1MO')
           * @param {ICAL.Time.weekDay=} aWeekStart The week start weekday
           * @return [pos, numericDow] (eg: [1, 3]) numericDow is relative to aWeekStart
           */
          ruleDayOfWeek: function ruleDayOfWeek(dow, aWeekStart) {
            var matches = dow.match(/([+-]?[0-9])?(MO|TU|WE|TH|FR|SA|SU)/);
            if (matches) {
              var pos = parseInt(matches[1] || 0, 10);
              dow = ICAL.Recur.icalDayToNumericDay(matches[2], aWeekStart);
              return [pos, dow];
            } else {
              return [0, 0];
            }
          },
          next_generic: function next_generic(aRuleType, aInterval, aDateAttr, aFollowingAttr, aPreviousIncr) {
            var has_by_rule = aRuleType in this.by_data;
            var this_freq = this.rule.freq == aInterval;
            var end_of_data = 0;
            if (aPreviousIncr && this[aPreviousIncr]() == 0) {
              return end_of_data;
            }
            if (has_by_rule) {
              this.by_indices[aRuleType]++;
              var idx = this.by_indices[aRuleType];
              var dta = this.by_data[aRuleType];
              if (this.by_indices[aRuleType] == dta.length) {
                this.by_indices[aRuleType] = 0;
                end_of_data = 1;
              }
              this.last[aDateAttr] = dta[this.by_indices[aRuleType]];
            } else if (this_freq) {
              this["increment_" + aDateAttr](this.rule.interval);
            }
            if (has_by_rule && end_of_data && this_freq) {
              this["increment_" + aFollowingAttr](1);
            }
            return end_of_data;
          },
          increment_monthday: function increment_monthday(inc) {
            for (var i = 0; i < inc; i++) {
              var daysInMonth = ICAL.Time.daysInMonth(this.last.month, this.last.year);
              this.last.day++;
              if (this.last.day > daysInMonth) {
                this.last.day -= daysInMonth;
                this.increment_month();
              }
            }
          },
          increment_month: function increment_month() {
            this.last.day = 1;
            if (this.has_by_data("BYMONTH")) {
              this.by_indices.BYMONTH++;
              if (this.by_indices.BYMONTH == this.by_data.BYMONTH.length) {
                this.by_indices.BYMONTH = 0;
                this.increment_year(1);
              }
              this.last.month = this.by_data.BYMONTH[this.by_indices.BYMONTH];
            } else {
              if (this.rule.freq == "MONTHLY") {
                this.last.month += this.rule.interval;
              } else {
                this.last.month++;
              }
              this.last.month--;
              var years = ICAL.helpers.trunc(this.last.month / 12);
              this.last.month %= 12;
              this.last.month++;
              if (years != 0) {
                this.increment_year(years);
              }
            }
          },
          increment_year: function increment_year(inc) {
            this.last.year += inc;
          },
          increment_generic: function increment_generic(inc, aDateAttr, aFactor, aNextIncrement) {
            this.last[aDateAttr] += inc;
            var nextunit = ICAL.helpers.trunc(this.last[aDateAttr] / aFactor);
            this.last[aDateAttr] %= aFactor;
            if (nextunit != 0) {
              this["increment_" + aNextIncrement](nextunit);
            }
          },
          has_by_data: function has_by_data(aRuleType) {
            return aRuleType in this.rule.parts;
          },
          expand_year_days: function expand_year_days(aYear) {
            var t = new ICAL.Time();
            this.days = [];
            var parts = {};
            var rules = ["BYDAY", "BYWEEKNO", "BYMONTHDAY", "BYMONTH", "BYYEARDAY"];
            for (var p in rules) {
              if (rules.hasOwnProperty(p)) {
                var part = rules[p];
                if (part in this.rule.parts) {
                  parts[part] = this.rule.parts[part];
                }
              }
            }
            if ("BYMONTH" in parts && "BYWEEKNO" in parts) {
              var valid = 1;
              var validWeeks = {};
              t.year = aYear;
              t.isDate = true;
              for (var monthIdx = 0; monthIdx < this.by_data.BYMONTH.length; monthIdx++) {
                var month = this.by_data.BYMONTH[monthIdx];
                t.month = month;
                t.day = 1;
                var first_week = t.weekNumber(this.rule.wkst);
                t.day = ICAL.Time.daysInMonth(month, aYear);
                var last_week = t.weekNumber(this.rule.wkst);
                for (monthIdx = first_week; monthIdx < last_week; monthIdx++) {
                  validWeeks[monthIdx] = 1;
                }
              }
              for (var weekIdx = 0; weekIdx < this.by_data.BYWEEKNO.length && valid; weekIdx++) {
                var weekno = this.by_data.BYWEEKNO[weekIdx];
                if (weekno < 52) {
                  valid &= validWeeks[weekIdx];
                } else {
                  valid = 0;
                }
              }
              if (valid) {
                delete parts.BYMONTH;
              } else {
                delete parts.BYWEEKNO;
              }
            }
            var partCount = Object.keys(parts).length;
            if (partCount == 0) {
              var t1 = this.dtstart.clone();
              t1.year = this.last.year;
              this.days.push(t1.dayOfYear());
            } else if (partCount == 1 && "BYMONTH" in parts) {
              for (var monthkey in this.by_data.BYMONTH) {
                if (!this.by_data.BYMONTH.hasOwnProperty(monthkey)) {
                  continue;
                }
                var t2 = this.dtstart.clone();
                t2.year = aYear;
                t2.month = this.by_data.BYMONTH[monthkey];
                t2.isDate = true;
                this.days.push(t2.dayOfYear());
              }
            } else if (partCount == 1 && "BYMONTHDAY" in parts) {
              for (var monthdaykey in this.by_data.BYMONTHDAY) {
                if (!this.by_data.BYMONTHDAY.hasOwnProperty(monthdaykey)) {
                  continue;
                }
                var t3 = this.dtstart.clone();
                var day_ = this.by_data.BYMONTHDAY[monthdaykey];
                if (day_ < 0) {
                  var daysInMonth = ICAL.Time.daysInMonth(t3.month, aYear);
                  day_ = day_ + daysInMonth + 1;
                }
                t3.day = day_;
                t3.year = aYear;
                t3.isDate = true;
                this.days.push(t3.dayOfYear());
              }
            } else if (partCount == 2 && "BYMONTHDAY" in parts && "BYMONTH" in parts) {
              for (var monthkey in this.by_data.BYMONTH) {
                if (!this.by_data.BYMONTH.hasOwnProperty(monthkey)) {
                  continue;
                }
                var month_ = this.by_data.BYMONTH[monthkey];
                var daysInMonth = ICAL.Time.daysInMonth(month_, aYear);
                for (var monthdaykey in this.by_data.BYMONTHDAY) {
                  if (!this.by_data.BYMONTHDAY.hasOwnProperty(monthdaykey)) {
                    continue;
                  }
                  var day_ = this.by_data.BYMONTHDAY[monthdaykey];
                  if (day_ < 0) {
                    day_ = day_ + daysInMonth + 1;
                  }
                  t.day = day_;
                  t.month = month_;
                  t.year = aYear;
                  t.isDate = true;
                  this.days.push(t.dayOfYear());
                }
              }
            } else if (partCount == 1 && "BYWEEKNO" in parts) {
            } else if (partCount == 2 && "BYWEEKNO" in parts && "BYMONTHDAY" in parts) {
            } else if (partCount == 1 && "BYDAY" in parts) {
              this.days = this.days.concat(this.expand_by_day(aYear));
            } else if (partCount == 2 && "BYDAY" in parts && "BYMONTH" in parts) {
              for (var monthkey in this.by_data.BYMONTH) {
                if (!this.by_data.BYMONTH.hasOwnProperty(monthkey)) {
                  continue;
                }
                var month = this.by_data.BYMONTH[monthkey];
                var daysInMonth = ICAL.Time.daysInMonth(month, aYear);
                t.year = aYear;
                t.month = this.by_data.BYMONTH[monthkey];
                t.day = 1;
                t.isDate = true;
                var first_dow = t.dayOfWeek();
                var doy_offset = t.dayOfYear() - 1;
                t.day = daysInMonth;
                var last_dow = t.dayOfWeek();
                if (this.has_by_data("BYSETPOS")) {
                  var set_pos_counter = 0;
                  var by_month_day = [];
                  for (var day = 1; day <= daysInMonth; day++) {
                    t.day = day;
                    if (this.is_day_in_byday(t)) {
                      by_month_day.push(day);
                    }
                  }
                  for (var spIndex = 0; spIndex < by_month_day.length; spIndex++) {
                    if (this.check_set_position(spIndex + 1) || this.check_set_position(spIndex - by_month_day.length)) {
                      this.days.push(doy_offset + by_month_day[spIndex]);
                    }
                  }
                } else {
                  for (var daycodedkey in this.by_data.BYDAY) {
                    if (!this.by_data.BYDAY.hasOwnProperty(daycodedkey)) {
                      continue;
                    }
                    var coded_day = this.by_data.BYDAY[daycodedkey];
                    var bydayParts = this.ruleDayOfWeek(coded_day);
                    var pos = bydayParts[0];
                    var dow = bydayParts[1];
                    var month_day;
                    var first_matching_day = (dow + 7 - first_dow) % 7 + 1;
                    var last_matching_day = daysInMonth - (last_dow + 7 - dow) % 7;
                    if (pos == 0) {
                      for (var day = first_matching_day; day <= daysInMonth; day += 7) {
                        this.days.push(doy_offset + day);
                      }
                    } else if (pos > 0) {
                      month_day = first_matching_day + (pos - 1) * 7;
                      if (month_day <= daysInMonth) {
                        this.days.push(doy_offset + month_day);
                      }
                    } else {
                      month_day = last_matching_day + (pos + 1) * 7;
                      if (month_day > 0) {
                        this.days.push(doy_offset + month_day);
                      }
                    }
                  }
                }
              }
              this.days.sort(function(a, b) {
                return a - b;
              });
            } else if (partCount == 2 && "BYDAY" in parts && "BYMONTHDAY" in parts) {
              var expandedDays = this.expand_by_day(aYear);
              for (var daykey in expandedDays) {
                if (!expandedDays.hasOwnProperty(daykey)) {
                  continue;
                }
                var day = expandedDays[daykey];
                var tt = ICAL.Time.fromDayOfYear(day, aYear);
                if (this.by_data.BYMONTHDAY.indexOf(tt.day) >= 0) {
                  this.days.push(day);
                }
              }
            } else if (partCount == 3 && "BYDAY" in parts && "BYMONTHDAY" in parts && "BYMONTH" in parts) {
              var expandedDays = this.expand_by_day(aYear);
              for (var daykey in expandedDays) {
                if (!expandedDays.hasOwnProperty(daykey)) {
                  continue;
                }
                var day = expandedDays[daykey];
                var tt = ICAL.Time.fromDayOfYear(day, aYear);
                if (this.by_data.BYMONTH.indexOf(tt.month) >= 0 && this.by_data.BYMONTHDAY.indexOf(tt.day) >= 0) {
                  this.days.push(day);
                }
              }
            } else if (partCount == 2 && "BYDAY" in parts && "BYWEEKNO" in parts) {
              var expandedDays = this.expand_by_day(aYear);
              for (var daykey in expandedDays) {
                if (!expandedDays.hasOwnProperty(daykey)) {
                  continue;
                }
                var day = expandedDays[daykey];
                var tt = ICAL.Time.fromDayOfYear(day, aYear);
                var weekno = tt.weekNumber(this.rule.wkst);
                if (this.by_data.BYWEEKNO.indexOf(weekno)) {
                  this.days.push(day);
                }
              }
            } else if (partCount == 3 && "BYDAY" in parts && "BYWEEKNO" in parts && "BYMONTHDAY" in parts) {
            } else if (partCount == 1 && "BYYEARDAY" in parts) {
              this.days = this.days.concat(this.by_data.BYYEARDAY);
            } else {
              this.days = [];
            }
            return 0;
          },
          expand_by_day: function expand_by_day(aYear) {
            var days_list = [];
            var tmp = this.last.clone();
            tmp.year = aYear;
            tmp.month = 1;
            tmp.day = 1;
            tmp.isDate = true;
            var start_dow = tmp.dayOfWeek();
            tmp.month = 12;
            tmp.day = 31;
            tmp.isDate = true;
            var end_dow = tmp.dayOfWeek();
            var end_year_day = tmp.dayOfYear();
            for (var daykey in this.by_data.BYDAY) {
              if (!this.by_data.BYDAY.hasOwnProperty(daykey)) {
                continue;
              }
              var day = this.by_data.BYDAY[daykey];
              var parts = this.ruleDayOfWeek(day);
              var pos = parts[0];
              var dow = parts[1];
              if (pos == 0) {
                var tmp_start_doy = (dow + 7 - start_dow) % 7 + 1;
                for (var doy = tmp_start_doy; doy <= end_year_day; doy += 7) {
                  days_list.push(doy);
                }
              } else if (pos > 0) {
                var first;
                if (dow >= start_dow) {
                  first = dow - start_dow + 1;
                } else {
                  first = dow - start_dow + 8;
                }
                days_list.push(first + (pos - 1) * 7);
              } else {
                var last3;
                pos = -pos;
                if (dow <= end_dow) {
                  last3 = end_year_day - end_dow + dow;
                } else {
                  last3 = end_year_day - end_dow + dow - 7;
                }
                days_list.push(last3 - (pos - 1) * 7);
              }
            }
            return days_list;
          },
          is_day_in_byday: function is_day_in_byday(tt) {
            for (var daykey in this.by_data.BYDAY) {
              if (!this.by_data.BYDAY.hasOwnProperty(daykey)) {
                continue;
              }
              var day = this.by_data.BYDAY[daykey];
              var parts = this.ruleDayOfWeek(day);
              var pos = parts[0];
              var dow = parts[1];
              var this_dow = tt.dayOfWeek();
              if (pos == 0 && dow == this_dow || tt.nthWeekDay(dow, pos) == tt.day) {
                return 1;
              }
            }
            return 0;
          },
          /**
           * Checks if given value is in BYSETPOS.
           *
           * @private
           * @param {Numeric} aPos position to check for.
           * @return {Boolean} false unless BYSETPOS rules exist
           *                   and the given value is present in rules.
           */
          check_set_position: function check_set_position(aPos) {
            if (this.has_by_data("BYSETPOS")) {
              var idx = this.by_data.BYSETPOS.indexOf(aPos);
              return idx !== -1;
            }
            return false;
          },
          sort_byday_rules: function icalrecur_sort_byday_rules(aRules) {
            for (var i = 0; i < aRules.length; i++) {
              for (var j = 0; j < i; j++) {
                var one = this.ruleDayOfWeek(aRules[j], this.rule.wkst)[1];
                var two = this.ruleDayOfWeek(aRules[i], this.rule.wkst)[1];
                if (one > two) {
                  var tmp = aRules[i];
                  aRules[i] = aRules[j];
                  aRules[j] = tmp;
                }
              }
            }
          },
          check_contract_restriction: function check_contract_restriction(aRuleType, v) {
            var indexMapValue = icalrecur_iterator._indexMap[aRuleType];
            var ruleMapValue = icalrecur_iterator._expandMap[this.rule.freq][indexMapValue];
            var pass = false;
            if (aRuleType in this.by_data && ruleMapValue == icalrecur_iterator.CONTRACT) {
              var ruleType = this.by_data[aRuleType];
              for (var bydatakey in ruleType) {
                if (ruleType.hasOwnProperty(bydatakey)) {
                  if (ruleType[bydatakey] == v) {
                    pass = true;
                    break;
                  }
                }
              }
            } else {
              pass = true;
            }
            return pass;
          },
          check_contracting_rules: function check_contracting_rules() {
            var dow = this.last.dayOfWeek();
            var weekNo = this.last.weekNumber(this.rule.wkst);
            var doy = this.last.dayOfYear();
            return this.check_contract_restriction("BYSECOND", this.last.second) && this.check_contract_restriction("BYMINUTE", this.last.minute) && this.check_contract_restriction("BYHOUR", this.last.hour) && this.check_contract_restriction("BYDAY", ICAL.Recur.numericDayToIcalDay(dow)) && this.check_contract_restriction("BYWEEKNO", weekNo) && this.check_contract_restriction("BYMONTHDAY", this.last.day) && this.check_contract_restriction("BYMONTH", this.last.month) && this.check_contract_restriction("BYYEARDAY", doy);
          },
          setup_defaults: function setup_defaults(aRuleType, req, deftime) {
            var indexMapValue = icalrecur_iterator._indexMap[aRuleType];
            var ruleMapValue = icalrecur_iterator._expandMap[this.rule.freq][indexMapValue];
            if (ruleMapValue != icalrecur_iterator.CONTRACT) {
              if (!(aRuleType in this.by_data)) {
                this.by_data[aRuleType] = [deftime];
              }
              if (this.rule.freq != req) {
                return this.by_data[aRuleType][0];
              }
            }
            return deftime;
          },
          /**
           * Convert iterator into a serialize-able object.  Will preserve current
           * iteration sequence to ensure the seamless continuation of the recurrence
           * rule.
           * @return {Object}
           */
          toJSON: function() {
            var result = /* @__PURE__ */ Object.create(null);
            result.initialized = this.initialized;
            result.rule = this.rule.toJSON();
            result.dtstart = this.dtstart.toJSON();
            result.by_data = this.by_data;
            result.days = this.days;
            result.last = this.last.toJSON();
            result.by_indices = this.by_indices;
            result.occurrence_number = this.occurrence_number;
            return result;
          }
        };
        icalrecur_iterator._indexMap = {
          "BYSECOND": 0,
          "BYMINUTE": 1,
          "BYHOUR": 2,
          "BYDAY": 3,
          "BYMONTHDAY": 4,
          "BYYEARDAY": 5,
          "BYWEEKNO": 6,
          "BYMONTH": 7,
          "BYSETPOS": 8
        };
        icalrecur_iterator._expandMap = {
          "SECONDLY": [1, 1, 1, 1, 1, 1, 1, 1],
          "MINUTELY": [2, 1, 1, 1, 1, 1, 1, 1],
          "HOURLY": [2, 2, 1, 1, 1, 1, 1, 1],
          "DAILY": [2, 2, 2, 1, 1, 1, 1, 1],
          "WEEKLY": [2, 2, 2, 2, 3, 3, 1, 1],
          "MONTHLY": [2, 2, 2, 2, 2, 3, 3, 1],
          "YEARLY": [2, 2, 2, 2, 2, 2, 2, 2]
        };
        icalrecur_iterator.UNKNOWN = 0;
        icalrecur_iterator.CONTRACT = 1;
        icalrecur_iterator.EXPAND = 2;
        icalrecur_iterator.ILLEGAL = 3;
        return icalrecur_iterator;
      })();
      ICAL.RecurExpansion = (function() {
        function formatTime(item) {
          return ICAL.helpers.formatClassType(item, ICAL.Time);
        }
        function compareTime(a, b) {
          return a.compare(b);
        }
        function isRecurringComponent(comp) {
          return comp.hasProperty("rdate") || comp.hasProperty("rrule") || comp.hasProperty("recurrence-id");
        }
        function RecurExpansion(options) {
          this.ruleDates = [];
          this.exDates = [];
          this.fromData(options);
        }
        RecurExpansion.prototype = {
          /**
           * True when iteration is fully completed.
           * @type {Boolean}
           */
          complete: false,
          /**
           * Array of rrule iterators.
           *
           * @type {ICAL.RecurIterator[]}
           * @private
           */
          ruleIterators: null,
          /**
           * Array of rdate instances.
           *
           * @type {ICAL.Time[]}
           * @private
           */
          ruleDates: null,
          /**
           * Array of exdate instances.
           *
           * @type {ICAL.Time[]}
           * @private
           */
          exDates: null,
          /**
           * Current position in ruleDates array.
           * @type {Number}
           * @private
           */
          ruleDateInc: 0,
          /**
           * Current position in exDates array
           * @type {Number}
           * @private
           */
          exDateInc: 0,
          /**
           * Current negative date.
           *
           * @type {ICAL.Time}
           * @private
           */
          exDate: null,
          /**
           * Current additional date.
           *
           * @type {ICAL.Time}
           * @private
           */
          ruleDate: null,
          /**
           * Start date of recurring rules.
           *
           * @type {ICAL.Time}
           */
          dtstart: null,
          /**
           * Last expanded time
           *
           * @type {ICAL.Time}
           */
          last: null,
          /**
           * Initialize the recurrence expansion from the data object. The options
           * object may also contain additional members, see the
           * {@link ICAL.RecurExpansion constructor} for more details.
           *
           * @param {Object} options
           *        Recurrence expansion options
           * @param {ICAL.Time} options.dtstart
           *        Start time of the event
           * @param {ICAL.Component=} options.component
           *        Component for expansion, required if not resuming.
           */
          fromData: function(options) {
            var start = ICAL.helpers.formatClassType(options.dtstart, ICAL.Time);
            if (!start) {
              throw new Error(".dtstart (ICAL.Time) must be given");
            } else {
              this.dtstart = start;
            }
            if (options.component) {
              this._init(options.component);
            } else {
              this.last = formatTime(options.last) || start.clone();
              if (!options.ruleIterators) {
                throw new Error(".ruleIterators or .component must be given");
              }
              this.ruleIterators = options.ruleIterators.map(function(item) {
                return ICAL.helpers.formatClassType(item, ICAL.RecurIterator);
              });
              this.ruleDateInc = options.ruleDateInc;
              this.exDateInc = options.exDateInc;
              if (options.ruleDates) {
                this.ruleDates = options.ruleDates.map(formatTime);
                this.ruleDate = this.ruleDates[this.ruleDateInc];
              }
              if (options.exDates) {
                this.exDates = options.exDates.map(formatTime);
                this.exDate = this.exDates[this.exDateInc];
              }
              if (typeof options.complete !== "undefined") {
                this.complete = options.complete;
              }
            }
          },
          /**
           * Retrieve the next occurrence in the series.
           * @return {ICAL.Time}
           */
          next: function() {
            var iter;
            var ruleOfDay;
            var next;
            var compare;
            var maxTries = 500;
            var currentTry = 0;
            while (true) {
              if (currentTry++ > maxTries) {
                throw new Error(
                  "max tries have occured, rule may be impossible to forfill."
                );
              }
              next = this.ruleDate;
              iter = this._nextRecurrenceIter(this.last);
              if (!next && !iter) {
                this.complete = true;
                break;
              }
              if (!next || iter && next.compare(iter.last) > 0) {
                next = iter.last.clone();
                iter.next();
              }
              if (this.ruleDate === next) {
                this._nextRuleDay();
              }
              this.last = next;
              if (this.exDate) {
                compare = this.exDate.compare(this.last);
                if (compare < 0) {
                  this._nextExDay();
                }
                if (compare === 0) {
                  this._nextExDay();
                  continue;
                }
              }
              return this.last;
            }
          },
          /**
           * Converts object into a serialize-able format. This format can be passed
           * back into the expansion to resume iteration.
           * @return {Object}
           */
          toJSON: function() {
            function toJSON(item) {
              return item.toJSON();
            }
            var result = /* @__PURE__ */ Object.create(null);
            result.ruleIterators = this.ruleIterators.map(toJSON);
            if (this.ruleDates) {
              result.ruleDates = this.ruleDates.map(toJSON);
            }
            if (this.exDates) {
              result.exDates = this.exDates.map(toJSON);
            }
            result.ruleDateInc = this.ruleDateInc;
            result.exDateInc = this.exDateInc;
            result.last = this.last.toJSON();
            result.dtstart = this.dtstart.toJSON();
            result.complete = this.complete;
            return result;
          },
          /**
           * Extract all dates from the properties in the given component. The
           * properties will be filtered by the property name.
           *
           * @private
           * @param {ICAL.Component} component        The component to search in
           * @param {String} propertyName             The property name to search for
           * @return {ICAL.Time[]}                    The extracted dates.
           */
          _extractDates: function(component, propertyName) {
            function handleProp(prop2) {
              idx = ICAL.helpers.binsearchInsert(
                result,
                prop2,
                compareTime
              );
              result.splice(idx, 0, prop2);
            }
            var result = [];
            var props = component.getAllProperties(propertyName);
            var len = props.length;
            var i = 0;
            var prop;
            var idx;
            for (; i < len; i++) {
              props[i].getValues().forEach(handleProp);
            }
            return result;
          },
          /**
           * Initialize the recurrence expansion.
           *
           * @private
           * @param {ICAL.Component} component    The component to initialize from.
           */
          _init: function(component) {
            this.ruleIterators = [];
            this.last = this.dtstart.clone();
            if (!isRecurringComponent(component)) {
              this.ruleDate = this.last.clone();
              this.complete = true;
              return;
            }
            if (component.hasProperty("rdate")) {
              this.ruleDates = this._extractDates(component, "rdate");
              if (this.ruleDates[0] && this.ruleDates[0].compare(this.dtstart) < 0) {
                this.ruleDateInc = 0;
                this.last = this.ruleDates[0].clone();
              } else {
                this.ruleDateInc = ICAL.helpers.binsearchInsert(
                  this.ruleDates,
                  this.last,
                  compareTime
                );
              }
              this.ruleDate = this.ruleDates[this.ruleDateInc];
            }
            if (component.hasProperty("rrule")) {
              var rules = component.getAllProperties("rrule");
              var i = 0;
              var len = rules.length;
              var rule;
              var iter;
              for (; i < len; i++) {
                rule = rules[i].getFirstValue();
                iter = rule.iterator(this.dtstart);
                this.ruleIterators.push(iter);
                iter.next();
              }
            }
            if (component.hasProperty("exdate")) {
              this.exDates = this._extractDates(component, "exdate");
              this.exDateInc = ICAL.helpers.binsearchInsert(
                this.exDates,
                this.last,
                compareTime
              );
              this.exDate = this.exDates[this.exDateInc];
            }
          },
          /**
           * Advance to the next exdate
           * @private
           */
          _nextExDay: function() {
            this.exDate = this.exDates[++this.exDateInc];
          },
          /**
           * Advance to the next rule date
           * @private
           */
          _nextRuleDay: function() {
            this.ruleDate = this.ruleDates[++this.ruleDateInc];
          },
          /**
           * Find and return the recurrence rule with the most recent event and
           * return it.
           *
           * @private
           * @return {?ICAL.RecurIterator}    Found iterator.
           */
          _nextRecurrenceIter: function() {
            var iters = this.ruleIterators;
            if (iters.length === 0) {
              return null;
            }
            var len = iters.length;
            var iter;
            var iterTime;
            var iterIdx = 0;
            var chosenIter;
            for (; iterIdx < len; iterIdx++) {
              iter = iters[iterIdx];
              iterTime = iter.last;
              if (iter.completed) {
                len--;
                if (iterIdx !== 0) {
                  iterIdx--;
                }
                iters.splice(iterIdx, 1);
                continue;
              }
              if (!chosenIter || chosenIter.last.compare(iterTime) > 0) {
                chosenIter = iter;
              }
            }
            return chosenIter;
          }
        };
        return RecurExpansion;
      })();
      ICAL.Event = (function() {
        function Event(component, options) {
          if (!(component instanceof ICAL.Component)) {
            options = component;
            component = null;
          }
          if (component) {
            this.component = component;
          } else {
            this.component = new ICAL.Component("vevent");
          }
          this._rangeExceptionCache = /* @__PURE__ */ Object.create(null);
          this.exceptions = /* @__PURE__ */ Object.create(null);
          this.rangeExceptions = [];
          if (options && options.strictExceptions) {
            this.strictExceptions = options.strictExceptions;
          }
          if (options && options.exceptions) {
            options.exceptions.forEach(this.relateException, this);
          } else if (this.component.parent && !this.isRecurrenceException()) {
            this.component.parent.getAllSubcomponents("vevent").forEach(function(event) {
              if (event.hasProperty("recurrence-id")) {
                this.relateException(event);
              }
            }, this);
          }
        }
        Event.prototype = {
          THISANDFUTURE: "THISANDFUTURE",
          /**
           * List of related event exceptions.
           *
           * @type {ICAL.Event[]}
           */
          exceptions: null,
          /**
           * When true, will verify exceptions are related by their UUID.
           *
           * @type {Boolean}
           */
          strictExceptions: false,
          /**
           * Relates a given event exception to this object.  If the given component
           * does not share the UID of this event it cannot be related and will throw
           * an exception.
           *
           * If this component is an exception it cannot have other exceptions
           * related to it.
           *
           * @param {ICAL.Component|ICAL.Event} obj       Component or event
           */
          relateException: function(obj) {
            if (this.isRecurrenceException()) {
              throw new Error("cannot relate exception to exceptions");
            }
            if (obj instanceof ICAL.Component) {
              obj = new ICAL.Event(obj);
            }
            if (this.strictExceptions && obj.uid !== this.uid) {
              throw new Error("attempted to relate unrelated exception");
            }
            var id = obj.recurrenceId.toString();
            this.exceptions[id] = obj;
            if (obj.modifiesFuture()) {
              var item = [
                obj.recurrenceId.toUnixTime(),
                id
              ];
              var idx = ICAL.helpers.binsearchInsert(
                this.rangeExceptions,
                item,
                compareRangeException
              );
              this.rangeExceptions.splice(idx, 0, item);
            }
          },
          /**
           * Checks if this record is an exception and has the RANGE=THISANDFUTURE
           * value.
           *
           * @return {Boolean}        True, when exception is within range
           */
          modifiesFuture: function() {
            if (!this.component.hasProperty("recurrence-id")) {
              return false;
            }
            var range = this.component.getFirstProperty("recurrence-id").getParameter("range");
            return range === this.THISANDFUTURE;
          },
          /**
           * Finds the range exception nearest to the given date.
           *
           * @param {ICAL.Time} time usually an occurrence time of an event
           * @return {?ICAL.Event} the related event/exception or null
           */
          findRangeException: function(time) {
            if (!this.rangeExceptions.length) {
              return null;
            }
            var utc = time.toUnixTime();
            var idx = ICAL.helpers.binsearchInsert(
              this.rangeExceptions,
              [utc],
              compareRangeException
            );
            idx -= 1;
            if (idx < 0) {
              return null;
            }
            var rangeItem = this.rangeExceptions[idx];
            if (utc < rangeItem[0]) {
              return null;
            }
            return rangeItem[1];
          },
          /**
           * This object is returned by {@link ICAL.Event#getOccurrenceDetails getOccurrenceDetails}
           *
           * @typedef {Object} occurrenceDetails
           * @memberof ICAL.Event
           * @property {ICAL.Time} recurrenceId       The passed in recurrence id
           * @property {ICAL.Event} item              The occurrence
           * @property {ICAL.Time} startDate          The start of the occurrence
           * @property {ICAL.Time} endDate            The end of the occurrence
           */
          /**
           * Returns the occurrence details based on its start time.  If the
           * occurrence has an exception will return the details for that exception.
           *
           * NOTE: this method is intend to be used in conjunction
           *       with the {@link ICAL.Event#iterator iterator} method.
           *
           * @param {ICAL.Time} occurrence time occurrence
           * @return {ICAL.Event.occurrenceDetails} Information about the occurrence
           */
          getOccurrenceDetails: function(occurrence) {
            var id = occurrence.toString();
            var utcId = occurrence.convertToZone(ICAL.Timezone.utcTimezone).toString();
            var item;
            var result = {
              //XXX: Clone?
              recurrenceId: occurrence
            };
            if (id in this.exceptions) {
              item = result.item = this.exceptions[id];
              result.startDate = item.startDate;
              result.endDate = item.endDate;
              result.item = item;
            } else if (utcId in this.exceptions) {
              item = this.exceptions[utcId];
              result.startDate = item.startDate;
              result.endDate = item.endDate;
              result.item = item;
            } else {
              var rangeExceptionId = this.findRangeException(
                occurrence
              );
              var end;
              if (rangeExceptionId) {
                var exception = this.exceptions[rangeExceptionId];
                result.item = exception;
                var startDiff = this._rangeExceptionCache[rangeExceptionId];
                if (!startDiff) {
                  var original = exception.recurrenceId.clone();
                  var newStart = exception.startDate.clone();
                  original.zone = newStart.zone;
                  startDiff = newStart.subtractDate(original);
                  this._rangeExceptionCache[rangeExceptionId] = startDiff;
                }
                var start = occurrence.clone();
                start.zone = exception.startDate.zone;
                start.addDuration(startDiff);
                end = start.clone();
                end.addDuration(exception.duration);
                result.startDate = start;
                result.endDate = end;
              } else {
                end = occurrence.clone();
                end.addDuration(this.duration);
                result.endDate = end;
                result.startDate = occurrence;
                result.item = this;
              }
            }
            return result;
          },
          /**
           * Builds a recur expansion instance for a specific point in time (defaults
           * to startDate).
           *
           * @param {ICAL.Time} startTime     Starting point for expansion
           * @return {ICAL.RecurExpansion}    Expansion object
           */
          iterator: function(startTime) {
            return new ICAL.RecurExpansion({
              component: this.component,
              dtstart: startTime || this.startDate
            });
          },
          /**
           * Checks if the event is recurring
           *
           * @return {Boolean}        True, if event is recurring
           */
          isRecurring: function() {
            var comp = this.component;
            return comp.hasProperty("rrule") || comp.hasProperty("rdate");
          },
          /**
           * Checks if the event describes a recurrence exception. See
           * {@tutorial terminology} for details.
           *
           * @return {Boolean}    True, if the event describes a recurrence exception
           */
          isRecurrenceException: function() {
            return this.component.hasProperty("recurrence-id");
          },
          /**
           * Returns the types of recurrences this event may have.
           *
           * Returned as an object with the following possible keys:
           *
           *    - YEARLY
           *    - MONTHLY
           *    - WEEKLY
           *    - DAILY
           *    - MINUTELY
           *    - SECONDLY
           *
           * @return {Object.<ICAL.Recur.frequencyValues, Boolean>}
           *          Object of recurrence flags
           */
          getRecurrenceTypes: function() {
            var rules = this.component.getAllProperties("rrule");
            var i = 0;
            var len = rules.length;
            var result = /* @__PURE__ */ Object.create(null);
            for (; i < len; i++) {
              var value = rules[i].getFirstValue();
              result[value.freq] = true;
            }
            return result;
          },
          /**
           * The uid of this event
           * @type {String}
           */
          get uid() {
            return this._firstProp("uid");
          },
          set uid(value) {
            this._setProp("uid", value);
          },
          /**
           * The start date
           * @type {ICAL.Time}
           */
          get startDate() {
            return this._firstProp("dtstart");
          },
          set startDate(value) {
            this._setTime("dtstart", value);
          },
          /**
           * The end date. This can be the result directly from the property, or the
           * end date calculated from start date and duration. Setting the property
           * will remove any duration properties.
           * @type {ICAL.Time}
           */
          get endDate() {
            var endDate = this._firstProp("dtend");
            if (!endDate) {
              var duration = this._firstProp("duration");
              endDate = this.startDate.clone();
              if (duration) {
                endDate.addDuration(duration);
              } else if (endDate.isDate) {
                endDate.day += 1;
              }
            }
            return endDate;
          },
          set endDate(value) {
            if (this.component.hasProperty("duration")) {
              this.component.removeProperty("duration");
            }
            this._setTime("dtend", value);
          },
          /**
           * The duration. This can be the result directly from the property, or the
           * duration calculated from start date and end date. Setting the property
           * will remove any `dtend` properties.
           * @type {ICAL.Duration}
           */
          get duration() {
            var duration = this._firstProp("duration");
            if (!duration) {
              return this.endDate.subtractDateTz(this.startDate);
            }
            return duration;
          },
          set duration(value) {
            if (this.component.hasProperty("dtend")) {
              this.component.removeProperty("dtend");
            }
            this._setProp("duration", value);
          },
          /**
           * The location of the event.
           * @type {String}
           */
          get location() {
            return this._firstProp("location");
          },
          set location(value) {
            return this._setProp("location", value);
          },
          /**
           * The attendees in the event
           * @type {ICAL.Property[]}
           * @readonly
           */
          get attendees() {
            return this.component.getAllProperties("attendee");
          },
          /**
           * The event summary
           * @type {String}
           */
          get summary() {
            return this._firstProp("summary");
          },
          set summary(value) {
            this._setProp("summary", value);
          },
          /**
           * The event description.
           * @type {String}
           */
          get description() {
            return this._firstProp("description");
          },
          set description(value) {
            this._setProp("description", value);
          },
          /**
           * The event color from [rfc7986](https://datatracker.ietf.org/doc/html/rfc7986)
           * @type {String}
           */
          get color() {
            return this._firstProp("color");
          },
          set color(value) {
            this._setProp("color", value);
          },
          /**
           * The organizer value as an uri. In most cases this is a mailto: uri, but
           * it can also be something else, like urn:uuid:...
           * @type {String}
           */
          get organizer() {
            return this._firstProp("organizer");
          },
          set organizer(value) {
            this._setProp("organizer", value);
          },
          /**
           * The sequence value for this event. Used for scheduling
           * see {@tutorial terminology}.
           * @type {Number}
           */
          get sequence() {
            return this._firstProp("sequence");
          },
          set sequence(value) {
            this._setProp("sequence", value);
          },
          /**
           * The recurrence id for this event. See {@tutorial terminology} for details.
           * @type {ICAL.Time}
           */
          get recurrenceId() {
            return this._firstProp("recurrence-id");
          },
          set recurrenceId(value) {
            this._setTime("recurrence-id", value);
          },
          /**
           * Set/update a time property's value.
           * This will also update the TZID of the property.
           *
           * TODO: this method handles the case where we are switching
           * from a known timezone to an implied timezone (one without TZID).
           * This does _not_ handle the case of moving between a known
           *  (by TimezoneService) timezone to an unknown timezone...
           *
           * We will not add/remove/update the VTIMEZONE subcomponents
           *  leading to invalid ICAL data...
           * @private
           * @param {String} propName     The property name
           * @param {ICAL.Time} time      The time to set
           */
          _setTime: function(propName, time) {
            var prop = this.component.getFirstProperty(propName);
            if (!prop) {
              prop = new ICAL.Property(propName);
              this.component.addProperty(prop);
            }
            if (time.zone === ICAL.Timezone.localTimezone || time.zone === ICAL.Timezone.utcTimezone) {
              prop.removeParameter("tzid");
            } else {
              prop.setParameter("tzid", time.zone.tzid);
            }
            prop.setValue(time);
          },
          _setProp: function(name, value) {
            this.component.updatePropertyWithValue(name, value);
          },
          _firstProp: function(name) {
            return this.component.getFirstPropertyValue(name);
          },
          /**
           * The string representation of this event.
           * @return {String}
           */
          toString: function() {
            return this.component.toString();
          }
        };
        function compareRangeException(a, b) {
          if (a[0] > b[0]) return 1;
          if (b[0] > a[0]) return -1;
          return 0;
        }
        return Event;
      })();
      ICAL.ComponentParser = (function() {
        function ComponentParser(options) {
          if (typeof options === "undefined") {
            options = {};
          }
          var key;
          for (key in options) {
            if (options.hasOwnProperty(key)) {
              this[key] = options[key];
            }
          }
        }
        ComponentParser.prototype = {
          /**
           * When true, parse events
           *
           * @type {Boolean}
           */
          parseEvent: true,
          /**
           * When true, parse timezones
           *
           * @type {Boolean}
           */
          parseTimezone: true,
          /* SAX like events here for reference */
          /**
           * Fired when parsing is complete
           * @callback
           */
          oncomplete: (
            /* istanbul ignore next */
            function() {
            }
          ),
          /**
           * Fired if an error occurs during parsing.
           *
           * @callback
           * @param {Error} err details of error
           */
          onerror: (
            /* istanbul ignore next */
            function(err2) {
            }
          ),
          /**
           * Fired when a top level component (VTIMEZONE) is found
           *
           * @callback
           * @param {ICAL.Timezone} component     Timezone object
           */
          ontimezone: (
            /* istanbul ignore next */
            function(component) {
            }
          ),
          /**
           * Fired when a top level component (VEVENT) is found.
           *
           * @callback
           * @param {ICAL.Event} component    Top level component
           */
          onevent: (
            /* istanbul ignore next */
            function(component) {
            }
          ),
          /**
           * Process a string or parse ical object.  This function itself will return
           * nothing but will start the parsing process.
           *
           * Events must be registered prior to calling this method.
           *
           * @param {ICAL.Component|String|Object} ical      The component to process,
           *        either in its final form, as a jCal Object, or string representation
           */
          process: function(ical) {
            if (typeof ical === "string") {
              ical = ICAL.parse(ical);
            }
            if (!(ical instanceof ICAL.Component)) {
              ical = new ICAL.Component(ical);
            }
            var components = ical.getAllSubcomponents();
            var i = 0;
            var len = components.length;
            var component;
            for (; i < len; i++) {
              component = components[i];
              switch (component.name) {
                case "vtimezone":
                  if (this.parseTimezone) {
                    var tzid = component.getFirstPropertyValue("tzid");
                    if (tzid) {
                      this.ontimezone(new ICAL.Timezone({
                        tzid,
                        component
                      }));
                    }
                  }
                  break;
                case "vevent":
                  if (this.parseEvent) {
                    this.onevent(new ICAL.Event(component));
                  }
                  break;
                default:
                  continue;
              }
            }
            this.oncomplete();
          }
        };
        return ComponentParser;
      })();
    }
  });

  // node_modules/ical-expander/zones-compiled.json
  var require_zones_compiled = __commonJS({
    "node_modules/ical-expander/zones-compiled.json"(exports, module) {
      module.exports = { "Africa/Abidjan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Accra": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Addis_Ababa": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Algiers": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Asmara": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Bamako": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Bangui": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Banjul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Bissau": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Blantyre": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Brazzaville": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Bujumbura": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Cairo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Casablanca": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20180325T020000\r\nRDATE:20180325T020000\r\nRDATE:20180617T020000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20180513T030000\r\nRDATE:20180513T030000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20190609T020000\r\nRDATE:20190609T020000\r\nRDATE:20200531T020000\r\nRDATE:20210516T020000\r\nRDATE:20220508T020000\r\nRDATE:20230430T020000\r\nRDATE:20240414T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20181028T030000\r\nRDATE:20181028T030000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20190505T030000\r\nRDATE:20190505T030000\r\nRDATE:20200419T030000\r\nRDATE:20210411T030000\r\nRDATE:20220327T030000\r\nRDATE:20230319T030000\r\nRDATE:20240310T030000\r\nEND:DAYLIGHT", "Africa/Ceuta": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Africa/Conakry": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Dakar": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Dar_es_Salaam": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Djibouti": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Douala": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/El_Aaiun": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20180325T020000\r\nRDATE:20180325T020000\r\nRDATE:20180617T020000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20180513T030000\r\nRDATE:20180513T030000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20181028T030000\r\nRDATE:20181028T030000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20190505T030000\r\nRDATE:20190505T030000\r\nRDATE:20200419T030000\r\nRDATE:20210411T030000\r\nRDATE:20220327T030000\r\nRDATE:20230319T030000\r\nRDATE:20240310T030000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20190609T020000\r\nRDATE:20190609T020000\r\nRDATE:20200531T020000\r\nRDATE:20210516T020000\r\nRDATE:20220508T020000\r\nRDATE:20230430T020000\r\nRDATE:20240414T020000\r\nEND:STANDARD", "Africa/Freetown": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Gaborone": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Harare": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Johannesburg": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:SAST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Juba": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Kampala": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Khartoum": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Kigali": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Kinshasa": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Lagos": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Libreville": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Lome": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Luanda": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Lubumbashi": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Lusaka": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Malabo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Maputo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Maseru": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:SAST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Mbabane": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:SAST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Mogadishu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Monrovia": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Nairobi": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Ndjamena": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Niamey": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Nouakchott": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Ouagadougou": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Porto-Novo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Sao_Tome": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:20180101T010000\r\nRDATE:20180101T010000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:20190101T020000\r\nRDATE:20190101T020000\r\nEND:STANDARD", "Africa/Tripoli": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Tunis": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Windhoek": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Adak": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-0900\r\nTZNAME:HDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-1000\r\nTZNAME:HST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Anchorage": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Anguilla": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Antigua": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Araguaina": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Buenos_Aires": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Catamarca": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Cordoba": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Jujuy": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/La_Rioja": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Mendoza": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Rio_Gallegos": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Salta": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/San_Juan": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/San_Luis": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Tucuman": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Argentina/Ushuaia": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Aruba": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Asuncion": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19701004T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700322T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=4SU\r\nEND:STANDARD", "America/Atikokan": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Bahia": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Bahia_Banderas": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT", "America/Barbados": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Belem": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Belize": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Blanc-Sablon": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Boa_Vista": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Bogota": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Boise": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Cambridge_Bay": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Campo_Grande": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20181104T000000\r\nRDATE:20181104T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20180218T000000\r\nRDATE:20180218T000000\r\nRDATE:20190217T000000\r\nEND:STANDARD", "America/Cancun": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Caracas": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Cayenne": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Cayman": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Chicago": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Chihuahua": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Costa_Rica": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Creston": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Cuiaba": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20181104T000000\r\nRDATE:20181104T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20180218T000000\r\nRDATE:20180218T000000\r\nRDATE:20190217T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Curacao": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Danmarkshavn": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Dawson": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:20180311T020000\r\nRDATE:20180311T020000\r\nRDATE:20190310T020000\r\nRDATE:20200308T020000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:20181104T020000\r\nRDATE:20181104T020000\r\nRDATE:20191103T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:20201101T000000\r\nRDATE:20201101T000000\r\nEND:STANDARD", "America/Dawson_Creek": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Denver": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Detroit": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Dominica": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Edmonton": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Eirunepe": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/El_Salvador": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Fort_Nelson": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Fortaleza": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Glace_Bay": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Goose_Bay": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "America/Grand_Turk": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:20181104T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:20190310T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:20180311T020000\r\nRDATE:20180311T020000\r\nEND:DAYLIGHT", "America/Grenada": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Guadeloupe": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Guatemala": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Guayaquil": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Guyana": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Halifax": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Havana": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:CST\r\nDTSTART:19701101T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:CDT\r\nDTSTART:19700308T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "America/Hermosillo": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Indiana/Indianapolis": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Knox": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Marengo": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Petersburg": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Tell_City": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Vevay": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Vincennes": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Indiana/Winamac": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "America/Inuvik": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Iqaluit": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Jamaica": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Juneau": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Kentucky/Louisville": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Kentucky/Monticello": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Kralendijk": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/La_Paz": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Lima": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Los_Angeles": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Lower_Princes": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Maceio": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Managua": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Manaus": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Marigot": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Martinique": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Matamoros": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Mazatlan": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Menominee": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Merida": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Metlakatla": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:20191103T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:20181104T020000\r\nRDATE:20181104T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:20190120T020000\r\nRDATE:20190120T020000\r\nEND:STANDARD", "America/Mexico_City": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Miquelon": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Moncton": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Monterrey": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Montevideo": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Montserrat": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Nassau": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/New_York": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Nipigon": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Nome": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Noronha": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/North_Dakota/Beulah": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/North_Dakota/Center": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/North_Dakota/New_Salem": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Nuuk": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700328T220000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19701024T230000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:STANDARD", "America/Ojinaga": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Panama": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Pangnirtung": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Paramaribo": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Phoenix": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Port-au-Prince": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Port_of_Spain": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Porto_Velho": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Puerto_Rico": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Punta_Arenas": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Rainy_River": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Rankin_Inlet": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Recife": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Regina": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Resolute": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "America/Rio_Branco": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Santarem": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Santiago": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20190407T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYMONTHDAY=2,3,4,5,6,7,8;BYDAY=SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20190908T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYMONTHDAY=2,3,4,5,6,7,8;BYDAY=SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20180812T000000\r\nRDATE:20180812T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20180513T000000\r\nRDATE:20180513T000000\r\nEND:STANDARD", "America/Santo_Domingo": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Sao_Paulo": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:20181104T000000\r\nRDATE:20181104T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20180218T000000\r\nRDATE:20180218T000000\r\nRDATE:20190217T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700101T000000\r\nEND:DAYLIGHT", "America/Scoresbysund": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700329T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:-0100\r\nTZNAME:-01\r\nDTSTART:19701025T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "America/Sitka": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/St_Barthelemy": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/St_Johns": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0230\r\nTZOFFSETTO:-0330\r\nTZNAME:NST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0330\r\nTZOFFSETTO:-0230\r\nTZNAME:NDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "America/St_Kitts": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/St_Lucia": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/St_Thomas": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/St_Vincent": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Swift_Current": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Tegucigalpa": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Thule": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Thunder_Bay": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Tijuana": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Toronto": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Tortola": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Vancouver": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Whitehorse": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:20180311T020000\r\nRDATE:20180311T020000\r\nRDATE:20190310T020000\r\nRDATE:20200308T020000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:20181104T020000\r\nRDATE:20181104T020000\r\nRDATE:20191103T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:20201101T000000\r\nRDATE:20201101T000000\r\nEND:STANDARD", "America/Winnipeg": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Yakutat": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Yellowknife": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Antarctica/Casey": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:20181007T040000\r\nRDATE:20181007T040000\r\nRDATE:20191004T030000\r\nRDATE:20201004T000100\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:20180311T040000\r\nRDATE:20180311T040000\r\nRDATE:20190317T030000\r\nRDATE:20200308T030000\r\nEND:STANDARD", "Antarctica/Davis": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/DumontDUrville": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/Macquarie": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Antarctica/Mawson": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/McMurdo": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:NZDT\r\nDTSTART:19700927T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1200\r\nTZNAME:NZST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Antarctica/Palmer": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/Rothera": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/Syowa": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Antarctica/Troll": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0200\r\nTZNAME:+02\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Antarctica/Vostok": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Arctic/Longyearbyen": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Asia/Aden": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Almaty": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Amman": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700326T235959\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1TH\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701030T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1FR\r\nEND:STANDARD", "Asia/Anadyr": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Aqtau": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Aqtobe": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Ashgabat": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Atyrau": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Baghdad": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Bahrain": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Baku": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Bangkok": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Barnaul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Beirut": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Asia/Bishkek": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Brunei": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Chita": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Choibalsan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Colombo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0530\r\nTZOFFSETTO:+0530\r\nTZNAME:+0530\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Damascus": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701030T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1FR\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700327T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1FR\r\nEND:DAYLIGHT", "Asia/Dhaka": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Dili": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Dubai": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Dushanbe": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Famagusta": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:20180325T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT", "Asia/Gaza": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:20200328T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:20201024T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:20180324T010000\r\nRDATE:20180324T010000\r\nRDATE:20190329T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:20181027T010000\r\nRDATE:20181027T010000\r\nRDATE:20191026T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Hebron": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:20200328T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:20201024T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:20180324T010000\r\nRDATE:20180324T010000\r\nRDATE:20190329T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:20181027T010000\r\nRDATE:20181027T010000\r\nRDATE:20191026T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Ho_Chi_Minh": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Hong_Kong": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:HKT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Hovd": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Irkutsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Istanbul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Jakarta": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:WIB\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Jayapura": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:WIT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Jerusalem": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:IDT\r\nDTSTART:19700327T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=23,24,25,26,27,28,29;BYDAY=FR\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:IST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Asia/Kabul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0430\r\nTZOFFSETTO:+0430\r\nTZNAME:+0430\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kamchatka": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Karachi": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:PKT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kathmandu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0545\r\nTZOFFSETTO:+0545\r\nTZNAME:+0545\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Khandyga": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kolkata": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0530\r\nTZOFFSETTO:+0530\r\nTZNAME:IST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Krasnoyarsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kuala_Lumpur": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kuching": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Kuwait": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Macau": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Magadan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Makassar": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:WITA\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Manila": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:PST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Muscat": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Nicosia": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT", "Asia/Novokuznetsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Novosibirsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Omsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Oral": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Phnom_Penh": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Pontianak": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:WIB\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Pyongyang": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0830\r\nTZNAME:KST\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0830\r\nTZOFFSETTO:+0900\r\nTZNAME:KST\r\nDTSTART:20180504T233000\r\nRDATE:20180504T233000\r\nEND:STANDARD", "Asia/Qatar": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Qostanay": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Qyzylorda": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:20181221T000000\r\nRDATE:20181221T000000\r\nEND:STANDARD", "Asia/Riyadh": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Sakhalin": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Samarkand": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Seoul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:KST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Shanghai": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Singapore": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Srednekolymsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Taipei": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Tashkent": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Tbilisi": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Tehran": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0330\r\nTZNAME:+0330\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0330\r\nTZOFFSETTO:+0430\r\nTZNAME:+0430\r\nDTSTART:20180321T235959\r\nRDATE:20180321T235959\r\nRDATE:20190321T235959\r\nRDATE:20200320T235959\r\nRDATE:20210321T235959\r\nRDATE:20220321T235959\r\nRDATE:20230321T235959\r\nRDATE:20240320T235959\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0430\r\nTZOFFSETTO:+0330\r\nTZNAME:+0330\r\nDTSTART:20180921T235959\r\nRDATE:20180921T235959\r\nRDATE:20190921T235959\r\nRDATE:20200920T235959\r\nRDATE:20210921T235959\r\nRDATE:20220921T235959\r\nRDATE:20230921T235959\r\nRDATE:20240920T235959\r\nEND:STANDARD", "Asia/Thimphu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Tokyo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:JST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Tomsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Ulaanbaatar": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Urumqi": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Ust-Nera": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Vientiane": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Vladivostok": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Yakutsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Yangon": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0630\r\nTZOFFSETTO:+0630\r\nTZNAME:+0630\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Yekaterinburg": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Yerevan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic/Azores": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700329T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:-0100\r\nTZNAME:-01\r\nDTSTART:19701025T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Atlantic/Bermuda": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Atlantic/Canary": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WEST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:WET\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Atlantic/Cape_Verde": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:-0100\r\nTZNAME:-01\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic/Faroe": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WEST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:WET\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Atlantic/Madeira": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WEST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:WET\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Atlantic/Reykjavik": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic/South_Georgia": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic/St_Helena": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic/Stanley": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Adelaide": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1030\r\nTZOFFSETTO:+0930\r\nTZNAME:ACST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0930\r\nTZOFFSETTO:+1030\r\nTZNAME:ACDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Australia/Brisbane": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Broken_Hill": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1030\r\nTZOFFSETTO:+0930\r\nTZNAME:ACST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0930\r\nTZOFFSETTO:+1030\r\nTZNAME:ACDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Australia/Currie": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Australia/Darwin": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0930\r\nTZOFFSETTO:+0930\r\nTZNAME:ACST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Eucla": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0845\r\nTZOFFSETTO:+0845\r\nTZNAME:+0845\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Hobart": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Australia/Lindeman": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Lord_Howe": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1030\r\nTZNAME:+1030\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1030\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Australia/Melbourne": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Australia/Perth": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:AWST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Australia/Sydney": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Europe/Amsterdam": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Andorra": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Astrakhan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Athens": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Belgrade": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Berlin": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Bratislava": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Brussels": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Bucharest": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Budapest": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Busingen": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Chisinau": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Copenhagen": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Dublin": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:IST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:DAYLIGHT", "Europe/Gibraltar": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Guernsey": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Helsinki": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Isle_of_Man": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Istanbul": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Jersey": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Kaliningrad": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Kiev": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Kirov": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Lisbon": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:WET\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WEST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT", "Europe/Ljubljana": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/London": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Luxembourg": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Madrid": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Malta": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Mariehamn": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Minsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Monaco": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Moscow": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:MSK\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Nicosia": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT", "Europe/Oslo": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Paris": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Podgorica": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Prague": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Riga": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Rome": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Samara": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/San_Marino": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Sarajevo": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Saratov": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Simferopol": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:MSK\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Skopje": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Sofia": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Stockholm": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Tallinn": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Tirane": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Ulyanovsk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Uzhgorod": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Vaduz": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Vatican": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Vienna": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Vilnius": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Volgograd": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:20181028T020000\r\nRDATE:20181028T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Warsaw": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Zagreb": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Zaporozhye": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Europe/Zurich": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Indian/Antananarivo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Chagos": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Christmas": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Cocos": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0630\r\nTZOFFSETTO:+0630\r\nTZNAME:+0630\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Comoro": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Kerguelen": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Mahe": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Maldives": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Mauritius": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Mayotte": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Indian/Reunion": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Apia": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1400\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700405T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1400\r\nTZNAME:+14\r\nDTSTART:19700927T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT", "Pacific/Auckland": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:NZDT\r\nDTSTART:19700927T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1200\r\nTZNAME:NZST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Pacific/Bougainville": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Chatham": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1245\r\nTZOFFSETTO:+1345\r\nTZNAME:+1345\r\nDTSTART:19700927T024500\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1345\r\nTZOFFSETTO:+1245\r\nTZNAME:+1245\r\nDTSTART:19700405T034500\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Pacific/Chuuk": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Easter": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:-06\r\nDTSTART:20190406T220000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SA\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:20190907T220000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=1SA\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:-06\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:20180811T220000\r\nRDATE:20180811T220000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:-06\r\nDTSTART:20180512T220000\r\nRDATE:20180512T220000\r\nEND:STANDARD", "Pacific/Efate": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Enderbury": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Fakaofo": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Fiji": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700118T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=1;BYMONTHDAY=12,13,14,15,16,17,18;BYDAY=SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:20211114T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:20181104T020000\r\nRDATE:20181104T020000\r\nRDATE:20191110T020000\r\nRDATE:20201220T020000\r\nEND:DAYLIGHT", "Pacific/Funafuti": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Galapagos": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:-06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Gambier": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0900\r\nTZNAME:-09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Guadalcanal": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Guam": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:ChST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Honolulu": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-1000\r\nTZNAME:HST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Kiritimati": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1400\r\nTZOFFSETTO:+1400\r\nTZNAME:+14\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Kosrae": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Kwajalein": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Majuro": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Marquesas": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0930\r\nTZOFFSETTO:-0930\r\nTZNAME:-0930\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Midway": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1100\r\nTZOFFSETTO:-1100\r\nTZNAME:SST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Nauru": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Niue": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1100\r\nTZOFFSETTO:-1100\r\nTZNAME:-11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Norfolk": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:20191006T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:20200405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1130\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:20190701T000000\r\nRDATE:20190701T000000\r\nEND:STANDARD", "Pacific/Noumea": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Pago_Pago": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1100\r\nTZOFFSETTO:-1100\r\nTZNAME:SST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Palau": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Pitcairn": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0800\r\nTZNAME:-08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Pohnpei": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Port_Moresby": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Rarotonga": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-1000\r\nTZNAME:-10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Saipan": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:ChST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Tahiti": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-1000\r\nTZNAME:-10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Tarawa": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Tongatapu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Wake": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific/Wallis": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "AUS Central Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0930\r\nTZOFFSETTO:+0930\r\nTZNAME:ACST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "AUS Eastern Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Afghanistan Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0430\r\nTZOFFSETTO:+0430\r\nTZNAME:+0430\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Asmera": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Africa/Timbuktu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Alaskan Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0900\r\nTZOFFSETTO:-0800\r\nTZNAME:AKDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0900\r\nTZNAME:AKST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Argentina/ComodRivadavia": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Buenos_Aires": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "America/Godthab": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700328T220000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19701024T230000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYMONTHDAY=24,25,26,27,28,29,30;BYDAY=SA\r\nEND:STANDARD", "America/Louisville": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Montreal": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "America/Santa_Isabel": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Arab Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Arabian Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Arabic Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Argentina Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Calcutta": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0530\r\nTZOFFSETTO:+0530\r\nTZNAME:IST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Katmandu": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0545\r\nTZOFFSETTO:+0545\r\nTZNAME:+0545\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Rangoon": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0630\r\nTZOFFSETTO:+0630\r\nTZNAME:+0630\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Asia/Saigon": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Atlantic Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:ADT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:AST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Atlantic/Faeroe": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:WEST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:WET\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Atlantic/Jan_Mayen": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Azerbaijan Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Azores Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700329T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:-0100\r\nTZNAME:-01\r\nDTSTART:19701025T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Bahia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Bangladesh Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Belarus Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Canada Central Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Cape Verde Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0100\r\nTZOFFSETTO:-0100\r\nTZNAME:-01\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Caucasus Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Cen. Australia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1030\r\nTZOFFSETTO:+0930\r\nTZNAME:ACST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0930\r\nTZOFFSETTO:+1030\r\nTZNAME:ACDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT", "Central America Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Central Asia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0600\r\nTZOFFSETTO:+0600\r\nTZNAME:+06\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Central Brazilian Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20181104T000000\r\nRDATE:20181104T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20180218T000000\r\nRDATE:20180218T000000\r\nRDATE:20190217T000000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Central Europe Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Central European Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Central Pacific Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Central Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Central Standard Time (Mexico)": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "China Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "E. Africa Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:EAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "E. Australia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "E. South America Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:20181104T000000\r\nRDATE:20181104T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20180218T000000\r\nRDATE:20180218T000000\r\nRDATE:20190217T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0200\r\nTZOFFSETTO:-0200\r\nTZNAME:-02\r\nDTSTART:19700101T000000\r\nEND:DAYLIGHT", "Eastern Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Egypt Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Ekaterinburg Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Europe/Belfast": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "FLE Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Fiji Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700118T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=1;BYMONTHDAY=12,13,14,15,16,17,18;BYDAY=SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:20211114T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:20181104T020000\r\nRDATE:20181104T020000\r\nRDATE:20191110T020000\r\nRDATE:20201220T020000\r\nEND:DAYLIGHT", "GMT Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:BST\r\nDTSTART:19700329T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "GTB Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Georgian Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Greenwich Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:GMT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Hawaiian Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-1000\r\nTZNAME:HST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Iran Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0330\r\nTZNAME:+0330\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0330\r\nTZOFFSETTO:+0430\r\nTZNAME:+0430\r\nDTSTART:20180321T235959\r\nRDATE:20180321T235959\r\nRDATE:20190321T235959\r\nRDATE:20200320T235959\r\nRDATE:20210321T235959\r\nRDATE:20220321T235959\r\nRDATE:20230321T235959\r\nRDATE:20240320T235959\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0430\r\nTZOFFSETTO:+0330\r\nTZNAME:+0330\r\nDTSTART:20180921T235959\r\nRDATE:20180921T235959\r\nRDATE:20190921T235959\r\nRDATE:20200920T235959\r\nRDATE:20210921T235959\r\nRDATE:20220921T235959\r\nRDATE:20230921T235959\r\nRDATE:20240920T235959\r\nEND:STANDARD", "Israel Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:IDT\r\nDTSTART:19700327T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYMONTHDAY=23,24,25,26,27,28,29;BYDAY=FR\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:IST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Jordan Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700326T235959\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1TH\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701030T010000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1FR\r\nEND:STANDARD", "Kaliningrad Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Korea Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:KST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Libya Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Line Islands Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1400\r\nTZOFFSETTO:+1400\r\nTZNAME:+14\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Magadan Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Mauritius Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Middle East Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700329T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701025T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Montevideo Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Morocco Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20180325T020000\r\nRDATE:20180325T020000\r\nRDATE:20180617T020000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20180513T030000\r\nRDATE:20180513T030000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0000\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20190609T020000\r\nRDATE:20190609T020000\r\nRDATE:20200531T020000\r\nRDATE:20210516T020000\r\nRDATE:20220508T020000\r\nRDATE:20230430T020000\r\nRDATE:20240414T020000\r\nEND:STANDARD\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:+01\r\nDTSTART:20181028T030000\r\nRDATE:20181028T030000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0000\r\nTZNAME:+00\r\nDTSTART:20190505T030000\r\nRDATE:20190505T030000\r\nRDATE:20200419T030000\r\nRDATE:20210411T030000\r\nRDATE:20220327T030000\r\nRDATE:20230319T030000\r\nRDATE:20240310T030000\r\nEND:DAYLIGHT", "Mountain Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Mountain Standard Time (Mexico)": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700405T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701025T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "N. Central Asia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Namibia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:CAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "New Zealand Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1300\r\nTZNAME:NZDT\r\nDTSTART:19700927T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1200\r\nTZNAME:NZST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Newfoundland Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0230\r\nTZOFFSETTO:-0330\r\nTZNAME:NST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0330\r\nTZOFFSETTO:-0230\r\nTZNAME:NDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT", "North Asia East Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "North Asia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pacific SA Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20190407T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYMONTHDAY=2,3,4,5,6,7,8;BYDAY=SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20190908T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYMONTHDAY=2,3,4,5,6,7,8;BYDAY=SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:20180812T000000\r\nRDATE:20180812T000000\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:20180513T000000\r\nRDATE:20180513T000000\r\nEND:STANDARD", "Pacific Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Pacific/Johnston": "BEGIN:STANDARD\r\nTZOFFSETFROM:-1000\r\nTZOFFSETTO:-1000\r\nTZNAME:HST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Pakistan Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:PKT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Paraguay Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19701004T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700322T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=4SU\r\nEND:STANDARD", "Romance Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "Russia Time Zone 10": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1100\r\nTZNAME:+11\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Russia Time Zone 11": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1200\r\nTZOFFSETTO:+1200\r\nTZNAME:+12\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Russia Time Zone 3": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0400\r\nTZOFFSETTO:+0400\r\nTZNAME:+04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Russian Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:MSK\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "SA Eastern Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0300\r\nTZOFFSETTO:-0300\r\nTZNAME:-03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "SA Pacific Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0500\r\nTZNAME:-05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "SA Western Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "SE Asia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0700\r\nTZOFFSETTO:+0700\r\nTZNAME:+07\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Samoa Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1400\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700405T040000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1400\r\nTZNAME:+14\r\nDTSTART:19700927T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r\nEND:DAYLIGHT", "Singapore Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "South Africa Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0200\r\nTZNAME:SAST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Sri Lanka Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0530\r\nTZOFFSETTO:+0530\r\nTZNAME:+0530\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Syria Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0200\r\nTZNAME:EET\r\nDTSTART:19701030T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1FR\r\nEND:STANDARD\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0300\r\nTZNAME:EEST\r\nDTSTART:19700327T000000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1FR\r\nEND:DAYLIGHT", "Taipei Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:CST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Tasmania Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1100\r\nTZNAME:AEDT\r\nDTSTART:19701004T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+1100\r\nTZOFFSETTO:+1000\r\nTZNAME:AEST\r\nDTSTART:19700405T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r\nEND:STANDARD", "Tokyo Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:JST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Tonga Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1300\r\nTZOFFSETTO:+1300\r\nTZNAME:+13\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Turkey Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0300\r\nTZOFFSETTO:+0300\r\nTZNAME:+03\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "US Eastern Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "US Mountain Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "US/Central": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0500\r\nTZNAME:CDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0600\r\nTZNAME:CST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "US/Eastern": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0500\r\nTZOFFSETTO:-0400\r\nTZNAME:EDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0500\r\nTZNAME:EST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "US/Mountain": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0600\r\nTZNAME:MDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0600\r\nTZOFFSETTO:-0700\r\nTZNAME:MST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "US/Pacific": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "US/Pacific-New": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:-0800\r\nTZOFFSETTO:-0700\r\nTZNAME:PDT\r\nDTSTART:19700308T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:-0700\r\nTZOFFSETTO:-0800\r\nTZNAME:PST\r\nDTSTART:19701101T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r\nEND:STANDARD", "Ulaanbaatar Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:+08\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Venezuela Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:-0400\r\nTZOFFSETTO:-0400\r\nTZNAME:-04\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Vladivostok Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "W. Australia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0800\r\nTZOFFSETTO:+0800\r\nTZNAME:AWST\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "W. Central Africa Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0100\r\nTZNAME:WAT\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "W. Europe Standard Time": "BEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nTZNAME:CEST\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\nBEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nTZNAME:CET\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD", "West Asia Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0500\r\nTZOFFSETTO:+0500\r\nTZNAME:+05\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "West Pacific Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+1000\r\nTZOFFSETTO:+1000\r\nTZNAME:+10\r\nDTSTART:19700101T000000\r\nEND:STANDARD", "Yakutsk Standard Time": "BEGIN:STANDARD\r\nTZOFFSETFROM:+0900\r\nTZOFFSETTO:+0900\r\nTZNAME:+09\r\nDTSTART:19700101T000000\r\nEND:STANDARD" };
    }
  });

  // node_modules/ical-expander/index.js
  var require_ical_expander = __commonJS({
    "node_modules/ical-expander/index.js"(exports, module) {
      "use strict";
      init_globals();
      var ICAL = require_ical();
      var timezones = require_zones_compiled();
      var IcalExpander = class {
        constructor(opts) {
          this.maxIterations = opts.maxIterations != null ? opts.maxIterations : 1e3;
          this.skipInvalidDates = opts.skipInvalidDates != null ? opts.skipInvalidDates : false;
          this.jCalData = ICAL.parse(opts.ics);
          this.component = new ICAL.Component(this.jCalData);
          this.events = this.component.getAllSubcomponents("vevent").map((vevent) => new ICAL.Event(vevent));
          if (this.skipInvalidDates) {
            this.events = this.events.filter((evt) => {
              try {
                evt.startDate.toJSDate();
                evt.endDate.toJSDate();
                return true;
              } catch (err2) {
                return false;
              }
            });
          }
        }
        between(after, before) {
          function isEventWithinRange(startTime, endTime) {
            return (!after || endTime >= after.getTime()) && (!before || startTime <= before.getTime());
          }
          function getTimes(eventOrOccurrence) {
            const startTime = eventOrOccurrence.startDate.toJSDate().getTime();
            let endTime = eventOrOccurrence.endDate.toJSDate().getTime();
            if (eventOrOccurrence.endDate.isDate && endTime > startTime) {
              endTime -= 1;
            }
            return { startTime, endTime };
          }
          const exceptions = [];
          this.events.forEach((event) => {
            if (event.isRecurrenceException()) exceptions.push(event);
          });
          const ret = {
            events: [],
            occurrences: []
          };
          this.events.filter((e) => !e.isRecurrenceException()).forEach((event) => {
            const exdates = [];
            event.component.getAllProperties("exdate").forEach((exdateProp) => {
              const exdate = exdateProp.getFirstValue();
              exdates.push(exdate.toJSDate().getTime());
            });
            if (event.isRecurring()) {
              const iterator = event.iterator();
              let next;
              let i = 0;
              do {
                i += 1;
                next = iterator.next();
                if (next) {
                  const occurrence = event.getOccurrenceDetails(next);
                  const { startTime: startTime2, endTime: endTime2 } = getTimes(occurrence);
                  const isOccurrenceExcluded = exdates.indexOf(startTime2) !== -1;
                  const exception = exceptions.find((ex) => ex.uid === event.uid && ex.recurrenceId.toJSDate().getTime() === occurrence.startDate.toJSDate().getTime());
                  if (before && startTime2 > before.getTime()) break;
                  if (isEventWithinRange(startTime2, endTime2)) {
                    if (exception) {
                      ret.events.push(exception);
                    } else if (!isOccurrenceExcluded) {
                      ret.occurrences.push(occurrence);
                    }
                  }
                }
              } while (next && (!this.maxIterations || i < this.maxIterations));
              return;
            }
            const { startTime, endTime } = getTimes(event);
            if (isEventWithinRange(startTime, endTime)) ret.events.push(event);
          });
          return ret;
        }
        before(before) {
          return this.between(void 0, before);
        }
        after(after) {
          return this.between(after);
        }
        all() {
          return this.between();
        }
      };
      function registerTimezones() {
        Object.keys(timezones).forEach((key) => {
          const icsData = timezones[key];
          const icsTimezone = `BEGIN:VTIMEZONE\r
TZID:${key}\r
${icsData}\r
END:VTIMEZONE`;
          const parsed = ICAL.parse(`BEGIN:VCALENDAR
PRODID:-//tzurl.org//NONSGML Olson 2012h//EN
VERSION:2.0
${icsTimezone}
END:VCALENDAR`);
          const comp = new ICAL.Component(parsed);
          const vtimezone = comp.getFirstSubcomponent("vtimezone");
          ICAL.TimezoneService.register(key, new ICAL.Timezone(vtimezone));
        });
      }
      registerTimezones();
      module.exports = IcalExpander;
    }
  });

  // mobile/shim/crypto.js
  var crypto_exports = {};
  __export(crypto_exports, {
    createHash: () => createHash,
    default: () => crypto_default,
    randomUUID: () => randomUUID
  });
  function createHash() {
    throw new Error("\uD734\uB300\uD3F0\uC5D0\uC11C\uB294 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC74C");
  }
  var randomUUID, crypto_default;
  var init_crypto = __esm({
    "mobile/shim/crypto.js"() {
      init_globals();
      randomUUID = () => globalThis.crypto && globalThis.crypto.randomUUID ? globalThis.crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        const r = Math.random() * 16 | 0;
        return (c === "x" ? r : r & 3 | 8).toString(16);
      });
      crypto_default = { randomUUID, createHash };
    }
  });

  // desktop/renderer/tz.js
  var require_tz = __commonJS({
    "desktop/renderer/tz.js"(exports, module) {
      init_globals();
      (function(root) {
        const ZONES = [
          ["Asia/Seoul", "\uC11C\uC6B8"],
          ["Asia/Tokyo", "\uB3C4\uCFC4"],
          ["Asia/Shanghai", "\uBCA0\uC774\uC9D5\xB7\uC0C1\uD558\uC774"],
          ["Asia/Hong_Kong", "\uD64D\uCF69"],
          ["Asia/Taipei", "\uD0C0\uC774\uBCA0\uC774"],
          ["Asia/Manila", "\uB9C8\uB2D0\uB77C"],
          ["Asia/Singapore", "\uC2F1\uAC00\uD3EC\uB974"],
          ["Asia/Kuala_Lumpur", "\uCFE0\uC54C\uB77C\uB8F8\uD478\uB974"],
          ["Asia/Jakarta", "\uC790\uCE74\uB974\uD0C0"],
          ["Asia/Bangkok", "\uBC29\uCF55"],
          ["Asia/Ho_Chi_Minh", "\uD638\uCC0C\uBBFC\xB7\uD558\uB178\uC774"],
          ["Asia/Kolkata", "\uC778\uB3C4 (\uBB44\uBC14\uC774\xB7\uB378\uB9AC)"],
          ["Asia/Dhaka", "\uB2E4\uCE74"],
          ["Asia/Karachi", "\uCE74\uB77C\uCE58"],
          ["Asia/Tashkent", "\uD0C0\uC288\uCF04\uD2B8"],
          ["Asia/Dubai", "\uB450\uBC14\uC774\xB7\uC544\uBD80\uB2E4\uBE44"],
          ["Asia/Riyadh", "\uC0AC\uC6B0\uB514 (\uB9AC\uC57C\uB4DC)"],
          ["Asia/Qatar", "\uCE74\uD0C0\uB974 (\uB3C4\uD558)"],
          ["Asia/Kuwait", "\uCFE0\uC6E8\uC774\uD2B8"],
          ["Asia/Baghdad", "\uBC14\uADF8\uB2E4\uB4DC"],
          ["Asia/Tehran", "\uD14C\uD5E4\uB780"],
          ["Europe/Istanbul", "\uC774\uC2A4\uD0C4\uBD88"],
          ["Europe/Moscow", "\uBAA8\uC2A4\uD06C\uBC14"],
          ["Africa/Cairo", "\uCE74\uC774\uB85C"],
          ["Europe/Berlin", "\uBCA0\uB97C\uB9B0"],
          ["Europe/Paris", "\uD30C\uB9AC"],
          ["Europe/Madrid", "\uB9C8\uB4DC\uB9AC\uB4DC"],
          ["Europe/Amsterdam", "\uC554\uC2A4\uD14C\uB974\uB2F4"],
          ["Europe/London", "\uB7F0\uB358"],
          ["UTC", "\uD611\uC815 \uC138\uACC4\uC2DC (UTC)"],
          ["America/Sao_Paulo", "\uC0C1\uD30C\uC6B8\uB8E8"],
          ["America/New_York", "\uB274\uC695"],
          ["America/Toronto", "\uD1A0\uB860\uD1A0"],
          ["America/Chicago", "\uC2DC\uCE74\uACE0"],
          ["America/Denver", "\uB374\uBC84"],
          ["America/Los_Angeles", "LA\xB7\uC0CC\uD504\uB780\uC2DC\uC2A4\uCF54"],
          ["America/Vancouver", "\uBC34\uCFE0\uBC84"],
          ["Pacific/Honolulu", "\uD558\uC640\uC774"],
          ["Australia/Sydney", "\uC2DC\uB4DC\uB2C8"],
          ["Australia/Perth", "\uD37C\uC2A4"],
          ["Pacific/Auckland", "\uC624\uD074\uB79C\uB4DC"]
        ];
        const NAME = Object.fromEntries(ZONES);
        const systemZone = () => {
          try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
          } catch {
            return "UTC";
          }
        };
        const valid = (tz) => {
          if (!tz) return false;
          try {
            new Intl.DateTimeFormat("en-US", { timeZone: tz });
            return true;
          } catch {
            return false;
          }
        };
        const resolve = (tz) => tz && tz !== "system" && valid(tz) ? tz : systemZone();
        const label = (tz) => NAME[tz] || String(tz || "").split("/").pop().replace(/_/g, " ");
        const fmtCache = /* @__PURE__ */ new Map();
        function parts(date, tz) {
          let f2 = fmtCache.get(tz);
          if (!f2) {
            f2 = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" });
            fmtCache.set(tz, f2);
          }
          const o = {};
          for (const p of f2.formatToParts(date)) if (p.type !== "literal") o[p.type] = +p.value;
          return o;
        }
        function wall(date, tz) {
          const p = parts(date, tz);
          return new Date(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second);
        }
        function offset(date, tz) {
          const p = parts(date, tz);
          return Math.round((Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) - Math.floor(date.getTime() / 1e3) * 1e3) / 6e4);
        }
        function toInstant(dateStr, timeStr, tz) {
          const [y, mo, d] = dateStr.split("-").map(Number);
          const [h, mi] = (timeStr || "00:00").split(":").map(Number);
          const guess = Date.UTC(y, mo - 1, d, h, mi);
          let t = guess - offset(new Date(guess), tz) * 6e4;
          t = guess - offset(new Date(t), tz) * 6e4;
          return new Date(t);
        }
        const offsetLabel = (date, tz) => {
          const m2 = offset(date, tz), s = m2 < 0 ? "\u2212" : "+", a = Math.abs(m2);
          return `UTC${s}${Math.floor(a / 60)}${a % 60 ? ":" + String(a % 60).padStart(2, "0") : ""}`;
        };
        const diffLabel = (date, from, to) => {
          const d = offset(date, to) - offset(date, from);
          if (!d) return "\uAC19\uC740 \uC2DC\uAC01";
          const s = d < 0 ? "\u2212" : "+", a = Math.abs(d);
          return `${s}${Math.floor(a / 60)}\uC2DC\uAC04${a % 60 ? " " + a % 60 + "\uBD84" : ""}`;
        };
        const api = { ZONES, label, systemZone, valid, resolve, parts, wall, offset, toInstant, offsetLabel, diffLabel };
        if (typeof module !== "undefined") module.exports = api;
        else root.TZ = api;
      })(typeof window !== "undefined" ? window : globalThis);
    }
  });

  // desktop/renderer/lunar.js
  var require_lunar = __commonJS({
    "desktop/renderer/lunar.js"(exports, module) {
      init_globals();
      (function(root) {
        let fmt2 = null;
        function F() {
          if (!fmt2) fmt2 = new Intl.DateTimeFormat("en-u-ca-dangi", { year: "numeric", month: "numeric", day: "numeric", timeZone: "Asia/Seoul" });
          return fmt2;
        }
        const pad = (n) => String(n).padStart(2, "0");
        const ymd2 = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        function toLunar(date) {
          const d = date instanceof Date ? date : /* @__PURE__ */ new Date(date + "T12:00:00");
          const noon = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 3));
          const parts = F().formatToParts(noon);
          const g = (t) => (parts.find((p) => p.type === t) || {}).value || "";
          const mRaw = g("month");
          return { y: Number(g("relatedYear") || g("year")), m: parseInt(mRaw, 10), d: Number(g("day")), leap: /bis/.test(mRaw) };
        }
        const cache = /* @__PURE__ */ new Map();
        function yearMap(y) {
          if (cache.has(y)) return cache.get(y);
          const m2 = /* @__PURE__ */ new Map();
          const d = new Date(y, 0, 15);
          const end = new Date(y + 1, 1, 25);
          for (; d <= end; d.setDate(d.getDate() + 1)) {
            const l = toLunar(d);
            if (l.y !== y) continue;
            const key = `${l.m}-${l.d}-${l.leap ? 1 : 0}`;
            if (!m2.has(key)) m2.set(key, ymd2(d));
          }
          cache.set(y, m2);
          return m2;
        }
        function toSolar(y, mo, d, leap) {
          const m2 = yearMap(Number(y));
          let v = m2.get(`${mo}-${d}-${leap ? 1 : 0}`);
          if (!v && Number(d) === 30) v = m2.get(`${mo}-29-${leap ? 1 : 0}`);
          return v || "";
        }
        const label = (l) => `${l.leap ? "\uC724" : ""}${l.m}.${l.d}`;
        const seollal = (y) => toSolar(y, 1, 1, false);
        const chuseok = (y) => toSolar(y, 8, 15, false);
        const api = { toLunar, toSolar, label, seollal, chuseok };
        if (typeof module !== "undefined" && module.exports) module.exports = api;
        if (typeof window !== "undefined") root.Lunar = api;
      })(typeof window !== "undefined" ? window : globalThis);
    }
  });

  // node_modules/tsdav/dist/tsdav.js
  var tsdav_exports = {};
  __export(tsdav_exports, {
    DAVAttributeMap: () => DAVAttributeMap,
    DAVClient: () => DAVClient,
    DAVNamespace: () => DAVNamespace,
    DAVNamespaceShort: () => DAVNamespaceShort,
    DigestUnsupportedError: () => DigestUnsupportedError,
    ICALObjects: () => ICALObjects,
    addressBookMultiGet: () => addressBookMultiGet,
    addressBookQuery: () => addressBookQuery,
    calendarMultiGet: () => calendarMultiGet,
    calendarQuery: () => calendarQuery,
    cleanupFalsy: () => cleanupFalsy,
    collectionQuery: () => collectionQuery,
    createAccount: () => createAccount,
    createCalendarObject: () => createCalendarObject,
    createDAVClient: () => createDAVClient,
    createObject: () => createObject,
    createVCard: () => createVCard,
    davRequest: () => davRequest,
    default: () => src_default,
    deleteCalendarObject: () => deleteCalendarObject,
    deleteObject: () => deleteObject,
    deleteVCard: () => deleteVCard,
    ensureTrailingSlash: () => ensureTrailingSlash,
    excludeHeaders: () => excludeHeaders,
    fetchAddressBooks: () => fetchAddressBooks,
    fetchCalendarObjects: () => fetchCalendarObjects,
    fetchCalendarUserAddresses: () => fetchCalendarUserAddresses,
    fetchCalendars: () => fetchCalendars,
    fetchHomeUrl: () => fetchHomeUrl,
    fetchOauthTokens: () => fetchOauthTokens,
    fetchPrincipalUrl: () => fetchPrincipalUrl,
    fetchVCards: () => fetchVCards,
    freeBusyQuery: () => freeBusyQuery,
    getBasicAuthHeaders: () => getBasicAuthHeaders,
    getBearerAuthHeaders: () => getBearerAuthHeaders,
    getDAVAttribute: () => getDAVAttribute,
    getOauthHeaders: () => getOauthHeaders,
    isCollectionDirty: () => isCollectionDirty,
    makeCalendar: () => makeCalendar,
    makeCollection: () => makeCollection,
    mergeHeaders: () => mergeHeaders,
    propfind: () => propfind,
    refreshAccessToken: () => refreshAccessToken,
    serviceDiscovery: () => serviceDiscovery,
    smartCollectionSync: () => smartCollectionSync,
    smartCollectionSyncDetailed: () => smartCollectionSyncDetailed,
    supportedReportSet: () => supportedReportSet,
    syncCalendars: () => syncCalendars,
    syncCalendarsDetailed: () => syncCalendarsDetailed,
    syncCollection: () => syncCollection,
    updateCalendarObject: () => updateCalendarObject,
    updateObject: () => updateObject,
    updateVCard: () => updateVCard,
    urlContains: () => urlContains,
    urlEquals: () => urlEquals,
    urlMatches: () => urlMatches
  });
  function hasFields(obj, fields) {
    if (!obj) return false;
    const inObj = (object) => object != null && fields.every((f2) => object[f2]);
    if (Array.isArray(obj)) return obj.length > 0 && obj.every((o) => inObj(o));
    return inObj(obj);
  }
  var __create2, __defProp2, __getOwnPropDesc2, __getOwnPropNames2, __getProtoOf2, __hasOwnProp2, __commonJSMin, __exportAll, __copyProps2, __toESM2, __require2, require_ms, require_common, import_browser, DAVNamespace, DAVAttributeMap, DAVNamespaceShort, ICALObjects, require_sax, require_array_helper, require_options_helper, require_xml2js, require_xml2json, require_js2xml, require_json2xml, import_lib, resolveFetch, fetch2, camelCase, findMissingFieldNames, hasOwn, davNamespaces, standardNamespaces, normalizedKey, normalizeElement, parseDAVXML, mergeDAVProps, normalizePercentEncoding, requestHelpers_exports, normalizeUrl, ensureTrailingSlash, urlEquals, urlContains, urlMatches, getDAVAttribute, cleanupFalsy, conditionalParam, excludeHeaders, mergeHeaders, request_exports, debug$6, parseStatusLine, davRequest, propfind, createObject, updateObject, deleteObject, getDAVUrlKey, diffDAVObjects, assertDAVResponses, assertDAVDiscovery, assertDAVProperty, assertDAVObjectResponses, getDAVText, collection_exports, debug$5, resolveDAVHref, collectionQuery, makeCollection, supportedReportSet, isCollectionDirty, syncCollection, smartCollectionSync, smartCollectionSyncDetailed, getObjectUrl, addressBook_exports, debug$4, addressBookQuery, addressBookMultiGet, fetchAddressBooks, fetchVCards, createVCard, updateVCard, deleteVCard, calendar_exports, debug$3, ISO_8601, ISO_8601_FULL, validateTimeRange, extractComponentNames, fetchCalendarUserAddresses, calendarQuery, calendarMultiGet, makeCalendar, fetchCalendars, fetchCalendarObjects, createCalendarObject, updateCalendarObject, deleteCalendarObject, syncCalendars, syncCalendarsDetailed, freeBusyQuery, SHIFTS, K2, toHex$1, md5, debug$2, TOKEN, parseAuthenticateHeader, SUPPORTED_ALGORITHMS, toDigestChallenge, selectDigestChallenge, toHex, DigestUnsupportedError, getCrypto, hash2, quote, usernameField, buildDigestAuthorization, createCnonce, toURL, isReplayable, MAX_REDIRECTS, REDIRECT_STATUSES, BODY_HEADERS, redirectInit, withoutAuthorization, protectionScopes, createDigestAuthState, createDigestFetch, account_exports, debug$1, getCandidateRootUrls, serviceDiscovery, extractHref, fetchPrincipalUrl, fetchHomeUrl, createAccount, EXPIRY_MARGIN_MS, isTokenUnexpired, getTokenExpiration, authHelpers_exports, debug, BASE64_ALPHABET, NON_LATIN1_BASIC_AUTH_MESSAGE, InvalidCharacterError, assertLatin1, encodeBase64, defaultParam, getBasicAuthHeaders, getBearerAuthHeaders, fetchOauthTokens, refreshAccessToken, getOauthHeaders, client_exports, resolveAuthHeaders, digestStates, authFetch, createDAVClient, DAVClient, src_default;
  var init_tsdav = __esm({
    "node_modules/tsdav/dist/tsdav.js"() {
      init_globals();
      __create2 = Object.create;
      __defProp2 = Object.defineProperty;
      __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
      __getOwnPropNames2 = Object.getOwnPropertyNames;
      __getProtoOf2 = Object.getPrototypeOf;
      __hasOwnProp2 = Object.prototype.hasOwnProperty;
      __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod, mod.exports), cb = null), mod.exports);
      __exportAll = (all, no_symbols) => {
        let target = {};
        for (var name in all) __defProp2(target, name, {
          get: all[name],
          enumerable: true
        });
        if (!no_symbols) __defProp2(target, Symbol.toStringTag, { value: "Module" });
        return target;
      };
      __copyProps2 = (to, from, except, desc) => {
        if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames2(from), i = 0, n = keys.length, key; i < n; i++) {
          key = keys[i];
          if (!__hasOwnProp2.call(to, key) && key !== except) __defProp2(to, key, {
            get: ((k) => from[k]).bind(null, key),
            enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable
          });
        }
        return to;
      };
      __toESM2 = (mod, isNodeMode, target) => (target = mod != null ? __create2(__getProtoOf2(mod)) : {}, __copyProps2(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp2.call(mod, "default") ? __defProp2(target, "default", {
        value: mod,
        enumerable: true
      }) : target, mod));
      __require2 = /* @__PURE__ */ ((x) => typeof __require !== "undefined" ? __require : typeof Proxy !== "undefined" ? new Proxy(x, { get: (a, b) => (typeof __require !== "undefined" ? __require : a)[b] }) : x)(function(x) {
        if (typeof __require !== "undefined") return __require.apply(this, arguments);
        throw Error('Calling `require` for "' + x + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
      });
      require_ms = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var s = 1e3;
        var m2 = s * 60;
        var h = m2 * 60;
        var d = h * 24;
        var w = d * 7;
        var y = d * 365.25;
        module.exports = function(val, options) {
          options = options || {};
          var type = typeof val;
          if (type === "string" && val.length > 0) return parse(val);
          else if (type === "number" && isFinite(val)) return options.long ? fmtLong(val) : fmtShort(val);
          throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(val));
        };
        function parse(str) {
          str = String(str);
          if (str.length > 100) return;
          var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
          if (!match) return;
          var n = parseFloat(match[1]);
          switch ((match[2] || "ms").toLowerCase()) {
            case "years":
            case "year":
            case "yrs":
            case "yr":
            case "y":
              return n * y;
            case "weeks":
            case "week":
            case "w":
              return n * w;
            case "days":
            case "day":
            case "d":
              return n * d;
            case "hours":
            case "hour":
            case "hrs":
            case "hr":
            case "h":
              return n * h;
            case "minutes":
            case "minute":
            case "mins":
            case "min":
            case "m":
              return n * m2;
            case "seconds":
            case "second":
            case "secs":
            case "sec":
            case "s":
              return n * s;
            case "milliseconds":
            case "millisecond":
            case "msecs":
            case "msec":
            case "ms":
              return n;
            default:
              return;
          }
        }
        function fmtShort(ms) {
          var msAbs = Math.abs(ms);
          if (msAbs >= d) return Math.round(ms / d) + "d";
          if (msAbs >= h) return Math.round(ms / h) + "h";
          if (msAbs >= m2) return Math.round(ms / m2) + "m";
          if (msAbs >= s) return Math.round(ms / s) + "s";
          return ms + "ms";
        }
        function fmtLong(ms) {
          var msAbs = Math.abs(ms);
          if (msAbs >= d) return plural(ms, msAbs, d, "day");
          if (msAbs >= h) return plural(ms, msAbs, h, "hour");
          if (msAbs >= m2) return plural(ms, msAbs, m2, "minute");
          if (msAbs >= s) return plural(ms, msAbs, s, "second");
          return ms + " ms";
        }
        function plural(ms, msAbs, n, name) {
          var isPlural = msAbs >= n * 1.5;
          return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
        }
      }));
      require_common = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        function setup(env) {
          createDebug.debug = createDebug;
          createDebug.default = createDebug;
          createDebug.coerce = coerce;
          createDebug.disable = disable;
          createDebug.enable = enable;
          createDebug.enabled = enabled;
          createDebug.humanize = require_ms();
          createDebug.destroy = destroy;
          Object.keys(env).forEach((key) => {
            createDebug[key] = env[key];
          });
          createDebug.names = [];
          createDebug.skips = [];
          createDebug.formatters = {};
          function selectColor(namespace) {
            let hash3 = 0;
            for (let i = 0; i < namespace.length; i++) {
              hash3 = (hash3 << 5) - hash3 + namespace.charCodeAt(i);
              hash3 |= 0;
            }
            return createDebug.colors[Math.abs(hash3) % createDebug.colors.length];
          }
          createDebug.selectColor = selectColor;
          function createDebug(namespace) {
            let prevTime;
            let enableOverride = null;
            let namespacesCache;
            let enabledCache;
            function debug2(...args) {
              if (!debug2.enabled) return;
              const self2 = debug2;
              const curr = Number(/* @__PURE__ */ new Date());
              self2.diff = curr - (prevTime || curr);
              self2.prev = prevTime;
              self2.curr = curr;
              prevTime = curr;
              args[0] = createDebug.coerce(args[0]);
              if (typeof args[0] !== "string") args.unshift("%O");
              let index = 0;
              args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
                if (match === "%%") return "%";
                index++;
                const formatter = createDebug.formatters[format];
                if (typeof formatter === "function") {
                  const val = args[index];
                  match = formatter.call(self2, val);
                  args.splice(index, 1);
                  index--;
                }
                return match;
              });
              createDebug.formatArgs.call(self2, args);
              (self2.log || createDebug.log).apply(self2, args);
            }
            debug2.namespace = namespace;
            debug2.useColors = createDebug.useColors();
            debug2.color = createDebug.selectColor(namespace);
            debug2.extend = extend;
            debug2.destroy = createDebug.destroy;
            Object.defineProperty(debug2, "enabled", {
              enumerable: true,
              configurable: false,
              get: () => {
                if (enableOverride !== null) return enableOverride;
                if (namespacesCache !== createDebug.namespaces) {
                  namespacesCache = createDebug.namespaces;
                  enabledCache = createDebug.enabled(namespace);
                }
                return enabledCache;
              },
              set: (v) => {
                enableOverride = v;
              }
            });
            if (typeof createDebug.init === "function") createDebug.init(debug2);
            return debug2;
          }
          function extend(namespace, delimiter) {
            const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
            newDebug.log = this.log;
            return newDebug;
          }
          function enable(namespaces) {
            createDebug.save(namespaces);
            createDebug.namespaces = namespaces;
            createDebug.names = [];
            createDebug.skips = [];
            const split = (typeof namespaces === "string" ? namespaces : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
            for (const ns of split) if (ns[0] === "-") createDebug.skips.push(ns.slice(1));
            else createDebug.names.push(ns);
          }
          function matchesTemplate(search, template) {
            let searchIndex = 0;
            let templateIndex = 0;
            let starIndex = -1;
            let matchIndex = 0;
            while (searchIndex < search.length) if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === "*")) {
              if (template[templateIndex] === "*") {
                starIndex = templateIndex;
                matchIndex = searchIndex;
                templateIndex++;
              } else {
                searchIndex++;
                templateIndex++;
              }
            } else if (starIndex !== -1) {
              templateIndex = starIndex + 1;
              matchIndex++;
              searchIndex = matchIndex;
            } else return false;
            while (templateIndex < template.length && template[templateIndex] === "*") templateIndex++;
            return templateIndex === template.length;
          }
          function disable() {
            const namespaces = [...createDebug.names, ...createDebug.skips.map((namespace) => "-" + namespace)].join(",");
            createDebug.enable("");
            return namespaces;
          }
          function enabled(name) {
            for (const skip of createDebug.skips) if (matchesTemplate(name, skip)) return false;
            for (const ns of createDebug.names) if (matchesTemplate(name, ns)) return true;
            return false;
          }
          function coerce(val) {
            if (val instanceof Error) return val.stack || val.message;
            return val;
          }
          function destroy() {
            console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
          }
          createDebug.enable(createDebug.load());
          return createDebug;
        }
        module.exports = setup;
      }));
      import_browser = /* @__PURE__ */ __toESM2((/* @__PURE__ */ __commonJSMin(((exports, module) => {
        exports.formatArgs = formatArgs;
        exports.save = save;
        exports.load = load;
        exports.useColors = useColors;
        exports.storage = localstorage();
        exports.destroy = /* @__PURE__ */ (() => {
          let warned = false;
          return () => {
            if (!warned) {
              warned = true;
              console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
            }
          };
        })();
        exports.colors = [
          "#0000CC",
          "#0000FF",
          "#0033CC",
          "#0033FF",
          "#0066CC",
          "#0066FF",
          "#0099CC",
          "#0099FF",
          "#00CC00",
          "#00CC33",
          "#00CC66",
          "#00CC99",
          "#00CCCC",
          "#00CCFF",
          "#3300CC",
          "#3300FF",
          "#3333CC",
          "#3333FF",
          "#3366CC",
          "#3366FF",
          "#3399CC",
          "#3399FF",
          "#33CC00",
          "#33CC33",
          "#33CC66",
          "#33CC99",
          "#33CCCC",
          "#33CCFF",
          "#6600CC",
          "#6600FF",
          "#6633CC",
          "#6633FF",
          "#66CC00",
          "#66CC33",
          "#9900CC",
          "#9900FF",
          "#9933CC",
          "#9933FF",
          "#99CC00",
          "#99CC33",
          "#CC0000",
          "#CC0033",
          "#CC0066",
          "#CC0099",
          "#CC00CC",
          "#CC00FF",
          "#CC3300",
          "#CC3333",
          "#CC3366",
          "#CC3399",
          "#CC33CC",
          "#CC33FF",
          "#CC6600",
          "#CC6633",
          "#CC9900",
          "#CC9933",
          "#CCCC00",
          "#CCCC33",
          "#FF0000",
          "#FF0033",
          "#FF0066",
          "#FF0099",
          "#FF00CC",
          "#FF00FF",
          "#FF3300",
          "#FF3333",
          "#FF3366",
          "#FF3399",
          "#FF33CC",
          "#FF33FF",
          "#FF6600",
          "#FF6633",
          "#FF9900",
          "#FF9933",
          "#FFCC00",
          "#FFCC33"
        ];
        function useColors() {
          if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) return true;
          if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return false;
          let m2;
          return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator !== "undefined" && navigator.userAgent && (m2 = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m2[1], 10) >= 31 || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
        }
        function formatArgs(args) {
          args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
          if (!this.useColors) return;
          const c = "color: " + this.color;
          args.splice(1, 0, c, "color: inherit");
          let index = 0;
          let lastC = 0;
          args[0].replace(/%[a-zA-Z%]/g, (match) => {
            if (match === "%%") return;
            index++;
            if (match === "%c") lastC = index;
          });
          args.splice(lastC, 0, c);
        }
        exports.log = console.debug || console.log || (() => {
        });
        function save(namespaces) {
          try {
            if (namespaces) exports.storage.setItem("debug", namespaces);
            else exports.storage.removeItem("debug");
          } catch (error) {
          }
        }
        function load() {
          let r;
          try {
            r = exports.storage.getItem("debug") || exports.storage.getItem("DEBUG");
          } catch (error) {
          }
          if (!r && typeof process !== "undefined" && "env" in process) r = process.env.DEBUG;
          return r;
        }
        function localstorage() {
          try {
            return localStorage;
          } catch (error) {
          }
        }
        module.exports = require_common()(exports);
        const { formatters } = module.exports;
        formatters.j = function(v) {
          try {
            return JSON.stringify(v);
          } catch (error) {
            return "[UnexpectedJSONParseError]: " + error.message;
          }
        };
      })))());
      DAVNamespace = /* @__PURE__ */ (function(DAVNamespace2) {
        DAVNamespace2["CALENDAR_SERVER"] = "http://calendarserver.org/ns/";
        DAVNamespace2["CALDAV_APPLE"] = "http://apple.com/ns/ical/";
        DAVNamespace2["CALDAV"] = "urn:ietf:params:xml:ns:caldav";
        DAVNamespace2["CARDDAV"] = "urn:ietf:params:xml:ns:carddav";
        DAVNamespace2["DAV"] = "DAV:";
        return DAVNamespace2;
      })({});
      DAVAttributeMap = {
        ["urn:ietf:params:xml:ns:caldav"]: "xmlns:c",
        ["urn:ietf:params:xml:ns:carddav"]: "xmlns:card",
        ["http://calendarserver.org/ns/"]: "xmlns:cs",
        ["http://apple.com/ns/ical/"]: "xmlns:ca",
        ["DAV:"]: "xmlns:d"
      };
      DAVNamespaceShort = /* @__PURE__ */ (function(DAVNamespaceShort2) {
        DAVNamespaceShort2["CALDAV"] = "c";
        DAVNamespaceShort2["CARDDAV"] = "card";
        DAVNamespaceShort2["CALENDAR_SERVER"] = "cs";
        DAVNamespaceShort2["CALDAV_APPLE"] = "ca";
        DAVNamespaceShort2["DAV"] = "d";
        return DAVNamespaceShort2;
      })({});
      ICALObjects = /* @__PURE__ */ (function(ICALObjects2) {
        ICALObjects2["VEVENT"] = "VEVENT";
        ICALObjects2["VTODO"] = "VTODO";
        ICALObjects2["VJOURNAL"] = "VJOURNAL";
        ICALObjects2["VFREEBUSY"] = "VFREEBUSY";
        ICALObjects2["VTIMEZONE"] = "VTIMEZONE";
        ICALObjects2["VALARM"] = "VALARM";
        return ICALObjects2;
      })({});
      require_sax = /* @__PURE__ */ __commonJSMin(((exports, module, this$1) => {
        (function(sax) {
          sax.parser = function(strict, opt) {
            return new SAXParser(strict, opt);
          };
          sax.SAXParser = SAXParser;
          sax.SAXStream = SAXStream;
          sax.createStream = createStream;
          sax.MAX_BUFFER_LENGTH = 65536;
          var buffers = [
            "comment",
            "sgmlDecl",
            "textNode",
            "tagName",
            "doctype",
            "procInstName",
            "procInstBody",
            "entity",
            "attribName",
            "attribValue",
            "cdata",
            "script"
          ];
          sax.EVENTS = [
            "text",
            "processinginstruction",
            "sgmldeclaration",
            "doctype",
            "comment",
            "opentagstart",
            "attribute",
            "opentag",
            "closetag",
            "opencdata",
            "cdata",
            "closecdata",
            "error",
            "end",
            "ready",
            "script",
            "opennamespace",
            "closenamespace"
          ];
          function SAXParser(strict, opt) {
            if (!(this instanceof SAXParser)) return new SAXParser(strict, opt);
            var parser = this;
            clearBuffers(parser);
            parser.q = parser.c = "";
            parser.bufferCheckPosition = sax.MAX_BUFFER_LENGTH;
            parser.encoding = null;
            parser.opt = opt || {};
            parser.opt.lowercase = parser.opt.lowercase || parser.opt.lowercasetags;
            parser.looseCase = parser.opt.lowercase ? "toLowerCase" : "toUpperCase";
            parser.opt.maxEntityCount = parser.opt.maxEntityCount || 512;
            parser.opt.maxEntityDepth = parser.opt.maxEntityDepth || 4;
            parser.entityCount = parser.entityDepth = 0;
            parser.tags = [];
            parser.closed = parser.closedRoot = parser.sawRoot = false;
            parser.tag = parser.error = null;
            parser.strict = !!strict;
            parser.noscript = !!(strict || parser.opt.noscript);
            parser.state = S.BEGIN;
            parser.strictEntities = parser.opt.strictEntities;
            parser.ENTITIES = parser.strictEntities ? Object.create(sax.XML_ENTITIES) : Object.create(sax.ENTITIES);
            parser.attribList = [];
            if (parser.opt.xmlns) parser.ns = Object.create(rootNS);
            if (parser.opt.unquotedAttributeValues === void 0) parser.opt.unquotedAttributeValues = !strict;
            parser.trackPosition = parser.opt.position !== false;
            if (parser.trackPosition) parser.position = parser.line = parser.column = 0;
            emit(parser, "onready");
          }
          if (!Object.create) Object.create = function(o) {
            function F() {
            }
            F.prototype = o;
            return new F();
          };
          if (!Object.keys) Object.keys = function(o) {
            var a = [];
            for (var i in o) if (o.hasOwnProperty(i)) a.push(i);
            return a;
          };
          function checkBufferLength(parser) {
            var maxAllowed = Math.max(sax.MAX_BUFFER_LENGTH, 10);
            var maxActual = 0;
            for (var i = 0, l = buffers.length; i < l; i++) {
              var len = parser[buffers[i]].length;
              if (len > maxAllowed) switch (buffers[i]) {
                case "textNode":
                  closeText(parser);
                  break;
                case "cdata":
                  emitNode(parser, "oncdata", parser.cdata);
                  parser.cdata = "";
                  break;
                case "script":
                  emitNode(parser, "onscript", parser.script);
                  parser.script = "";
                  break;
                default:
                  error(parser, "Max buffer length exceeded: " + buffers[i]);
              }
              maxActual = Math.max(maxActual, len);
            }
            parser.bufferCheckPosition = sax.MAX_BUFFER_LENGTH - maxActual + parser.position;
          }
          function clearBuffers(parser) {
            for (var i = 0, l = buffers.length; i < l; i++) parser[buffers[i]] = "";
          }
          function flushBuffers(parser) {
            closeText(parser);
            if (parser.cdata !== "") {
              emitNode(parser, "oncdata", parser.cdata);
              parser.cdata = "";
            }
            if (parser.script !== "") {
              emitNode(parser, "onscript", parser.script);
              parser.script = "";
            }
          }
          SAXParser.prototype = {
            end: function() {
              end(this);
            },
            write,
            resume: function() {
              this.error = null;
              return this;
            },
            close: function() {
              return this.write(null);
            },
            flush: function() {
              flushBuffers(this);
            }
          };
          var Stream;
          try {
            Stream = __require2("stream").Stream;
          } catch (ex) {
            Stream = function() {
            };
          }
          if (!Stream) Stream = function() {
          };
          var streamWraps = sax.EVENTS.filter(function(ev) {
            return ev !== "error" && ev !== "end";
          });
          function createStream(strict, opt) {
            return new SAXStream(strict, opt);
          }
          function determineBufferEncoding(data, isEnd) {
            if (data.length >= 2) {
              if (data[0] === 255 && data[1] === 254) return "utf-16le";
              if (data[0] === 254 && data[1] === 255) return "utf-16be";
            }
            if (data.length >= 3 && data[0] === 239 && data[1] === 187 && data[2] === 191) return "utf8";
            if (data.length >= 4) {
              if (data[0] === 60 && data[1] === 0 && data[2] === 63 && data[3] === 0) return "utf-16le";
              if (data[0] === 0 && data[1] === 60 && data[2] === 0 && data[3] === 63) return "utf-16be";
              return "utf8";
            }
            return isEnd ? "utf8" : null;
          }
          function SAXStream(strict, opt) {
            if (!(this instanceof SAXStream)) return new SAXStream(strict, opt);
            Stream.apply(this);
            this._parser = new SAXParser(strict, opt);
            this.writable = true;
            this.readable = true;
            var me = this;
            this._parser.onend = function() {
              me.emit("end");
            };
            this._parser.onerror = function(er) {
              me.emit("error", er);
              me._parser.error = null;
            };
            this._decoder = null;
            this._decoderBuffer = null;
            streamWraps.forEach(function(ev) {
              Object.defineProperty(me, "on" + ev, {
                get: function() {
                  return me._parser["on" + ev];
                },
                set: function(h) {
                  if (!h) {
                    me.removeAllListeners(ev);
                    me._parser["on" + ev] = h;
                    return h;
                  }
                  me.on(ev, h);
                },
                enumerable: true,
                configurable: false
              });
            });
          }
          SAXStream.prototype = Object.create(Stream.prototype, { constructor: { value: SAXStream } });
          SAXStream.prototype._decodeBuffer = function(data, isEnd) {
            if (this._decoderBuffer) {
              data = import_buffer.Buffer.concat([this._decoderBuffer, data]);
              this._decoderBuffer = null;
            }
            if (!this._decoder) {
              var encoding = determineBufferEncoding(data, isEnd);
              if (!encoding) {
                this._decoderBuffer = data;
                return "";
              }
              this._parser.encoding = encoding;
              this._decoder = new TextDecoder(encoding);
            }
            return this._decoder.decode(data, { stream: !isEnd });
          };
          SAXStream.prototype.write = function(data) {
            if (typeof import_buffer.Buffer === "function" && typeof import_buffer.Buffer.isBuffer === "function" && import_buffer.Buffer.isBuffer(data)) data = this._decodeBuffer(data, false);
            else if (this._decoderBuffer) {
              var remaining = this._decodeBuffer(import_buffer.Buffer.alloc(0), true);
              if (remaining) {
                this._parser.write(remaining);
                this.emit("data", remaining);
              }
            }
            this._parser.write(data.toString());
            this.emit("data", data);
            return true;
          };
          SAXStream.prototype.end = function(chunk) {
            if (chunk && chunk.length) this.write(chunk);
            if (this._decoderBuffer) {
              var finalChunk = this._decodeBuffer(import_buffer.Buffer.alloc(0), true);
              if (finalChunk) {
                this._parser.write(finalChunk);
                this.emit("data", finalChunk);
              }
            } else if (this._decoder) {
              var remaining = this._decoder.decode();
              if (remaining) {
                this._parser.write(remaining);
                this.emit("data", remaining);
              }
            }
            this._parser.end();
            return true;
          };
          SAXStream.prototype.on = function(ev, handler) {
            var me = this;
            if (!me._parser["on" + ev] && streamWraps.indexOf(ev) !== -1) me._parser["on" + ev] = function() {
              var args = arguments.length === 1 ? [arguments[0]] : Array.apply(null, arguments);
              args.splice(0, 0, ev);
              me.emit.apply(me, args);
            };
            return Stream.prototype.on.call(me, ev, handler);
          };
          var CDATAre = /^\[CDATA\[$/i;
          var DOCTYPEre = /^DOCTYPE$/i;
          var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
          var XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";
          var rootNS = {
            xml: XML_NAMESPACE,
            xmlns: XMLNS_NAMESPACE
          };
          var nameStart = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
          var nameBody = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
          var entityStart = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
          var entityBody = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
          function isWhitespace(c) {
            return c === " " || c === "\n" || c === "\r" || c === "	";
          }
          function isQuote(c) {
            return c === '"' || c === "'";
          }
          function isAttribEnd(c) {
            return c === ">" || isWhitespace(c);
          }
          function isMatch(regex, c) {
            return regex.test(c);
          }
          function notMatch(regex, c) {
            return !isMatch(regex, c);
          }
          var S = 0;
          sax.STATE = {
            BEGIN: S++,
            BEGIN_WHITESPACE: S++,
            TEXT: S++,
            TEXT_ENTITY: S++,
            OPEN_WAKA: S++,
            SGML_DECL: S++,
            SGML_DECL_QUOTED: S++,
            DOCTYPE: S++,
            DOCTYPE_QUOTED: S++,
            DOCTYPE_DTD: S++,
            DOCTYPE_DTD_QUOTED: S++,
            COMMENT_STARTING: S++,
            COMMENT: S++,
            COMMENT_ENDING: S++,
            COMMENT_ENDED: S++,
            CDATA: S++,
            CDATA_ENDING: S++,
            CDATA_ENDING_2: S++,
            PROC_INST: S++,
            PROC_INST_BODY: S++,
            PROC_INST_ENDING: S++,
            OPEN_TAG: S++,
            OPEN_TAG_SLASH: S++,
            ATTRIB: S++,
            ATTRIB_NAME: S++,
            ATTRIB_NAME_SAW_WHITE: S++,
            ATTRIB_VALUE: S++,
            ATTRIB_VALUE_QUOTED: S++,
            ATTRIB_VALUE_CLOSED: S++,
            ATTRIB_VALUE_UNQUOTED: S++,
            ATTRIB_VALUE_ENTITY_Q: S++,
            ATTRIB_VALUE_ENTITY_U: S++,
            CLOSE_TAG: S++,
            CLOSE_TAG_SAW_WHITE: S++,
            SCRIPT: S++,
            SCRIPT_ENDING: S++
          };
          sax.XML_ENTITIES = Object.assign(/* @__PURE__ */ Object.create(null), {
            amp: "&",
            gt: ">",
            lt: "<",
            quot: '"',
            apos: "'"
          });
          sax.ENTITIES = Object.assign(/* @__PURE__ */ Object.create(null), {
            amp: "&",
            gt: ">",
            lt: "<",
            quot: '"',
            apos: "'",
            AElig: 198,
            Aacute: 193,
            Acirc: 194,
            Agrave: 192,
            Aring: 197,
            Atilde: 195,
            Auml: 196,
            Ccedil: 199,
            ETH: 208,
            Eacute: 201,
            Ecirc: 202,
            Egrave: 200,
            Euml: 203,
            Iacute: 205,
            Icirc: 206,
            Igrave: 204,
            Iuml: 207,
            Ntilde: 209,
            Oacute: 211,
            Ocirc: 212,
            Ograve: 210,
            Oslash: 216,
            Otilde: 213,
            Ouml: 214,
            THORN: 222,
            Uacute: 218,
            Ucirc: 219,
            Ugrave: 217,
            Uuml: 220,
            Yacute: 221,
            aacute: 225,
            acirc: 226,
            aelig: 230,
            agrave: 224,
            aring: 229,
            atilde: 227,
            auml: 228,
            ccedil: 231,
            eacute: 233,
            ecirc: 234,
            egrave: 232,
            eth: 240,
            euml: 235,
            iacute: 237,
            icirc: 238,
            igrave: 236,
            iuml: 239,
            ntilde: 241,
            oacute: 243,
            ocirc: 244,
            ograve: 242,
            oslash: 248,
            otilde: 245,
            ouml: 246,
            szlig: 223,
            thorn: 254,
            uacute: 250,
            ucirc: 251,
            ugrave: 249,
            uuml: 252,
            yacute: 253,
            yuml: 255,
            copy: 169,
            reg: 174,
            nbsp: 160,
            iexcl: 161,
            cent: 162,
            pound: 163,
            curren: 164,
            yen: 165,
            brvbar: 166,
            sect: 167,
            uml: 168,
            ordf: 170,
            laquo: 171,
            not: 172,
            shy: 173,
            macr: 175,
            deg: 176,
            plusmn: 177,
            sup1: 185,
            sup2: 178,
            sup3: 179,
            acute: 180,
            micro: 181,
            para: 182,
            middot: 183,
            cedil: 184,
            ordm: 186,
            raquo: 187,
            frac14: 188,
            frac12: 189,
            frac34: 190,
            iquest: 191,
            times: 215,
            divide: 247,
            OElig: 338,
            oelig: 339,
            Scaron: 352,
            scaron: 353,
            Yuml: 376,
            fnof: 402,
            circ: 710,
            tilde: 732,
            Alpha: 913,
            Beta: 914,
            Gamma: 915,
            Delta: 916,
            Epsilon: 917,
            Zeta: 918,
            Eta: 919,
            Theta: 920,
            Iota: 921,
            Kappa: 922,
            Lambda: 923,
            Mu: 924,
            Nu: 925,
            Xi: 926,
            Omicron: 927,
            Pi: 928,
            Rho: 929,
            Sigma: 931,
            Tau: 932,
            Upsilon: 933,
            Phi: 934,
            Chi: 935,
            Psi: 936,
            Omega: 937,
            alpha: 945,
            beta: 946,
            gamma: 947,
            delta: 948,
            epsilon: 949,
            zeta: 950,
            eta: 951,
            theta: 952,
            iota: 953,
            kappa: 954,
            lambda: 955,
            mu: 956,
            nu: 957,
            xi: 958,
            omicron: 959,
            pi: 960,
            rho: 961,
            sigmaf: 962,
            sigma: 963,
            tau: 964,
            upsilon: 965,
            phi: 966,
            chi: 967,
            psi: 968,
            omega: 969,
            thetasym: 977,
            upsih: 978,
            piv: 982,
            ensp: 8194,
            emsp: 8195,
            thinsp: 8201,
            zwnj: 8204,
            zwj: 8205,
            lrm: 8206,
            rlm: 8207,
            ndash: 8211,
            mdash: 8212,
            lsquo: 8216,
            rsquo: 8217,
            sbquo: 8218,
            ldquo: 8220,
            rdquo: 8221,
            bdquo: 8222,
            dagger: 8224,
            Dagger: 8225,
            bull: 8226,
            hellip: 8230,
            permil: 8240,
            prime: 8242,
            Prime: 8243,
            lsaquo: 8249,
            rsaquo: 8250,
            oline: 8254,
            frasl: 8260,
            euro: 8364,
            image: 8465,
            weierp: 8472,
            real: 8476,
            trade: 8482,
            alefsym: 8501,
            larr: 8592,
            uarr: 8593,
            rarr: 8594,
            darr: 8595,
            harr: 8596,
            crarr: 8629,
            lArr: 8656,
            uArr: 8657,
            rArr: 8658,
            dArr: 8659,
            hArr: 8660,
            forall: 8704,
            part: 8706,
            exist: 8707,
            empty: 8709,
            nabla: 8711,
            isin: 8712,
            notin: 8713,
            ni: 8715,
            prod: 8719,
            sum: 8721,
            minus: 8722,
            lowast: 8727,
            radic: 8730,
            prop: 8733,
            infin: 8734,
            ang: 8736,
            and: 8743,
            or: 8744,
            cap: 8745,
            cup: 8746,
            int: 8747,
            there4: 8756,
            sim: 8764,
            cong: 8773,
            asymp: 8776,
            ne: 8800,
            equiv: 8801,
            le: 8804,
            ge: 8805,
            sub: 8834,
            sup: 8835,
            nsub: 8836,
            sube: 8838,
            supe: 8839,
            oplus: 8853,
            otimes: 8855,
            perp: 8869,
            sdot: 8901,
            lceil: 8968,
            rceil: 8969,
            lfloor: 8970,
            rfloor: 8971,
            lang: 9001,
            rang: 9002,
            loz: 9674,
            spades: 9824,
            clubs: 9827,
            hearts: 9829,
            diams: 9830
          });
          Object.keys(sax.ENTITIES).forEach(function(key) {
            var e = sax.ENTITIES[key];
            var s2 = typeof e === "number" ? String.fromCharCode(e) : e;
            sax.ENTITIES[key] = s2;
          });
          for (var s in sax.STATE) sax.STATE[sax.STATE[s]] = s;
          S = sax.STATE;
          function emit(parser, event, data) {
            parser[event] && parser[event](data);
          }
          function getDeclaredEncoding(body) {
            var match = body && body.match(/(?:^|\s)encoding\s*=\s*(['"])([^'"]+)\1/i);
            return match ? match[2] : null;
          }
          function normalizeEncodingName(encoding) {
            if (!encoding) return null;
            return encoding.toLowerCase().replace(/[^a-z0-9]/g, "");
          }
          function encodingsMatch(detectedEncoding, declaredEncoding) {
            const detected = normalizeEncodingName(detectedEncoding);
            const declared = normalizeEncodingName(declaredEncoding);
            if (!detected || !declared) return true;
            if (declared === "utf16") return detected === "utf16le" || detected === "utf16be";
            return detected === declared;
          }
          function validateXmlDeclarationEncoding(parser, data) {
            if (!parser.strict || !parser.encoding || !data || data.name !== "xml") return;
            var declaredEncoding = getDeclaredEncoding(data.body);
            if (declaredEncoding && !encodingsMatch(parser.encoding, declaredEncoding)) strictFail(parser, "XML declaration encoding " + declaredEncoding + " does not match detected stream encoding " + parser.encoding.toUpperCase());
          }
          function emitNode(parser, nodeType, data) {
            if (parser.textNode) closeText(parser);
            emit(parser, nodeType, data);
          }
          function closeText(parser) {
            parser.textNode = textopts(parser.opt, parser.textNode);
            if (parser.textNode) emit(parser, "ontext", parser.textNode);
            parser.textNode = "";
          }
          function textopts(opt, text) {
            if (opt.trim) text = text.trim();
            if (opt.normalize) text = text.replace(/\s+/g, " ");
            return text;
          }
          function error(parser, er) {
            closeText(parser);
            if (parser.trackPosition) er += "\nLine: " + parser.line + "\nColumn: " + parser.column + "\nChar: " + parser.c;
            er = new Error(er);
            parser.error = er;
            emit(parser, "onerror", er);
            return parser;
          }
          function end(parser) {
            if (parser.sawRoot && !parser.closedRoot) strictFail(parser, "Unclosed root tag");
            if (parser.state !== S.BEGIN && parser.state !== S.BEGIN_WHITESPACE && parser.state !== S.TEXT) error(parser, "Unexpected end");
            closeText(parser);
            parser.c = "";
            parser.closed = true;
            emit(parser, "onend");
            SAXParser.call(parser, parser.strict, parser.opt);
            return parser;
          }
          function strictFail(parser, message) {
            if (typeof parser !== "object" || !(parser instanceof SAXParser)) throw new Error("bad call to strictFail");
            if (parser.strict) error(parser, message);
          }
          function newTag(parser) {
            if (!parser.strict) parser.tagName = parser.tagName[parser.looseCase]();
            var parent = parser.tags[parser.tags.length - 1] || parser;
            var tag = parser.tag = {
              name: parser.tagName,
              attributes: {}
            };
            if (parser.opt.xmlns) tag.ns = parent.ns;
            parser.attribList.length = 0;
            emitNode(parser, "onopentagstart", tag);
          }
          function qname(name, attribute) {
            var qualName = name.indexOf(":") < 0 ? ["", name] : name.split(":");
            var prefix = qualName[0];
            var local = qualName[1];
            if (attribute && name === "xmlns") {
              prefix = "xmlns";
              local = "";
            }
            return {
              prefix,
              local
            };
          }
          function attrib(parser) {
            if (!parser.strict) parser.attribName = parser.attribName[parser.looseCase]();
            if (parser.attribList.indexOf(parser.attribName) !== -1 || parser.tag.attributes.hasOwnProperty(parser.attribName)) {
              parser.attribName = parser.attribValue = "";
              return;
            }
            if (parser.opt.xmlns) {
              var qn = qname(parser.attribName, true);
              var prefix = qn.prefix;
              var local = qn.local;
              if (prefix === "xmlns") {
                if (local === "xml" && parser.attribValue !== XML_NAMESPACE) strictFail(parser, "xml: prefix must be bound to " + XML_NAMESPACE + "\nActual: " + parser.attribValue);
                else if (local === "xmlns" && parser.attribValue !== XMLNS_NAMESPACE) strictFail(parser, "xmlns: prefix must be bound to " + XMLNS_NAMESPACE + "\nActual: " + parser.attribValue);
                else {
                  var tag = parser.tag;
                  var parent = parser.tags[parser.tags.length - 1] || parser;
                  if (tag.ns === parent.ns) tag.ns = Object.create(parent.ns);
                  tag.ns[local] = parser.attribValue;
                }
              }
              parser.attribList.push([parser.attribName, parser.attribValue]);
            } else {
              parser.tag.attributes[parser.attribName] = parser.attribValue;
              emitNode(parser, "onattribute", {
                name: parser.attribName,
                value: parser.attribValue
              });
            }
            parser.attribName = parser.attribValue = "";
          }
          function openTag(parser, selfClosing) {
            if (parser.opt.xmlns) {
              var tag = parser.tag;
              var qn = qname(parser.tagName);
              tag.prefix = qn.prefix;
              tag.local = qn.local;
              tag.uri = tag.ns[qn.prefix] || "";
              if (tag.prefix && !tag.uri) {
                strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(parser.tagName));
                tag.uri = qn.prefix;
              }
              var parent = parser.tags[parser.tags.length - 1] || parser;
              if (tag.ns && parent.ns !== tag.ns) Object.keys(tag.ns).forEach(function(p) {
                emitNode(parser, "onopennamespace", {
                  prefix: p,
                  uri: tag.ns[p]
                });
              });
              for (var i = 0, l = parser.attribList.length; i < l; i++) {
                var nv = parser.attribList[i];
                var name = nv[0];
                var value = nv[1];
                var qualName = qname(name, true);
                var prefix = qualName.prefix;
                var local = qualName.local;
                var uri = prefix === "" ? "" : tag.ns[prefix] || "";
                var a = {
                  name,
                  value,
                  prefix,
                  local,
                  uri
                };
                if (prefix && prefix !== "xmlns" && !uri) {
                  strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(prefix));
                  a.uri = prefix;
                }
                parser.tag.attributes[name] = a;
                emitNode(parser, "onattribute", a);
              }
              parser.attribList.length = 0;
            }
            parser.tag.isSelfClosing = !!selfClosing;
            parser.sawRoot = true;
            parser.tags.push(parser.tag);
            emitNode(parser, "onopentag", parser.tag);
            if (!selfClosing) {
              if (!parser.noscript && parser.tagName.toLowerCase() === "script") parser.state = S.SCRIPT;
              else parser.state = S.TEXT;
              parser.tag = null;
              parser.tagName = "";
            }
            parser.attribName = parser.attribValue = "";
            parser.attribList.length = 0;
          }
          function closeTag(parser) {
            if (!parser.tagName) {
              strictFail(parser, "Weird empty close tag.");
              parser.textNode += "</>";
              parser.state = S.TEXT;
              return;
            }
            if (parser.script) {
              if (parser.tagName !== "script") {
                parser.script += "</" + parser.tagName + ">";
                parser.tagName = "";
                parser.state = S.SCRIPT;
                return;
              }
              emitNode(parser, "onscript", parser.script);
              parser.script = "";
            }
            var t = parser.tags.length;
            var tagName = parser.tagName;
            if (!parser.strict) tagName = tagName[parser.looseCase]();
            var closeTo = tagName;
            while (t--) if (parser.tags[t].name !== closeTo) strictFail(parser, "Unexpected close tag");
            else break;
            if (t < 0) {
              strictFail(parser, "Unmatched closing tag: " + parser.tagName);
              parser.textNode += "</" + parser.tagName + ">";
              parser.state = S.TEXT;
              return;
            }
            parser.tagName = tagName;
            var s2 = parser.tags.length;
            while (s2-- > t) {
              var tag = parser.tag = parser.tags.pop();
              parser.tagName = parser.tag.name;
              emitNode(parser, "onclosetag", parser.tagName);
              var x = {};
              for (var i in tag.ns) x[i] = tag.ns[i];
              var parent = parser.tags[parser.tags.length - 1] || parser;
              if (parser.opt.xmlns && tag.ns !== parent.ns) Object.keys(tag.ns).forEach(function(p) {
                var n = tag.ns[p];
                emitNode(parser, "onclosenamespace", {
                  prefix: p,
                  uri: n
                });
              });
            }
            if (t === 0) parser.closedRoot = true;
            parser.tagName = parser.attribValue = parser.attribName = "";
            parser.attribList.length = 0;
            parser.state = S.TEXT;
          }
          function parseEntity(parser) {
            var entity = parser.entity;
            var entityLC = entity.toLowerCase();
            var num;
            var numStr = "";
            if (parser.ENTITIES[entity]) return parser.ENTITIES[entity];
            if (parser.ENTITIES[entityLC]) return parser.ENTITIES[entityLC];
            entity = entityLC;
            if (entity.charAt(0) === "#") {
              if (entity.charAt(1) === "x") {
                entity = entity.slice(2);
                num = parseInt(entity, 16);
                numStr = num.toString(16);
              } else {
                entity = entity.slice(1);
                num = parseInt(entity, 10);
                numStr = num.toString(10);
              }
            }
            entity = entity.replace(/^0+/, "");
            if (isNaN(num) || numStr.toLowerCase() !== entity || num < 0 || num > 1114111 || !isXmlChar(num)) {
              strictFail(parser, "Invalid character entity");
              return "&" + parser.entity + ";";
            }
            return String.fromCodePoint(num);
          }
          function isXmlChar(num) {
            return num === 9 || num === 10 || num === 13 || num >= 32 && num <= 55295 || num >= 57344 && num <= 65533 || num >= 65536 && num <= 1114111;
          }
          function beginWhiteSpace(parser, c) {
            if (c === "<") {
              parser.state = S.OPEN_WAKA;
              parser.startTagPosition = parser.position;
            } else if (!isWhitespace(c)) {
              strictFail(parser, "Non-whitespace before first tag.");
              parser.textNode = c;
              parser.state = S.TEXT;
            }
          }
          function charAt(chunk, i) {
            var result = "";
            if (i < chunk.length) result = chunk.charAt(i);
            return result;
          }
          function write(chunk) {
            var parser = this;
            if (this.error) throw this.error;
            if (parser.closed) return error(parser, "Cannot write after close. Assign an onready handler.");
            if (chunk === null) return end(parser);
            if (typeof chunk === "object") chunk = chunk.toString();
            var i = 0;
            var c = "";
            while (true) {
              c = charAt(chunk, i++);
              parser.c = c;
              if (!c) break;
              if (parser.trackPosition) {
                parser.position++;
                if (c === "\n") {
                  parser.line++;
                  parser.column = 0;
                } else parser.column++;
              }
              switch (parser.state) {
                case S.BEGIN:
                  parser.state = S.BEGIN_WHITESPACE;
                  if (c === "\uFEFF") continue;
                  beginWhiteSpace(parser, c);
                  continue;
                case S.BEGIN_WHITESPACE:
                  beginWhiteSpace(parser, c);
                  continue;
                case S.TEXT:
                  if (parser.sawRoot && !parser.closedRoot) {
                    var starti = i - 1;
                    while (c && c !== "<" && c !== "&") {
                      c = charAt(chunk, i++);
                      if (c && parser.trackPosition) {
                        parser.position++;
                        if (c === "\n") {
                          parser.line++;
                          parser.column = 0;
                        } else parser.column++;
                      }
                    }
                    parser.textNode += chunk.substring(starti, i - 1);
                  }
                  if (c === "<" && !(parser.sawRoot && parser.closedRoot && !parser.strict)) {
                    parser.state = S.OPEN_WAKA;
                    parser.startTagPosition = parser.position;
                  } else {
                    if (!isWhitespace(c) && (!parser.sawRoot || parser.closedRoot)) strictFail(parser, "Text data outside of root node.");
                    if (c === "&") parser.state = S.TEXT_ENTITY;
                    else parser.textNode += c;
                  }
                  continue;
                case S.SCRIPT:
                  if (c === "<") parser.state = S.SCRIPT_ENDING;
                  else parser.script += c;
                  continue;
                case S.SCRIPT_ENDING:
                  if (c === "/") parser.state = S.CLOSE_TAG;
                  else {
                    parser.script += "<" + c;
                    parser.state = S.SCRIPT;
                  }
                  continue;
                case S.OPEN_WAKA:
                  if (c === "!") {
                    parser.state = S.SGML_DECL;
                    parser.sgmlDecl = "";
                  } else if (isWhitespace(c)) {
                  } else if (isMatch(nameStart, c)) {
                    parser.state = S.OPEN_TAG;
                    parser.tagName = c;
                  } else if (c === "/") {
                    parser.state = S.CLOSE_TAG;
                    parser.tagName = "";
                  } else if (c === "?") {
                    parser.state = S.PROC_INST;
                    parser.procInstName = parser.procInstBody = "";
                  } else {
                    strictFail(parser, "Unencoded <");
                    if (parser.startTagPosition + 1 < parser.position) {
                      var pad = parser.position - parser.startTagPosition;
                      c = new Array(pad).join(" ") + c;
                    }
                    parser.textNode += "<" + c;
                    parser.state = S.TEXT;
                  }
                  continue;
                case S.SGML_DECL:
                  if (parser.sgmlDecl + c === "--") {
                    parser.state = S.COMMENT;
                    parser.comment = "";
                    parser.sgmlDecl = "";
                    continue;
                  }
                  if (parser.doctype && parser.doctype !== true && parser.sgmlDecl) {
                    parser.state = S.DOCTYPE_DTD;
                    parser.doctype += "<!" + parser.sgmlDecl + c;
                    parser.sgmlDecl = "";
                  } else if (CDATAre.test(parser.sgmlDecl + c)) {
                    emitNode(parser, "onopencdata");
                    parser.state = S.CDATA;
                    parser.sgmlDecl = "";
                    parser.cdata = "";
                  } else if (DOCTYPEre.test(parser.sgmlDecl + c)) {
                    parser.state = S.DOCTYPE;
                    if (parser.doctype || parser.sawRoot) strictFail(parser, "Inappropriately located doctype declaration");
                    parser.doctype = "";
                    parser.sgmlDecl = "";
                  } else if (c === ">") {
                    emitNode(parser, "onsgmldeclaration", parser.sgmlDecl);
                    parser.sgmlDecl = "";
                    parser.state = S.TEXT;
                  } else if (isQuote(c)) {
                    parser.state = S.SGML_DECL_QUOTED;
                    parser.sgmlDecl += c;
                  } else parser.sgmlDecl += c;
                  continue;
                case S.SGML_DECL_QUOTED:
                  if (c === parser.q) {
                    parser.state = S.SGML_DECL;
                    parser.q = "";
                  }
                  parser.sgmlDecl += c;
                  continue;
                case S.DOCTYPE:
                  if (c === ">") {
                    parser.state = S.TEXT;
                    emitNode(parser, "ondoctype", parser.doctype);
                    parser.doctype = true;
                  } else {
                    parser.doctype += c;
                    if (c === "[") parser.state = S.DOCTYPE_DTD;
                    else if (isQuote(c)) {
                      parser.state = S.DOCTYPE_QUOTED;
                      parser.q = c;
                    }
                  }
                  continue;
                case S.DOCTYPE_QUOTED:
                  parser.doctype += c;
                  if (c === parser.q) {
                    parser.q = "";
                    parser.state = S.DOCTYPE;
                  }
                  continue;
                case S.DOCTYPE_DTD:
                  if (c === "]") {
                    parser.doctype += c;
                    parser.state = S.DOCTYPE;
                  } else if (c === "<") {
                    parser.state = S.OPEN_WAKA;
                    parser.startTagPosition = parser.position;
                  } else if (isQuote(c)) {
                    parser.doctype += c;
                    parser.state = S.DOCTYPE_DTD_QUOTED;
                    parser.q = c;
                  } else parser.doctype += c;
                  continue;
                case S.DOCTYPE_DTD_QUOTED:
                  parser.doctype += c;
                  if (c === parser.q) {
                    parser.state = S.DOCTYPE_DTD;
                    parser.q = "";
                  }
                  continue;
                case S.COMMENT:
                  if (c === "-") parser.state = S.COMMENT_ENDING;
                  else parser.comment += c;
                  continue;
                case S.COMMENT_ENDING:
                  if (c === "-") {
                    parser.state = S.COMMENT_ENDED;
                    parser.comment = textopts(parser.opt, parser.comment);
                    if (parser.comment) emitNode(parser, "oncomment", parser.comment);
                    parser.comment = "";
                  } else {
                    parser.comment += "-" + c;
                    parser.state = S.COMMENT;
                  }
                  continue;
                case S.COMMENT_ENDED:
                  if (c !== ">") {
                    strictFail(parser, "Malformed comment");
                    parser.comment += "--" + c;
                    parser.state = S.COMMENT;
                  } else if (parser.doctype && parser.doctype !== true) parser.state = S.DOCTYPE_DTD;
                  else parser.state = S.TEXT;
                  continue;
                case S.CDATA:
                  var starti = i - 1;
                  while (c && c !== "]") {
                    c = charAt(chunk, i++);
                    if (c && parser.trackPosition) {
                      parser.position++;
                      if (c === "\n") {
                        parser.line++;
                        parser.column = 0;
                      } else parser.column++;
                    }
                  }
                  parser.cdata += chunk.substring(starti, i - 1);
                  if (c === "]") parser.state = S.CDATA_ENDING;
                  continue;
                case S.CDATA_ENDING:
                  if (c === "]") parser.state = S.CDATA_ENDING_2;
                  else {
                    parser.cdata += "]" + c;
                    parser.state = S.CDATA;
                  }
                  continue;
                case S.CDATA_ENDING_2:
                  if (c === ">") {
                    if (parser.cdata) emitNode(parser, "oncdata", parser.cdata);
                    emitNode(parser, "onclosecdata");
                    parser.cdata = "";
                    parser.state = S.TEXT;
                  } else if (c === "]") parser.cdata += "]";
                  else {
                    parser.cdata += "]]" + c;
                    parser.state = S.CDATA;
                  }
                  continue;
                case S.PROC_INST:
                  if (c === "?") parser.state = S.PROC_INST_ENDING;
                  else if (isWhitespace(c)) parser.state = S.PROC_INST_BODY;
                  else parser.procInstName += c;
                  continue;
                case S.PROC_INST_BODY:
                  if (!parser.procInstBody && isWhitespace(c)) continue;
                  else if (c === "?") parser.state = S.PROC_INST_ENDING;
                  else parser.procInstBody += c;
                  continue;
                case S.PROC_INST_ENDING:
                  if (c === ">") {
                    const procInstEndData = {
                      name: parser.procInstName,
                      body: parser.procInstBody
                    };
                    validateXmlDeclarationEncoding(parser, procInstEndData);
                    emitNode(parser, "onprocessinginstruction", procInstEndData);
                    parser.procInstName = parser.procInstBody = "";
                    parser.state = S.TEXT;
                  } else {
                    parser.procInstBody += "?" + c;
                    parser.state = S.PROC_INST_BODY;
                  }
                  continue;
                case S.OPEN_TAG:
                  if (isMatch(nameBody, c)) parser.tagName += c;
                  else {
                    newTag(parser);
                    if (c === ">") openTag(parser);
                    else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
                    else {
                      if (!isWhitespace(c)) strictFail(parser, "Invalid character in tag name");
                      parser.state = S.ATTRIB;
                    }
                  }
                  continue;
                case S.OPEN_TAG_SLASH:
                  if (c === ">") {
                    openTag(parser, true);
                    closeTag(parser);
                  } else {
                    strictFail(parser, "Forward-slash in opening tag not followed by >");
                    parser.state = S.ATTRIB;
                  }
                  continue;
                case S.ATTRIB:
                  if (isWhitespace(c)) continue;
                  else if (c === ">") openTag(parser);
                  else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
                  else if (isMatch(nameStart, c)) {
                    parser.attribName = c;
                    parser.attribValue = "";
                    parser.state = S.ATTRIB_NAME;
                  } else strictFail(parser, "Invalid attribute name");
                  continue;
                case S.ATTRIB_NAME:
                  if (c === "=") parser.state = S.ATTRIB_VALUE;
                  else if (c === ">") {
                    strictFail(parser, "Attribute without value");
                    parser.attribValue = parser.attribName;
                    attrib(parser);
                    openTag(parser);
                  } else if (isWhitespace(c)) parser.state = S.ATTRIB_NAME_SAW_WHITE;
                  else if (isMatch(nameBody, c)) parser.attribName += c;
                  else strictFail(parser, "Invalid attribute name");
                  continue;
                case S.ATTRIB_NAME_SAW_WHITE:
                  if (c === "=") parser.state = S.ATTRIB_VALUE;
                  else if (isWhitespace(c)) continue;
                  else {
                    strictFail(parser, "Attribute without value");
                    parser.tag.attributes[parser.attribName] = "";
                    parser.attribValue = "";
                    emitNode(parser, "onattribute", {
                      name: parser.attribName,
                      value: ""
                    });
                    parser.attribName = "";
                    if (c === ">") openTag(parser);
                    else if (isMatch(nameStart, c)) {
                      parser.attribName = c;
                      parser.state = S.ATTRIB_NAME;
                    } else {
                      strictFail(parser, "Invalid attribute name");
                      parser.state = S.ATTRIB;
                    }
                  }
                  continue;
                case S.ATTRIB_VALUE:
                  if (isWhitespace(c)) continue;
                  else if (isQuote(c)) {
                    parser.q = c;
                    parser.state = S.ATTRIB_VALUE_QUOTED;
                  } else {
                    if (!parser.opt.unquotedAttributeValues) error(parser, "Unquoted attribute value");
                    parser.state = S.ATTRIB_VALUE_UNQUOTED;
                    parser.attribValue = c;
                  }
                  continue;
                case S.ATTRIB_VALUE_QUOTED:
                  if (c !== parser.q) {
                    if (c === "&") parser.state = S.ATTRIB_VALUE_ENTITY_Q;
                    else parser.attribValue += c;
                    continue;
                  }
                  attrib(parser);
                  parser.q = "";
                  parser.state = S.ATTRIB_VALUE_CLOSED;
                  continue;
                case S.ATTRIB_VALUE_CLOSED:
                  if (isWhitespace(c)) parser.state = S.ATTRIB;
                  else if (c === ">") openTag(parser);
                  else if (c === "/") parser.state = S.OPEN_TAG_SLASH;
                  else if (isMatch(nameStart, c)) {
                    strictFail(parser, "No whitespace between attributes");
                    parser.attribName = c;
                    parser.attribValue = "";
                    parser.state = S.ATTRIB_NAME;
                  } else strictFail(parser, "Invalid attribute name");
                  continue;
                case S.ATTRIB_VALUE_UNQUOTED:
                  if (!isAttribEnd(c)) {
                    if (c === "&") parser.state = S.ATTRIB_VALUE_ENTITY_U;
                    else parser.attribValue += c;
                    continue;
                  }
                  attrib(parser);
                  if (c === ">") openTag(parser);
                  else parser.state = S.ATTRIB;
                  continue;
                case S.CLOSE_TAG:
                  if (!parser.tagName) {
                    if (isWhitespace(c)) continue;
                    else if (notMatch(nameStart, c)) {
                      if (parser.script) {
                        parser.script += "</" + c;
                        parser.state = S.SCRIPT;
                      } else strictFail(parser, "Invalid tagname in closing tag.");
                    } else parser.tagName = c;
                  } else if (c === ">") closeTag(parser);
                  else if (isMatch(nameBody, c)) parser.tagName += c;
                  else if (parser.script) {
                    parser.script += "</" + parser.tagName + c;
                    parser.tagName = "";
                    parser.state = S.SCRIPT;
                  } else {
                    if (!isWhitespace(c)) strictFail(parser, "Invalid tagname in closing tag");
                    parser.state = S.CLOSE_TAG_SAW_WHITE;
                  }
                  continue;
                case S.CLOSE_TAG_SAW_WHITE:
                  if (isWhitespace(c)) continue;
                  if (c === ">") closeTag(parser);
                  else strictFail(parser, "Invalid characters in closing tag");
                  continue;
                case S.TEXT_ENTITY:
                case S.ATTRIB_VALUE_ENTITY_Q:
                case S.ATTRIB_VALUE_ENTITY_U:
                  var returnState;
                  var buffer;
                  switch (parser.state) {
                    case S.TEXT_ENTITY:
                      returnState = S.TEXT;
                      buffer = "textNode";
                      break;
                    case S.ATTRIB_VALUE_ENTITY_Q:
                      returnState = S.ATTRIB_VALUE_QUOTED;
                      buffer = "attribValue";
                      break;
                    case S.ATTRIB_VALUE_ENTITY_U:
                      returnState = S.ATTRIB_VALUE_UNQUOTED;
                      buffer = "attribValue";
                  }
                  if (c === ";") {
                    var parsedEntity = parseEntity(parser);
                    if (parser.opt.unparsedEntities && !Object.values(sax.XML_ENTITIES).includes(parsedEntity)) {
                      if ((parser.entityCount += 1) > parser.opt.maxEntityCount) error(parser, "Parsed entity count exceeds max entity count");
                      if ((parser.entityDepth += 1) > parser.opt.maxEntityDepth) error(parser, "Parsed entity depth exceeds max entity depth");
                      parser.entity = "";
                      parser.state = returnState;
                      parser.write(parsedEntity);
                      parser.entityDepth -= 1;
                    } else {
                      parser[buffer] += parsedEntity;
                      parser.entity = "";
                      parser.state = returnState;
                    }
                  } else if (isMatch(parser.entity.length ? entityBody : entityStart, c)) parser.entity += c;
                  else {
                    strictFail(parser, "Invalid character in entity name");
                    parser[buffer] += "&" + parser.entity + c;
                    parser.entity = "";
                    parser.state = returnState;
                  }
                  continue;
                default:
                  throw new Error(parser, "Unknown state: " + parser.state);
              }
            }
            if (parser.position >= parser.bufferCheckPosition) checkBufferLength(parser);
            return parser;
          }
          if (!String.fromCodePoint) (function() {
            var stringFromCharCode = String.fromCharCode;
            var floor = Math.floor;
            var fromCodePoint = function() {
              var MAX_SIZE = 16384;
              var codeUnits = [];
              var highSurrogate;
              var lowSurrogate;
              var index = -1;
              var length = arguments.length;
              if (!length) return "";
              var result = "";
              while (++index < length) {
                var codePoint = Number(arguments[index]);
                if (!isFinite(codePoint) || codePoint < 0 || codePoint > 1114111 || floor(codePoint) !== codePoint) throw RangeError("Invalid code point: " + codePoint);
                if (codePoint <= 65535) codeUnits.push(codePoint);
                else {
                  codePoint -= 65536;
                  highSurrogate = (codePoint >> 10) + 55296;
                  lowSurrogate = codePoint % 1024 + 56320;
                  codeUnits.push(highSurrogate, lowSurrogate);
                }
                if (index + 1 === length || codeUnits.length > MAX_SIZE) {
                  result += stringFromCharCode.apply(null, codeUnits);
                  codeUnits.length = 0;
                }
              }
              return result;
            };
            if (Object.defineProperty) Object.defineProperty(String, "fromCodePoint", {
              value: fromCodePoint,
              configurable: true,
              writable: true
            });
            else String.fromCodePoint = fromCodePoint;
          })();
        })(typeof exports === "undefined" ? this$1.sax = {} : exports);
      }));
      require_array_helper = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        module.exports = { isArray: function(value) {
          if (Array.isArray) return Array.isArray(value);
          return Object.prototype.toString.call(value) === "[object Array]";
        } };
      }));
      require_options_helper = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var isArray = require_array_helper().isArray;
        module.exports = {
          copyOptions: function(options) {
            var key, copy = {};
            for (key in options) if (options.hasOwnProperty(key)) copy[key] = options[key];
            return copy;
          },
          ensureFlagExists: function(item, options) {
            if (!(item in options) || typeof options[item] !== "boolean") options[item] = false;
          },
          ensureSpacesExists: function(options) {
            if (!("spaces" in options) || typeof options.spaces !== "number" && typeof options.spaces !== "string") options.spaces = 0;
          },
          ensureAlwaysArrayExists: function(options) {
            if (!("alwaysArray" in options) || typeof options.alwaysArray !== "boolean" && !isArray(options.alwaysArray)) options.alwaysArray = false;
          },
          ensureKeyExists: function(key, options) {
            if (!(key + "Key" in options) || typeof options[key + "Key"] !== "string") options[key + "Key"] = options.compact ? "_" + key : key;
          },
          checkFnExists: function(key, options) {
            return key + "Fn" in options;
          }
        };
      }));
      require_xml2js = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var sax = require_sax();
        var expat = {
          on: function() {
          },
          parse: function() {
          }
        };
        var helper = require_options_helper();
        var isArray = require_array_helper().isArray;
        var options;
        var pureJsParser = true;
        var currentElement;
        function validateOptions(userOptions) {
          options = helper.copyOptions(userOptions);
          helper.ensureFlagExists("ignoreDeclaration", options);
          helper.ensureFlagExists("ignoreInstruction", options);
          helper.ensureFlagExists("ignoreAttributes", options);
          helper.ensureFlagExists("ignoreText", options);
          helper.ensureFlagExists("ignoreComment", options);
          helper.ensureFlagExists("ignoreCdata", options);
          helper.ensureFlagExists("ignoreDoctype", options);
          helper.ensureFlagExists("compact", options);
          helper.ensureFlagExists("alwaysChildren", options);
          helper.ensureFlagExists("addParent", options);
          helper.ensureFlagExists("trim", options);
          helper.ensureFlagExists("nativeType", options);
          helper.ensureFlagExists("nativeTypeAttributes", options);
          helper.ensureFlagExists("sanitize", options);
          helper.ensureFlagExists("instructionHasAttributes", options);
          helper.ensureFlagExists("captureSpacesBetweenElements", options);
          helper.ensureAlwaysArrayExists(options);
          helper.ensureKeyExists("declaration", options);
          helper.ensureKeyExists("instruction", options);
          helper.ensureKeyExists("attributes", options);
          helper.ensureKeyExists("text", options);
          helper.ensureKeyExists("comment", options);
          helper.ensureKeyExists("cdata", options);
          helper.ensureKeyExists("doctype", options);
          helper.ensureKeyExists("type", options);
          helper.ensureKeyExists("name", options);
          helper.ensureKeyExists("elements", options);
          helper.ensureKeyExists("parent", options);
          helper.checkFnExists("doctype", options);
          helper.checkFnExists("instruction", options);
          helper.checkFnExists("cdata", options);
          helper.checkFnExists("comment", options);
          helper.checkFnExists("text", options);
          helper.checkFnExists("instructionName", options);
          helper.checkFnExists("elementName", options);
          helper.checkFnExists("attributeName", options);
          helper.checkFnExists("attributeValue", options);
          helper.checkFnExists("attributes", options);
          return options;
        }
        function nativeType(value) {
          var nValue = Number(value);
          if (!isNaN(nValue)) return nValue;
          var bValue = value.toLowerCase();
          if (bValue === "true") return true;
          else if (bValue === "false") return false;
          return value;
        }
        function addField(type, value) {
          var key;
          if (options.compact) {
            if (!currentElement[options[type + "Key"]] && (isArray(options.alwaysArray) ? options.alwaysArray.indexOf(options[type + "Key"]) !== -1 : options.alwaysArray)) currentElement[options[type + "Key"]] = [];
            if (currentElement[options[type + "Key"]] && !isArray(currentElement[options[type + "Key"]])) currentElement[options[type + "Key"]] = [currentElement[options[type + "Key"]]];
            if (type + "Fn" in options && typeof value === "string") value = options[type + "Fn"](value, currentElement);
            if (type === "instruction" && ("instructionFn" in options || "instructionNameFn" in options)) {
              for (key in value) if (value.hasOwnProperty(key)) {
                if ("instructionFn" in options) value[key] = options.instructionFn(value[key], key, currentElement);
                else {
                  var temp = value[key];
                  delete value[key];
                  value[options.instructionNameFn(key, temp, currentElement)] = temp;
                }
              }
            }
            if (isArray(currentElement[options[type + "Key"]])) currentElement[options[type + "Key"]].push(value);
            else currentElement[options[type + "Key"]] = value;
          } else {
            if (!currentElement[options.elementsKey]) currentElement[options.elementsKey] = [];
            var element = {};
            element[options.typeKey] = type;
            if (type === "instruction") {
              for (key in value) if (value.hasOwnProperty(key)) break;
              element[options.nameKey] = "instructionNameFn" in options ? options.instructionNameFn(key, value, currentElement) : key;
              if (options.instructionHasAttributes) {
                element[options.attributesKey] = value[key][options.attributesKey];
                if ("instructionFn" in options) element[options.attributesKey] = options.instructionFn(element[options.attributesKey], key, currentElement);
              } else {
                if ("instructionFn" in options) value[key] = options.instructionFn(value[key], key, currentElement);
                element[options.instructionKey] = value[key];
              }
            } else {
              if (type + "Fn" in options) value = options[type + "Fn"](value, currentElement);
              element[options[type + "Key"]] = value;
            }
            if (options.addParent) element[options.parentKey] = currentElement;
            currentElement[options.elementsKey].push(element);
          }
        }
        function manipulateAttributes(attributes) {
          if ("attributesFn" in options && attributes) attributes = options.attributesFn(attributes, currentElement);
          if ((options.trim || "attributeValueFn" in options || "attributeNameFn" in options || options.nativeTypeAttributes) && attributes) {
            var key;
            for (key in attributes) if (attributes.hasOwnProperty(key)) {
              if (options.trim) attributes[key] = attributes[key].trim();
              if (options.nativeTypeAttributes) attributes[key] = nativeType(attributes[key]);
              if ("attributeValueFn" in options) attributes[key] = options.attributeValueFn(attributes[key], key, currentElement);
              if ("attributeNameFn" in options) {
                var temp = attributes[key];
                delete attributes[key];
                attributes[options.attributeNameFn(key, attributes[key], currentElement)] = temp;
              }
            }
          }
          return attributes;
        }
        function onInstruction(instruction) {
          var attributes = {};
          if (instruction.body && (instruction.name.toLowerCase() === "xml" || options.instructionHasAttributes)) {
            var attrsRegExp = /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|(\w+))\s*/g;
            var match;
            while ((match = attrsRegExp.exec(instruction.body)) !== null) attributes[match[1]] = match[2] || match[3] || match[4];
            attributes = manipulateAttributes(attributes);
          }
          if (instruction.name.toLowerCase() === "xml") {
            if (options.ignoreDeclaration) return;
            currentElement[options.declarationKey] = {};
            if (Object.keys(attributes).length) currentElement[options.declarationKey][options.attributesKey] = attributes;
            if (options.addParent) currentElement[options.declarationKey][options.parentKey] = currentElement;
          } else {
            if (options.ignoreInstruction) return;
            if (options.trim) instruction.body = instruction.body.trim();
            var value = {};
            if (options.instructionHasAttributes && Object.keys(attributes).length) {
              value[instruction.name] = {};
              value[instruction.name][options.attributesKey] = attributes;
            } else value[instruction.name] = instruction.body;
            addField("instruction", value);
          }
        }
        function onStartElement(name, attributes) {
          var element;
          if (typeof name === "object") {
            attributes = name.attributes;
            name = name.name;
          }
          attributes = manipulateAttributes(attributes);
          if ("elementNameFn" in options) name = options.elementNameFn(name, currentElement);
          if (options.compact) {
            element = {};
            if (!options.ignoreAttributes && attributes && Object.keys(attributes).length) {
              element[options.attributesKey] = {};
              var key;
              for (key in attributes) if (attributes.hasOwnProperty(key)) element[options.attributesKey][key] = attributes[key];
            }
            if (!(name in currentElement) && (isArray(options.alwaysArray) ? options.alwaysArray.indexOf(name) !== -1 : options.alwaysArray)) currentElement[name] = [];
            if (currentElement[name] && !isArray(currentElement[name])) currentElement[name] = [currentElement[name]];
            if (isArray(currentElement[name])) currentElement[name].push(element);
            else currentElement[name] = element;
          } else {
            if (!currentElement[options.elementsKey]) currentElement[options.elementsKey] = [];
            element = {};
            element[options.typeKey] = "element";
            element[options.nameKey] = name;
            if (!options.ignoreAttributes && attributes && Object.keys(attributes).length) element[options.attributesKey] = attributes;
            if (options.alwaysChildren) element[options.elementsKey] = [];
            currentElement[options.elementsKey].push(element);
          }
          element[options.parentKey] = currentElement;
          currentElement = element;
        }
        function onText(text) {
          if (options.ignoreText) return;
          if (!text.trim() && !options.captureSpacesBetweenElements) return;
          if (options.trim) text = text.trim();
          if (options.nativeType) text = nativeType(text);
          if (options.sanitize) text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
          addField("text", text);
        }
        function onComment(comment) {
          if (options.ignoreComment) return;
          if (options.trim) comment = comment.trim();
          addField("comment", comment);
        }
        function onEndElement(name) {
          var parentElement = currentElement[options.parentKey];
          if (!options.addParent) delete currentElement[options.parentKey];
          currentElement = parentElement;
        }
        function onCdata(cdata) {
          if (options.ignoreCdata) return;
          if (options.trim) cdata = cdata.trim();
          addField("cdata", cdata);
        }
        function onDoctype(doctype) {
          if (options.ignoreDoctype) return;
          doctype = doctype.replace(/^ /, "");
          if (options.trim) doctype = doctype.trim();
          addField("doctype", doctype);
        }
        function onError(error) {
          error.note = error;
        }
        module.exports = function(xml, userOptions) {
          var parser = pureJsParser ? sax.parser(true, {}) : parser = new expat.Parser("UTF-8");
          var result = {};
          currentElement = result;
          options = validateOptions(userOptions);
          if (pureJsParser) {
            parser.opt = { strictEntities: true };
            parser.onopentag = onStartElement;
            parser.ontext = onText;
            parser.oncomment = onComment;
            parser.onclosetag = onEndElement;
            parser.onerror = onError;
            parser.oncdata = onCdata;
            parser.ondoctype = onDoctype;
            parser.onprocessinginstruction = onInstruction;
          } else {
            parser.on("startElement", onStartElement);
            parser.on("text", onText);
            parser.on("comment", onComment);
            parser.on("endElement", onEndElement);
            parser.on("error", onError);
          }
          if (pureJsParser) parser.write(xml).close();
          else if (!parser.parse(xml)) throw new Error("XML parsing error: " + parser.getError());
          if (result[options.elementsKey]) {
            var temp = result[options.elementsKey];
            delete result[options.elementsKey];
            result[options.elementsKey] = temp;
            delete result.text;
          }
          return result;
        };
      }));
      require_xml2json = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var helper = require_options_helper();
        var xml2js = require_xml2js();
        function validateOptions(userOptions) {
          var options = helper.copyOptions(userOptions);
          helper.ensureSpacesExists(options);
          return options;
        }
        module.exports = function(xml, userOptions) {
          var options = validateOptions(userOptions), js = xml2js(xml, options), json, parentKey = "compact" in options && options.compact ? "_parent" : "parent";
          if ("addParent" in options && options.addParent) json = JSON.stringify(js, function(k, v) {
            return k === parentKey ? "_" : v;
          }, options.spaces);
          else json = JSON.stringify(js, null, options.spaces);
          return json.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
        };
      }));
      require_js2xml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var helper = require_options_helper();
        var isArray = require_array_helper().isArray;
        var currentElement;
        var currentElementName;
        function validateOptions(userOptions) {
          var options = helper.copyOptions(userOptions);
          helper.ensureFlagExists("ignoreDeclaration", options);
          helper.ensureFlagExists("ignoreInstruction", options);
          helper.ensureFlagExists("ignoreAttributes", options);
          helper.ensureFlagExists("ignoreText", options);
          helper.ensureFlagExists("ignoreComment", options);
          helper.ensureFlagExists("ignoreCdata", options);
          helper.ensureFlagExists("ignoreDoctype", options);
          helper.ensureFlagExists("compact", options);
          helper.ensureFlagExists("indentText", options);
          helper.ensureFlagExists("indentCdata", options);
          helper.ensureFlagExists("indentAttributes", options);
          helper.ensureFlagExists("indentInstruction", options);
          helper.ensureFlagExists("fullTagEmptyElement", options);
          helper.ensureFlagExists("noQuotesForNativeAttributes", options);
          helper.ensureSpacesExists(options);
          if (typeof options.spaces === "number") options.spaces = Array(options.spaces + 1).join(" ");
          helper.ensureKeyExists("declaration", options);
          helper.ensureKeyExists("instruction", options);
          helper.ensureKeyExists("attributes", options);
          helper.ensureKeyExists("text", options);
          helper.ensureKeyExists("comment", options);
          helper.ensureKeyExists("cdata", options);
          helper.ensureKeyExists("doctype", options);
          helper.ensureKeyExists("type", options);
          helper.ensureKeyExists("name", options);
          helper.ensureKeyExists("elements", options);
          helper.checkFnExists("doctype", options);
          helper.checkFnExists("instruction", options);
          helper.checkFnExists("cdata", options);
          helper.checkFnExists("comment", options);
          helper.checkFnExists("text", options);
          helper.checkFnExists("instructionName", options);
          helper.checkFnExists("elementName", options);
          helper.checkFnExists("attributeName", options);
          helper.checkFnExists("attributeValue", options);
          helper.checkFnExists("attributes", options);
          helper.checkFnExists("fullTagEmptyElement", options);
          return options;
        }
        function writeIndentation(options, depth, firstLine) {
          return (!firstLine && options.spaces ? "\n" : "") + Array(depth + 1).join(options.spaces);
        }
        function writeAttributes(attributes, options, depth) {
          if (options.ignoreAttributes) return "";
          if ("attributesFn" in options) attributes = options.attributesFn(attributes, currentElementName, currentElement);
          var key, attr, attrName, quote2, result = [];
          for (key in attributes) if (attributes.hasOwnProperty(key) && attributes[key] !== null && attributes[key] !== void 0) {
            quote2 = options.noQuotesForNativeAttributes && typeof attributes[key] !== "string" ? "" : '"';
            attr = "" + attributes[key];
            attr = attr.replace(/"/g, "&quot;");
            attrName = "attributeNameFn" in options ? options.attributeNameFn(key, attr, currentElementName, currentElement) : key;
            result.push(options.spaces && options.indentAttributes ? writeIndentation(options, depth + 1, false) : " ");
            result.push(attrName + "=" + quote2 + ("attributeValueFn" in options ? options.attributeValueFn(attr, key, currentElementName, currentElement) : attr) + quote2);
          }
          if (attributes && Object.keys(attributes).length && options.spaces && options.indentAttributes) result.push(writeIndentation(options, depth, false));
          return result.join("");
        }
        function writeDeclaration(declaration, options, depth) {
          currentElement = declaration;
          currentElementName = "xml";
          return options.ignoreDeclaration ? "" : "<?xml" + writeAttributes(declaration[options.attributesKey], options, depth) + "?>";
        }
        function writeInstruction(instruction, options, depth) {
          if (options.ignoreInstruction) return "";
          var key;
          for (key in instruction) if (instruction.hasOwnProperty(key)) break;
          var instructionName = "instructionNameFn" in options ? options.instructionNameFn(key, instruction[key], currentElementName, currentElement) : key;
          if (typeof instruction[key] === "object") {
            currentElement = instruction;
            currentElementName = instructionName;
            return "<?" + instructionName + writeAttributes(instruction[key][options.attributesKey], options, depth) + "?>";
          } else {
            var instructionValue = instruction[key] ? instruction[key] : "";
            if ("instructionFn" in options) instructionValue = options.instructionFn(instructionValue, key, currentElementName, currentElement);
            return "<?" + instructionName + (instructionValue ? " " + instructionValue : "") + "?>";
          }
        }
        function writeComment(comment, options) {
          return options.ignoreComment ? "" : "<!--" + ("commentFn" in options ? options.commentFn(comment, currentElementName, currentElement) : comment) + "-->";
        }
        function writeCdata(cdata, options) {
          return options.ignoreCdata ? "" : "<![CDATA[" + ("cdataFn" in options ? options.cdataFn(cdata, currentElementName, currentElement) : cdata.replace("]]>", "]]]]><![CDATA[>")) + "]]>";
        }
        function writeDoctype(doctype, options) {
          return options.ignoreDoctype ? "" : "<!DOCTYPE " + ("doctypeFn" in options ? options.doctypeFn(doctype, currentElementName, currentElement) : doctype) + ">";
        }
        function writeText(text, options) {
          if (options.ignoreText) return "";
          text = "" + text;
          text = text.replace(/&amp;/g, "&");
          text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
          return "textFn" in options ? options.textFn(text, currentElementName, currentElement) : text;
        }
        function hasContent(element, options) {
          var i;
          if (element.elements && element.elements.length) for (i = 0; i < element.elements.length; ++i) switch (element.elements[i][options.typeKey]) {
            case "text":
              if (options.indentText) return true;
              break;
            case "cdata":
              if (options.indentCdata) return true;
              break;
            case "instruction":
              if (options.indentInstruction) return true;
              break;
            case "doctype":
            case "comment":
            case "element":
              return true;
            default:
              return true;
          }
          return false;
        }
        function writeElement(element, options, depth) {
          currentElement = element;
          currentElementName = element.name;
          var xml = [], elementName = "elementNameFn" in options ? options.elementNameFn(element.name, element) : element.name;
          xml.push("<" + elementName);
          if (element[options.attributesKey]) xml.push(writeAttributes(element[options.attributesKey], options, depth));
          var withClosingTag = element[options.elementsKey] && element[options.elementsKey].length || element[options.attributesKey] && element[options.attributesKey]["xml:space"] === "preserve";
          if (!withClosingTag) {
            if ("fullTagEmptyElementFn" in options) withClosingTag = options.fullTagEmptyElementFn(element.name, element);
            else withClosingTag = options.fullTagEmptyElement;
          }
          if (withClosingTag) {
            xml.push(">");
            if (element[options.elementsKey] && element[options.elementsKey].length) {
              xml.push(writeElements(element[options.elementsKey], options, depth + 1));
              currentElement = element;
              currentElementName = element.name;
            }
            xml.push(options.spaces && hasContent(element, options) ? "\n" + Array(depth + 1).join(options.spaces) : "");
            xml.push("</" + elementName + ">");
          } else xml.push("/>");
          return xml.join("");
        }
        function writeElements(elements, options, depth, firstLine) {
          return elements.reduce(function(xml, element) {
            var indent = writeIndentation(options, depth, firstLine && !xml);
            switch (element.type) {
              case "element":
                return xml + indent + writeElement(element, options, depth);
              case "comment":
                return xml + indent + writeComment(element[options.commentKey], options);
              case "doctype":
                return xml + indent + writeDoctype(element[options.doctypeKey], options);
              case "cdata":
                return xml + (options.indentCdata ? indent : "") + writeCdata(element[options.cdataKey], options);
              case "text":
                return xml + (options.indentText ? indent : "") + writeText(element[options.textKey], options);
              case "instruction":
                var instruction = {};
                instruction[element[options.nameKey]] = element[options.attributesKey] ? element : element[options.instructionKey];
                return xml + (options.indentInstruction ? indent : "") + writeInstruction(instruction, options, depth);
            }
          }, "");
        }
        function hasContentCompact(element, options, anyContent) {
          var key;
          for (key in element) if (element.hasOwnProperty(key)) switch (key) {
            case options.parentKey:
            case options.attributesKey:
              break;
            case options.textKey:
              if (options.indentText || anyContent) return true;
              break;
            case options.cdataKey:
              if (options.indentCdata || anyContent) return true;
              break;
            case options.instructionKey:
              if (options.indentInstruction || anyContent) return true;
              break;
            case options.doctypeKey:
            case options.commentKey:
              return true;
            default:
              return true;
          }
          return false;
        }
        function writeElementCompact(element, name, options, depth, indent) {
          currentElement = element;
          currentElementName = name;
          var elementName = "elementNameFn" in options ? options.elementNameFn(name, element) : name;
          if (typeof element === "undefined" || element === null || element === "") return "fullTagEmptyElementFn" in options && options.fullTagEmptyElementFn(name, element) || options.fullTagEmptyElement ? "<" + elementName + "></" + elementName + ">" : "<" + elementName + "/>";
          var xml = [];
          if (name) {
            xml.push("<" + elementName);
            if (typeof element !== "object") {
              xml.push(">" + writeText(element, options) + "</" + elementName + ">");
              return xml.join("");
            }
            if (element[options.attributesKey]) xml.push(writeAttributes(element[options.attributesKey], options, depth));
            var withClosingTag = hasContentCompact(element, options, true) || element[options.attributesKey] && element[options.attributesKey]["xml:space"] === "preserve";
            if (!withClosingTag) {
              if ("fullTagEmptyElementFn" in options) withClosingTag = options.fullTagEmptyElementFn(name, element);
              else withClosingTag = options.fullTagEmptyElement;
            }
            if (withClosingTag) xml.push(">");
            else {
              xml.push("/>");
              return xml.join("");
            }
          }
          xml.push(writeElementsCompact(element, options, depth + 1, false));
          currentElement = element;
          currentElementName = name;
          if (name) xml.push((indent ? writeIndentation(options, depth, false) : "") + "</" + elementName + ">");
          return xml.join("");
        }
        function writeElementsCompact(element, options, depth, firstLine) {
          var i, key, nodes, xml = [];
          for (key in element) if (element.hasOwnProperty(key)) {
            nodes = isArray(element[key]) ? element[key] : [element[key]];
            for (i = 0; i < nodes.length; ++i) {
              switch (key) {
                case options.declarationKey:
                  xml.push(writeDeclaration(nodes[i], options, depth));
                  break;
                case options.instructionKey:
                  xml.push((options.indentInstruction ? writeIndentation(options, depth, firstLine) : "") + writeInstruction(nodes[i], options, depth));
                  break;
                case options.attributesKey:
                case options.parentKey:
                  break;
                case options.textKey:
                  xml.push((options.indentText ? writeIndentation(options, depth, firstLine) : "") + writeText(nodes[i], options));
                  break;
                case options.cdataKey:
                  xml.push((options.indentCdata ? writeIndentation(options, depth, firstLine) : "") + writeCdata(nodes[i], options));
                  break;
                case options.doctypeKey:
                  xml.push(writeIndentation(options, depth, firstLine) + writeDoctype(nodes[i], options));
                  break;
                case options.commentKey:
                  xml.push(writeIndentation(options, depth, firstLine) + writeComment(nodes[i], options));
                  break;
                default:
                  xml.push(writeIndentation(options, depth, firstLine) + writeElementCompact(nodes[i], key, options, depth, hasContentCompact(nodes[i], options)));
              }
              firstLine = firstLine && !xml.length;
            }
          }
          return xml.join("");
        }
        module.exports = function(js, options) {
          options = validateOptions(options);
          var xml = [];
          currentElement = js;
          currentElementName = "_root_";
          if (options.compact) xml.push(writeElementsCompact(js, options, 0, true));
          else {
            if (js[options.declarationKey]) xml.push(writeDeclaration(js[options.declarationKey], options, 0));
            if (js[options.elementsKey] && js[options.elementsKey].length) xml.push(writeElements(js[options.elementsKey], options, 0, !xml.length));
          }
          return xml.join("");
        };
      }));
      require_json2xml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
        var js2xml = require_js2xml();
        module.exports = function(json, options) {
          if (json instanceof import_buffer.Buffer) json = json.toString();
          var js = null;
          if (typeof json === "string") try {
            js = JSON.parse(json);
          } catch (e) {
            throw new Error("The JSON structure is invalid");
          }
          else js = json;
          return js2xml(js, options);
        };
      }));
      import_lib = /* @__PURE__ */ __toESM2((/* @__PURE__ */ __commonJSMin(((exports, module) => {
        module.exports = {
          xml2js: require_xml2js(),
          xml2json: require_xml2json(),
          js2xml: require_js2xml(),
          json2xml: require_json2xml()
        };
      })))());
      resolveFetch = () => {
        if (typeof globalThis !== "undefined" && typeof globalThis.fetch === "function") return globalThis.fetch.bind(globalThis);
        return (() => {
          throw new Error("tsdav: global fetch is not available in this runtime. Upgrade to Node.js >= 18, run under a browser/Bun/Deno, or install a fetch polyfill on globalThis before importing tsdav. You can also pass a custom `fetch` implementation to `createDAVClient`, `DAVClient`, or individual request helpers.");
        });
      };
      fetch2 = resolveFetch();
      camelCase = (str) => str.replace(/[-_]+(\w?)/g, (_m, c) => c ? c.toUpperCase() : "");
      findMissingFieldNames = (obj, fields) => {
        if (!obj || typeof obj !== "object") return fields.map((f2) => f2.toString()).join(",");
        return fields.reduce((prev, curr) => obj[curr] ? prev : `${prev.length ? `${prev},` : ""}${curr.toString()}`, "");
      };
      hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
      davNamespaces = new Set(Object.values(DAVNamespace));
      standardNamespaces = new Map([
        ...[
          "multistatus",
          "response",
          "propstat",
          "prop",
          "href",
          "status",
          "error",
          "responsedescription",
          "resourcetype",
          "collection",
          "getetag",
          "displayname",
          "syncToken",
          "supportedReportSet",
          "supportedReport",
          "report",
          "currentUserPrincipal"
        ].map((name) => [name, "DAV:"]),
        ...[
          "calendarData",
          "calendar",
          "calendarDescription",
          "calendarTimezone",
          "calendarHomeSet",
          "calendarUserAddressSet",
          "supportedCalendarComponentSet",
          "comp"
        ].map((name) => [name, "urn:ietf:params:xml:ns:caldav"]),
        ...[
          "addressData",
          "addressbook",
          "addressbookHomeSet"
        ].map((name) => [name, "urn:ietf:params:xml:ns:carddav"]),
        ["getctag", "http://calendarserver.org/ns/"],
        ["calendarColor", "http://apple.com/ns/ical/"]
      ]);
      normalizedKey = (name, namespace) => {
        const localName = camelCase(name.replace(/^.*:/, ""));
        const standardNamespace = standardNamespaces.get(localName);
        return namespace && standardNamespace && namespace !== standardNamespace ? `{${namespace}}${localName}` : localName;
      };
      normalizeElement = (element, inheritedNamespaces) => {
        const namespaceContext = Object.assign(/* @__PURE__ */ Object.create(null), inheritedNamespaces);
        const attributes = /* @__PURE__ */ Object.create(null);
        for (const [name2, value2] of Object.entries(element.attributes ?? {})) {
          if (name2 === "xmlns" || name2.startsWith("xmlns:")) namespaceContext[name2 === "xmlns" ? "" : name2.slice(6)] = String(value2);
          if (name2 !== "xmlns") attributes[name2] = value2;
        }
        const name = element.name ?? "";
        const separator = name.indexOf(":");
        const namespace = namespaceContext[separator === -1 ? "" : name.slice(0, separator)] ?? "";
        const children = element.elements ?? [];
        const elements = children.filter((child) => child.type === "element");
        const text = children.filter((child) => child.type === "text" || child.type === "cdata").map((child) => String(child.text ?? child.cdata ?? "")).join("");
        const value = {};
        const namespaces = /* @__PURE__ */ Object.create(null);
        if (Object.keys(attributes).length) value._attributes = attributes;
        if (!elements.length) {
          const hasText = children.some((child) => child.type === "text");
          const hasCdata = children.some((child) => child.type === "cdata");
          if (hasText) return {
            value: text,
            namespace,
            namespaces
          };
          if (hasCdata) value._cdata = text;
          return {
            value,
            namespace,
            namespaces
          };
        }
        if (text.trim()) value._text = text;
        for (const child of elements) {
          const normalized = normalizeElement(child, namespaceContext);
          const localName = camelCase((child.name ?? "").replace(/^.*:/, ""));
          let key = normalizedKey(child.name ?? "", normalized.namespace);
          const previousNamespace = namespaces[key];
          if (hasOwn(value, key) && previousNamespace !== normalized.namespace) {
            if (davNamespaces.has(normalized.namespace) && !davNamespaces.has(previousNamespace)) {
              const previousKey = `{${previousNamespace}}${localName}`;
              Object.defineProperty(value, previousKey, {
                value: value[key],
                enumerable: true,
                configurable: true,
                writable: true
              });
              namespaces[previousKey] = previousNamespace;
              delete value[key];
            } else key = `{${normalized.namespace}}${localName}`;
          }
          if (hasOwn(value, key)) {
            if (Array.isArray(value[key])) value[key].push(normalized.value);
            else value[key] = [value[key], normalized.value];
          } else Object.defineProperty(value, key, {
            value: normalized.value,
            enumerable: true,
            configurable: true,
            writable: true
          });
          namespaces[key] = normalized.namespace;
          if (localName === "prop" && normalized.namespace === "DAV:") value.propNamespaces = normalized.namespaces;
        }
        return {
          value,
          namespace,
          namespaces
        };
      };
      parseDAVXML = (xml) => {
        const document2 = import_lib.default.xml2js(xml, {
          compact: false,
          ignoreDeclaration: true
        });
        const result = {};
        for (const element of document2.elements ?? []) {
          if (element.type !== "element") continue;
          const normalized = normalizeElement(element, {});
          const key = normalizedKey(element.name ?? "", normalized.namespace);
          Object.defineProperty(result, key, {
            value: normalized.value,
            enumerable: true
          });
        }
        return result;
      };
      mergeDAVProps = (propStats) => {
        const groups = /* @__PURE__ */ new Map();
        for (const stat of propStats) {
          if (!stat.ok) continue;
          for (const [name, value] of Object.entries(stat.props)) {
            const namespaces = groups.get(name) ?? /* @__PURE__ */ new Map();
            namespaces.set(stat.namespaces?.[name] ?? "", value);
            groups.set(name, namespaces);
          }
        }
        const props = {};
        for (const [name, namespaces] of groups) {
          const primary = [...namespaces.keys()].find((namespace) => davNamespaces.has(namespace)) ?? namespaces.keys().next().value;
          for (const [namespace, value] of namespaces) Object.defineProperty(props, namespace === primary ? name : `{${namespace}}${name}`, {
            value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        }
        return props;
      };
      normalizePercentEncoding = (href) => {
        let url;
        try {
          url = new URL(href);
        } catch {
          return href;
        }
        url.pathname = url.pathname.split("/").map((segment) => {
          try {
            return encodeURIComponent(decodeURIComponent(segment));
          } catch {
            return segment;
          }
        }).join("/");
        return url.href;
      };
      requestHelpers_exports = /* @__PURE__ */ __exportAll({
        cleanupFalsy: () => cleanupFalsy,
        conditionalParam: () => conditionalParam,
        ensureTrailingSlash: () => ensureTrailingSlash,
        excludeHeaders: () => excludeHeaders,
        getDAVAttribute: () => getDAVAttribute,
        mergeHeaders: () => mergeHeaders,
        urlContains: () => urlContains,
        urlEquals: () => urlEquals,
        urlMatches: () => urlMatches
      });
      normalizeUrl = (url) => {
        const trimmed = url.trim();
        return trimmed.endsWith("/") ? trimmed.slice(0, -1) : trimmed;
      };
      ensureTrailingSlash = (url) => {
        const trimmed = url.trim();
        const suffixIndex = trimmed.search(/[?#]/);
        const pathname = suffixIndex === -1 ? trimmed : trimmed.slice(0, suffixIndex);
        const suffix = suffixIndex === -1 ? "" : trimmed.slice(suffixIndex);
        return `${pathname.endsWith("/") ? pathname : `${pathname}/`}${suffix}`;
      };
      urlEquals = (urlA, urlB) => {
        if (!urlA && !urlB) return true;
        if (!urlA || !urlB) return false;
        return normalizeUrl(urlA) === normalizeUrl(urlB);
      };
      urlContains = (urlA, urlB) => {
        if (!urlA && !urlB) return true;
        if (!urlA || !urlB) return false;
        const strippedUrlA = normalizeUrl(urlA);
        const strippedUrlB = normalizeUrl(urlB);
        return strippedUrlA.includes(strippedUrlB) || strippedUrlB.includes(strippedUrlA);
      };
      urlMatches = (urlA, urlB, baseUrl) => {
        if (!urlA || !urlB || !baseUrl) return urlEquals(urlA, urlB);
        try {
          return urlEquals(normalizePercentEncoding(new URL(urlA, baseUrl).href), normalizePercentEncoding(new URL(urlB, baseUrl).href));
        } catch {
          return urlEquals(urlA, urlB);
        }
      };
      getDAVAttribute = (nsArr) => nsArr.reduce((prev, curr) => ({
        ...prev,
        [DAVAttributeMap[curr]]: curr
      }), {});
      cleanupFalsy = (obj) => Object.entries(obj).reduce((prev, [key, value]) => {
        if (value) return {
          ...prev,
          [key]: value
        };
        return prev;
      }, {});
      conditionalParam = (key, param) => {
        if (param) return { [key]: param };
        return {};
      };
      excludeHeaders = (headers, headersToExclude) => {
        if (!headers) return {};
        if (!headersToExclude || headersToExclude.length === 0) return headers;
        const excludeSet = new Set(headersToExclude.map((h) => h.toLowerCase()));
        return Object.fromEntries(Object.entries(headers).filter(([key]) => !excludeSet.has(key.toLowerCase())));
      };
      mergeHeaders = (...headerSources) => {
        const headersByLowercaseName = /* @__PURE__ */ new Map();
        const setHeader = (name, value) => {
          headersByLowercaseName.set(name.toLowerCase(), [name, value]);
        };
        for (const source of headerSources) {
          if (!source) continue;
          if (Array.isArray(source)) {
            for (const [name, value] of source) setHeader(name, value);
            continue;
          }
          if (typeof source.forEach === "function") {
            source.forEach((value, name) => {
              setHeader(name, value);
            });
            continue;
          }
          for (const [name, value] of Object.entries(source)) setHeader(name, value);
        }
        return Object.fromEntries(headersByLowercaseName.values());
      };
      request_exports = /* @__PURE__ */ __exportAll({
        createObject: () => createObject,
        davRequest: () => davRequest,
        deleteObject: () => deleteObject,
        propfind: () => propfind,
        updateObject: () => updateObject
      });
      debug$6 = (0, import_browser.default)("tsdav:request");
      parseStatusLine = (statusLine) => {
        const match = /^\S+\s+(?<status>\d{3})(?:\s+(?<statusText>.*))?$/.exec(statusLine?.trim() ?? "");
        const status2 = match?.groups?.status;
        const statusText = match?.groups?.statusText;
        return status2 ? {
          status: Number.parseInt(status2, 10),
          statusText: statusText ?? ""
        } : void 0;
      };
      davRequest = async (params) => {
        const { url, init: init3, convertIncoming = true, parseOutgoing = true, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const { headers = {}, body, namespace, method, attributes } = init3;
        let processedBody = body;
        if (attributes && body != null && typeof body === "object" && !Array.isArray(body)) processedBody = Object.fromEntries(Object.entries(body).map(([key, value]) => {
          if (value && typeof value === "object" && !Array.isArray(value)) {
            const element = value;
            return [key, {
              ...element,
              _attributes: {
                ...attributes,
                ...element._attributes
              }
            }];
          }
          return [key, value];
        }));
        const xmlBody = convertIncoming && body != null ? import_lib.default.js2xml({
          _declaration: { _attributes: {
            version: "1.0",
            encoding: "utf-8"
          } },
          ...processedBody
        }, {
          compact: true,
          spaces: 2,
          elementNameFn: (name) => {
            if (namespace && !/^.+:.+/.test(name)) return `${namespace}:${name}`;
            return name;
          }
        }) : body;
        const fetchOptionsWithoutHeaders = { ...fetchOptions };
        delete fetchOptionsWithoutHeaders.headers;
        const mergedHeaders = excludeHeaders(mergeHeaders({ "Content-Type": "text/xml;charset=UTF-8" }, cleanupFalsy(headers), fetchOptions.headers), headersToExclude);
        const davResponse = await requestFetch(url, {
          ...fetchOptionsWithoutHeaders,
          headers: mergedHeaders,
          body: xmlBody,
          method
        });
        const resText = await davResponse.text();
        if (!davResponse.ok || !davResponse.headers.get("content-type")?.toLowerCase().includes("xml") || !parseOutgoing || !resText) return [{
          href: davResponse.url,
          ok: davResponse.ok,
          status: davResponse.status,
          statusText: davResponse.statusText,
          raw: resText
        }];
        let result;
        try {
          result = parseDAVXML(resText);
        } catch (e) {
          debug$6(`Failed to parse DAV response XML: ${e.message}`);
          return [{
            href: davResponse.url,
            ok: false,
            status: davResponse.status,
            statusText: davResponse.statusText,
            raw: resText,
            parseError: e.message
          }];
        }
        if (!result?.multistatus) return [{
          href: davResponse.url,
          ok: davResponse.ok,
          status: davResponse.status,
          statusText: davResponse.statusText,
          raw: result
        }];
        return (Array.isArray(result.multistatus.response) ? result.multistatus.response : [result.multistatus.response]).map((responseBody) => {
          if (!responseBody) return {
            raw: result,
            status: davResponse.status,
            statusText: davResponse.statusText,
            ok: davResponse.ok
          };
          const propStats = (Array.isArray(responseBody.propstat) ? responseBody.propstat : responseBody.propstat ? [responseBody.propstat] : []).map((stat) => {
            const parsed = parseStatusLine(stat.status);
            const status3 = parsed?.status ?? 0;
            return {
              props: stat.prop ?? {},
              namespaces: stat.propNamespaces,
              status: status3,
              statusText: parsed?.statusText ?? "Invalid DAV property status",
              ok: status3 >= 200 && status3 < 300,
              error: stat.error,
              responsedescription: stat.responsedescription
            };
          });
          const failedStatus = propStats.length > 0 && propStats.every((stat) => !stat.ok) ? propStats[0] : void 0;
          const parsedStatus = parseStatusLine(responseBody.status) ?? failedStatus;
          const status2 = parsedStatus?.status ?? davResponse.status;
          return {
            raw: result,
            href: responseBody.href,
            status: status2,
            statusText: parsedStatus?.statusText ?? davResponse.statusText,
            ok: status2 >= 200 && status2 < 300,
            error: responseBody.error,
            responsedescription: responseBody.responsedescription,
            propStats,
            props: mergeDAVProps(propStats)
          };
        });
      };
      propfind = async (params) => {
        const { url, props, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return davRequest({
          url,
          init: {
            method: "PROPFIND",
            headers: excludeHeaders(cleanupFalsy({
              depth,
              ...headers
            }), headersToExclude),
            namespace: "d",
            body: { propfind: {
              _attributes: getDAVAttribute([
                "urn:ietf:params:xml:ns:caldav",
                "http://apple.com/ns/ical/",
                "http://calendarserver.org/ns/",
                "urn:ietf:params:xml:ns:carddav",
                "DAV:"
              ]),
              prop: props
            } }
          },
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      createObject = async (params) => {
        const { url, data, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions;
        return requestFetch(url, {
          ...fetchOptionsWithoutHeaders,
          method: "PUT",
          body: data,
          headers: excludeHeaders(mergeHeaders(headers, fetchHeaders), headersToExclude)
        });
      };
      updateObject = async (params) => {
        const { url, data, etag, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions;
        return requestFetch(url, {
          ...fetchOptionsWithoutHeaders,
          method: "PUT",
          body: data,
          headers: excludeHeaders(mergeHeaders(cleanupFalsy({
            "If-Match": etag,
            ...headers
          }), fetchHeaders), headersToExclude)
        });
      };
      deleteObject = async (params) => {
        const { url, headers, etag, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions;
        return requestFetch(url, {
          ...fetchOptionsWithoutHeaders,
          method: "DELETE",
          headers: excludeHeaders(mergeHeaders(cleanupFalsy({
            "If-Match": etag,
            ...headers
          }), fetchHeaders), headersToExclude)
        });
      };
      getDAVUrlKey = (url, baseUrl) => {
        let resolved;
        try {
          resolved = normalizePercentEncoding(new URL(url, ensureTrailingSlash(baseUrl)).href);
        } catch {
          resolved = url.trim();
        }
        return resolved.endsWith("/") ? resolved.slice(0, -1) : resolved;
      };
      diffDAVObjects = (local, remote, baseUrl, incremental = false, deletedObjects = []) => {
        const localByUrl = new Map(local.map((object) => [getDAVUrlKey(object.url, baseUrl), object]));
        const remoteByUrl = new Map(remote.map((object) => [getDAVUrlKey(object.url, baseUrl), object]));
        const deleted = incremental ? deletedObjects : local.filter((object) => !remoteByUrl.has(getDAVUrlKey(object.url, baseUrl)));
        const deletedUrls = new Set(deleted.map((object) => getDAVUrlKey(object.url, baseUrl)));
        const created = remote.filter((object) => !localByUrl.has(getDAVUrlKey(object.url, baseUrl)));
        const updated = [];
        const unchanged = [];
        for (const object of local) {
          const key = getDAVUrlKey(object.url, baseUrl);
          if (deletedUrls.has(key)) continue;
          const found = remoteByUrl.get(key);
          if (found && found.etag !== object.etag) updated.push(found);
          else if (found || incremental) unchanged.push(object);
        }
        return {
          created,
          updated,
          deleted,
          unchanged
        };
      };
      assertDAVResponses = (responses, context) => {
        const failed = responses.find((response) => !response.ok || response.status >= 400);
        if (failed) throw new Error(`${context}: ${failed.status} ${failed.statusText}`);
      };
      assertDAVDiscovery = (responses, context) => {
        assertDAVResponses(responses, context);
        for (const response of responses) {
          if (response.raw?.multistatus && !response.raw.multistatus.response) continue;
          assertDAVProperty(response, "resourcetype", context);
          if (!response.props || !hasOwn(response.props, "resourcetype") || typeof response.href !== "string" || !response.href) throw new Error(`${context}: missing resourcetype or href in DAV multistatus response`);
        }
      };
      assertDAVProperty = (response, name, context) => {
        const failed = response.propStats?.find((stat) => !stat.ok && hasOwn(stat.props, name));
        if (failed && !hasOwn(response.props ?? {}, name)) throw new Error(`${context}: ${name} returned ${failed.status} ${failed.statusText}`);
      };
      assertDAVObjectResponses = (responses, property, objectUrls, baseUrl, context) => {
        assertDAVResponses(responses, context);
        const fetchedUrls = /* @__PURE__ */ new Set();
        for (const response of responses) {
          assertDAVProperty(response, property, context);
          if (!response.href || typeof (response.props?.[property]?._cdata ?? response.props?.[property]) !== "string") throw new Error(`${context}: missing ${property} or href`);
          fetchedUrls.add(getDAVUrlKey(response.href, baseUrl));
        }
        const withoutQuery = (url) => getDAVUrlKey(url.replace(/\?.*$/, ""), baseUrl);
        const countsByPath = /* @__PURE__ */ new Map();
        for (const url of objectUrls) {
          const key = withoutQuery(url);
          countsByPath.set(key, (countsByPath.get(key) ?? 0) + 1);
        }
        if (objectUrls.some((url) => !fetchedUrls.has(getDAVUrlKey(url, baseUrl)) && !(countsByPath.get(withoutQuery(url)) === 1 && fetchedUrls.has(withoutQuery(url))))) throw new Error(`${context}: incomplete response`);
      };
      getDAVText = (value) => {
        const text = typeof value === "string" || typeof value === "number" ? String(value) : value?._cdata ?? value?._text;
        return typeof text === "string" ? text : void 0;
      };
      collection_exports = /* @__PURE__ */ __exportAll({
        collectionQuery: () => collectionQuery,
        isCollectionDirty: () => isCollectionDirty,
        makeCollection: () => makeCollection,
        smartCollectionSync: () => smartCollectionSync,
        smartCollectionSyncDetailed: () => smartCollectionSyncDetailed,
        supportedReportSet: () => supportedReportSet,
        syncCollection: () => syncCollection
      });
      debug$5 = (0, import_browser.default)("tsdav:collection");
      resolveDAVHref = (href, baseUrl) => {
        try {
          return new URL(href, ensureTrailingSlash(baseUrl)).href;
        } catch {
          return href;
        }
      };
      collectionQuery = async (params) => {
        const { url, body, depth, defaultNamespace = "d", headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const queryResults = await davRequest({
          url,
          init: {
            method: "REPORT",
            headers: excludeHeaders(cleanupFalsy({
              depth,
              ...headers
            }), headersToExclude),
            namespace: defaultNamespace,
            body
          },
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        const emptyNotFound = queryResults[0];
        if (defaultNamespace === "c" && body?.["calendar-query"] != null && queryResults.length === 1 && emptyNotFound && emptyNotFound.status === 404 && urlMatches(url, emptyNotFound.href, url) && !emptyNotFound.error && Object.keys(emptyNotFound.props ?? {}).length === 0 && typeof emptyNotFound.raw === "object" && emptyNotFound.raw !== null && emptyNotFound.raw.multistatus?.response?.propstat == null) return [];
        const errorResponse = queryResults.find((res) => !res.ok || res.status && res.status >= 400);
        if (errorResponse) throw new Error(`Collection query failed: ${errorResponse.status} ${errorResponse.statusText}. ${typeof errorResponse.raw === "string" ? `Raw response: ${errorResponse.raw.slice(0, 4096)}` : ""}`);
        if ((body?.["calendar-query"] || body?.["calendar-multiget"] || body?.["addressbook-query"] || body?.["addressbook-multiget"]) && queryResults.some((response) => !response.raw?.multistatus)) throw new Error("Collection query failed: expected a DAV multistatus response");
        if ((body?.["calendar-query"] || body?.["calendar-multiget"] || body?.["addressbook-query"] || body?.["addressbook-multiget"]) && queryResults.some((response) => response.raw?.multistatus?.response && (typeof response.href !== "string" || !response.href))) throw new Error("Collection query failed: missing href in DAV response");
        const firstQueryResult = queryResults[0];
        if (queryResults.length === 1 && firstQueryResult && (!firstQueryResult.raw || firstQueryResult.raw.multistatus && !firstQueryResult.raw.multistatus.response) && firstQueryResult.status && firstQueryResult.status < 300) return [];
        return queryResults;
      };
      makeCollection = async (params) => {
        const { url, props, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return davRequest({
          url,
          init: {
            method: "MKCOL",
            headers: excludeHeaders(cleanupFalsy({
              depth,
              ...headers
            }), headersToExclude),
            namespace: "d",
            body: props ? { mkcol: {
              _attributes: getDAVAttribute([
                "DAV:",
                "urn:ietf:params:xml:ns:caldav",
                "urn:ietf:params:xml:ns:carddav",
                "http://calendarserver.org/ns/",
                "http://apple.com/ns/ical/"
              ]),
              set: { prop: props }
            } } : void 0
          },
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      supportedReportSet = async (params) => {
        const { collection, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const supportedReport = (await propfind({
          url: collection.url,
          props: { [`d:supported-report-set`]: {} },
          depth: "0",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        }))[0]?.props?.supportedReportSet?.supportedReport;
        if (!supportedReport) return [];
        return (Array.isArray(supportedReport) ? supportedReport : [supportedReport]).map((sr) => sr?.report ? Object.keys(sr.report)[0] : void 0).filter((name) => typeof name === "string" && name.length > 0);
      };
      isCollectionDirty = async (params) => {
        const { collection, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const res = (await propfind({
          url: collection.url,
          props: { [`cs:getctag`]: {} },
          depth: "0",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        })).find((r) => urlMatches(collection.url, r.href, collection.url));
        if (!res) throw new Error("Collection does not exist on server");
        const unavailableCtag = res.propStats?.length && res.propStats.every((stat) => stat.status === 404 && hasOwn(stat.props, "getctag"));
        if (!res.ok && !unavailableCtag) throw new Error(`Collection status check failed: ${res.status} ${res.statusText}`);
        const remoteCtag = getDAVText(res.props?.getctag);
        return {
          isDirty: collection.ctag == null || remoteCtag == null || `${collection.ctag}` !== `${remoteCtag}`,
          newCtag: remoteCtag
        };
      };
      syncCollection = (params) => {
        const { url, props, headers, syncLevel, syncToken, headersToExclude, fetchOptions, fetch: fetchOverride } = params;
        return davRequest({
          url,
          init: {
            method: "REPORT",
            namespace: "d",
            headers: excludeHeaders({ ...headers }, headersToExclude),
            body: { "sync-collection": {
              _attributes: getDAVAttribute([
                "urn:ietf:params:xml:ns:caldav",
                "urn:ietf:params:xml:ns:carddav",
                "DAV:"
              ]),
              "sync-level": syncLevel,
              "sync-token": syncToken,
              [`d:prop`]: props
            } }
          },
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      smartCollectionSync = async (params) => {
        const { collection, method, headers, headersToExclude, account, detailedResult, fetchOptions = {}, fetch: fetchOverride } = params;
        const requiredFields = ["accountType", "homeUrl"];
        if (!account || !hasFields(account, requiredFields)) {
          if (!account) throw new Error("no account for smartCollectionSync");
          throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before smartCollectionSync`);
        }
        const syncMethod = method ?? (collection.reports?.includes("syncCollection") ? "webdav" : "basic");
        debug$5(`smart collection sync with type ${account.accountType} and method ${syncMethod}`);
        if (syncMethod === "webdav") {
          const requestSync = (syncToken2) => syncCollection({
            url: collection.url,
            props: {
              [`d:getetag`]: {},
              [`${account.accountType === "caldav" ? "c" : "card"}:${account.accountType === "caldav" ? "calendar-data" : "address-data"}`]: {},
              [`d:displayname`]: {}
            },
            syncLevel: 1,
            syncToken: syncToken2,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          });
          let syncToken = collection.syncToken;
          let result = await requestSync(syncToken);
          if (syncToken && result.length === 1 && result[0].status >= 400 && result[0].status < 500 && typeof result[0].raw === "string" && result[0].raw.includes("valid-sync-token")) {
            debug$5("sync token rejected by server, starting a full sync");
            syncToken = void 0;
            result = await requestSync(syncToken);
          }
          const isObjectResponse = (r) => {
            return typeof r.href === "string" && getDAVUrlKey(r.href, collection.url) !== getDAVUrlKey(collection.url, collection.url) && !r.props?.resourcetype?.collection;
          };
          const errorResponse = result.find((r) => (!r.ok || r.status >= 400) && !(r.status === 404 && !r.propStats?.length && isObjectResponse(r)));
          if (errorResponse) throw new Error(`Collection sync failed: ${errorResponse.status} ${errorResponse.statusText}`);
          if (result.some((response) => response.raw && !response.raw.multistatus)) throw new Error("Collection sync failed: expected a DAV multistatus response");
          if (result.some((response) => response.raw?.multistatus?.response && (typeof response.href !== "string" || !response.href))) throw new Error("Collection sync failed: missing href in DAV response");
          const objectResponses = result.filter(isObjectResponse);
          const changedObjectUrls = objectResponses.filter((o) => o.status !== 404).map((r) => r.href);
          const deletedObjectUrls = objectResponses.filter((o) => o.status === 404).map((r) => r.href);
          const objectMultiGet = collection.objectMultiGet;
          if (changedObjectUrls.length > 0 && !objectMultiGet) throw new Error("collection.objectMultiGet is required for webdav sync changes");
          const multiGetObjectResponse = changedObjectUrls.length ? await objectMultiGet?.({
            url: collection.url,
            props: {
              [`d:getetag`]: {},
              [`${account.accountType === "caldav" ? "c" : "card"}:${account.accountType === "caldav" ? "calendar-data" : "address-data"}`]: {}
            },
            objectUrls: changedObjectUrls,
            depth: "1",
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          }) ?? [] : [];
          assertDAVObjectResponses(multiGetObjectResponse, account.accountType === "caldav" ? "calendarData" : "addressData", changedObjectUrls, collection.url, "Collection sync multi-get failed");
          const remoteObjects = multiGetObjectResponse.map((res) => {
            return {
              url: resolveDAVHref(res.href ?? "", collection.url),
              etag: getDAVText(res.props?.getetag),
              data: account?.accountType === "caldav" ? res.props?.calendarData?._cdata ?? res.props?.calendarData : res.props?.addressData?._cdata ?? res.props?.addressData
            };
          });
          const localObjects = collection.objects ?? [];
          const deletedObjects = deletedObjectUrls.map((url) => ({
            url: resolveDAVHref(url, collection.url),
            etag: ""
          }));
          const { created, updated, deleted, unchanged } = diffDAVObjects(localObjects, remoteObjects, collection.url, Boolean(syncToken), deletedObjects);
          return {
            ...collection,
            objects: detailedResult ? {
              created,
              updated,
              deleted
            } : [
              ...unchanged,
              ...created,
              ...updated
            ],
            syncToken: getDAVText(result[0]?.raw?.multistatus?.syncToken) ?? collection.syncToken
          };
        }
        if (syncMethod === "basic") {
          const { isDirty, newCtag } = await isCollectionDirty({
            collection,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          });
          if (!isDirty) return detailedResult ? {
            ...collection,
            objects: {
              created: [],
              updated: [],
              deleted: []
            }
          } : collection;
          const localObjects = collection.objects ?? [];
          if (!collection.fetchObjects) throw new Error("collection.fetchObjects is required for basic sync changes");
          const remoteObjects = await collection.fetchObjects({
            collection,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          }) ?? [];
          const { created, updated, deleted, unchanged } = diffDAVObjects(localObjects, remoteObjects, collection.url);
          return {
            ...collection,
            objects: detailedResult ? {
              created,
              updated,
              deleted
            } : [
              ...unchanged,
              ...created,
              ...updated
            ],
            ctag: newCtag
          };
        }
        return detailedResult ? {
          ...collection,
          objects: {
            created: [],
            updated: [],
            deleted: []
          }
        } : collection;
      };
      smartCollectionSyncDetailed = async (params) => smartCollectionSync({
        ...params,
        detailedResult: true
      });
      getObjectUrl = (collectionUrl, filename) => {
        if (!filename || filename.includes("/") || /^(?:\.|%2e){1,2}$/i.test(filename)) throw new Error(`Invalid object filename "${filename}": expected a single path segment`);
        const segment = filename.replace(/%(?![\da-f]{2})|[?#\\\x00-\x20\x7f]/gi, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")}`);
        return new URL(`./${segment}`, ensureTrailingSlash(collectionUrl)).href;
      };
      addressBook_exports = /* @__PURE__ */ __exportAll({
        addressBookMultiGet: () => addressBookMultiGet,
        addressBookQuery: () => addressBookQuery,
        createVCard: () => createVCard,
        deleteVCard: () => deleteVCard,
        fetchAddressBooks: () => fetchAddressBooks,
        fetchVCards: () => fetchVCards,
        updateVCard: () => updateVCard
      });
      debug$4 = (0, import_browser.default)("tsdav:addressBook");
      addressBookQuery = async (params) => {
        const { url, props, filters, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return collectionQuery({
          url,
          body: { "addressbook-query": cleanupFalsy({
            _attributes: getDAVAttribute(["urn:ietf:params:xml:ns:carddav", "DAV:"]),
            [`d:prop`]: props,
            filter: filters ?? { "prop-filter": { _attributes: { name: "FN" } } }
          }) },
          defaultNamespace: "card",
          depth,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      addressBookMultiGet = async (params) => {
        const { url, props, objectUrls, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return collectionQuery({
          url,
          body: { "addressbook-multiget": cleanupFalsy({
            _attributes: getDAVAttribute(["DAV:", "urn:ietf:params:xml:ns:carddav"]),
            [`d:prop`]: props,
            [`d:href`]: objectUrls
          }) },
          defaultNamespace: "card",
          depth,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      fetchAddressBooks = async (params) => {
        const { account, headers, props: customProps, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params ?? {};
        const requiredFields = ["homeUrl", "rootUrl"];
        if (!account || !hasFields(account, requiredFields)) {
          if (!account) throw new Error("no account for fetchAddressBooks");
          throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before fetchAddressBooks`);
        }
        const res = await propfind({
          url: account.homeUrl,
          props: {
            ...customProps ?? {
              [`d:displayname`]: {},
              [`cs:getctag`]: {},
              [`d:resourcetype`]: {},
              [`d:sync-token`]: {}
            },
            [`d:resourcetype`]: {}
          },
          depth: "1",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        assertDAVDiscovery(res, "Address book discovery failed");
        return Promise.all(res.filter((r) => Object.keys(r.props?.resourcetype ?? {}).includes("addressbook")).map((rs) => {
          const displayName = rs.props?.displayname?._cdata ?? rs.props?.displayname;
          debug$4(`Found address book named ${typeof displayName === "string" ? displayName : ""},
             props: ${JSON.stringify(rs.props)}`);
          return {
            url: new URL(rs.href ?? "", ensureTrailingSlash(account.rootUrl ?? "")).href,
            ctag: getDAVText(rs.props?.getctag),
            displayName: typeof displayName === "string" ? displayName : "",
            resourcetype: Object.keys(rs.props?.resourcetype ?? {}),
            syncToken: getDAVText(rs.props?.syncToken)
          };
        }).map(async (addr) => ({
          ...addr,
          reports: await supportedReportSet({
            collection: addr,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          })
        })));
      };
      fetchVCards = async (params) => {
        const { addressBook, headers, objectUrls, headersToExclude, urlFilter = (url) => Boolean(url), useMultiGet = true, fetchOptions = {}, fetch: fetchOverride } = params;
        debug$4(`Fetching vcards from ${addressBook?.url}`);
        const requiredFields = ["url"];
        if (!addressBook || !hasFields(addressBook, requiredFields)) {
          if (!addressBook) throw new Error("cannot fetchVCards for undefined addressBook");
          throw new Error(`addressBook must have ${findMissingFieldNames(addressBook, requiredFields)} before fetchVCards`);
        }
        const vcardUrls = (objectUrls ?? (await addressBookQuery({
          url: addressBook.url,
          props: { [`d:getetag`]: {} },
          depth: "1",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        })).map((res) => res.href ?? "")).filter((url) => typeof url === "string" && url.trim().length > 0).map((url) => url.startsWith("http") ? url : new URL(url, ensureTrailingSlash(addressBook.url)).href).filter((url) => !urlEquals(url, addressBook.url)).filter(urlFilter).map((url) => {
          const parsedUrl = new URL(url);
          return `${parsedUrl.pathname}${parsedUrl.search}`;
        });
        const targetUrls = new Set(vcardUrls.map((url) => getDAVUrlKey(url, addressBook.url)));
        let vCardResults = [];
        if (vcardUrls.length > 0) {
          if (useMultiGet) vCardResults = await addressBookMultiGet({
            url: addressBook.url,
            props: {
              [`d:getetag`]: {},
              [`card:address-data`]: {}
            },
            objectUrls: vcardUrls,
            depth: "1",
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          });
          else {
            vCardResults = await addressBookQuery({
              url: addressBook.url,
              props: {
                [`d:getetag`]: {},
                [`card:address-data`]: {}
              },
              depth: "1",
              headers: excludeHeaders(headers, headersToExclude),
              headersToExclude,
              fetchOptions,
              fetch: fetchOverride
            });
            vCardResults = vCardResults.filter((res) => !!res.href && targetUrls.has(getDAVUrlKey(res.href, addressBook.url)));
          }
        }
        assertDAVObjectResponses(vCardResults, "addressData", vcardUrls, addressBook.url, "VCard fetch failed");
        return vCardResults.map((res) => ({
          url: new URL(res.href ?? "", ensureTrailingSlash(addressBook.url)).href,
          etag: getDAVText(res.props?.getetag),
          data: res.props?.addressData?._cdata ?? res.props?.addressData
        }));
      };
      createVCard = async (params) => {
        const { addressBook, vCardString, filename, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return createObject({
          url: getObjectUrl(addressBook.url, filename),
          data: vCardString,
          headers: excludeHeaders({
            "content-type": "text/vcard; charset=utf-8",
            "If-None-Match": "*",
            ...headers
          }, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      updateVCard = async (params) => {
        const { vCard, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return updateObject({
          url: vCard.url,
          data: vCard.data,
          etag: vCard.etag,
          headers: excludeHeaders({
            "content-type": "text/vcard; charset=utf-8",
            ...headers
          }, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      deleteVCard = async (params) => {
        const { vCard, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return deleteObject({
          url: vCard.url,
          etag: vCard.etag,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      calendar_exports = /* @__PURE__ */ __exportAll({
        calendarMultiGet: () => calendarMultiGet,
        calendarQuery: () => calendarQuery,
        createCalendarObject: () => createCalendarObject,
        deleteCalendarObject: () => deleteCalendarObject,
        fetchCalendarObjects: () => fetchCalendarObjects,
        fetchCalendarUserAddresses: () => fetchCalendarUserAddresses,
        fetchCalendars: () => fetchCalendars,
        freeBusyQuery: () => freeBusyQuery,
        makeCalendar: () => makeCalendar,
        syncCalendars: () => syncCalendars,
        syncCalendarsDetailed: () => syncCalendarsDetailed,
        updateCalendarObject: () => updateCalendarObject
      });
      debug$3 = (0, import_browser.default)("tsdav:calendar");
      ISO_8601 = /^\d{4}(-\d\d(-\d\d(T\d\d:\d\d(:\d\d)?(\.\d+)?(([+-]\d\d:\d\d)|Z)?)?)?)?$/i;
      ISO_8601_FULL = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i;
      validateTimeRange = (timeRange) => {
        const { start, end } = timeRange;
        if (!(ISO_8601.test(start) && ISO_8601.test(end) || ISO_8601_FULL.test(start) && ISO_8601_FULL.test(end))) throw new Error("invalid timeRange format, not in ISO8601");
        if (Number.isNaN(new Date(start).getTime()) || Number.isNaN(new Date(end).getTime())) throw new Error("invalid timeRange: start or end is not a valid date");
        if (new Date(start).getTime() >= new Date(end).getTime()) throw new Error("invalid timeRange: start must be before end");
      };
      extractComponentNames = (compSet) => {
        let names = [];
        if (Array.isArray(compSet)) names = compSet.map((sc) => sc?._attributes?.name);
        else if (compSet && typeof compSet === "object") names = [compSet._attributes?.name];
        return names.filter((n) => typeof n === "string" && n.length > 0);
      };
      fetchCalendarUserAddresses = async (params) => {
        const { account, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requiredFields = ["principalUrl", "rootUrl"];
        if (!hasFields(account, requiredFields)) throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before fetchUserAddresses`);
        debug$3(`Fetch user addresses from ${account.principalUrl}`);
        const matched = (await propfind({
          url: account.principalUrl,
          props: { [`c:calendar-user-address-set`]: {} },
          depth: "0",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        })).find((r) => urlMatches(account.principalUrl, r.href, account.rootUrl));
        if (!matched || !matched.ok) throw new Error("cannot find calendarUserAddresses");
        const rawHrefs = matched?.props?.calendarUserAddressSet?.href;
        let hrefArray = [];
        if (Array.isArray(rawHrefs)) hrefArray = rawHrefs;
        else if (rawHrefs) hrefArray = [rawHrefs];
        const addresses = hrefArray.filter((h) => typeof h === "string" && h.length > 0);
        debug$3(`Fetched calendar user addresses ${addresses}`);
        return addresses;
      };
      calendarQuery = async (params) => {
        const { url, props, filters, timezone, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return collectionQuery({
          url,
          body: { "calendar-query": cleanupFalsy({
            _attributes: getDAVAttribute([
              "urn:ietf:params:xml:ns:caldav",
              "http://calendarserver.org/ns/",
              "http://apple.com/ns/ical/",
              "DAV:"
            ]),
            [`d:prop`]: props,
            filter: filters,
            timezone
          }) },
          defaultNamespace: "c",
          depth,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      calendarMultiGet = async (params) => {
        const { url, props, objectUrls, filters, timezone, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return collectionQuery({
          url,
          body: { "calendar-multiget": cleanupFalsy({
            _attributes: getDAVAttribute(["DAV:", "urn:ietf:params:xml:ns:caldav"]),
            [`d:prop`]: props,
            [`d:href`]: objectUrls,
            filter: filters,
            timezone
          }) },
          defaultNamespace: "c",
          depth,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      makeCalendar = async (params) => {
        const { url, props, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return davRequest({
          url,
          init: {
            method: "MKCALENDAR",
            headers: excludeHeaders(cleanupFalsy({
              depth,
              ...headers
            }), headersToExclude),
            namespace: "d",
            body: { [`c:mkcalendar`]: {
              _attributes: getDAVAttribute([
                "DAV:",
                "urn:ietf:params:xml:ns:caldav",
                "http://apple.com/ns/ical/"
              ]),
              set: { prop: props }
            } }
          },
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      fetchCalendars = async (params) => {
        const { headers, account, props: customProps, projectedProps, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params ?? {};
        const requiredFields = ["homeUrl", "rootUrl"];
        if (!account || !hasFields(account, requiredFields)) {
          if (!account) throw new Error("no account for fetchCalendars");
          throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before fetchCalendars`);
        }
        const res = await propfind({
          url: account.homeUrl,
          props: {
            ...customProps ?? {
              [`c:calendar-description`]: {},
              [`c:calendar-timezone`]: {},
              [`d:displayname`]: {},
              [`ca:calendar-color`]: {},
              [`cs:getctag`]: {},
              [`d:resourcetype`]: {},
              [`c:supported-calendar-component-set`]: {},
              [`d:sync-token`]: {}
            },
            [`d:resourcetype`]: {},
            [`c:supported-calendar-component-set`]: {}
          },
          depth: "1",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        assertDAVDiscovery(res, "Calendar discovery failed");
        return Promise.all(res.filter((r) => Object.keys(r.props?.resourcetype ?? {}).includes("calendar")).filter((rc) => {
          const components = extractComponentNames(rc.props?.supportedCalendarComponentSet?.comp);
          return components.length === 0 || components.some((c) => Object.values(ICALObjects).includes(c));
        }).map((rs) => {
          const description = rs.props?.calendarDescription;
          const timezone = rs.props?.calendarTimezone;
          const compSet = rs.props?.supportedCalendarComponentSet?.comp;
          const projectedEntries = Object.entries(rs.props ?? {}).filter(([key]) => projectedProps?.[key]);
          return {
            description: typeof description === "string" ? description : "",
            timezone: typeof timezone === "string" ? timezone : "",
            url: new URL(rs.href ?? "", ensureTrailingSlash(account.rootUrl ?? "")).href,
            ctag: getDAVText(rs.props?.getctag),
            calendarColor: rs.props?.calendarColor,
            displayName: getDAVText(rs.props?.displayname),
            components: extractComponentNames(compSet),
            resourcetype: Object.keys(rs.props?.resourcetype ?? {}),
            syncToken: getDAVText(rs.props?.syncToken),
            ...projectedProps && projectedEntries.length > 0 ? { projectedProps: Object.fromEntries(projectedEntries) } : {}
          };
        }).map(async (cal) => ({
          ...cal,
          reports: await supportedReportSet({
            collection: cal,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          })
        })));
      };
      fetchCalendarObjects = async (params) => {
        const { calendar, objectUrls, filters: customFilters, timeRange, headers, expand, urlFilter = (url) => Boolean(url?.includes(".ics")), useMultiGet = true, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        if (expand && !timeRange) throw new Error("timeRange is required when expand is true");
        if (timeRange) validateTimeRange(timeRange);
        debug$3(`Fetching calendar objects from ${calendar?.url}`);
        const requiredFields = ["url"];
        if (!calendar || !hasFields(calendar, requiredFields)) {
          if (!calendar) throw new Error("cannot fetchCalendarObjects for undefined calendar");
          throw new Error(`calendar must have ${findMissingFieldNames(calendar, requiredFields)} before fetchCalendarObjects`);
        }
        const filters = customFilters ?? [{ "comp-filter": {
          _attributes: { name: "VCALENDAR" },
          "comp-filter": {
            _attributes: { name: "VEVENT" },
            ...timeRange ? { "time-range": { _attributes: {
              start: `${new Date(timeRange.start).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`,
              end: `${new Date(timeRange.end).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`
            } } } : {}
          }
        } }];
        let initialResponses = [];
        if (!objectUrls) initialResponses = await calendarQuery({
          url: calendar.url,
          props: {
            [`d:getetag`]: {},
            ...expand && timeRange ? { [`c:calendar-data`]: { [`c:expand`]: { _attributes: {
              start: `${new Date(timeRange.start).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`,
              end: `${new Date(timeRange.end).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`
            } } } } : {}
          },
          filters,
          depth: "1",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        const calendarObjectUrls = (objectUrls ?? initialResponses.map((res) => res.href ?? "")).filter((url) => typeof url === "string" && url.trim().length > 0).map((url) => url.startsWith("http") ? url : new URL(url, ensureTrailingSlash(calendar.url)).href).filter(urlFilter).map((url) => {
          const parsedUrl = new URL(url);
          return `${parsedUrl.pathname}${parsedUrl.search}`;
        });
        const targetUrls = new Set(calendarObjectUrls.map((url) => getDAVUrlKey(url, calendar.url)));
        let calendarObjectResults = [];
        if (calendarObjectUrls.length > 0) {
          if (expand && !objectUrls) calendarObjectResults = initialResponses.filter((res) => {
            const fullUrl = (res.href ?? "").startsWith("http") ? res.href : new URL(res.href ?? "", ensureTrailingSlash(calendar.url)).href;
            return urlFilter(fullUrl ?? "");
          });
          else if (!useMultiGet) {
            calendarObjectResults = await calendarQuery({
              url: calendar.url,
              props: {
                [`d:getetag`]: {},
                [`c:calendar-data`]: { ...expand && timeRange ? { [`c:expand`]: { _attributes: {
                  start: `${new Date(timeRange.start).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`,
                  end: `${new Date(timeRange.end).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`
                } } } : {} }
              },
              filters,
              depth: "1",
              headers: excludeHeaders(headers, headersToExclude),
              headersToExclude,
              fetchOptions,
              fetch: fetchOverride
            });
            calendarObjectResults = calendarObjectResults.filter((res) => {
              const fullUrl = (res.href ?? "").startsWith("http") ? res.href ?? "" : new URL(res.href ?? "", ensureTrailingSlash(calendar.url)).href;
              return targetUrls.has(getDAVUrlKey(fullUrl, calendar.url));
            });
          } else calendarObjectResults = await calendarMultiGet({
            url: calendar.url,
            props: {
              [`d:getetag`]: {},
              [`c:calendar-data`]: { ...expand && timeRange ? { [`c:expand`]: { _attributes: {
                start: `${new Date(timeRange.start).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`,
                end: `${new Date(timeRange.end).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`
              } } } : {} }
            },
            objectUrls: calendarObjectUrls,
            depth: "1",
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            fetchOptions,
            fetch: fetchOverride
          });
        }
        assertDAVObjectResponses(calendarObjectResults, "calendarData", calendarObjectUrls, calendar.url, "Calendar object fetch failed");
        return calendarObjectResults.map((res) => ({
          url: new URL(res.href ?? "", ensureTrailingSlash(calendar.url)).href,
          etag: getDAVText(res.props?.getetag),
          data: res.props?.calendarData?._cdata ?? res.props?.calendarData
        }));
      };
      createCalendarObject = async (params) => {
        const { calendar, iCalString, filename, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return createObject({
          url: getObjectUrl(calendar.url, filename),
          data: iCalString,
          headers: excludeHeaders({
            "content-type": "text/calendar; charset=utf-8",
            "If-None-Match": "*",
            ...headers
          }, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      updateCalendarObject = async (params) => {
        const { calendarObject, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return updateObject({
          url: calendarObject.url,
          data: calendarObject.data,
          etag: calendarObject.etag,
          headers: excludeHeaders({
            "content-type": "text/calendar; charset=utf-8",
            ...headers
          }, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      deleteCalendarObject = async (params) => {
        const { calendarObject, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        return deleteObject({
          url: calendarObject.url,
          etag: calendarObject.etag,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
      };
      syncCalendars = async (params) => {
        const { oldCalendars, account, detailedResult, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        if (!account) throw new Error("Must have account before syncCalendars");
        const localCalendars = oldCalendars ?? account.calendars ?? [];
        const remoteCalendars = await fetchCalendars({
          account,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        const baseUrl = account.rootUrl ?? account.homeUrl ?? account.serverUrl;
        const localByUrl = new Map(localCalendars.map((cal) => [getDAVUrlKey(cal.url, baseUrl), cal]));
        const remoteByUrl = new Map(remoteCalendars.map((cal) => [getDAVUrlKey(cal.url, baseUrl), cal]));
        const created = remoteCalendars.filter((cal) => !localByUrl.has(getDAVUrlKey(cal.url, baseUrl)));
        const updated = [];
        const unchanged = [];
        const deleted = [];
        for (const local of localCalendars) {
          const remote = remoteByUrl.get(getDAVUrlKey(local.url, baseUrl));
          if (!remote) deleted.push(local);
          else if (!remote.syncToken && !remote.ctag || remote.syncToken && remote.syncToken !== local.syncToken || remote.ctag && remote.ctag !== local.ctag) updated.push({
            local,
            remote
          });
          else unchanged.push(local);
        }
        debug$3(`updated calendars: ${updated.map(({ remote }) => remote.displayName)}`);
        const updatedWithObjects = await Promise.all(updated.map(async ({ local, remote }) => {
          const fetchObjects = async (fetchParams) => {
            if (!fetchParams) return [];
            const { collection: collection2, ...requestParams } = fetchParams;
            return fetchCalendarObjects({
              ...requestParams,
              calendar: collection2,
              filters: { "comp-filter": { _attributes: { name: "VCALENDAR" } } },
              urlFilter: (url) => getDAVUrlKey(url, collection2.url) !== getDAVUrlKey(collection2.url, collection2.url)
            });
          };
          const collection = {
            ...remote,
            ctag: local.ctag,
            syncToken: local.syncToken,
            objects: local.objects,
            objectMultiGet: calendarMultiGet,
            fetchObjects
          };
          const result = await smartCollectionSync({
            collection,
            detailedResult: false,
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            account,
            fetchOptions,
            fetch: fetchOverride
          });
          return {
            ...result,
            ctag: remote.reports?.includes("syncCollection") ? remote.ctag ?? result.ctag : result.ctag ?? remote.ctag,
            syncToken: remote.reports?.includes("syncCollection") ? result.syncToken : remote.syncToken ?? result.syncToken
          };
        }));
        return detailedResult ? {
          created,
          updated: updatedWithObjects,
          deleted
        } : [
          ...unchanged,
          ...created,
          ...updatedWithObjects
        ];
      };
      syncCalendarsDetailed = async (params) => syncCalendars({
        ...params,
        detailedResult: true
      });
      freeBusyQuery = async (params) => {
        const { url, timeRange, depth, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        if (!timeRange) throw new Error("timeRange is required");
        validateTimeRange(timeRange);
        const response = (await collectionQuery({
          url,
          body: { "free-busy-query": cleanupFalsy({
            _attributes: getDAVAttribute(["urn:ietf:params:xml:ns:caldav"]),
            [`c:time-range`]: { _attributes: {
              start: `${new Date(timeRange.start).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`,
              end: `${new Date(timeRange.end).toISOString().slice(0, 19).replace(/[-:.]/g, "")}Z`
            } }
          }) },
          defaultNamespace: "c",
          depth,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        }))[0];
        if (!response) throw new Error("freeBusyQuery returned no response");
        return response;
      };
      SHIFTS = [
        [
          7,
          12,
          17,
          22
        ],
        [
          5,
          9,
          14,
          20
        ],
        [
          4,
          11,
          16,
          23
        ],
        [
          6,
          10,
          15,
          21
        ]
      ];
      K2 = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32));
      toHex$1 = (word) => {
        let hex = "";
        for (let i = 0; i < 4; i += 1) hex += (word >>> i * 8 & 255).toString(16).padStart(2, "0");
        return hex;
      };
      md5 = (input) => {
        const bytes = new TextEncoder().encode(input);
        const paddedLength = (bytes.length + 8 >>> 6) + 1 << 6;
        const buffer = new Uint8Array(paddedLength);
        buffer.set(bytes);
        buffer[bytes.length] = 128;
        const view = new DataView(buffer.buffer);
        const bitLength = bytes.length * 8;
        view.setUint32(paddedLength - 8, bitLength >>> 0, true);
        view.setUint32(paddedLength - 4, Math.floor(bitLength / 2 ** 32), true);
        let a0 = 1732584193;
        let b0 = 4023233417;
        let c0 = 2562383102;
        let d0 = 271733878;
        for (let offset = 0; offset < paddedLength; offset += 64) {
          let a = a0;
          let b = b0;
          let c = c0;
          let d = d0;
          for (let i = 0; i < 64; i += 1) {
            let f2;
            let g;
            if (i < 16) {
              f2 = b & c | ~b & d;
              g = i;
            } else if (i < 32) {
              f2 = d & b | ~d & c;
              g = (5 * i + 1) % 16;
            } else if (i < 48) {
              f2 = b ^ c ^ d;
              g = (3 * i + 5) % 16;
            } else {
              f2 = c ^ (b | ~d);
              g = 7 * i % 16;
            }
            const sum = a + f2 + K2[i] + view.getUint32(offset + g * 4, true) | 0;
            const shift = SHIFTS[i >>> 4][i % 4];
            a = d;
            d = c;
            c = b;
            b = b + (sum << shift | sum >>> 32 - shift) | 0;
          }
          a0 = a0 + a | 0;
          b0 = b0 + b | 0;
          c0 = c0 + c | 0;
          d0 = d0 + d | 0;
        }
        return toHex$1(a0) + toHex$1(b0) + toHex$1(c0) + toHex$1(d0);
      };
      debug$2 = (0, import_browser.default)("tsdav:digestAuth");
      TOKEN = /[!#$%&'*+.^_`|~0-9A-Za-z-]+/y;
      parseAuthenticateHeader = (value) => {
        const challenges = [];
        let current;
        let pos = 0;
        const skip = (chars) => {
          while (pos < value.length && chars.test(value[pos])) pos += 1;
        };
        while (pos < value.length) {
          skip(/[\s,]/);
          TOKEN.lastIndex = pos;
          const token = TOKEN.exec(value)?.[0];
          if (!token) {
            pos += 1;
            continue;
          }
          pos += token.length;
          skip(/\s/);
          if (value[pos] !== "=") {
            current = {
              scheme: token.toLowerCase(),
              params: {}
            };
            challenges.push(current);
            continue;
          }
          pos += 1;
          skip(/\s/);
          let paramValue = "";
          if (value[pos] === '"') {
            pos += 1;
            while (pos < value.length && value[pos] !== '"') {
              if (value[pos] === "\\") pos += 1;
              paramValue += value[pos] ?? "";
              pos += 1;
            }
            pos += 1;
          } else while (pos < value.length && !/[\s,]/.test(value[pos])) {
            paramValue += value[pos];
            pos += 1;
          }
          if (current) current.params[token.toLowerCase()] = paramValue;
        }
        return challenges;
      };
      SUPPORTED_ALGORITHMS = [
        "SHA-256",
        "SHA-256-SESS",
        "MD5",
        "MD5-SESS"
      ];
      toDigestChallenge = (params) => {
        const algorithm = (params.algorithm ?? "MD5").toUpperCase();
        if (params.realm == null || !params.nonce || !SUPPORTED_ALGORITHMS.includes(algorithm)) return;
        const qopOptions = params.qop?.split(",").map((qop) => qop.trim().toLowerCase());
        if (qopOptions && !qopOptions.includes("auth")) return;
        if (!qopOptions && algorithm.endsWith("-SESS")) return;
        return {
          realm: params.realm,
          nonce: params.nonce,
          opaque: params.opaque,
          domain: params.domain,
          qop: qopOptions ? "auth" : void 0,
          algorithm,
          stale: params.stale?.toLowerCase() === "true"
        };
      };
      selectDigestChallenge = (header, { unlessBasic = false, allowSHA256 = true } = {}) => {
        const challenges = parseAuthenticateHeader(header ?? "");
        if (unlessBasic && challenges.some(({ scheme }) => scheme === "basic")) return;
        return challenges.filter(({ scheme }) => scheme === "digest").map(({ params }) => toDigestChallenge(params)).filter((challenge) => challenge != null).filter((challenge) => allowSHA256 || !challenge.algorithm.startsWith("SHA")).sort((a, b) => SUPPORTED_ALGORITHMS.indexOf(a.algorithm) - SUPPORTED_ALGORITHMS.indexOf(b.algorithm))[0];
      };
      toHex = (bytes) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
      DigestUnsupportedError = class extends Error {
        constructor() {
          super("tsdav: Digest authentication requires the WebCrypto API (globalThis.crypto), available in Node.js >= 19, browsers, Bun and Deno. On Node.js 18, assign webcrypto from node:crypto to globalThis.crypto.");
          this.name = "DigestUnsupportedError";
        }
      };
      getCrypto = (algorithm) => {
        const { crypto } = globalThis;
        if (!crypto?.getRandomValues || algorithm?.startsWith("SHA") && !crypto.subtle) throw new DigestUnsupportedError();
        return crypto;
      };
      hash2 = async (algorithm, data) => algorithm.startsWith("MD5") ? md5(data) : toHex(new Uint8Array(await getCrypto(algorithm).subtle.digest("SHA-256", new TextEncoder().encode(data))));
      quote = (value) => `"${value.replace(/["\\]/g, "\\$&")}"`;
      usernameField = (username) => /^[\x20-\x7e]*$/.test(username) ? `username=${quote(username)}` : `username*=UTF-8''${encodeURIComponent(username).replace(/['()*]/g, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`)}`;
      buildDigestAuthorization = async (params) => {
        const { challenge, username, password, method, uri, cnonce } = params;
        const { realm, nonce, qop, algorithm } = challenge;
        const nc = params.nc.toString(16).padStart(8, "0");
        let ha1 = await hash2(algorithm, `${username}:${realm}:${password}`);
        if (algorithm.endsWith("-SESS")) ha1 = await hash2(algorithm, `${ha1}:${nonce}:${cnonce}`);
        const ha2 = await hash2(algorithm, `${method}:${uri}`);
        const response = await hash2(algorithm, qop ? `${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}` : `${ha1}:${nonce}:${ha2}`);
        return `Digest ${[
          usernameField(username),
          `realm=${quote(realm)}`,
          `uri=${quote(uri)}`,
          `algorithm=${algorithm.replace("-SESS", "-sess")}`,
          `nonce=${quote(nonce)}`,
          ...qop ? [
            `nc=${nc}`,
            `cnonce=${quote(cnonce)}`,
            `qop=${qop}`
          ] : [],
          `response=${quote(response)}`,
          ...challenge.opaque != null ? [`opaque=${quote(challenge.opaque)}`] : []
        ].join(", ")}`;
      };
      createCnonce = () => toHex(getCrypto().getRandomValues(/* @__PURE__ */ new Uint8Array(16)));
      toURL = (input) => {
        if (input instanceof URL) return input;
        if (typeof input !== "string") return void 0;
        try {
          return new URL(input);
        } catch {
          return;
        }
      };
      isReplayable = (body) => body == null || typeof body !== "object" || !(typeof body.getReader === "function" || Symbol.asyncIterator in body);
      MAX_REDIRECTS = 20;
      REDIRECT_STATUSES = [
        301,
        302,
        303,
        307,
        308
      ];
      BODY_HEADERS = [
        "content-encoding",
        "content-language",
        "content-location",
        "content-type"
      ];
      redirectInit = (status2, init3) => {
        const method = (init3.method ?? "GET").toUpperCase();
        if (status2 === 303 && method !== "GET" && method !== "HEAD" || (status2 === 301 || status2 === 302) && method === "POST") {
          const headers = new Headers(init3.headers);
          for (const name of BODY_HEADERS) headers.delete(name);
          return {
            ...init3,
            method: "GET",
            body: void 0,
            headers
          };
        }
        return init3;
      };
      withoutAuthorization = (init3) => {
        const headers = new Headers(init3.headers);
        headers.delete("authorization");
        return {
          ...init3,
          headers
        };
      };
      protectionScopes = (challenge, url) => {
        if (!challenge.domain?.trim()) return [`${url.origin}/`];
        return challenge.domain.trim().split(/\s+/).flatMap((scope) => {
          try {
            if (!scope.startsWith("/") && !/^[a-z][a-z\d+.-]*:/i.test(scope)) return [];
            const target = new URL(scope, `${url.origin}/`);
            target.hash = "";
            return target.origin === url.origin ? [target.href] : [];
          } catch {
            return [];
          }
        });
      };
      createDigestAuthState = (active = true) => ({
        active,
        challenges: /* @__PURE__ */ new Map()
      });
      createDigestFetch = (params) => {
        const { credentials, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const state2 = params.state ?? createDigestAuthState();
        const authorize = async (init3, url, method, uri) => {
          const entry = state2.challenges.get(url.origin)?.find((session) => session.scopes.some((scope) => url.href.startsWith(scope)));
          if (!entry) return withoutAuthorization(init3);
          entry.nc += 1;
          const { challenge, nc } = entry;
          const authorization = await buildDigestAuthorization({
            challenge,
            username: credentials.username ?? "",
            password: credentials.password ?? "",
            method,
            uri,
            nc,
            cnonce: challenge.algorithm.endsWith("-SESS") ? entry.cnonce : createCnonce()
          });
          const headers = new Headers(init3.headers);
          headers.set("authorization", authorization);
          return {
            ...init3,
            headers
          };
        };
        const acceptChallenge = (response, url) => {
          const header = response.headers.get("www-authenticate");
          const options = { unlessBasic: !state2.active };
          const challenge = !globalThis.crypto?.subtle && selectDigestChallenge(header, {
            ...options,
            allowSHA256: false
          }) || selectDigestChallenge(header, options);
          if (!challenge) return false;
          try {
            getCrypto(challenge.algorithm);
          } catch (err2) {
            if (!state2.active && err2 instanceof DigestUnsupportedError) return false;
            throw err2;
          }
          if (!state2.active) {
            debug$2("Server only offers Digest authentication, switching from Basic");
            state2.active = true;
          }
          debug$2(`Digest challenge received for ${url.origin}${challenge.stale ? " (stale nonce)" : ""}`);
          const sessions = state2.challenges.get(url.origin) ?? [];
          const scopes = protectionScopes(challenge, url);
          const known = sessions.find((session) => session.challenge.realm === challenge.realm && session.challenge.algorithm === challenge.algorithm && session.challenge.nonce === challenge.nonce);
          state2.challenges.set(url.origin, [{
            challenge,
            scopes,
            nc: known?.nc ?? 0,
            cnonce: known?.cnonce ?? createCnonce()
          }, ...sessions.filter((session) => session.challenge.realm !== challenge.realm)]);
          return true;
        };
        const request = async (input, init3, url, retry) => {
          const method = (init3.method ?? "GET").toUpperCase();
          const uri = `${url.pathname}${url.search}`;
          const response = await requestFetch(input, await authorize(init3, url, method, uri));
          if (response.status !== 401 || !retry || !isReplayable(init3.body) || !acceptChallenge(response, url)) return response;
          await response.body?.cancel().catch(() => void 0);
          return requestFetch(input, await authorize(init3, url, method, uri));
        };
        return async (input, init3 = {}) => {
          const url = toURL(input);
          if (!url) return requestFetch(input, init3);
          if (state2.active) init3 = {
            ...init3,
            credentials: init3.credentials ?? "omit"
          };
          let challenged = false;
          if (!state2.active) {
            const response = await requestFetch(input, init3);
            if (response.status !== 401 || !isReplayable(init3.body) || (toURL(response.url ?? "") ?? url).origin !== url.origin || !acceptChallenge(response, toURL(response.url) ?? url)) return response;
            await response.body?.cancel().catch(() => void 0);
            challenged = true;
            init3 = {
              ...init3,
              credentials: init3.credentials ?? "omit"
            };
            const finalUrl = toURL(response.url) ?? url;
            if (finalUrl.href !== url.href) {
              const method = (init3.method ?? "GET").toUpperCase();
              if (method !== "GET" && method !== "HEAD") throw new TypeError("tsdav: Digest negotiation after an automatic redirect requires the final DAV URL. Set serverUrl and collection URLs to their canonical locations.");
              return request(finalUrl.href, {
                ...init3,
                redirect: "error"
              }, finalUrl, false);
            }
          }
          if ((init3.redirect ?? "follow") !== "follow" || !isReplayable(init3.body)) return request(input, init3, url, !challenged);
          let target = input;
          let targetUrl = url;
          let targetInit = {
            ...init3,
            redirect: "manual"
          };
          let leftOrigin = false;
          for (let redirects = 0; ; redirects += 1) {
            const response = leftOrigin ? await requestFetch(target, targetInit) : await request(target, targetInit, targetUrl, !challenged);
            challenged = false;
            if (response.type === "opaqueredirect") {
              const method = (targetInit.method ?? "GET").toUpperCase();
              if (method !== "GET" && method !== "HEAD") throw new TypeError("tsdav: Digest authentication cannot safely follow an opaque browser redirect for this method. Use the final DAV URL, including its trailing slash.");
              const resolved = await requestFetch(target, {
                ...withoutAuthorization(targetInit),
                redirect: "follow"
              });
              const finalUrl = toURL(resolved.url);
              if (!finalUrl || finalUrl.origin !== url.origin || leftOrigin || resolved.status !== 401) return resolved;
              if (!acceptChallenge(resolved, finalUrl)) return resolved;
              await resolved.body?.cancel().catch(() => void 0);
              return request(finalUrl.href, {
                ...targetInit,
                redirect: "error"
              }, finalUrl, false);
            }
            const location2 = response.headers.get("location");
            if (!REDIRECT_STATUSES.includes(response.status) || !location2) return response;
            if (redirects === MAX_REDIRECTS) throw new TypeError("tsdav: too many redirects");
            await response.body?.cancel().catch(() => void 0);
            targetUrl = new URL(location2, targetUrl);
            target = targetUrl.href;
            targetInit = redirectInit(response.status, targetInit);
            if (targetUrl.origin !== url.origin) {
              leftOrigin = true;
              targetInit = withoutAuthorization(targetInit);
            }
          }
        };
      };
      account_exports = /* @__PURE__ */ __exportAll({
        createAccount: () => createAccount,
        fetchHomeUrl: () => fetchHomeUrl,
        fetchPrincipalUrl: () => fetchPrincipalUrl,
        serviceDiscovery: () => serviceDiscovery
      });
      debug$1 = (0, import_browser.default)("tsdav:account");
      getCandidateRootUrls = (serverUrl, discoveredRootUrl) => {
        const candidates = [
          discoveredRootUrl,
          serverUrl,
          new URL("/", serverUrl).href
        ];
        return candidates.filter((url, index) => candidates.indexOf(url) === index);
      };
      serviceDiscovery = async (params) => {
        debug$1("Service discovery...");
        const { account, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requestFetch = fetchOverride ?? fetch2;
        const endpoint = new URL(account.serverUrl);
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions;
        const uri = new URL(`/.well-known/${account.accountType}`, endpoint);
        uri.protocol = endpoint.protocol ?? "http";
        const extractRedirect = (response) => {
          if (response.status >= 300 && response.status < 400) {
            const location2 = response.headers.get("Location");
            if (typeof location2 === "string" && location2.length) {
              debug$1(`Service discovery redirected to ${location2}`);
              return new URL(location2, uri).href;
            }
          }
        };
        try {
          const redirectUrl = extractRedirect(await requestFetch(uri.href, {
            ...fetchOptionsWithoutHeaders,
            method: "PROPFIND",
            headers: excludeHeaders(mergeHeaders({ "Content-Type": "text/xml;charset=UTF-8" }, headers, fetchHeaders), headersToExclude),
            body: `<?xml version="1.0" encoding="utf-8" ?>
<d:propfind xmlns:d="DAV:">
  <d:prop>
    <d:resourcetype/>
  </d:prop>
</d:propfind>`,
            redirect: "manual"
          }));
          if (redirectUrl) return redirectUrl;
        } catch (err2) {
          if (err2 instanceof DigestUnsupportedError) throw err2;
          debug$1(`Service discovery PROPFIND failed: ${err2.stack}`);
        }
        try {
          const redirectUrl = extractRedirect(await requestFetch(uri.href, {
            ...fetchOptionsWithoutHeaders,
            method: "GET",
            body: void 0,
            headers: excludeHeaders(mergeHeaders(headers, fetchHeaders), headersToExclude),
            redirect: "manual"
          }));
          if (redirectUrl) return redirectUrl;
        } catch (err2) {
          if (err2 instanceof DigestUnsupportedError) throw err2;
          debug$1(`Service discovery GET failed: ${err2.stack}`);
        }
        return endpoint.href;
      };
      extractHref = (raw) => {
        if (typeof raw === "string" && raw.trim().length > 0) return raw.trim();
        if (Array.isArray(raw)) {
          for (const item of raw) {
            const found = extractHref(item);
            if (found) return found;
          }
          return;
        }
        if (raw && typeof raw === "object") {
          if ("_cdata" in raw && typeof raw._cdata === "string") {
            const cdata = raw._cdata.trim();
            if (cdata.length > 0) return cdata;
          }
          if ("_text" in raw && typeof raw._text === "string") {
            const text = raw._text.trim();
            if (text.length > 0) return text;
          }
        }
      };
      fetchPrincipalUrl = async (params) => {
        const { account, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requiredFields = ["rootUrl"];
        if (!hasFields(account, requiredFields)) throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before fetchPrincipalUrl`);
        debug$1(`Fetching principal url from path ${account.rootUrl}`);
        const [response] = await propfind({
          url: account.rootUrl,
          props: { [`d:current-user-principal`]: {} },
          depth: "0",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        if (!response?.ok) {
          debug$1(`Fetch principal url failed: ${response?.statusText ?? "empty response"}`);
          if (response?.status === 401) throw new Error(`Invalid credentials: PROPFIND ${account.rootUrl} returned 401 Unauthorized`);
          throw new Error("cannot find principalUrl");
        }
        const principalHref = extractHref(response.props?.currentUserPrincipal?.href);
        if (!principalHref) {
          debug$1("Fetch principal url failed: missing current-user-principal href");
          throw new Error("cannot find principalUrl");
        }
        debug$1(`Fetched principal url ${principalHref}`);
        return new URL(principalHref, ensureTrailingSlash(account.rootUrl)).href;
      };
      fetchHomeUrl = async (params) => {
        const { account, headers, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const requiredFields = ["principalUrl", "rootUrl"];
        if (!hasFields(account, requiredFields)) throw new Error(`account must have ${findMissingFieldNames(account, requiredFields)} before fetchHomeUrl`);
        debug$1(`Fetch home url from ${account.principalUrl}`);
        const responses = await propfind({
          url: account.principalUrl,
          props: account.accountType === "caldav" ? { [`c:calendar-home-set`]: {} } : { [`card:addressbook-home-set`]: {} },
          depth: "0",
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        const matched = responses.find((r) => urlMatches(account.principalUrl, r.href, account.rootUrl));
        if (!matched || !matched.ok) {
          debug$1(`Fetch home url failed with status ${matched?.statusText} and error ${JSON.stringify(responses.map((r) => r.error))}`);
          throw new Error("cannot find homeUrl");
        }
        const homeHref = extractHref(account.accountType === "caldav" ? matched.props?.calendarHomeSet?.href : matched.props?.addressbookHomeSet?.href);
        if (!homeHref) {
          debug$1(`Fetch home url failed: server did not return a ${account.accountType === "caldav" ? "calendar-home-set" : "addressbook-home-set"} href`);
          throw new Error("cannot find homeUrl");
        }
        const result = new URL(homeHref, ensureTrailingSlash(account.rootUrl)).href;
        debug$1(`Fetched home url ${result}`);
        return result;
      };
      createAccount = async (params) => {
        const { account, headers, loadCollections = false, loadObjects = false, headersToExclude, fetchOptions = {}, fetch: fetchOverride } = params;
        const newAccount = { ...account };
        const discoveredRootUrl = account.rootUrl ?? await serviceDiscovery({
          account,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        if (account.rootUrl) newAccount.rootUrl = account.rootUrl;
        else if (account.principalUrl) newAccount.rootUrl = discoveredRootUrl;
        else {
          const findPrincipalUrl = async (rootUrls, index = 0, lastPrincipalError) => {
            const rootUrl2 = rootUrls[index];
            if (!rootUrl2) throw lastPrincipalError ?? /* @__PURE__ */ new Error("cannot find principalUrl");
            try {
              return {
                rootUrl: rootUrl2,
                principalUrl: await fetchPrincipalUrl({
                  account: {
                    ...newAccount,
                    rootUrl: rootUrl2
                  },
                  headers: excludeHeaders(headers, headersToExclude),
                  headersToExclude,
                  fetchOptions,
                  fetch: fetchOverride
                })
              };
            } catch (err2) {
              if (err2 instanceof DigestUnsupportedError) throw err2;
              const isCredentialsError = lastPrincipalError?.message.startsWith("Invalid credentials");
              return findPrincipalUrl(rootUrls, index + 1, isCredentialsError ? lastPrincipalError : err2);
            }
          };
          const { rootUrl, principalUrl } = await findPrincipalUrl(getCandidateRootUrls(account.serverUrl, discoveredRootUrl));
          newAccount.rootUrl = rootUrl;
          newAccount.principalUrl = principalUrl;
        }
        newAccount.principalUrl = account.principalUrl ?? newAccount.principalUrl ?? await fetchPrincipalUrl({
          account: newAccount,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        newAccount.homeUrl = account.homeUrl ?? await fetchHomeUrl({
          account: newAccount,
          headers: excludeHeaders(headers, headersToExclude),
          headersToExclude,
          fetchOptions,
          fetch: fetchOverride
        });
        if (loadCollections || loadObjects) {
          if (account.accountType === "caldav") newAccount.calendars = await fetchCalendars({
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            account: newAccount,
            fetchOptions,
            fetch: fetchOverride
          });
          else if (account.accountType === "carddav") newAccount.addressBooks = await fetchAddressBooks({
            headers: excludeHeaders(headers, headersToExclude),
            headersToExclude,
            account: newAccount,
            fetchOptions,
            fetch: fetchOverride
          });
        }
        if (loadObjects) {
          if (account.accountType === "caldav" && newAccount.calendars) newAccount.calendars = await Promise.all(newAccount.calendars.map(async (cal) => ({
            ...cal,
            objects: await fetchCalendarObjects({
              calendar: cal,
              filters: { "comp-filter": { _attributes: { name: "VCALENDAR" } } },
              urlFilter: (url) => !urlEquals(url, cal.url),
              headers: excludeHeaders(headers, headersToExclude),
              headersToExclude,
              fetchOptions,
              fetch: fetchOverride
            })
          })));
          else if (account.accountType === "carddav" && newAccount.addressBooks) newAccount.addressBooks = await Promise.all(newAccount.addressBooks.map(async (addr) => ({
            ...addr,
            objects: await fetchVCards({
              addressBook: addr,
              headers: excludeHeaders(headers, headersToExclude),
              headersToExclude,
              fetchOptions,
              fetch: fetchOverride
            })
          })));
        }
        return newAccount;
      };
      EXPIRY_MARGIN_MS = 6e4;
      isTokenUnexpired = (expiration) => Date.now() < expiration - EXPIRY_MARGIN_MS;
      getTokenExpiration = (expiresIn) => {
        const seconds = typeof expiresIn === "string" && expiresIn.trim() !== "" ? Number(expiresIn) : expiresIn;
        return typeof seconds === "number" && Number.isFinite(seconds) && seconds > 0 ? Date.now() + seconds * 1e3 : void 0;
      };
      authHelpers_exports = /* @__PURE__ */ __exportAll({
        defaultParam: () => defaultParam,
        fetchOauthTokens: () => fetchOauthTokens,
        getBasicAuthHeaders: () => getBasicAuthHeaders,
        getBearerAuthHeaders: () => getBearerAuthHeaders,
        getOauthHeaders: () => getOauthHeaders,
        refreshAccessToken: () => refreshAccessToken
      });
      debug = (0, import_browser.default)("tsdav:authHelper");
      BASE64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      NON_LATIN1_BASIC_AUTH_MESSAGE = "The string to be encoded contains characters outside of the Latin1 range.";
      InvalidCharacterError = class extends Error {
        constructor(message) {
          super(message);
          this.name = "InvalidCharacterError";
        }
      };
      assertLatin1 = (charCode) => {
        if (charCode > 255) throw new InvalidCharacterError(NON_LATIN1_BASIC_AUTH_MESSAGE);
      };
      encodeBase64 = (input) => {
        let output = "";
        let position = 0;
        while (position < input.length) {
          const first = input.charCodeAt(position);
          position += 1;
          assertLatin1(first);
          if (position === input.length) {
            output += BASE64_ALPHABET[Math.floor(first / 4)];
            output += `${BASE64_ALPHABET[first % 4 * 16]}==`;
            break;
          }
          const second = input.charCodeAt(position);
          position += 1;
          assertLatin1(second);
          if (position === input.length) {
            output += BASE64_ALPHABET[Math.floor(first / 4)];
            output += BASE64_ALPHABET[first % 4 * 16 + Math.floor(second / 16)];
            output += `${BASE64_ALPHABET[second % 16 * 4]}=`;
            break;
          }
          const third = input.charCodeAt(position);
          position += 1;
          assertLatin1(third);
          output += BASE64_ALPHABET[Math.floor(first / 4)];
          output += BASE64_ALPHABET[first % 4 * 16 + Math.floor(second / 16)];
          output += BASE64_ALPHABET[second % 16 * 4 + Math.floor(third / 64)];
          output += BASE64_ALPHABET[third % 64];
        }
        return output;
      };
      defaultParam = (fn, params) => (...args) => {
        const overrides = args[0];
        const mergedParams = {
          ...params,
          ...overrides
        };
        if (params.headers || overrides?.headers) mergedParams.headers = mergeHeaders(params.headers, overrides?.headers);
        return fn(mergedParams);
      };
      getBasicAuthHeaders = (credentials) => {
        debug(`Basic auth token generated for user "${credentials.username ?? ""}"`);
        return { authorization: `Basic ${encodeBase64(`${credentials.username}:${credentials.password}`)}` };
      };
      getBearerAuthHeaders = (credentials) => {
        return { authorization: `Bearer ${credentials.accessToken}` };
      };
      fetchOauthTokens = async (credentials, fetchOptions, fetchOverride) => {
        const requireFields = [
          "authorizationCode",
          "redirectUrl",
          "clientId",
          "clientSecret",
          "tokenUrl"
        ];
        if (!hasFields(credentials, requireFields)) throw new Error(`Oauth credentials missing: ${findMissingFieldNames(credentials, requireFields)}`);
        const param = new URLSearchParams({
          grant_type: "authorization_code",
          code: credentials.authorizationCode,
          redirect_uri: credentials.redirectUrl,
          client_id: credentials.clientId,
          client_secret: credentials.clientSecret
        });
        debug(`Fetching oauth tokens from ${credentials.tokenUrl}`);
        const requestFetch = fetchOverride ?? fetch2;
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions ?? {};
        const response = await requestFetch(credentials.tokenUrl, {
          ...fetchOptionsWithoutHeaders,
          method: "POST",
          body: param.toString(),
          headers: mergeHeaders({ "content-type": "application/x-www-form-urlencoded" }, fetchHeaders)
        });
        if (response.ok) return await response.json();
        debug(`Fetch Oauth tokens failed with status ${response.status}`);
        return {};
      };
      refreshAccessToken = async (credentials, fetchOptions, fetchOverride) => {
        const requireFields = [
          "refreshToken",
          "clientId",
          "clientSecret",
          "tokenUrl"
        ];
        if (!hasFields(credentials, requireFields)) throw new Error(`Oauth credentials missing: ${findMissingFieldNames(credentials, requireFields)}`);
        const param = new URLSearchParams({
          client_id: credentials.clientId,
          client_secret: credentials.clientSecret,
          refresh_token: credentials.refreshToken,
          grant_type: "refresh_token"
        });
        const requestFetch = fetchOverride ?? fetch2;
        const { headers: fetchHeaders, ...fetchOptionsWithoutHeaders } = fetchOptions ?? {};
        const response = await requestFetch(credentials.tokenUrl, {
          ...fetchOptionsWithoutHeaders,
          method: "POST",
          body: param.toString(),
          headers: mergeHeaders({ "Content-Type": "application/x-www-form-urlencoded" }, fetchHeaders)
        });
        if (response.ok) return await response.json();
        debug(`Refresh access token failed with status ${response.status}`);
        return {};
      };
      getOauthHeaders = async (credentials, fetchOptions, fetchOverride) => {
        debug("Fetching oauth headers");
        let tokens = {};
        let didRefresh = false;
        if (credentials.accessToken && (credentials.expiration == null && !credentials.refreshToken || credentials.expiration != null && isTokenUnexpired(credentials.expiration))) tokens = {
          access_token: credentials.accessToken,
          refresh_token: credentials.refreshToken
        };
        else {
          tokens = credentials.refreshToken ? await refreshAccessToken(credentials, fetchOptions, fetchOverride) : await fetchOauthTokens(credentials, fetchOptions, fetchOverride);
          didRefresh = true;
        }
        if (didRefresh) {
          if (tokens.access_token) credentials.accessToken = tokens.access_token;
          if (tokens.refresh_token) credentials.refreshToken = tokens.refresh_token;
          if (tokens.access_token) credentials.expiration = getTokenExpiration(tokens.expires_in);
        }
        debug("Oauth tokens obtained");
        return {
          tokens,
          headers: tokens.access_token ? { authorization: `Bearer ${tokens.access_token}` } : {}
        };
      };
      client_exports = /* @__PURE__ */ __exportAll({
        DAVClient: () => DAVClient,
        createDAVClient: () => createDAVClient
      });
      resolveAuthHeaders = async (client, fetchOptions = client.fetchOptions, fetchOverride = client.fetchOverride) => {
        switch (client.authMethod) {
          case "Basic":
            return getBasicAuthHeaders(client.credentials);
          case "Bearer":
            return getBearerAuthHeaders(client.credentials);
          case "Oauth": {
            const { headers } = await getOauthHeaders(client.credentials, fetchOptions, fetchOverride);
            if (!headers.authorization) throw new Error("OAuth authentication failed: token endpoint returned no access token");
            return headers;
          }
          case "Digest":
            return client.credentials.digestString != null ? { Authorization: `Digest ${client.credentials.digestString}` } : {};
          case "Custom":
            if (!client.authFunction) throw new Error("authMethod 'Custom' requires an authFunction to produce request headers");
            return await client.authFunction(client.credentials) ?? {};
          default:
            throw new Error("Invalid auth method");
        }
      };
      digestStates = /* @__PURE__ */ new WeakMap();
      authFetch = (client, fetchOverride = client.fetchOverride, headersToExclude, requestHeaders = client.fetchOptions?.headers) => {
        const digest = client.authMethod === "Digest" && client.credentials.digestString == null;
        if (!digest && client.authMethod !== "Basic" || new Headers(requestHeaders).has("authorization") || headersToExclude?.some((header) => header.toLowerCase() === "authorization")) return fetchOverride;
        let entry = digestStates.get(client);
        const { username, password } = client.credentials;
        if (!entry || entry.authMethod !== client.authMethod || entry.username !== username || entry.password !== password) {
          entry = {
            state: createDigestAuthState(digest),
            authMethod: client.authMethod,
            username,
            password
          };
          digestStates.set(client, entry);
        }
        return createDigestFetch({
          credentials: client.credentials,
          fetch: fetchOverride,
          state: entry.state
        });
      };
      createDAVClient = async (params) => {
        const client = new DAVClient(params);
        client.authHeaders = await resolveAuthHeaders(client);
        client.account = params.defaultAccountType ? await createAccount({
          account: {
            serverUrl: params.serverUrl,
            credentials: params.credentials,
            accountType: params.defaultAccountType
          },
          headers: client.authHeaders,
          fetchOptions: client.fetchOptions,
          fetch: authFetch(client)
        }) : void 0;
        return {
          davRequest: client.davRequest.bind(client),
          propfind: client.propfind.bind(client),
          createAccount: async (...args) => {
            if (!args[0].account.accountType) throw new Error("createAccount requires an accountType; pass one via `account.accountType`.");
            return client.createAccount(...args);
          },
          createObject: client.createObject.bind(client),
          updateObject: client.updateObject.bind(client),
          deleteObject: client.deleteObject.bind(client),
          calendarQuery: client.calendarQuery.bind(client),
          addressBookQuery: client.addressBookQuery.bind(client),
          collectionQuery: client.collectionQuery.bind(client),
          makeCollection: client.makeCollection.bind(client),
          calendarMultiGet: client.calendarMultiGet.bind(client),
          makeCalendar: client.makeCalendar.bind(client),
          freeBusyQuery: client.freeBusyQuery.bind(client),
          syncCollection: client.syncCollection.bind(client),
          supportedReportSet: client.supportedReportSet.bind(client),
          isCollectionDirty: client.isCollectionDirty.bind(client),
          smartCollectionSync: client.smartCollectionSync.bind(client),
          smartCollectionSyncDetailed: client.smartCollectionSyncDetailed.bind(client),
          fetchCalendars: client.fetchCalendars.bind(client),
          fetchCalendarUserAddresses: client.fetchCalendarUserAddresses.bind(client),
          fetchCalendarObjects: client.fetchCalendarObjects.bind(client),
          createCalendarObject: client.createCalendarObject.bind(client),
          updateCalendarObject: client.updateCalendarObject.bind(client),
          deleteCalendarObject: client.deleteCalendarObject.bind(client),
          syncCalendars: client.syncCalendars.bind(client),
          syncCalendarsDetailed: client.syncCalendarsDetailed.bind(client),
          fetchAddressBooks: client.fetchAddressBooks.bind(client),
          addressBookMultiGet: client.addressBookMultiGet.bind(client),
          fetchVCards: client.fetchVCards.bind(client),
          createVCard: client.createVCard.bind(client),
          updateVCard: client.updateVCard.bind(client),
          deleteVCard: client.deleteVCard.bind(client)
        };
      };
      DAVClient = class {
        constructor(params) {
          this.serverUrl = params.serverUrl;
          this.credentials = params.credentials;
          this.authMethod = params.authMethod ?? "Basic";
          this.accountType = params.defaultAccountType ?? "caldav";
          this.authFunction = params.authFunction;
          this.fetchOptions = params.fetchOptions ?? {};
          this.fetchOverride = params.fetch;
          this.calendarMultiGet = this.calendarMultiGet.bind(this);
          this.addressBookMultiGet = this.addressBookMultiGet.bind(this);
        }
        async authenticate(force = false, fetchOptions = this.fetchOptions, fetchOverride = this.fetchOverride) {
          if (!force && this.authMethod !== "Oauth") return;
          if (!force && this.authHeaders && this.credentials.accessToken && (this.credentials.expiration == null || isTokenUnexpired(this.credentials.expiration))) {
            this.authHeaders = { authorization: `Bearer ${this.credentials.accessToken}` };
            return;
          }
          if (this.authentication) return this.authentication;
          const authenticate = async () => {
            this.authHeaders = await resolveAuthHeaders(this, fetchOptions, fetchOverride);
          };
          this.authentication = authenticate();
          try {
            await this.authentication;
          } finally {
            this.authentication = void 0;
          }
        }
        async requestDefaults(params) {
          await this.authenticate(false, params?.fetchOptions ?? this.fetchOptions, params?.fetch ?? this.fetchOverride);
          return {
            url: this.serverUrl,
            headers: this.authHeaders,
            account: this.account,
            fetchOptions: this.fetchOptions,
            fetch: authFetch(this, params?.fetch, params?.headersToExclude, mergeHeaders(params?.headers, params?.init?.headers, (params?.fetchOptions ?? this.fetchOptions)?.headers))
          };
        }
        async invoke(fn, params) {
          const defaults = await this.requestDefaults(params);
          const callParams = params ? {
            ...params,
            fetch: defaults.fetch
          } : params;
          return await defaultParam(fn, defaults)(...[callParams]);
        }
        async login(options) {
          await this.authenticate(true);
          this.account = this.accountType ? await createAccount({
            account: {
              serverUrl: this.serverUrl,
              credentials: this.credentials,
              accountType: this.accountType
            },
            headers: this.authHeaders,
            loadCollections: options?.loadCollections,
            loadObjects: options?.loadObjects,
            fetchOptions: this.fetchOptions,
            fetch: authFetch(this)
          }) : void 0;
        }
        async davRequest(params0) {
          const { init: init3, fetchOptions, ...rest } = params0;
          const { headers, ...restInit } = init3;
          const defaults = await this.requestDefaults(params0);
          return davRequest({
            ...rest,
            init: {
              ...restInit,
              headers: mergeHeaders(defaults.headers, headers)
            },
            fetchOptions: fetchOptions ?? this.fetchOptions,
            fetch: defaults.fetch
          });
        }
        async createObject(...params) {
          return this.invoke(createObject, params[0]);
        }
        async updateObject(...params) {
          return this.invoke(updateObject, params[0]);
        }
        async deleteObject(...params) {
          return this.invoke(deleteObject, params[0]);
        }
        async propfind(...params) {
          return this.invoke(propfind, params[0]);
        }
        async createAccount(params0) {
          const { account, headers, headersToExclude, loadCollections, loadObjects, fetchOptions } = params0;
          const defaults = await this.requestDefaults(params0);
          const accountType = account.accountType ?? this.accountType;
          if (!accountType) throw new Error("createAccount requires an accountType; pass one via `account.accountType` or configure `defaultAccountType` on the DAVClient.");
          return createAccount({
            account: {
              serverUrl: this.serverUrl,
              credentials: this.credentials,
              ...account,
              accountType
            },
            headers: mergeHeaders(defaults.headers, headers),
            headersToExclude,
            loadCollections,
            loadObjects,
            fetchOptions: fetchOptions ?? this.fetchOptions,
            fetch: defaults.fetch
          });
        }
        async collectionQuery(...params) {
          return this.invoke(collectionQuery, params[0]);
        }
        async makeCollection(...params) {
          return this.invoke(makeCollection, params[0]);
        }
        async syncCollection(...params) {
          return this.invoke(syncCollection, params[0]);
        }
        async supportedReportSet(...params) {
          return this.invoke(supportedReportSet, params[0]);
        }
        async isCollectionDirty(...params) {
          return this.invoke(isCollectionDirty, params[0]);
        }
        async smartCollectionSync(...params) {
          return this.invoke(smartCollectionSync, params[0]);
        }
        async smartCollectionSyncDetailed(param) {
          return this.invoke(smartCollectionSyncDetailed, param);
        }
        async calendarQuery(...params) {
          return this.invoke(calendarQuery, params[0]);
        }
        async makeCalendar(...params) {
          return this.invoke(makeCalendar, params[0]);
        }
        async freeBusyQuery(...params) {
          return this.invoke(freeBusyQuery, params[0]);
        }
        async calendarMultiGet(...params) {
          return this.invoke(calendarMultiGet, params[0]);
        }
        async fetchCalendars(...params) {
          return this.invoke(fetchCalendars, params[0]);
        }
        async fetchCalendarUserAddresses(...params) {
          return this.invoke(fetchCalendarUserAddresses, params[0]);
        }
        async fetchCalendarObjects(...params) {
          return this.invoke(fetchCalendarObjects, params[0]);
        }
        async createCalendarObject(...params) {
          return this.invoke(createCalendarObject, params[0]);
        }
        async updateCalendarObject(...params) {
          return this.invoke(updateCalendarObject, params[0]);
        }
        async deleteCalendarObject(...params) {
          return this.invoke(deleteCalendarObject, params[0]);
        }
        async syncCalendars(...params) {
          return this.invoke(syncCalendars, params[0]);
        }
        async syncCalendarsDetailed(...params) {
          return this.invoke(syncCalendarsDetailed, params[0]);
        }
        async addressBookQuery(...params) {
          return this.invoke(addressBookQuery, params[0]);
        }
        async addressBookMultiGet(...params) {
          return this.invoke(addressBookMultiGet, params[0]);
        }
        async fetchAddressBooks(...params) {
          return this.invoke(fetchAddressBooks, params[0]);
        }
        async fetchVCards(...params) {
          return this.invoke(fetchVCards, params[0]);
        }
        async createVCard(...params) {
          return this.invoke(createVCard, params[0]);
        }
        async updateVCard(...params) {
          return this.invoke(updateVCard, params[0]);
        }
        async deleteVCard(...params) {
          return this.invoke(deleteVCard, params[0]);
        }
      };
      src_default = {
        DAVNamespace,
        DAVNamespaceShort,
        DAVAttributeMap,
        ICALObjects,
        ...client_exports,
        ...request_exports,
        ...collection_exports,
        ...account_exports,
        ...addressBook_exports,
        ...calendar_exports,
        ...authHelpers_exports,
        ...requestHelpers_exports
      };
    }
  });

  // desktop/src/sync.js
  var require_sync = __commonJS({
    "desktop/src/sync.js"(exports, module) {
      init_globals();
      var IcalExpander = require_ical_expander();
      var crypto = (init_crypto(), __toCommonJS(crypto_exports));
      var TZ = require_tz();
      var Lunar = require_lunar();
      var DAYS_BACK = 40;
      var DAYS_FWD = 400;
      var pad = (n) => String(n).padStart(2, "0");
      var ymdLocal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      function range() {
        const now = /* @__PURE__ */ new Date();
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - DAYS_BACK);
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + DAYS_FWD);
        return { start, end };
      }
      var REPEAT_TO = { daily: "DAILY", weekly: "WEEKLY", monthly: "MONTHLY", yearly: "YEARLY" };
      var REPEAT_FROM = { DAILY: "daily", WEEKLY: "weekly", MONTHLY: "monthly", YEARLY: "yearly" };
      function expandLocal(e, start, end) {
        const allDay = !!e.allDay;
        const at = (v) => allDay ? /* @__PURE__ */ new Date(v + "T00:00:00") : new Date(v);
        const s0 = at(e.start), dur = Math.max(0, at(e.end) - s0);
        if (!REPEAT_TO[e.repeat]) return s0 < end && new Date(s0.getTime() + dur) > start ? [e] : [];
        if (e.repeat === "yearly" && e.lunar && e.lunar.m) {
          const out2 = [], until2 = e.repeatUntil ? /* @__PURE__ */ new Date(e.repeatUntil + "T23:59:59") : null;
          for (let y = Math.max(s0.getFullYear(), start.getFullYear() - 1); y <= end.getFullYear() + 1; y++) {
            let v = Lunar.toSolar(y, e.lunar.m, e.lunar.d, e.lunar.leap) || (e.lunar.leap ? Lunar.toSolar(y, e.lunar.m, e.lunar.d, false) : "");
            if (!v) continue;
            const d = /* @__PURE__ */ new Date(v + "T00:00:00");
            if (!allDay) d.setHours(s0.getHours(), s0.getMinutes(), 0, 0);
            if (d < new Date(s0.getFullYear(), s0.getMonth(), s0.getDate())) continue;
            if (until2 && d > until2) break;
            if (d >= end) break;
            const de = allDay ? (() => {
              const x = new Date(d);
              x.setDate(x.getDate() + Math.max(1, Math.round(dur / 864e5)));
              return x;
            })() : new Date(d.getTime() + dur);
            if (de <= start) continue;
            out2.push({ ...e, start: allDay ? ymdLocal(d) : d.toISOString(), end: allDay ? ymdLocal(de) : de.toISOString() });
          }
          return out2;
        }
        const until = e.repeatUntil ? /* @__PURE__ */ new Date(e.repeatUntil + "T23:59:59") : null;
        const fmt2 = (d) => allDay ? ymdLocal(d) : d.toISOString();
        const step = e.repeat === "daily" ? 1 : e.repeat === "weekly" ? 7 : 0;
        let i = 0;
        if (step) i = Math.max(0, Math.floor((start - s0 - dur) / (step * 864e5)) - 1);
        const out = [];
        for (let n = 0; n < 1500; n++, i++) {
          const d = new Date(s0);
          if (step) d.setDate(s0.getDate() + i * step);
          else if (e.repeat === "monthly") {
            d.setDate(1);
            d.setMonth(s0.getMonth() + i);
            d.setDate(s0.getDate());
            if (d.getDate() !== s0.getDate()) continue;
          } else {
            d.setFullYear(s0.getFullYear() + i);
            if (d.getMonth() !== s0.getMonth()) continue;
          }
          if (until && d > until) break;
          if (d >= end) break;
          const de = allDay ? (() => {
            const x = new Date(d);
            x.setDate(x.getDate() + Math.round(dur / 864e5));
            return x;
          })() : new Date(d.getTime() + dur);
          if (de <= start) continue;
          out.push({ ...e, start: fmt2(d), end: fmt2(de) });
        }
        return out;
      }
      function timeToOut(t) {
        if (t.isDate) return { value: `${t.year}-${pad(t.month)}-${pad(t.day)}`, allDay: true };
        return { value: t.toJSDate().toISOString(), allDay: false };
      }
      function expandIcs(text, src, start, end, extra = {}) {
        const out = [];
        const exp = new IcalExpander({ ics: text, maxIterations: 2e3 });
        const { events, occurrences } = exp.between(start, end);
        const push = (item, s, e, recurring) => {
          const S = timeToOut(s);
          let repeat = "", repeatUntil = "", seriesStart = "", seriesEnd = "";
          if (recurring) {
            try {
              const rr = item.component.getFirstPropertyValue("rrule");
              const parts = rr ? Object.keys(rr.parts || {}).filter((k) => (rr.parts[k] || []).length) : [];
              const simple = rr && (!rr.interval || rr.interval === 1) && !rr.count && parts.every((k) => k === "BYDAY" || k === "BYMONTHDAY" || k === "BYMONTH");
              const f2 = rr && REPEAT_FROM[String(rr.freq || "").toUpperCase()];
              if (simple && f2) {
                repeat = f2;
                if (rr.until) repeatUntil = `${rr.until.year}-${pad(rr.until.month)}-${pad(rr.until.day)}`;
                seriesStart = timeToOut(item.startDate).value;
                seriesEnd = timeToOut(item.endDate || item.startDate).value;
              }
            } catch {
            }
          }
          let E = e ? timeToOut(e) : S;
          const status2 = (item.component.getFirstPropertyValue("status") || "").toUpperCase();
          if (status2 === "CANCELLED") return;
          let tz = String(item.component.getFirstPropertyValue("x-deskcal-tz") || "");
          if (!tz && !s.isDate) {
            const z = s.timezone || s.zone && s.zone.tzid || "";
            tz = z === "Z" ? "UTC" : z;
          }
          if (!TZ.valid(tz) || tz === "floating") tz = "";
          let lunar = null;
          const lv = String(item.component.getFirstPropertyValue("x-deskcal-lunar") || "");
          if (/^\d{1,2}-\d{1,2}-[01]$/.test(lv)) {
            const [m2, d, l] = lv.split("-").map(Number);
            lunar = { m: m2, d, leap: !!l };
          }
          out.push({
            id: `${src.id}|${item.uid}|${S.value}`,
            uid: item.uid,
            sourceId: src.id,
            source: src.name,
            color: src.color,
            title: item.summary || "(\uC81C\uBAA9 \uC5C6\uC74C)",
            start: S.value,
            end: E.value,
            allDay: S.allDay,
            location: item.location || "",
            notes: item.description || "",
            categoryName: String(item.component.getFirstPropertyValue("categories") || ""),
            tz,
            recurring,
            repeat,
            repeatUntil,
            seriesStart,
            seriesEnd,
            lunar,
            writable: !!extra.writable && (!recurring || !!repeat),
            href: extra.href,
            etag: extra.etag
          });
        };
        events.forEach((ev) => push(ev, ev.startDate, ev.endDate, false));
        occurrences.forEach((o) => push(o.item, o.startDate, o.endDate, true));
        return out;
      }
      var esc = (s) => String(s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
      var utcStamp = (d) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
      function buildIcs(ev) {
        const lines = [
          "BEGIN:VCALENDAR",
          "VERSION:2.0",
          "PRODID:-//DeskCal//KO",
          "CALSCALE:GREGORIAN",
          "BEGIN:VEVENT",
          `UID:${ev.uid}`,
          `DTSTAMP:${utcStamp(/* @__PURE__ */ new Date())}`
        ];
        if (ev.allDay) {
          lines.push(`DTSTART;VALUE=DATE:${ev.start.replace(/-/g, "")}`);
          lines.push(`DTEND;VALUE=DATE:${ev.end.replace(/-/g, "")}`);
        } else {
          lines.push(`DTSTART:${utcStamp(new Date(ev.start))}`);
          lines.push(`DTEND:${utcStamp(new Date(ev.end))}`);
        }
        if (ev.repeat && REPEAT_TO[ev.repeat]) {
          let rule = `RRULE:FREQ=${REPEAT_TO[ev.repeat]}`;
          if (ev.repeatUntil) rule += ev.allDay ? `;UNTIL=${ev.repeatUntil.replace(/-/g, "")}` : `;UNTIL=${utcStamp(/* @__PURE__ */ new Date(ev.repeatUntil + "T23:59:59"))}`;
          lines.push(rule);
        }
        lines.push(`SUMMARY:${esc(ev.title)}`);
        if (ev.location) lines.push(`LOCATION:${esc(ev.location)}`);
        if (ev.notes) lines.push(`DESCRIPTION:${esc(ev.notes)}`);
        if (ev.categoryName) lines.push(`CATEGORIES:${esc(ev.categoryName)}`);
        if (ev.tz && !ev.allDay) lines.push(`X-DESKCAL-TZ:${ev.tz}`);
        if (ev.lunar && ev.lunar.m) lines.push(`X-DESKCAL-LUNAR:${ev.lunar.m}-${ev.lunar.d}-${ev.lunar.leap ? 1 : 0}`);
        lines.push("END:VEVENT", "END:VCALENDAR");
        return lines.join("\r\n") + "\r\n";
      }
      function normalizeInput(input) {
        const title = (input.title || "").trim() || "(\uC81C\uBAA9 \uC5C6\uC74C)";
        const rep = REPEAT_TO[input.repeat] ? { repeat: input.repeat, repeatUntil: /^\d{4}-\d{2}-\d{2}$/.test(input.repeatUntil || "") ? input.repeatUntil : "" } : {};
        const lu = input.lunar && Number(input.lunar.m) >= 1 && Number(input.lunar.m) <= 12 && Number(input.lunar.d) >= 1 && Number(input.lunar.d) <= 30 ? { m: Number(input.lunar.m), d: Number(input.lunar.d), leap: !!input.lunar.leap } : null;
        if (lu) rep.lunar = lu;
        if (input.allDay) {
          const s2 = input.date;
          const lastDay = input.endDate && input.endDate >= s2 ? input.endDate : s2;
          const d = /* @__PURE__ */ new Date(lastDay + "T00:00:00");
          d.setDate(d.getDate() + 1);
          return { title, allDay: true, start: s2, end: ymdLocal(d), location: input.location || "", notes: input.notes || "", categoryName: input.categoryName || "", ...rep };
        }
        const zone = TZ.valid(input.tz) ? input.tz : null;
        const at = (d, t) => zone ? TZ.toInstant(d, t, zone) : /* @__PURE__ */ new Date(`${d}T${t}:00`);
        const s = at(input.date, input.startTime || "09:00");
        let e = at(input.endDate || input.date, input.endTime || input.startTime || "10:00");
        if (!(e > s)) e = new Date(s.getTime() + 60 * 60 * 1e3);
        return { title, allDay: false, start: s.toISOString(), end: e.toISOString(), location: input.location || "", notes: input.notes || "", categoryName: input.categoryName || "", tz: zone || "", ...rep };
      }
      async function fetchIcs(src, start, end) {
        let url = (src.url || "").trim();
        if (!url) throw new Error("iCal \uC8FC\uC18C\uAC00 \uBE44\uC5B4 \uC788\uC2B5\uB2C8\uB2E4");
        if (url.startsWith("webcal://")) url = "https://" + url.slice(9);
        const res = await fetch(url, { headers: { "User-Agent": "DeskCal/0.2" } });
        if (!res.ok) throw new Error(`\uC8FC\uC18C \uC751\uB2F5 \uC624\uB958 (${res.status})`);
        return expandIcs(await res.text(), src, start, end);
      }
      var davClients = /* @__PURE__ */ new Map();
      function netFetch(u, init3) {
        let f2 = fetch;
        try {
          const { net: net2 } = (init_electron(), __toCommonJS(electron_exports));
          if (net2 && net2.fetch) f2 = net2.fetch.bind(net2);
        } catch {
        }
        return f2(u, init3).catch((e) => {
          const c = e && e.cause;
          const why = c ? c.code || c.message || String(c) : e && e.message;
          const err2 = new Error(`fetch failed: ${why}`);
          err2.cause = c;
          throw err2;
        });
      }
      async function davDiag(base, username, password) {
        const root = base.replace(/\/+$/, "") + "/";
        const auth = "Basic " + import_buffer.Buffer.from(`${username}:${password}`).toString("base64");
        const body = '<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:current-user-principal/><c:calendar-home-set/><d:resourcetype/></d:prop></d:propfind>';
        const paths = ["", ".well-known/caldav", `principals/users/${username}/`, `principals/${username}/`, `calendars/${username}/`];
        const out = [];
        for (const p of paths) {
          try {
            const r = await netFetch(root + p, { method: "PROPFIND", headers: { Authorization: auth, Depth: "0" }, body: import_buffer.Buffer.from(body, "utf8"), redirect: "manual" });
            const t = r.status < 400 ? (await r.text()).replace(/\s+/g, " ") : "";
            const href = (t.match(/current-user-principal>\s*<[^>]*href>([^<]+)/i) || [])[1] || (t.match(/calendar-home-set>\s*<[^>]*href>([^<]+)/i) || [])[1] || "";
            out.push(`/${p || ""} \u2192 ${r.status}${r.headers.get("location") ? " \u279C " + r.headers.get("location") : ""}${href ? " (" + href + ")" : ""}`);
          } catch (e) {
            out.push(`/${p} \u2192 \uC624\uB958 ${e.message}`);
          }
        }
        return out.join(" | ");
      }
      async function naverDiscover(base, username, password) {
        const host2 = new URL(base).origin;
        const auth = "Basic " + import_buffer.Buffer.from(`${username}:${password}`).toString("base64");
        const log = [];
        const pf = async (url, depth, body) => {
          const r = await netFetch(url, { method: "PROPFIND", headers: { Authorization: auth, Depth: String(depth) }, body: import_buffer.Buffer.from(body, "utf8") });
          const text = r.status < 400 ? await r.text() : "";
          log.push(`${url.replace(host2, "")} \u2192 ${r.status}`);
          return { status: r.status, text };
        };
        const tag = (n) => `<(?:[\\w-]+:)?${n}[^>]*>`;
        const hrefAfter = (t, n) => {
          const m2 = t.match(new RegExp(tag(n) + "\\s*" + tag("href") + "\\s*([^<\\s]+)", "i"));
          return m2 ? m2[1] : "";
        };
        let principal = "", home = "";
        const P = "<D:propfind xmlns:D='DAV:'><D:prop><D:current-user-principal/></D:prop></D:propfind>";
        const H = `<?xml version='1.0' encoding='utf-8'?><ns0:propfind xmlns:C="urn:ietf:params:xml:ns:caldav" xmlns:ns0="DAV:"><ns0:prop><C:calendar-home-set/></ns0:prop></ns0:propfind>`;
        const I = `<?xml version='1.0' encoding='utf-8'?><ns0:propfind xmlns:C="urn:ietf:params:xml:ns:caldav" xmlns:ns0="DAV:" xmlns:cs="http://calendarserver.org/ns/"><ns0:prop><ns0:resourcetype/><ns0:displayname/><cs:getctag/></ns0:prop></ns0:propfind>`;
        try {
          const r = await pf(host2 + "/principals/", 0, P);
          if (r.status < 300) principal = hrefAfter(r.text, "current-user-principal");
        } catch (e) {
          log.push("/principals/ \u2192 " + e.message);
        }
        if (principal) {
          try {
            const r = await pf(new URL(principal, host2).href, 0, H);
            if (r.status < 300) home = hrefAfter(r.text, "calendar-home-set");
          } catch (e) {
            log.push("principal \u2192 " + e.message);
          }
        }
        const cands = [...new Set([home, `/caldav/${username}/calendar/`, `/caldav/${username}/`].filter(Boolean))];
        for (const c of cands) {
          let r;
          try {
            r = await pf(new URL(c, host2).href, 1, I);
          } catch (e) {
            log.push(c + " \u2192 " + e.message);
            continue;
          }
          if (r.status >= 300) continue;
          const parts = r.text.split(new RegExp("<(?:[\\w-]+:)?response[\\s>]", "i")).slice(1);
          const cals = [];
          for (const part of parts) {
            const href = (part.match(new RegExp(tag("href") + "\\s*([^<\\s]+)", "i")) || [])[1];
            const isCal = new RegExp("<(?:[\\w-]+:)?calendar\\s*/>", "i").test(part);
            if (!href || !isCal) continue;
            const name = (part.match(new RegExp(tag("displayname") + "([^<]*)", "i")) || [])[1] || "\uCE98\uB9B0\uB354";
            const ctag = (part.match(new RegExp(tag("getctag") + "([^<]*)", "i")) || [])[1] || "";
            cals.push({ url: new URL(href, host2).href, displayName: name.trim(), ctag, components: ["VEVENT"], resourcetype: ["calendar"] });
          }
          if (cals.length) return { calendars: cals, home: new URL(c, host2).href, principal: principal ? new URL(principal, host2).href : "", log };
        }
        const err2 = new Error("naver-discover-failed");
        err2.log = log.join(" | ");
        throw err2;
      }
      async function davFor(src, password) {
        const key = `${src.id}|${src.url}|${src.username}|${password}`;
        if (davClients.has(key)) return davClients.get(key);
        const { DAVClient: DAVClient2 } = await Promise.resolve().then(() => (init_tsdav(), tsdav_exports));
        const url = src.url || "https://caldav.calendar.naver.com", naver = /naver/i.test(url);
        const username = String(src.username || "").trim().replace(naver ? /@naver\.com$/i : /^$/, "");
        const pw = String(password || "").replace(/\s+/g, naver ? "" : " ").trim();
        const naverFetch = (u, init3 = {}) => {
          if (!/^(PROPFIND|REPORT)$/i.test(init3.method || "")) return netFetch(u, init3);
          const h = new Headers(init3.headers || {});
          h.delete("content-type");
          const body = typeof init3.body === "string" ? import_buffer.Buffer.from(init3.body, "utf8") : init3.body;
          return netFetch(u, { ...init3, headers: h, body });
        };
        const client = new DAVClient2({ serverUrl: url, credentials: { username, password: pw }, authMethod: "Basic", defaultAccountType: "caldav", ...naver ? { fetch: naverFetch } : {} });
        let calendars = null, naverLog = "";
        if (naver) {
          try {
            const d = await naverDiscover(url, username, pw);
            await client.authenticate(true);
            client.account = { serverUrl: url, rootUrl: new URL(url).origin + "/", principalUrl: d.principal || d.home, homeUrl: d.home, accountType: "caldav", credentials: client.credentials };
            const entry2 = { client, calendars: d.calendars };
            davClients.set(key, entry2);
            return entry2;
          } catch (e) {
            naverLog = e.log || e.message;
            if (/→ 401/.test(naverLog)) throw new Error('\uB124\uC774\uBC84 \uB85C\uADF8\uC778 \uC2E4\uD328 (401): \uC544\uC774\uB514\uB098 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694. \uD3C9\uC18C \uBE44\uBC00\uBC88\uD638\uAC00 \uC544\uB2C8\uB77C "\uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uBE44\uBC00\uBC88\uD638"\uB97C \uB123\uC5B4 \uC8FC\uC138\uC694 (\uB124\uC774\uBC84 > \uB0B4\uC815\uBCF4 > \uBCF4\uC548\uC124\uC815 > 2\uB2E8\uACC4 \uC778\uC99D \uAD00\uB9AC > \uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uBE44\uBC00\uBC88\uD638)');
          }
        }
        try {
          await client.login();
        } catch (e) {
          const msg = String(e && e.message);
          if (/401|Unauthorized|Invalid credentials/i.test(msg)) {
            throw new Error(naver ? '\uB124\uC774\uBC84 \uB85C\uADF8\uC778 \uC2E4\uD328 (401): \uC544\uC774\uB514\uB098 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694. \uB124\uC774\uBC84 \uCE98\uB9B0\uB354 \uC5F0\uACB0\uC5D0\uB294 \uD3C9\uC18C \uBE44\uBC00\uBC88\uD638\uAC00 \uC544\uB2C8\uB77C "\uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uBE44\uBC00\uBC88\uD638"\uB97C \uB123\uC5B4\uC57C \uD574\uC694 (\uB124\uC774\uBC84 > \uB0B4\uC815\uBCF4 > \uBCF4\uC548\uC124\uC815 > 2\uB2E8\uACC4 \uC778\uC99D \uAD00\uB9AC > \uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uBE44\uBC00\uBC88\uD638)' : "\uB85C\uADF8\uC778 \uC2E4\uD328 (401): \uC544\uC774\uB514\uB098 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694");
          }
          if (!/principalUrl|homeUrl/i.test(msg)) throw e;
          if (naver) {
            try {
              const d = await naverDiscover(url, username, pw);
              await client.authenticate(true);
              client.account = { serverUrl: url, rootUrl: new URL(url).origin + "/", principalUrl: d.principal || d.home, homeUrl: d.home, accountType: "caldav", credentials: client.credentials };
              calendars = d.calendars;
            } catch (e2) {
              throw new Error(`\uB124\uC774\uBC84 \uCE98\uB9B0\uB354 \uC704\uCE58\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC5B4\uC694 (${msg}). \uC544\uB798 \uC9C4\uB2E8 \uB0B4\uC6A9\uC744 \uAC1C\uBC1C\uC790\uC5D0\uAC8C \uBCF4\uB0B4 \uC8FC\uC138\uC694 \u2192 ${naverLog || e2.log || e2.message}`);
            }
          }
          const root = url.replace(/\/+$/, "") + "/";
          const tries = [`calendars/${username}/`, `calendars/${username}@naver.com/`, `${username}/`, ""];
          for (const h of calendars ? [] : tries) {
            client.account = { serverUrl: url, rootUrl: root, principalUrl: root + `principals/users/${username}/`, homeUrl: root + h, accountType: "caldav", credentials: client.credentials };
            try {
              const got = await client.fetchCalendars();
              if (got && got.length) {
                calendars = got;
                break;
              }
            } catch {
            }
          }
          if (!calendars) {
            const d = await davDiag(url, username, pw).catch(() => "");
            throw new Error(`\uCE98\uB9B0\uB354 \uC8FC\uC18C\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC5B4\uC694 (${msg}). \uC544\uB798 \uC9C4\uB2E8 \uB0B4\uC6A9\uC744 \uAC1C\uBC1C\uC790\uC5D0\uAC8C \uBCF4\uB0B4 \uC8FC\uC138\uC694 \u2192 ${d}`);
          }
        }
        const all = calendars || await client.fetchCalendars();
        calendars = all.filter((c) => !c.components || c.components.includes("VEVENT"));
        const entry = { client, calendars };
        davClients.set(key, entry);
        return entry;
      }
      function pickCalendars(src, calendars) {
        const wanted = (src.calendars || "").split(",").map((s) => s.trim()).filter(Boolean);
        if (!wanted.length) return calendars;
        return calendars.filter((c) => wanted.includes(String(c.displayName)));
      }
      async function fetchCaldav(src, password, start, end) {
        const { client, calendars } = await davFor(src, password);
        const out = [];
        for (const cal of pickCalendars(src, calendars)) {
          const objs = await client.fetchCalendarObjects({
            calendar: cal,
            timeRange: { start: start.toISOString(), end: end.toISOString() }
          });
          for (const o of objs) {
            if (!o.data) continue;
            try {
              out.push(...expandIcs(o.data, src, start, end, { writable: true, href: o.url, etag: o.etag }));
            } catch {
            }
          }
        }
        return out;
      }
      function fetchLocal(src, list, start, end) {
        const out = [];
        for (const base of list) {
          for (const e of expandLocal(base, start, end)) {
            const rec = !!REPEAT_TO[base.repeat];
            out.push({
              ...e,
              id: `${src.id}|${e.uid}|${e.start}`,
              sourceId: src.id,
              source: src.name,
              color: src.color,
              recurring: rec,
              repeat: rec ? base.repeat : "",
              repeatUntil: base.repeatUntil || "",
              lunar: base.lunar || null,
              seriesStart: rec ? base.start : "",
              seriesEnd: rec ? base.end : "",
              writable: true
            });
          }
        }
        return out;
      }
      async function fetchAll(settings, ctx) {
        const { start, end } = range();
        const events = [];
        const errors = [];
        await Promise.all(settings.sources.filter((s) => s.enabled !== false).map(async (src) => {
          try {
            let got = [];
            if (src.type === "ics") got = await fetchIcs(src, start, end);
            else if (src.type === "caldav") got = await fetchCaldav(src, ctx.decrypt(src.password), start, end);
            else if (src.type === "local") got = fetchLocal(src, ctx.getLocal(), start, end);
            if (src.holiday) got = got.map((e) => ({ ...e, holiday: true, writable: false }));
            events.push(...got);
          } catch (e) {
            errors.push(`${src.name}: ${e.message || e}`);
          }
        }));
        events.sort((a, b) => a.start < b.start ? -1 : a.start > b.start ? 1 : 0);
        return { events, errors };
      }
      async function createEvent(src, input, ctx) {
        const data = { ...normalizeInput(input), uid: `${crypto.randomUUID()}@deskcal` };
        if (src.type === "local") {
          const list = ctx.getLocal();
          list.push(data);
          ctx.saveLocal(list);
          return data.uid;
        }
        if (src.type === "caldav") {
          const { client, calendars } = await davFor(src, ctx.decrypt(src.password));
          const targets = pickCalendars(src, calendars);
          const cal = targets.find((c) => String(c.displayName) === src.writeCalendar) || targets[0];
          if (!cal) throw new Error("\uC4F8 \uC218 \uC788\uB294 \uCE98\uB9B0\uB354\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4");
          const r = await client.createCalendarObject({ calendar: cal, filename: `${data.uid.replace(/@.*/, "")}.ics`, iCalString: buildIcs(data) });
          if (r && r.ok === false) throw new Error(`\uC800\uC7A5 \uC2E4\uD328 (${r.status})`);
          return data.uid;
        }
        throw new Error("\uC774 \uCE98\uB9B0\uB354\uB294 \uC77D\uAE30 \uC804\uC6A9\uC785\uB2C8\uB2E4");
      }
      async function updateEvent(src, ev, input, ctx) {
        if (ev.recurring && !ev.repeat) throw new Error("\uC774 \uBC18\uBCF5 \uC77C\uC815\uC740 \uC6D0\uB798 \uCE98\uB9B0\uB354\uC5D0\uC11C \uC218\uC815\uD574 \uC8FC\uC138\uC694");
        const data = { ...normalizeInput(input), uid: ev.uid };
        if (src.type === "local") {
          const list = ctx.getLocal().map((e) => e.uid === ev.uid ? data : e);
          ctx.saveLocal(list);
          return;
        }
        if (src.type === "caldav") {
          const { client } = await davFor(src, ctx.decrypt(src.password));
          const r = await client.updateCalendarObject({ calendarObject: { url: ev.href, etag: ev.etag, data: buildIcs(data) } });
          if (r && r.ok === false) throw new Error(`\uC218\uC815 \uC2E4\uD328 (${r.status}) \u2014 \uB2E4\uB978 \uACF3\uC5D0\uC11C \uBA3C\uC800 \uBC14\uB00C\uC5C8\uC744 \uC218 \uC788\uC5B4\uC694`);
          return;
        }
        throw new Error("\uC774 \uCE98\uB9B0\uB354\uB294 \uC77D\uAE30 \uC804\uC6A9\uC785\uB2C8\uB2E4");
      }
      async function deleteEvent(src, ev, ctx) {
        if (ev.recurring && !ev.repeat) throw new Error("\uC774 \uBC18\uBCF5 \uC77C\uC815\uC740 \uC6D0\uB798 \uCE98\uB9B0\uB354\uC5D0\uC11C \uC0AD\uC81C\uD574 \uC8FC\uC138\uC694");
        if (src.type === "local") {
          ctx.saveLocal(ctx.getLocal().filter((e) => e.uid !== ev.uid));
          return;
        }
        if (src.type === "caldav") {
          const { client } = await davFor(src, ctx.decrypt(src.password));
          const r = await client.deleteCalendarObject({ calendarObject: { url: ev.href, etag: ev.etag } });
          if (r && r.ok === false) throw new Error(`\uC0AD\uC81C \uC2E4\uD328 (${r.status})`);
          return;
        }
        throw new Error("\uC774 \uCE98\uB9B0\uB354\uB294 \uC77D\uAE30 \uC804\uC6A9\uC785\uB2C8\uB2E4");
      }
      function forgetClients() {
        davClients.clear();
      }
      async function testSource(src, password) {
        davClients.forEach((_v, k) => {
          if (k.startsWith(src.id + "|")) davClients.delete(k);
        });
        const { calendars } = await davFor(src, password);
        return calendars.map((c) => String(c.displayName || "\uC774\uB984 \uC5C6\uC74C"));
      }
      module.exports = { testSource, fetchAll, createEvent, updateEvent, deleteEvent, buildIcs, normalizeInput, expandIcs, forgetClients };
    }
  });

  // desktop/renderer/datesense.js
  var require_datesense = __commonJS({
    "desktop/renderer/datesense.js"(exports, module) {
      init_globals();
      (function(root) {
        const WDK = "\uC77C\uC6D4\uD654\uC218\uBAA9\uAE08\uD1A0";
        const pad = (n) => String(n).padStart(2, "0");
        const ymd2 = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        function parse(text, now = /* @__PURE__ */ new Date()) {
          const t = String(text || "").replace(/\s+/g, " ");
          const base = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          const add = (n) => new Date(base.getFullYear(), base.getMonth(), base.getDate() + n);
          const valid = (mo, d) => mo >= 1 && mo <= 12 && d >= 1 && d <= 31;
          const nextMD = (mo, d) => {
            let x2 = new Date(base.getFullYear(), mo - 1, d);
            if (x2 < base) x2 = new Date(base.getFullYear() + 1, mo - 1, d);
            return x2;
          };
          let date = null;
          const found = [];
          let m2;
          if ((m2 = t.match(/(\d{4})\s*[-./년]\s*(\d{1,2})\s*[-./월]\s*(\d{1,2})\s*일?/)) && valid(+m2[2], +m2[3])) {
            date = new Date(+m2[1], +m2[2] - 1, +m2[3]);
            found.push(m2[0]);
          } else if ((m2 = t.match(/(\d{1,2})\s*월\s*(\d{1,2})\s*일/)) && valid(+m2[1], +m2[2])) {
            date = nextMD(+m2[1], +m2[2]);
            found.push(m2[0]);
          } else if ((m2 = t.match(/(?:^|[^\d:/.])(\d{1,2})\s*[/.]\s*(\d{1,2})(?![\d:/.]|\s*분기)/)) && valid(+m2[1], +m2[2])) {
            date = nextMD(+m2[1], +m2[2]);
            found.push(m2[0].replace(/^[^\d]/, "").trim());
          } else if (m2 = t.match(/(오늘|내일|낼|모레|글피)/)) {
            date = add({ \uC624\uB298: 0, \uB0B4\uC77C: 1, \uB0BC: 1, \uBAA8\uB808: 2, \uAE00\uD53C: 3 }[m2[1]]);
            found.push(m2[0]);
          } else if (m2 = t.match(/(\d{1,2})\s*일\s*(?:후|뒤)/)) {
            date = add(+m2[1]);
            found.push(m2[0]);
          } else if (m2 = t.match(/(이번\s*주|다음\s*주|담주|차주|다다음\s*주)?\s*([일월화수목금토])요일/)) {
            const wd = WDK.indexOf(m2[2]);
            const which = (m2[1] || "").replace(/\s/g, "");
            if (!which) {
              date = add((wd - base.getDay() + 7) % 7);
            } else {
              const mondayIdx = (d) => (d + 6) % 7;
              const thisMon = add(-mondayIdx(base.getDay()));
              const weeks = which === "\uC774\uBC88\uC8FC" ? 0 : which === "\uB2E4\uB2E4\uC74C\uC8FC" ? 2 : 1;
              date = new Date(thisMon.getFullYear(), thisMon.getMonth(), thisMon.getDate() + weeks * 7 + mondayIdx(wd));
            }
            found.push(m2[0].trim());
          } else if ((m2 = t.match(/(?:^|[^\d])(\d{1,2})\s*일(?!\s*(?:후|뒤|간|동안|째))/)) && +m2[1] >= 1 && +m2[1] <= 31) {
            let x2 = new Date(base.getFullYear(), base.getMonth(), +m2[1]);
            if (x2 < base) x2 = new Date(base.getFullYear(), base.getMonth() + 1, +m2[1]);
            date = x2;
            found.push(m2[0].replace(/^[^\d]/, "").trim());
          }
          let start = null, end = null;
          const toH = (mer, h) => {
            h = +h;
            if (/오후|저녁|밤/.test(mer || "") && h < 12) h += 12;
            else if (/낮/.test(mer || "") && h < 7) h += 12;
            else if (/오전|아침|새벽/.test(mer || "") && h === 12) h = 0;
            else if (!mer && h >= 1 && h <= 6) h += 12;
            return h;
          };
          const tre = /(오전|오후|아침|낮|저녁|밤|새벽)?\s*(?:(\d{1,2})\s*시\s*(?:(\d{1,2})\s*분|(반))?|(\d{1,2}):(\d{2})(?!\d))|(정오)/g;
          const times = [];
          let x;
          while ((x = tre.exec(t)) && times.length < 2) {
            if (x[7]) times.push({ h: 12, m: 0, s: x[0].trim() });
            else if (x[5] !== void 0) {
              if (+x[5] < 24 && +x[6] < 60) times.push({ h: x[1] ? toH(x[1], x[5]) : +x[5], m: +x[6], s: x[0].trim(), mer: x[1] });
            } else if (x[2] !== void 0 && +x[2] <= 24) times.push({ h: toH(x[1], x[2]), m: x[4] ? 30 : +(x[3] || 0), s: x[0].trim(), mer: x[1] });
          }
          if (times.length) {
            const a = times[0];
            start = `${pad(a.h % 24)}:${pad(a.m)}`;
            found.push(a.s);
            if (times[1]) {
              let b = times[1];
              let bh = b.h;
              if (!b.mer && a.h >= 12 && bh < 12) bh += 12;
              if (bh * 60 + b.m > a.h * 60 + a.m) {
                end = `${pad(bh % 24)}:${pad(b.m)}`;
                found.push(b.s);
              }
            }
            if (!date) {
              const today = new Date(base);
              today.setHours(a.h, a.m);
              date = today > now ? base : add(1);
            }
          }
          if (!date) return null;
          return { date: ymd2(date), start, end, found: found.join(" "), parts: found.slice() };
        }
        const api = { parse };
        if (typeof module !== "undefined") module.exports = api;
        else root.DateSense = api;
      })(typeof window !== "undefined" ? window : globalThis);
    }
  });

  // desktop/src/smartparse.js
  var require_smartparse = __commonJS({
    "desktop/src/smartparse.js"(exports, module) {
      init_globals();
      var DateSense = require_datesense();
      var Lunar = null;
      try {
        Lunar = require_lunar();
      } catch {
      }
      var pad = (n) => String(n).padStart(2, "0");
      var ymd2 = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      var addMin = (hm2, min) => {
        const [h, m2] = hm2.split(":").map(Number);
        const t = Math.min(23 * 60 + 59, h * 60 + m2 + min);
        return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`;
      };
      var ASK = /\s*(?:일정\s*(?:으로|을|를)?\s*)?(?:캘린더에\s*|달력에\s*)?(?:등록|추가|저장|입력|기록|예약|메모)\s*(?:좀\s*)?(?:해\s*줘|해\s*주세요|해\s*줄래|해\s*주라|해\s*줘요|하기|해|할래|함|부탁(?:해|드려요|합니다)?)?[.!~ ]*$/;
      var ASK2 = /\s*(?:잡아|넣어|적어|알려|기억해|남겨)\s*(?:줘|주세요|줄래|줘요|주라|둬|두세요)[.!~ ]*$/;
      var TAIL = /\s*(?:있어|있음|있어요|있습니다|예정|예정이야|예정이에요|이야|이에요|입니다|해야\s*함|해야\s*해|가야\s*함|가야\s*해)[.!~ ]*$/;
      var REP = [[/매일|날마다/, "daily"], [/매주|주마다|매\s*주/, "weekly"], [/매달|매월|달마다/, "monthly"], [/매년|해마다|매해/, "yearly"]];
      var LABEL = /^\s*[-•·*▶■□○●◦]?\s*(일시|일자|날짜|시간|예약일|예약\s*일시|수거일|방문일|기간|장소|위치|주소|주제|제목|과정|안건|행사|행사명|내용|대상|인원)\s*[:：]\s*(.+)$/;
      function tidy(s) {
        return String(s || "").replace(/\(\s*\)/g, " ").replace(/\s+/g, " ").replace(/^[\s~\-–·,:：.]+|[\s~\-–·,:：]+$/g, "").replace(/\s*(?:에|에는|은|는|을|를|이|가|도|부터|까지|쯤|경|정도)$/g, "").trim();
      }
      function reminders2(s) {
        const out = [];
        const re = /(?:(\d+|한|두|세)\s*(달|개월|주|주일|일|시간|분)|(하루|이틀))\s*전(?:에)?\s*(?:알림|알람|알려\s*(?:줘|주세요)?|리마인드)/g;
        const num = { \uD558\uB8E8: 1, \uC774\uD2C0: 2, \uD55C: 1, \uB450: 2, \uC138: 3 };
        let m2;
        while (m2 = re.exec(s)) {
          let n, unit;
          if (m2[3]) {
            n = num[m2[3]];
            unit = "day";
          } else {
            n = num[m2[1]] || +m2[1];
            unit = { \uB2EC: "month", \uAC1C\uC6D4: "month", \uC8FC: "week", \uC8FC\uC77C: "week", \uC77C: "day", \uC2DC\uAC04: "hour", \uBD84: "minute" }[m2[2]];
          }
          out.push({ n, unit, s: m2[0] });
        }
        return out;
      }
      function one(seg, now, prev) {
        let s = String(seg || "").trim();
        if (!s) return null;
        const used = [];
        let repeat = "";
        for (const [re, v] of REP) {
          const m2 = s.match(re);
          if (m2) {
            repeat = v;
            used.push(m2[0]);
            break;
          }
        }
        let lunar = null, date = "", start = "", end = "";
        const lm = s.match(/음력\s*(윤)?\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일?/);
        if (lm && Lunar) {
          lunar = { m: +lm[2], d: +lm[3], leap: !!lm[1] };
          const y = now.getFullYear();
          let sol = Lunar.toSolar(y, lunar.m, lunar.d, lunar.leap);
          if (!sol || sol < ymd2(now)) sol = Lunar.toSolar(y + 1, lunar.m, lunar.d, lunar.leap);
          if (sol) date = sol;
          used.push(lm[0]);
          if (!repeat) repeat = "yearly";
        }
        const rem = reminders2(s);
        for (const r2 of rem) used.push(r2.s);
        let sNoRem = s;
        for (const r2 of rem) sNoRem = sNoRem.replace(r2.s, " ");
        const r = DateSense.parse(lunar ? sNoRem.replace(lm[0], " ") : sNoRem, now);
        let when = "";
        if (r) {
          if (!date) date = r.date;
          start = r.start || "";
          end = r.end || "";
          used.push(...r.parts || []);
          when = r.found || "";
          if (prev && prev.date && /[월화수목금토일]요일/.test(r.found || "") && !/이번|다음|담주|차주|다다음/.test(r.found || "") && date < prev.date && prev.nextWk) {
            const d = /* @__PURE__ */ new Date(date + "T00:00:00");
            d.setDate(d.getDate() + 7);
            date = ymd2(d);
          }
        }
        if (lunar) when = lm[0] + (when ? " " + when : "");
        if (!date && !start) return null;
        if (start && !end) {
          const dm = s.match(/(\d+)\s*시간\s*(반)?(?:\s*(\d+)\s*분)?\s*(?:동안|짜리|정도)?(?!\s*(?:전|후|뒤))/) || s.match(/(?:^|\s)(\d+)\s*분\s*(?:동안|간|짜리)/);
          if (dm) {
            const mins = dm[0].includes("\uC2DC\uAC04") ? +dm[1] * 60 + (dm[2] ? 30 : 0) + +(dm[3] || 0) : +dm[1];
            if (mins > 0 && mins <= 12 * 60) {
              end = addMin(start, mins);
              used.push(dm[0].trim());
            }
          }
        }
        if (!start) {
          if (/점심/.test(s)) start = "12:00";
          else if (/저녁\s*(?:약속|식사|모임|회식)|회식/.test(s)) start = "19:00";
          if (start && !end) end = addMin(start, 90);
        }
        let location2 = "";
        let rest = s;
        for (const u of used.sort((a, b) => b.length - a.length)) if (u) rest = rest.replace(u, " ");
        const paren = rest.match(/[(\[]\s*([^()\[\]]{2,30})\s*[)\]]/);
        if (paren && !/^\s*\d{1,2}\s*(?:시|:)|오전|오후/.test(paren[1])) {
          location2 = paren[1].trim().replace(/^(장소|위치)\s*[:：]?\s*/, "");
          rest = rest.replace(paren[0], " ");
        }
        if (!location2) {
          const at = rest.match(/(?:^|\s)((?:[^\s]+\s){0,1}[^\s]+?)에서(?=\s|$)/);
          if (at && !/(?:오전|오후|저녁|아침|점심|시|분)$/.test(at[1])) {
            location2 = at[1].trim();
            rest = rest.replace(at[0], " ");
          }
        }
        let title = rest.replace(ASK, "").replace(ASK2, "").replace(TAIL, "");
        title = title.replace(/\s(?:에|에는|은|는)\s/g, " ");
        title = tidy(title).replace(ASK, "").replace(ASK2, "").replace(TAIL, "");
        title = tidy(title);
        if (!title || /^[\d\s:~\-]+$/.test(title)) title = "(\uC81C\uBAA9 \uC5C6\uC74C)";
        return {
          title,
          when,
          date,
          startTime: start,
          endTime: end,
          allDay: !start,
          location: location2,
          repeat,
          lunar,
          rem: rem.length ? rem.map(({ n, unit }) => ({ n, unit })) : void 0
        };
      }
      function form(text, now) {
        const lines = String(text).split(/\n/);
        const f2 = {};
        let head = "";
        for (const ln of lines) {
          const m2 = ln.match(LABEL);
          if (m2) {
            const k = m2[1].replace(/\s/g, "");
            if (!f2[k]) f2[k] = m2[2].trim();
            continue;
          }
          const h = ln.match(/^\s*[\[【<]\s*([^\]】>]{2,30})\s*[\]】>]/);
          if (h && !head) head = h[1].replace(/\s*(?:안내|공지|알림|확정|변경)\s*$/, "").trim();
        }
        const whenTxt = f2["\uC77C\uC2DC"] || f2["\uC608\uC57D\uC77C\uC2DC"] || f2["\uC77C\uC790"] || f2["\uB0A0\uC9DC"] || f2["\uC608\uC57D\uC77C"] || f2["\uC218\uAC70\uC77C"] || f2["\uBC29\uBB38\uC77C"] || f2["\uAE30\uAC04"] || "";
        if (!whenTxt) return null;
        const e = one(whenTxt + (f2["\uC2DC\uAC04"] ? " " + f2["\uC2DC\uAC04"] : ""), now);
        if (!e) return null;
        e.title = f2["\uC8FC\uC81C"] || f2["\uC81C\uBAA9"] || f2["\uACFC\uC815"] || f2["\uD589\uC0AC\uBA85"] || f2["\uD589\uC0AC"] || f2["\uC548\uAC74"] || head || e.title;
        e.title = tidy(e.title.replace(/^\s*['"“”‘’]|['"“”‘’]\s*$/g, ""));
        e.location = f2["\uC7A5\uC18C"] || f2["\uC704\uCE58"] || f2["\uC8FC\uC18C"] || e.location;
        e.when = whenTxt;
        return [e];
      }
      function parse(text, now = /* @__PURE__ */ new Date()) {
        const src = String(text || "").trim();
        if (!src) return [];
        const asForm = form(src, now);
        if (asForm) return asForm;
        const segs = src.split(/\n+|[;；]|,(?!\s*\d{1,2}\s*(?:시|:))|，|\s그리고\s|\s하고\s(?=.*(?:시|요일|일|내일|모레))/).map((x) => x.trim()).filter(Boolean);
        const out = [];
        let prev = null;
        for (const sgm of segs) {
          const e = one(sgm, now, prev);
          if (e) {
            e.nextWk = /다음|담주|차주|다다음/.test(e.when || "") || !!(prev && prev.nextWk && !/이번/.test(e.when || ""));
            out.push(e);
            prev = e;
            continue;
          }
          if (prev) {
            const t = tidy(sgm.replace(ASK, "").replace(ASK2, ""));
            if (t && !prev.location && /역|층|호|카페|식당|센터|병원|회의실|사무실|빌딩|타워|홀|점|관/.test(t)) prev.location = t;
          }
        }
        return out.slice(0, 20).map((e) => {
          delete e.nextWk;
          return e;
        });
      }
      module.exports = { parse, one };
    }
  });

  // mobile/ai.js
  var require_ai = __commonJS({
    "mobile/ai.js"(exports, module) {
      init_globals();
      var SmartParse = require_smartparse();
      var ST = { models: [], model: "rules", modelPath: "", modelSize: 0, runtime: "rules", mobile: true, phase: "idle", message: "", loaded: false };
      module.exports = {
        init() {
        },
        MODELS: [],
        status: () => ({ ...ST }),
        download: async () => {
        },
        cancelDownload: async () => {
        },
        deleteModels() {
        },
        unload() {
        },
        ensureRuntime: async () => {
        },
        ruleParse: (text, now) => SmartParse.parse(text, now),
        resolveOne: (e) => e,
        analyze: async (text, _s, now = /* @__PURE__ */ new Date()) => {
          const t0 = Date.now();
          return { events: SmartParse.parse(text, now), usedAI: false, ms: Date.now() - t0 };
        }
      };
    }
  });

  // mobile/shim/empty.js
  var empty_exports = {};
  __export(empty_exports, {
    analyze: () => analyze,
    applyAndRestart: () => applyAndRestart2,
    available: () => available,
    cancelDownload: () => cancelDownload,
    check: () => check2,
    default: () => empty_default,
    deleteModels: () => deleteModels,
    download: () => download,
    execFile: () => execFile,
    getState: () => getState2,
    init: () => init2,
    newer: () => newer2,
    pathToFileURL: () => pathToFileURL,
    pinToDesktop: () => pinToDesktop,
    prepare: () => prepare2,
    sendToBottom: () => sendToBottom,
    status: () => status,
    unload: () => unload,
    unpin: () => unpin,
    watchDesktopClicks: () => watchDesktopClicks
  });
  var noop2, off, available, pinToDesktop, unpin, sendToBottom, watchDesktopClicks, init2, check2, prepare2, applyAndRestart2, getState2, newer2, status, unload, download, cancelDownload, deleteModels, analyze, execFile, pathToFileURL, empty_default;
  var init_empty = __esm({
    "mobile/shim/empty.js"() {
      init_globals();
      noop2 = () => {
      };
      off = () => false;
      available = off;
      pinToDesktop = noop2;
      unpin = noop2;
      sendToBottom = noop2;
      watchDesktopClicks = noop2;
      init2 = noop2;
      check2 = async () => ({});
      prepare2 = async () => ({});
      applyAndRestart2 = noop2;
      getState2 = () => ({ phase: "idle", current: window.__APP_VERSION, available: false, message: "\uD734\uB300\uD3F0 \uC571\uC740 \uC2A4\uD1A0\uC5B4\xB7APK\uB85C \uC5C5\uB370\uC774\uD2B8\uD574\uC694" });
      newer2 = (a, b) => {
        const p = (v) => String(v || "").split(".").map((x2) => parseInt(x2, 10) || 0);
        const x = p(a), y = p(b);
        for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
        return false;
      };
      status = () => ({ available: false, mobile: true });
      unload = noop2;
      download = async () => {
      };
      cancelDownload = noop2;
      deleteModels = noop2;
      analyze = async () => ({ items: [] });
      execFile = (_c, _a, _o, cb) => (cb || _o)(new Error("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC74C"));
      pathToFileURL = (p) => ({ href: "file://" + p });
      empty_default = { available, pinToDesktop, unpin, sendToBottom, watchDesktopClicks, init: init2, check: check2, prepare: prepare2, applyAndRestart: applyAndRestart2, getState: getState2, newer: newer2, status, unload, download, cancelDownload, deleteModels, analyze, execFile, pathToFileURL };
    }
  });

  // desktop/src/cloud-config.js
  var require_cloud_config = __commonJS({
    "desktop/src/cloud-config.js"(exports, module) {
      init_globals();
      module.exports = {
        apiKey: "AIzaSyCBJZJrVKkxOnJHdizuZ81JpMn8Fv8jEls",
        projectId: "total-calendar-8d0f2"
      };
      if (typeof process !== "undefined" && process.env && process.env.TC_CLOUD_MOCK) {
        const b = process.env.TC_CLOUD_MOCK;
        Object.assign(module.exports, { apiKey: "mock", projectId: "mock", authBase: b + "/v1", tokenBase: b + "/v1", fsBase: b + "/v1" });
      }
    }
  });

  // desktop/src/cloud.js
  var require_cloud = __commonJS({
    "desktop/src/cloud.js"(exports, module) {
      init_globals();
      var CFG = require_cloud_config();
      var AUTH = (CFG.authBase || "https://identitytoolkit.googleapis.com/v1") + "/accounts:";
      var TOKEN2 = (CFG.tokenBase || "https://securetoken.googleapis.com/v1") + "/token";
      var FS = () => `${CFG.fsBase || "https://firestore.googleapis.com/v1"}/projects/${CFG.projectId}/databases/(default)/documents`;
      var COLLS = {
        events: { file: "local-events.json", key: "uid" },
        notes: { file: "notes.json", key: "id" },
        stickies: { file: "stickies.json", key: "id" },
        // 캘린더 연결 목록 (설정 안에 있음) — 주소·이름·색은 맞추고, 비밀번호는 올리지 않음 / '내 기기' 캘린더는 기기마다
        sources: { file: "settings.json", key: "id", fromSettings: true }
      };
      function cleanSources(st) {
        return (st && st.sources || []).filter((x) => x && x.type !== "local").map((x) => {
          const o = { ...x };
          delete o.password;
          delete o.hasPassword;
          return o;
        });
      }
      var listOf = (c, data) => COLLS[c].fromSettings ? cleanSources(data) : data || [];
      var MAPS = {
        remind: { file: "event-reminders.json" },
        cats: { file: "categories.json" },
        birth: { file: "birthyears.json" }
      };
      var WHOLE = { stickers: { file: "stickers.json" } };
      var SETTING_KEYS = ["appearance", "categories", "characters", "reminders", "colorBy", "view", "exportTargets"];
      var APPEAR_LOCAL = ["wallpaperAlign", "wallpaperWidth"];
      var store4 = null;
      var fetchFn = null;
      var hooks = {};
      var device = "pc";
      var tok = { id: "", exp: 0 };
      var state2 = { signedIn: false, email: "", uid: "", syncing: false, lastSync: 0, message: "", error: "" };
      var pushTimer = null;
      var running = null;
      var now = () => Date.now();
      var META = "sync-meta.json";
      var getMeta = () => ({ t: {}, tomb: {}, seen: {}, dirty: {}, base: 0, ...store4.readJSON(META, {}) });
      var saveMeta = (m2) => store4.quiet(() => store4.writeJSON(META, m2));
      var getAcc = () => store4.readJSON("account.json", null);
      var setState = (s) => {
        state2 = { ...state2, ...s };
        hooks.onState && hooks.onState(getState3());
      };
      var getState3 = () => ({ ...state2, configured: !!(CFG.apiKey && CFG.projectId) });
      function init3(o) {
        store4 = o.store;
        fetchFn = o.fetch || fetch;
        hooks = o.hooks || {};
        device = o.device || "pc";
        const acc = getAcc();
        if (acc && acc.uid) state2 = { ...state2, signedIn: true, email: acc.email, uid: acc.uid, lastSync: acc.lastSync || 0 };
        store4.onSave((name, data, old) => {
          if (name === META || name === "account.json") return;
          if (!state2.signedIn) return;
          const m2 = getMeta();
          let changed = false, any = false;
          for (const [c, d] of Object.entries(COLLS)) {
            if (d.file !== name) continue;
            const k = d.key, before = new Map(listOf(c, old).map((x) => [String(x[k]), JSON.stringify(x)]));
            const after = new Map(listOf(c, data).map((x) => [String(x[k]), JSON.stringify(x)]));
            changed = false;
            m2.t[c] = m2.t[c] || {};
            m2.tomb[c] = m2.tomb[c] || {};
            for (const [id, js] of after) if (before.get(id) !== js) {
              m2.t[c][id] = now();
              delete m2.tomb[c][id];
              changed = true;
            }
            if (!d.fromSettings) {
              for (const id of before.keys()) if (!after.has(id)) {
                m2.tomb[c][id] = now();
                delete m2.t[c][id];
                changed = true;
              }
            }
            if (changed) {
              m2.dirty[c] = true;
              any = true;
            }
          }
          changed = any;
          for (const [c, d] of Object.entries(MAPS)) {
            if (d.file !== name) continue;
            m2.t[c] = m2.t[c] || {};
            m2.tomb[c] = m2.tomb[c] || {};
            const o2 = old || {}, n2 = data || {};
            for (const k of Object.keys(n2)) if (JSON.stringify(o2[k]) !== JSON.stringify(n2[k])) {
              m2.t[c][k] = now();
              delete m2.tomb[c][k];
              changed = true;
            }
            for (const k of Object.keys(o2)) if (!(k in n2)) {
              m2.tomb[c][k] = now();
              delete m2.t[c][k];
              changed = true;
            }
            if (changed) m2.dirty[c] = true;
          }
          for (const [c, d] of Object.entries(WHOLE)) {
            if (d.file !== name || JSON.stringify(old) === JSON.stringify(data)) continue;
            m2.t[c] = now();
            m2.dirty[c] = true;
            changed = true;
          }
          if (name === "settings.json" && JSON.stringify(pickSettings(old)) !== JSON.stringify(pickSettings(data))) {
            m2.t.settings = now();
            m2.dirty.settings = true;
            changed = true;
          }
          if (changed) {
            saveMeta(m2);
            schedulePush();
          }
        });
      }
      function markRemoved(c, ids) {
        if (!state2.signedIn || !ids || !ids.length) return;
        const m2 = getMeta();
        m2.tomb[c] = m2.tomb[c] || {};
        m2.t[c] = m2.t[c] || {};
        for (const id of ids) {
          m2.tomb[c][id] = now();
          delete m2.t[c][id];
        }
        m2.dirty[c] = true;
        saveMeta(m2);
        schedulePush();
      }
      function pickSettings(s) {
        if (!s) return null;
        const out = {};
        for (const k of SETTING_KEYS) if (k in s) out[k] = s[k];
        if (out.appearance) {
          out.appearance = { ...out.appearance };
          for (const k of APPEAR_LOCAL) delete out.appearance[k];
        }
        return out;
      }
      function schedulePush() {
        clearTimeout(pushTimer);
        pushTimer = setTimeout(() => sync().catch(() => {
        }), 3e3);
      }
      var ERR = {
        EMAIL_EXISTS: "\uC774\uBBF8 \uAC00\uC785\uB41C \uC774\uBA54\uC77C\uC774\uC5D0\uC694. \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694",
        EMAIL_NOT_FOUND: "\uAC00\uC785\uB418\uC9C0 \uC54A\uC740 \uC774\uBA54\uC77C\uC774\uC5D0\uC694",
        INVALID_PASSWORD: "\uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694",
        INVALID_LOGIN_CREDENTIALS: "\uC774\uBA54\uC77C\uC774\uB098 \uBE44\uBC00\uBC88\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC544\uC694",
        INVALID_EMAIL: "\uC774\uBA54\uC77C \uC8FC\uC18C \uD615\uC2DD\uC774 \uB9DE\uC9C0 \uC54A\uC544\uC694",
        MISSING_PASSWORD: "\uBE44\uBC00\uBC88\uD638\uB97C \uB123\uC5B4 \uC8FC\uC138\uC694",
        WEAK_PASSWORD: "\uBE44\uBC00\uBC88\uD638\uB294 6\uC790 \uC774\uC0C1\uC73C\uB85C \uC815\uD574 \uC8FC\uC138\uC694",
        USER_DISABLED: "\uC0AC\uC6A9\uC774 \uC911\uC9C0\uB41C \uACC4\uC815\uC774\uC5D0\uC694",
        TOO_MANY_ATTEMPTS_TRY_LATER: "\uC2DC\uB3C4\uAC00 \uB108\uBB34 \uB9CE\uC544\uC694. \uC7A0\uC2DC \uB4A4\uC5D0 \uB2E4\uC2DC \uD574 \uC8FC\uC138\uC694",
        OPERATION_NOT_ALLOWED: "\uC774\uBA54\uC77C \uB85C\uADF8\uC778\uC774 \uC544\uC9C1 \uCF1C\uC838 \uC788\uC9C0 \uC54A\uC544\uC694 (\uC11C\uBC84 \uC124\uC815 \uD655\uC778 \uD544\uC694)",
        TOKEN_EXPIRED: "\uB85C\uADF8\uC778\uC774 \uB9CC\uB8CC\uB410\uC5B4\uC694. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694",
        INVALID_REFRESH_TOKEN: "\uB85C\uADF8\uC778\uC774 \uB9CC\uB8CC\uB410\uC5B4\uC694. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694",
        USER_NOT_FOUND: "\uACC4\uC815\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694"
      };
      function niceErr(j, status2) {
        const code = String(j && j.error && j.error.message || "").split(" ")[0].split(":")[0];
        return new Error(ERR[code] || j && j.error && j.error.message || `\uC11C\uBC84 \uC624\uB958 (${status2})`);
      }
      async function post(url, body, form) {
        const r = await fetchFn(url, {
          method: "POST",
          headers: { "Content-Type": form ? "application/x-www-form-urlencoded" : "application/json" },
          body: form ? new URLSearchParams(body).toString() : JSON.stringify(body)
        });
        let j = null;
        try {
          j = await r.json();
        } catch {
        }
        if (!r.ok) throw niceErr(j, r.status);
        return j;
      }
      function ensureCfg() {
        if (!CFG.apiKey || !CFG.projectId) throw new Error("\uB3D9\uAE30\uD654 \uC11C\uBC84\uAC00 \uC544\uC9C1 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC558\uC5B4\uC694 (\uAC1C\uBC1C\uC790 \uC124\uC815 \uD544\uC694)");
      }
      async function signIn(email, password, create) {
        ensureCfg();
        email = String(email || "").trim();
        const j = await post(`${AUTH}${create ? "signUp" : "signInWithPassword"}?key=${CFG.apiKey}`, { email, password, returnSecureToken: true });
        tok = { id: j.idToken, exp: now() + (Number(j.expiresIn) || 3600) * 1e3 - 6e4 };
        store4.quiet(() => store4.writeJSON("account.json", { email: j.email || email, uid: j.localId, refresh: store4.encrypt(j.refreshToken), since: now() }));
        const m2 = getMeta();
        m2.base = 1;
        m2.seen = {};
        m2.dirty = { events: true, notes: true, stickies: true, sources: true, remind: true, cats: true, birth: true, stickers: true, settings: true };
        saveMeta(m2);
        setState({ signedIn: true, email: j.email || email, uid: j.localId, error: "", message: create ? "\uAC00\uC785\uD558\uACE0 \uB85C\uADF8\uC778\uD588\uC5B4\uC694" : "\uB85C\uADF8\uC778\uD588\uC5B4\uC694" });
        await sync();
        return getState3();
      }
      async function resetPassword(email) {
        ensureCfg();
        await post(`${AUTH}sendOobCode?key=${CFG.apiKey}`, { requestType: "PASSWORD_RESET", email: String(email || "").trim() });
        return true;
      }
      function signOut() {
        store4.quiet(() => {
          store4.writeJSON("account.json", {});
          store4.writeJSON(META, {});
        });
        tok = { id: "", exp: 0 };
        setState({ signedIn: false, email: "", uid: "", lastSync: 0, message: "\uB85C\uADF8\uC544\uC6C3\uD588\uC5B4\uC694. \uC774 \uAE30\uAE30\uC758 \uC77C\uC815\xB7\uBA54\uBAA8\uB294 \uADF8\uB300\uB85C \uB0A8\uC544 \uC788\uC5B4\uC694", error: "" });
      }
      async function idToken() {
        if (tok.id && tok.exp > now()) return tok.id;
        const acc = getAcc();
        if (!acc || !acc.refresh) throw new Error("\uB85C\uADF8\uC778\uC774 \uD544\uC694\uD574\uC694");
        try {
          const j = await post(`${TOKEN2}?key=${CFG.apiKey}`, { grant_type: "refresh_token", refresh_token: store4.decrypt(acc.refresh) }, true);
          tok = { id: j.id_token, exp: now() + (Number(j.expires_in) || 3600) * 1e3 - 6e4 };
          return tok.id;
        } catch (e) {
          if (/만료|찾지 못/.test(e.message)) signOut();
          throw e;
        }
      }
      async function fsGet(path) {
        const r = await fetchFn(`${FS()}/${path}`, { headers: { Authorization: "Bearer " + await idToken() } });
        if (r.status === 404) return { data: null, updateTime: null };
        let j = null;
        try {
          j = await r.json();
        } catch {
        }
        if (!r.ok) throw niceErr(j, r.status);
        let data = null;
        try {
          data = JSON.parse(j.fields.json.stringValue);
        } catch {
        }
        return { data, updateTime: j.updateTime };
      }
      async function fsPut(path, data, updateTime) {
        const pre = updateTime ? `&currentDocument.updateTime=${encodeURIComponent(updateTime)}` : "&currentDocument.exists=false";
        const r = await fetchFn(`${FS()}/${path}?updateMask.fieldPaths=json&updateMask.fieldPaths=device&updateMask.fieldPaths=at${pre}`, {
          method: "PATCH",
          headers: { Authorization: "Bearer " + await idToken(), "Content-Type": "application/json" },
          body: JSON.stringify({ fields: { json: { stringValue: JSON.stringify(data) }, device: { stringValue: device }, at: { integerValue: String(now()) } } })
        });
        if (r.status === 409 || r.status === 400 || r.status === 412) {
          const e = new Error("conflict");
          e.conflict = true;
          throw e;
        }
        let j = null;
        try {
          j = await r.json();
        } catch {
        }
        if (!r.ok) throw niceErr(j, r.status);
        return j.updateTime;
      }
      function mergeEntries(localItems, localT, localTomb, remote) {
        const r = remote || { items: {}, tomb: {} };
        const ids = /* @__PURE__ */ new Set([...localItems.keys(), ...Object.keys(r.items || {}), ...Object.keys(r.tomb || {}), ...Object.keys(localTomb || {})]);
        const items = {}, tomb = {};
        for (const id of ids) {
          const cand = [];
          if (localItems.has(id)) cand.push({ v: localItems.get(id), t: localT[id] || 1 });
          if (localTomb && localTomb[id]) cand.push({ del: true, t: localTomb[id] });
          if (r.items && r.items[id]) cand.push({ v: r.items[id].v, t: r.items[id].t || 1 });
          if (r.tomb && r.tomb[id]) cand.push({ del: true, t: r.tomb[id] });
          cand.sort((a, b) => b.t - a.t || (a.del ? -1 : 1));
          const w = cand[0];
          if (w.del) tomb[id] = w.t;
          else items[id] = { v: w.v, t: w.t };
        }
        const cut = now() - 30 * 864e5;
        for (const id of Object.keys(tomb)) if (tomb[id] < cut) delete tomb[id];
        return { items, tomb };
      }
      async function syncOne(name, m2, remoteStamp, changes) {
        const path = `users/${state2.uid}/data/${name}`;
        const isDirty = !!m2.dirty[name];
        const remoteChanged = remoteStamp && remoteStamp !== m2.seen[name];
        if (!isDirty && !remoteChanged) return false;
        for (let attempt = 0; attempt < 3; attempt++) {
          const { data: remote, updateTime } = await fsGet(path);
          let merged, localNew, applyLocal = false;
          if (COLLS[name]) {
            const d = COLLS[name];
            const list = listOf(name, store4.readJSON(d.file, d.fromSettings ? {} : []));
            const map = new Map(list.map((x) => [String(x[d.key]), x]));
            merged = mergeEntries(map, m2.t[name] || {}, m2.tomb[name] || {}, remote);
            localNew = Object.values(merged.items).map((x) => x.v);
            applyLocal = JSON.stringify(sortBy(localNew, d.key)) !== JSON.stringify(sortBy(list, d.key));
            if (applyLocal) {
              if (d.fromSettings) changes[name] = localNew;
              else {
                store4.quiet(() => store4.writeJSON(d.file, localNew));
                changes[name] = true;
              }
            }
          } else if (MAPS[name]) {
            const d = MAPS[name];
            const obj = store4.readJSON(d.file, {});
            merged = mergeEntries(new Map(Object.entries(obj)), m2.t[name] || {}, m2.tomb[name] || {}, remote);
            localNew = Object.fromEntries(Object.entries(merged.items).map(([k, x]) => [k, x.v]));
            if (JSON.stringify(sortObj(localNew)) !== JSON.stringify(sortObj(obj))) {
              store4.quiet(() => store4.writeJSON(d.file, localNew));
              changes[name] = true;
            }
          } else {
            const lt = name === "settings" ? m2.t.settings || 1 : m2.t[name] || 1;
            const local = name === "settings" ? pickSettings(store4.readJSON("settings.json", {})) : store4.readJSON(WHOLE[name].file, null);
            if (remote && remote.t > lt) {
              merged = remote;
              if (name === "settings") changes.settings = remote.v;
              else {
                store4.quiet(() => store4.writeJSON(WHOLE[name].file, remote.v));
                changes[name] = true;
              }
            } else merged = { v: local, t: lt };
          }
          const need = JSON.stringify(remote) !== JSON.stringify(merged);
          try {
            let stamp = remoteStamp;
            if (need) {
              await fsPut(path, merged, updateTime);
              stamp = now();
              changes.__stamp = changes.__stamp || {};
              changes.__stamp[name] = stamp;
            }
            if (COLLS[name] || MAPS[name]) {
              m2.t[name] = Object.fromEntries(Object.entries(merged.items).map(([k, x]) => [k, x.t]));
              m2.tomb[name] = { ...merged.tomb };
            } else m2.t[name] = merged.t;
            m2.dirty[name] = false;
            m2.seen[name] = stamp || m2.seen[name];
            return true;
          } catch (e) {
            if (!e.conflict) throw e;
          }
        }
        throw new Error("\uB3D9\uC2DC\uC5D0 \uBC14\uB010 \uB0B4\uC6A9\uC774 \uB9CE\uC544 \uC7A0\uC2DC \uB4A4 \uB2E4\uC2DC \uB9DE\uCD9C\uAC8C\uC694");
      }
      var sortBy = (l, k) => [...l || []].sort((a, b) => String(a[k]).localeCompare(String(b[k])));
      var sortObj = (o) => Object.fromEntries(Object.entries(o || {}).sort(([a], [b]) => a.localeCompare(b)));
      async function sync() {
        if (!state2.signedIn || !CFG.apiKey) return getState3();
        if (running) return running;
        running = (async () => {
          setState({ syncing: true, error: "" });
          try {
            const m2 = getMeta();
            const { data: man, updateTime } = await fsGet(`users/${state2.uid}`);
            const stamps = man && man.stamps || {};
            const changes = {};
            for (const name of [...Object.keys(COLLS), ...Object.keys(MAPS), ...Object.keys(WHOLE), "settings"]) {
              if (!(name in m2.seen) && !(name in m2.t)) m2.dirty[name] = true;
            }
            for (const name of [...Object.keys(COLLS), ...Object.keys(MAPS), ...Object.keys(WHOLE), "settings"]) {
              await syncOne(name, m2, stamps[name], changes);
            }
            if (changes.__stamp) {
              const next = { stamps: { ...stamps, ...changes.__stamp }, device, at: now() };
              for (const [k, v] of Object.entries(changes.__stamp)) m2.seen[k] = v;
              try {
                await fsPut(`users/${state2.uid}`, next, updateTime);
              } catch (e) {
                if (!e.conflict) throw e;
                const again = await fsGet(`users/${state2.uid}`);
                await fsPut(`users/${state2.uid}`, { stamps: { ...again.data && again.data.stamps || {}, ...changes.__stamp }, device, at: now() }, again.updateTime);
              }
              delete changes.__stamp;
            }
            saveMeta(m2);
            const acc = getAcc();
            if (acc) store4.quiet(() => store4.writeJSON("account.json", { ...acc, lastSync: now() }));
            setState({ syncing: false, lastSync: now(), message: "" });
            if (Object.keys(changes).length && hooks.onRemoteChange) hooks.onRemoteChange(changes);
          } catch (e) {
            setState({ syncing: false, error: String(e.message || e) });
          } finally {
            running = null;
          }
          return getState3();
        })();
        return running;
      }
      module.exports = { init: init3, signIn, signOut, resetPassword, sync, getState: getState3, schedulePush, markRemoved };
    }
  });

  // desktop/renderer/themes.js
  var require_themes = __commonJS({
    "desktop/renderer/themes.js"(exports, module) {
      init_globals();
      (function(root) {
        const hex = (h) => {
          let s = String(h || "#000").replace("#", "");
          if (s.length === 3) s = s.split("").map((c) => c + c).join("");
          const n = parseInt(s.slice(0, 6), 16);
          return [n >> 16 & 255, n >> 8 & 255, n & 255];
        };
        const toHex2 = (r, g, b) => "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
        const mix = (a, b, t) => {
          const x = hex(a), y = hex(b);
          return toHex2(x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t);
        };
        const lum = (h) => {
          const [r, g, b] = hex(h);
          return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
        };
        const rgba = (h, a) => {
          const [r, g, b] = hex(h);
          return `rgba(${r},${g},${b},${a})`;
        };
        const isHex = (v) => /^#?[0-9a-f]{6}$/i.test(String(v || "").trim());
        function build(p) {
          const dark = p.dark != null ? p.dark : lum(p.bg) < 0.45;
          const text = p.text, bg = p.bg;
          const panel = p.panel || mix(bg, dark ? "#ffffff" : "#ffffff", dark ? 0.03 : 0.55);
          const pop = p.pop || (dark ? mix(bg, "#ffffff", 0.07) : "#FFFFFF");
          const ink = p.ink || text;
          return {
            dark,
            vars: {
              "--bg": p.bg2 ? `linear-gradient(180deg, ${bg}, ${p.bg2})` : bg,
              "--bg-solid": bg,
              "--panel-solid": panel,
              "--popover": pop,
              "--surface": "transparent",
              "--surface-2": rgba(ink, dark ? 0.05 : 0.05),
              "--surface-3": rgba(ink, dark ? 0.095 : 0.09),
              "--line": rgba(ink, dark ? 0.085 : 0.11),
              "--line-strong": rgba(ink, dark ? 0.16 : 0.2),
              "--text": text,
              "--sub": p.sub || mix(text, bg, dark ? 0.36 : 0.28),
              "--dim": p.dim || mix(text, bg, dark ? 0.58 : 0.5),
              "--sun": p.sun || (dark ? "#E58378" : "#C8483E"),
              "--sat": p.sat || (dark ? "#86A9D6" : "#3A69B0"),
              "--danger": dark ? "#E8877C" : "#C0443A",
              "--ok": dark ? "#8DBE86" : "#4E8A47",
              "--warn": dark ? "#D9B25F" : "#A87B1F",
              "--shadow": dark ? "0 10px 28px rgba(0,0,0,.45)" : `0 10px 26px ${rgba(mix(text, bg, 0.3), 0.14)}`,
              "--chip-ink": text,
              "--glass": "none",
              "color-scheme": dark ? "dark" : "light"
            }
          };
        }
        const S = (body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">${body}</svg>`;
        const MOTIF = {
          cheese: S('<path d="M3 17 L20 8 L21 18 Z" fill="#F6CE55" stroke="#C9952A" stroke-width="1.2" stroke-linejoin="round"/><circle cx="14" cy="14.5" r="1.6" fill="#E3AE3A"/><circle cx="18" cy="15.5" r="1" fill="#E3AE3A"/><circle cx="10" cy="16" r="1" fill="#E3AE3A"/>'),
          book: S('<rect x="5" y="4" width="13" height="16" rx="2" fill="#9C86D8"/><rect x="7" y="4" width="2" height="16" fill="#7F68C2"/><rect x="11" y="8" width="5" height="1.5" rx=".7" fill="#fff" opacity=".8"/>'),
          star: S('<path d="M12 3.5l2.5 5.2 5.7.8-4.1 4 1 5.6L12 16.4 6.9 19.1l1-5.6-4.1-4 5.7-.8z" fill="#F7CF5C" stroke="#D8A73A" stroke-width=".8" stroke-linejoin="round"/>'),
          sparkle: S('<path d="M12 2c.8 5 2.2 6.6 7 7.5-4.8.9-6.2 2.5-7 7.5-.8-5-2.2-6.6-7-7.5 4.8-.9 6.2-2.5 7-7.5z" fill="#FFFFFF" stroke="#BFE7D6" stroke-width=".8"/>'),
          clover: S('<circle cx="12" cy="7.5" r="4" fill="#79B865"/><circle cx="7.5" cy="13" r="4" fill="#79B865"/><circle cx="16.5" cy="13" r="4" fill="#79B865"/><path d="M12 13 Q13 18 16 21" stroke="#5E9A4C" stroke-width="1.6" fill="none" stroke-linecap="round"/>'),
          cloud: S('<path d="M7 18h10.5a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6-1A4.5 4.5 0 0 0 7 18z" fill="#FFFFFF" stroke="#C9D7EA" stroke-width="1.1"/>'),
          milk: S('<path d="M9 3h6v3l2 3v11a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 7 20V9l2-3z" fill="#FFFFFF" stroke="#B9C7D6" stroke-width="1.1"/><rect x="7" y="12" width="10" height="4" fill="#8CC5F0"/>'),
          tangerine: S('<circle cx="12" cy="13.5" r="7" fill="#F7962E"/><circle cx="9.5" cy="11" r="1.6" fill="#FFC27A" opacity=".8"/><path d="M12 6.5 Q15 3 18 4.5 Q15.5 7.5 12 6.5z" fill="#5FA34B"/>'),
          leaf: S('<path d="M5 19 C5 9 11 4 20 4 C20 13 15 19 5 19z" fill="#6DAA55"/><path d="M5 19 L15 9" stroke="#4E8A3D" stroke-width="1.2" stroke-linecap="round"/>'),
          stripe: S('<path d="M4 7 Q12 4 20 7" stroke="#3A2A1C" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".55"/><path d="M4 13 Q12 10 20 13" stroke="#3A2A1C" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".55"/>'),
          petal: S('<g fill="#F6B3C6" stroke="#E8869F" stroke-width=".7"><ellipse cx="12" cy="6.5" rx="3" ry="4"/><ellipse cx="17.2" cy="10.3" rx="3" ry="4" transform="rotate(72 17.2 10.3)"/><ellipse cx="15.2" cy="16.6" rx="3" ry="4" transform="rotate(144 15.2 16.6)"/><ellipse cx="8.8" cy="16.6" rx="3" ry="4" transform="rotate(216 8.8 16.6)"/><ellipse cx="6.8" cy="10.3" rx="3" ry="4" transform="rotate(288 6.8 10.3)"/></g><circle cx="12" cy="12" r="1.8" fill="#F7D46A"/>'),
          carrot: S('<path d="M15 8 L5 20 L17 10z" fill="#F28C38" stroke="#D8701F" stroke-width=".9" stroke-linejoin="round"/><path d="M15 8 Q15 3 17 2 M16 9 Q20 6 22 7 M16 8.5 Q19 4 21 3.5" stroke="#5FA34B" stroke-width="1.6" fill="none" stroke-linecap="round"/>'),
          heart: S('<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z" fill="#F38BA8"/>'),
          pearl: S('<circle cx="12" cy="12" r="6.5" fill="#F4F1FA" stroke="#C9C2DF" stroke-width="1"/><circle cx="9.8" cy="9.6" r="1.8" fill="#FFFFFF"/>'),
          teacup: S('<path d="M5 9h12v4a6 6 0 0 1-12 0z" fill="#FFFFFF" stroke="#8FA672" stroke-width="1.2"/><path d="M17 10.5h1.5a2 2 0 0 1 0 4H16.5" stroke="#8FA672" stroke-width="1.2" fill="none"/><rect x="6" y="9.5" width="10" height="2.4" fill="#9CBF6A"/><path d="M3 20h16" stroke="#8FA672" stroke-width="1.4" stroke-linecap="round"/><path d="M9 3c-1 1.5 1 2 0 3.5M13 3c-1 1.5 1 2 0 3.5" stroke="#B6C7A3" stroke-width="1.1" fill="none" stroke-linecap="round"/>'),
          drop: S('<path d="M12 3 C12 3 6 10.5 6 14.5a6 6 0 0 0 12 0C18 10.5 12 3 12 3z" fill="#A9D3C0"/><circle cx="10" cy="14" r="1.4" fill="#fff" opacity=".8"/>'),
          ribbon: S('<path d="M12 11 L5 6.5 V15.5z M12 11 L19 6.5 V15.5z" fill="#B79BF0" stroke="#9378D6" stroke-width=".9" stroke-linejoin="round"/><circle cx="12" cy="11" r="2" fill="#9378D6"/><path d="M11 12.5 L8.5 20 M13 12.5 L15.5 20" stroke="#9378D6" stroke-width="1.6" stroke-linecap="round"/>'),
          flag: S('<path d="M2 5 Q12 9 22 5" stroke="#B0A3C9" stroke-width="1" fill="none"/><path d="M5 6.3 L7.5 13 L10 7.6z" fill="#F4A6C8"/><path d="M10.6 7.7 L12.5 14.5 L14.4 7.7z" fill="#9FD3F2"/><path d="M15 7.6 L17 13 L19.4 6.3z" fill="#F8D676"/>'),
          moon: S('<path d="M15.5 3.5A8.5 8.5 0 1 0 20.5 17 7 7 0 0 1 15.5 3.5z" fill="#FBE7A1" stroke="#E5C66A" stroke-width=".9"/>'),
          banana: S('<path d="M4 7 C6 16 13 20 20 17 C14 17 8 13 6.5 6z" fill="#F7D24A" stroke="#D3A82A" stroke-width="1" stroke-linejoin="round"/><path d="M4 7 L5.4 5.6 L6.5 6" stroke="#6B5323" stroke-width="1.4" fill="none" stroke-linecap="round"/>'),
          palm: S('<path d="M12 21 V11" stroke="#7A5A34" stroke-width="1.8" stroke-linecap="round"/><path d="M12 11 C8 7 4 8 2.5 10 C6 9 9 10 12 11z M12 11 C16 7 20 8 21.5 10 C18 9 15 10 12 11z M12 11 C10 6 11 3 13 2 C12 5 12.5 8 12 11z" fill="#59A35B"/>'),
          sun: S('<circle cx="12" cy="12" r="4.5" fill="#FFC94A"/><g stroke="#F6A93A" stroke-width="1.8" stroke-linecap="round"><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/></g>'),
          egg: S('<path d="M5 13 C3 8 9 4 13 6 C18 4 22 9 19 13 C20 18 13 20 10 18 C6 19 4 16 5 13z" fill="#FFFFFF" stroke="#E5DCCB" stroke-width="1"/><circle cx="12" cy="12" r="3.4" fill="#FFC531"/><circle cx="11" cy="11" r="1" fill="#fff" opacity=".7"/>'),
          bread: S('<path d="M4 12a8 5 0 0 1 16 0v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z" fill="#E7A65A" stroke="#C47F35" stroke-width="1"/><path d="M8 10 l1.5 3M12 9.5 l1.5 3M16 10 l1.5 3" stroke="#F7CF95" stroke-width="1.3" stroke-linecap="round"/>'),
          paw: S('<g fill="#C98E5B"><ellipse cx="12" cy="15.5" rx="4.5" ry="3.8"/><circle cx="6.5" cy="10" r="2"/><circle cx="10" cy="6.8" r="2"/><circle cx="14" cy="6.8" r="2"/><circle cx="17.5" cy="10" r="2"/></g>'),
          bone: S('<path d="M7 9.5a2.4 2.4 0 1 1 2.4-2.9L14.6 11.7a2.4 2.4 0 1 1 2.9 2.4 2.4 2.4 0 1 1-2.4 2.9L9.9 11.9A2.4 2.4 0 1 1 7 9.5z" fill="#FFFFFF" stroke="#D9C7AE" stroke-width="1"/>'),
          ball: S('<circle cx="12" cy="12" r="7" fill="#7CC0E8"/><path d="M5.5 9.5 Q12 13 18.5 9.5 M6 15 Q12 11.5 18 15" stroke="#FFFFFF" stroke-width="1.4" fill="none"/>'),
          strawberry: S('<path d="M12 21 C6 18 4 13 5.5 9.5 C8 8 16 8 18.5 9.5 C20 13 18 18 12 21z" fill="#F0566E"/><path d="M7 8.5 L9.5 6 L12 8 L14.5 6 L17 8.5 L12 10z" fill="#5FA34B"/><g fill="#FFE3A3"><circle cx="9" cy="12.5" r=".7"/><circle cx="12" cy="13" r=".7"/><circle cx="15" cy="12.5" r=".7"/><circle cx="10.5" cy="16" r=".7"/><circle cx="13.5" cy="16" r=".7"/></g>'),
          donut: S('<circle cx="12" cy="12" r="8" fill="#E8B07A"/><circle cx="12" cy="12" r="6.6" fill="#F59BB2"/><circle cx="12" cy="12" r="2.6" fill="#FFF5F7"/><g stroke-width="1.2" stroke-linecap="round"><path d="M8 8.5l1 .6" stroke="#FFE07A"/><path d="M15.5 8l.8-.9" stroke="#8ED0F2"/><path d="M16 15l1 .5" stroke="#FFFFFF"/><path d="M8.5 15.5l-.6 1" stroke="#9FDA8E"/></g>'),
          dot: S('<circle cx="12" cy="12" r="4" fill="#F7A9B9"/>'),
          maple: S('<path d="M12 2l1.8 4.2 3.4-1.6-1 3.9 4.3.3-3.2 3 1.6 1.4-4.4.9.6 3.4L12 15.6 8.9 17.5l.6-3.4-4.4-.9 1.6-1.4-3.2-3 4.3-.3-1-3.9 3.4 1.6z" fill="#E8692C"/><path d="M12 15.6V22" stroke="#B84E1C" stroke-width="1.3" stroke-linecap="round"/>'),
          acorn: S('<path d="M6 10h12a6 7 0 0 1-12 0z" fill="#C98B4E"/><path d="M5 10.5c0-3 3-5 7-5s7 2 7 5z" fill="#7A5232"/><path d="M12 5.5V3" stroke="#5E3E24" stroke-width="1.6" stroke-linecap="round"/>'),
          snowflake: S('<g stroke="#8DB8EA" stroke-width="1.8" stroke-linecap="round"><path d="M12 2v20M3.3 7l17.4 10M3.3 17l17.4-10"/><path d="M9.5 3.8 12 6l2.5-2.2M9.5 20.2 12 18l2.5 2.2"/></g>'),
          pumpkin: S('<ellipse cx="12" cy="14" rx="8.5" ry="7" fill="#F28A2B"/><path d="M12 7v14M8 7.8c-2 3-2 9.5 0 12.4M16 7.8c2 3 2 9.5 0 12.4" stroke="#D86E14" stroke-width="1.1" fill="none"/><path d="M12 7c0-2 1-3 2.5-3.5" stroke="#5E8C3A" stroke-width="1.8" fill="none" stroke-linecap="round"/>'),
          bat: S('<path d="M12 9c1.5 0 2 1 2 2 2-2 5-2 8-1-2 1-2.5 3-2 5-1.5-1-3-1-4.5 0-.5-1-2-1.5-3.5-1.5S9 14 8.5 15c-1.5-1-3-1-4.5 0 .5-2 0-4-2-5 3-1 6-1 8 1 0-1 .5-2 2-2z" fill="#4A3B5C"/>'),
          ghost: S('<path d="M5 20V11a7 7 0 0 1 14 0v9l-2.3-1.6L14.3 20 12 18.4 9.7 20l-2.4-1.6z" fill="#FFFFFF" stroke="#C9C2DA" stroke-width="1"/><circle cx="9.6" cy="11" r="1.1" fill="#3B3346"/><circle cx="14.4" cy="11" r="1.1" fill="#3B3346"/>'),
          gift: S('<rect x="4" y="10" width="16" height="11" rx="1.5" fill="#D9473E"/><rect x="3" y="7" width="18" height="4" rx="1" fill="#E85B50"/><rect x="11" y="7" width="2.4" height="14" fill="#F6D35B"/><path d="M12 7c-2-3-5-3-5-1s3 1 5 1c2 0 5 1 5-1s-3-2-5 1z" fill="none" stroke="#F6D35B" stroke-width="1.5"/>'),
          xtree: S('<path d="M12 2 5 12h3.5L4 18h16l-4.5-6H19z" fill="#3E9A5A"/><rect x="10.5" y="18" width="3" height="3.5" fill="#8A5A35"/><circle cx="9.5" cy="13.5" r="1" fill="#F2C94C"/><circle cx="14.5" cy="15.5" r="1" fill="#E85B50"/><circle cx="12" cy="9" r="1" fill="#E85B50"/>'),
          firework: S('<g stroke-width="1.8" stroke-linecap="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4" stroke="#F2A51A"/><path d="M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" stroke="#E86AA0"/></g><circle cx="12" cy="12" r="1.8" fill="#8E7CE8"/>'),
          persimmon: S('<circle cx="12" cy="13.5" r="7.5" fill="#F07A2A"/><path d="M8 7.5c1.5 1 2.5 1 4 0 1.5 1 2.5 1 4 0-.5 2-2 3-4 3s-3.5-1-4-3z" fill="#5E8C3A"/><circle cx="9.5" cy="12" r="1.5" fill="#FFB27A" opacity=".7"/>'),
          fullmoon: S('<circle cx="12" cy="12" r="8.5" fill="#FBE18A" stroke="#EDC24F" stroke-width="1"/><circle cx="9" cy="10" r="1.6" fill="#EFCF6A"/><circle cx="14.5" cy="14" r="1.1" fill="#EFCF6A"/>'),
          starfish: S('<path d="M12 2.5l2.3 6.3 6.6.3-5.2 4.1 1.9 6.4L12 15.9l-5.6 3.7 1.9-6.4-5.2-4.1 6.6-.3z" fill="#F69A7C" stroke="#E67455" stroke-width=".8" stroke-linejoin="round"/>'),
          watermelon: S('<path d="M3 9a9 9 0 0 0 18 0z" fill="#5FAE58"/><path d="M4.6 9a7.4 7.4 0 0 0 14.8 0z" fill="#F2556D"/><g fill="#3A2A2A"><circle cx="9" cy="12" r=".7"/><circle cx="12" cy="13.6" r=".7"/><circle cx="15" cy="12" r=".7"/></g>'),
          lantern: S('<path d="M12 2v2.5" stroke="#B98A2E" stroke-width="1.4"/><rect x="9" y="4" width="6" height="2" rx=".6" fill="#B98A2E"/><ellipse cx="12" cy="12" rx="6.5" ry="6" fill="#E04A3A"/><path d="M12 6v12M8.3 7.2c-1.5 3-1.5 6.6 0 9.6M15.7 7.2c1.5 3 1.5 6.6 0 9.6" stroke="#B83426" stroke-width=".9" fill="none"/><rect x="9" y="17.6" width="6" height="1.8" rx=".6" fill="#B98A2E"/><path d="M12 19.4v2.6" stroke="#F2C94C" stroke-width="1.6" stroke-linecap="round"/>')
        };
        const svgUrl = (svg) => `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;
        const BASIC = [
          // 다크
          { id: "midnight", group: "dark", name: "\uC789\uD06C", desc: "\uB530\uB73B\uD55C \uBA39\uC0C9", accent: "#D27A4A", p: { bg: "#141414", bg2: "#121212", panel: "#1A1A1A", pop: "#1E1E1E", text: "#ECE9E3", sub: "#A39F97", dim: "#6F6B64", sun: "#E07A6E", sat: "#7FA3D1" } },
          { id: "aurora", group: "dark", name: "\uD3EC\uB808\uC2A4\uD2B8", desc: "\uC9D9\uC740 \uC774\uB07C\uC0C9", accent: "#8DBE86", p: { bg: "#141A16", bg2: "#121814", panel: "#19211C", pop: "#1C251F", text: "#E7EBE4", sub: "#A0AA9F", dim: "#6C766C", sun: "#E08070", sat: "#8BAECB" } },
          { id: "navy", group: "dark", name: "\uBBF8\uB4DC\uB098\uC787 \uBE14\uB8E8", desc: "\uAE4A\uC740 \uBC24 \uB0A8\uC0C9", accent: "#7FA7E8", p: { bg: "#0F1626", bg2: "#0C1220", panel: "#141D30", text: "#E6EAF2", sub: "#9AA6BD", dim: "#64708A" } },
          { id: "mocha", group: "dark", name: "\uBAA8\uCE74", desc: "\uCEE4\uD53C \uD55C \uC794 \uAC19\uC740 \uBE0C\uB77C\uC6B4", accent: "#D49A6A", p: { bg: "#1B1613", bg2: "#171310", panel: "#221C18", text: "#EFE6DD", sub: "#B3A497", dim: "#7D6F63" } },
          { id: "plum", group: "dark", name: "\uD50C\uB7FC", desc: "\uCC28\uBD84\uD55C \uC790\uB450\uBE5B \uBCF4\uB77C", accent: "#C58BE0", p: { bg: "#1A1420", bg2: "#16111B", panel: "#221A2A", text: "#EEE6F3", sub: "#AE9DBC", dim: "#786985" } },
          { id: "deepsea", group: "dark", name: "\uB525 \uC624\uC158", desc: "\uAE4A\uC740 \uBC14\uB2E4 \uCCAD\uB85D", accent: "#4FB3A9", p: { bg: "#0E1A1C", bg2: "#0B1517", panel: "#132326", text: "#E2EFEF", sub: "#94AEAF", dim: "#5E7778" } },
          { id: "graphite", group: "dark", name: "\uADF8\uB77C\uD30C\uC774\uD2B8", desc: "\uAD70\uB354\uB354\uAE30 \uC5C6\uB294 \uD68C\uC0C9", accent: "#8AB4F8", p: { bg: "#1C1E22", bg2: "#191B1E", panel: "#23262B", text: "#E8EAED", sub: "#A2A7AF", dim: "#6C727B" } },
          { id: "oled", group: "dark", name: "\uC62C \uBE14\uB799", desc: "\uC644\uC804\uD55C \uAC80\uC815 (OLED)", accent: "#F5C451", p: { bg: "#000000", panel: "#0A0A0A", pop: "#141414", text: "#F2F2F2", sub: "#A6A6A6", dim: "#6B6B6B" } },
          { id: "neon", group: "dark", name: "\uB124\uC628 \uB098\uC774\uD2B8", desc: "\uBCF4\uB78F\uBE5B \uBC24 + \uD551\uD06C \uD3EC\uC778\uD2B8", accent: "#FF5FA8", p: { bg: "#0F0C1E", bg2: "#140F28", panel: "#171230", text: "#ECE8FF", sub: "#A69FCC", dim: "#6D6696", sat: "#7FB4FF", sun: "#FF7A9C" } },
          { id: "hc", group: "dark", name: "\uACE0\uB300\uBE44", desc: "\uAE00\uC790\uAC00 \uAC00\uC7A5 \uB610\uB837\uD558\uAC8C", accent: "#FFD400", p: { bg: "#000000", panel: "#000000", pop: "#111111", text: "#FFFFFF", sub: "#E6E6E6", dim: "#C2C2C2", sun: "#FF8A80", sat: "#9CC7FF", ink: "#FFFFFF" } },
          { id: "wine", group: "dark", name: "\uC640\uC778", desc: "\uAE4A\uC740 \uBC84\uAC74\uB514", accent: "#E0848F", p: { bg: "#1C1315", bg2: "#181012", panel: "#241A1C", pop: "#291E21", text: "#F1E6E7", sub: "#B39EA1", dim: "#7C686B", sun: "#F08A8A", sat: "#93A9D8" } },
          { id: "starry", group: "dark", name: "\uBCC4\uBC24", desc: "\uB0A8\uBCF4\uB78F\uBE5B \uBC24\uD558\uB298 + \uBCC4\uBE5B \uB178\uB791", accent: "#F2C46D", p: { bg: "#11142A", bg2: "#0E1124", panel: "#181C36", pop: "#1D213D", text: "#E9EAF6", sub: "#A3A7C7", dim: "#6D7192", sun: "#F08E8E", sat: "#8DB2F2" } },
          // 라이트
          { id: "paper", group: "light", name: "\uD398\uC774\uD37C", desc: "\uBBF8\uC0C9 \uC885\uC774", accent: "#D27A4A", p: { bg: "#F4F1EA", bg2: "#F1EDE5", panel: "#FBF9F5", text: "#24211C", sub: "#6B655C", dim: "#9D978D", sun: "#C24A3E", sat: "#3A69B0" } },
          { id: "snow", group: "light", name: "\uC2A4\uB178\uC6B0", desc: "\uAE68\uB057\uD55C \uD770\uC0C9", accent: "#3B6FE0", p: { bg: "#FAFAFA", panel: "#FFFFFF", text: "#1D1F23", sub: "#5F6670", dim: "#9AA0A8" } },
          { id: "latte", group: "light", name: "\uB77C\uB5BC", desc: "\uBD80\uB4DC\uB7EC\uC6B4 \uBCA0\uC774\uC9C0", accent: "#B9773F", p: { bg: "#F3EBE1", bg2: "#EFE5D9", panel: "#FAF5EF", text: "#3A2E25", sub: "#6E5D50", dim: "#A08F81" } },
          { id: "sage", group: "light", name: "\uC138\uC774\uC9C0", desc: "\uC740\uC740\uD55C \uD480\uBE5B", accent: "#5E8C61", p: { bg: "#EEF2EA", panel: "#F7F9F4", text: "#26302A", sub: "#5E6B61", dim: "#95A198" } },
          { id: "lavender", group: "light", name: "\uB77C\uBCA4\uB354 \uBBF8\uC2A4\uD2B8", desc: "\uC5F0\uBCF4\uB77C \uC548\uAC1C", accent: "#8A6FD1", p: { bg: "#F2EFF8", panel: "#FAF8FD", text: "#2E2A3A", sub: "#6C6680", dim: "#A39DB5" } },
          { id: "peach", group: "light", name: "\uD53C\uCE58", desc: "\uBCF5\uC22D\uC544\uBE5B \uB530\uB73B\uD568", accent: "#D46E55", p: { bg: "#FBEFE8", panel: "#FFF8F4", text: "#3B2A25", sub: "#6E5750", dim: "#A8918A" } },
          { id: "sky", group: "light", name: "\uC2A4\uCE74\uC774", desc: "\uB9D1\uC740 \uD558\uB298\uC0C9", accent: "#3D8BD9", p: { bg: "#EBF3FA", panel: "#F7FBFE", text: "#1F2D3A", sub: "#5A6B7B", dim: "#93A3B2" } },
          { id: "nordic", group: "light", name: "\uB178\uB974\uB515", desc: "\uCC28\uAC00\uC6B4 \uD68C\uCCAD\uC0C9", accent: "#5B7A99", p: { bg: "#ECEFF3", panel: "#F6F8FA", text: "#262B33", sub: "#616B78", dim: "#9AA3AE" } },
          { id: "pastel", group: "light", name: "\uD30C\uC2A4\uD154", desc: "\uBD84\uD64D\xB7\uBCF4\uB77C \uADF8\uB77C\uB370\uC774\uC158", accent: "#C9789E", p: { bg: "#F8F1EE", bg2: "#F1ECF4", panel: "#FCF8F6", text: "#3A2E36", sub: "#76646F", dim: "#A8979F", sun: "#D0606E", sat: "#5B7FC0" } },
          { id: "mono", group: "light", name: "\uBAA8\uB178", desc: "\uD751\uBC31 \uBBF8\uB2C8\uBA40", accent: "#111111", p: { bg: "#FFFFFF", panel: "#FFFFFF", text: "#111111", sub: "#555555", dim: "#999999", sun: "#111111", sat: "#111111" } },
          { id: "butter", group: "light", name: "\uBC84\uD130 \uD06C\uB9BC", desc: "\uD3EC\uADFC\uD55C \uB178\uB780 \uD06C\uB9BC", accent: "#C9952A", p: { bg: "#FBF5E3", bg2: "#F8F0DA", panel: "#FFFBF0", text: "#3A3222", sub: "#7A6E55", dim: "#AEA28A", sun: "#C8503F", sat: "#4A72B0" } },
          { id: "mint", group: "light", name: "\uBBFC\uD2B8 \uC18C\uB2E4", desc: "\uC2DC\uC6D0\uD55C \uBBFC\uD2B8\uBE5B", accent: "#2E9C82", p: { bg: "#EAF6F2", bg2: "#E3F2EE", panel: "#F6FCFA", text: "#21352F", sub: "#5F7871", dim: "#94A8A2", sun: "#C8503F", sat: "#3C72B4" } }
        ];
        const LINA = [
          {
            char: "rat",
            name: "\uCE58\uC988 \uB3C4\uC11C\uAD00",
            story: "\uCC45 \uC0AC\uC774\uC5D0 \uCE58\uC988\uB97C \uC228\uACA8 \uB450\uB294 \uAF3C\uAF3C\uD55C \uC0AC\uC11C \uC950",
            motifs: ["cheese", "book", "star"],
            day: { bg: "#F4F0FA", bg2: "#F7F2E4", panel: "#FBF9FE", text: "#3A3248", accent: "#BD8A14" },
            night: { bg: "#1D1A28", bg2: "#1A1722", panel: "#252134", text: "#EEE9F7", accent: "#F2C94C" }
          },
          {
            char: "ox",
            name: "\uBAA9\uC7A5\uC758 \uC544\uCE68",
            story: "\uD074\uB85C\uBC84 \uB4E4\uD310\uC5D0\uC11C \uC6B0\uC720 \uD55C \uBCD1\uC73C\uB85C \uD558\uB8E8\uB97C \uC2DC\uC791\uD558\uB294 \uC18C",
            motifs: ["clover", "cloud", "milk"],
            day: { bg: "#F5F4EA", bg2: "#EEF3E4", panel: "#FFFEF8", text: "#2F3328", accent: "#5F9A4C" },
            night: { bg: "#161B16", bg2: "#131813", panel: "#1D231D", text: "#ECEFE6", accent: "#8BC27A" }
          },
          {
            char: "tiger",
            name: "\uADE4\uBE5B \uC232",
            story: "\uADE4\uB098\uBB34 \uC232\uC744 \uC9C0\uD0A4\uB294 \uC904\uBB34\uB2AC \uAF2C\uB9C8 \uD638\uB791\uC774",
            motifs: ["tangerine", "leaf", "stripe"],
            day: { bg: "#FFF3E6", bg2: "#FDEBD6", panel: "#FFFAF4", text: "#3D2A1C", accent: "#D46D0E" },
            night: { bg: "#1E1610", bg2: "#1A130D", panel: "#271D15", text: "#F6EADF", accent: "#F5A04A" }
          },
          {
            char: "rabbit",
            name: "\uBC9A\uAF43 \uD53C\uD06C\uB2C9",
            story: "\uBC9A\uAF43 \uC544\uB798 \uB2F9\uADFC \uB3C4\uC2DC\uB77D\uC744 \uD3BC\uCE58\uB294 \uD1A0\uB07C",
            motifs: ["petal", "carrot", "heart"],
            day: { bg: "#FDF0F3", bg2: "#FBE8EE", panel: "#FFF8FA", text: "#3E2A31", accent: "#E06A8E" },
            night: { bg: "#1E1519", bg2: "#1A1216", panel: "#281C21", text: "#F8E9EE", accent: "#F29AB5" }
          },
          {
            char: "dragon",
            name: "\uBBFC\uD2B8 \uAD6C\uB984 \uC655\uAD6D",
            story: "\uAD6C\uB984 \uC704 \uC655\uAD6D\uC5D0\uC11C \uC9C4\uC8FC\uB97C \uBAA8\uC73C\uB294 \uC544\uAE30 \uC6A9",
            motifs: ["cloud", "sparkle", "pearl"],
            day: { bg: "#ECF7F1", bg2: "#E4F2F2", panel: "#F7FCF9", text: "#213A30", accent: "#2FA077" },
            night: { bg: "#0F1C18", bg2: "#0D1816", panel: "#152621", text: "#E3F3EC", accent: "#5FD3A6" }
          },
          {
            char: "snake",
            name: "\uB9D0\uCC28 \uD2F0\uD0C0\uC784",
            story: "\uC624\uD6C4 \uC138 \uC2DC, \uB9D0\uCC28 \uD55C \uC794\uC744 \uB0B4\uB9AC\uB294 \uB2E4\uC815\uD55C \uBC40",
            motifs: ["teacup", "leaf", "drop"],
            day: { bg: "#EEF3E4", bg2: "#E8EEDB", panel: "#F8FAF2", text: "#2D3523", accent: "#6F8C3C" },
            night: { bg: "#171B12", bg2: "#14170F", panel: "#1F2419", text: "#ECF0E3", accent: "#A4C46A" }
          },
          {
            char: "horse",
            name: "\uB77C\uBCA4\uB354 \uCE90\uB7EC\uC140",
            story: "\uBCC4\uBE5B \uD68C\uC804\uBAA9\uB9C8\uB97C \uD0C0\uACE0 \uB2EC\uB9AC\uB294 \uAFC8\uAFB8\uB294 \uB9D0",
            motifs: ["star", "ribbon", "flag"],
            day: { bg: "#F3EEFA", bg2: "#EEE6F8", panel: "#FBF8FE", text: "#33284A", accent: "#8B67D1" },
            night: { bg: "#1A1626", bg2: "#161221", panel: "#221D32", text: "#EFE9FA", accent: "#B79BF0" }
          },
          {
            char: "goat",
            name: "\uC19C\uC0AC\uD0D5 \uAFC8\uB098\uB77C",
            story: "\uAD6C\uB984 \uC19C\uC0AC\uD0D5\uC744 \uBCA0\uACE0 \uB0AE\uC7A0 \uC790\uB294 \uC591",
            motifs: ["cloud", "moon", "star"],
            day: { bg: "#EEF4FB", bg2: "#F6EEF6", panel: "#FAFCFF", text: "#26324A", accent: "#CC6690" },
            night: { bg: "#121729", bg2: "#0F1322", panel: "#1A2036", text: "#E8ECF8", accent: "#F3B5CF" }
          },
          {
            char: "monkey",
            name: "\uBC14\uB098\uB098 \uC815\uAE00",
            story: "\uC57C\uC790\uC218 \uC0AC\uC774\uB85C \uBC14\uB098\uB098\uB97C \uB098\uB974\uB294 \uC7A5\uB09C\uAFB8\uB7EC\uAE30",
            motifs: ["banana", "palm", "leaf"],
            day: { bg: "#F8F3E2", bg2: "#F0F2DD", panel: "#FFFCF2", text: "#36301C", accent: "#A57C06" },
            night: { bg: "#18170F", bg2: "#15140C", panel: "#211F15", text: "#F2EEDC", accent: "#F0CB4A" }
          },
          {
            char: "rooster",
            name: "\uC0C8\uBCBD \uD587\uC0B4 \uBCA0\uC774\uCEE4\uB9AC",
            story: "\uD574 \uB728\uAE30 \uC804 \uBE75\uC744 \uAD7D\uB294 \uBD80\uC9C0\uB7F0\uD55C \uB2ED",
            motifs: ["sun", "egg", "bread"],
            day: { bg: "#FFF8E8", bg2: "#FFF1DA", panel: "#FFFDF6", text: "#3A2D17", accent: "#DA4A35" },
            night: { bg: "#1C1712", bg2: "#18130F", panel: "#251F18", text: "#F7EEDF", accent: "#F2785F" }
          },
          {
            char: "dog",
            name: "\uC0B0\uCC45 \uACF5\uC6D0",
            story: "\uACF5 \uD558\uB098\uBA74 \uD558\uB8E8\uAC00 \uD589\uBCF5\uD55C \uC0B0\uCC45 \uCE5C\uAD6C",
            motifs: ["paw", "bone", "ball"],
            day: { bg: "#F7F1E8", bg2: "#EEF3F6", panel: "#FFFBF5", text: "#35291E", accent: "#B8702E" },
            night: { bg: "#19150F", bg2: "#15120D", panel: "#221D16", text: "#F3EADF", accent: "#E8AE6E" }
          },
          {
            char: "pig",
            name: "\uB538\uAE30 \uB514\uC800\uD2B8 \uCE74\uD398",
            story: "\uB538\uAE30 \uB3C4\uB11B\uC744 \uAD7D\uB294 \uB514\uC800\uD2B8 \uCE74\uD398 \uC0AC\uC7A5\uB2D8",
            motifs: ["strawberry", "donut", "dot"],
            day: { bg: "#FFF0F2", bg2: "#FDE8EC", panel: "#FFF8F9", text: "#40262C", accent: "#E35C78" },
            night: { bg: "#1F1417", bg2: "#1B1114", panel: "#2A1B20", text: "#FBE8EC", accent: "#F48CA0" }
          }
        ];
        const CHAR_NAME = { rat: "\uC950", ox: "\uC18C", tiger: "\uD638\uB791\uC774", rabbit: "\uD1A0\uB07C", dragon: "\uC6A9", snake: "\uBC40", horse: "\uB9D0", goat: "\uC591", monkey: "\uC6D0\uC22D\uC774", rooster: "\uB2ED", dog: "\uAC1C", pig: "\uB3FC\uC9C0" };
        const THEMES = BASIC.map((t) => ({ ...t, ...build(t.p) }));
        for (const c of LINA) {
          for (const mode of ["day", "night"]) {
            const p = c[mode];
            const b = build(p);
            THEMES.push({
              id: `lina-${c.char}-${mode}`,
              group: "linaverse",
              char: c.char,
              mode,
              ck: "base",
              name: c.name + (mode === "night" ? " \xB7 \uB2E4\uD06C" : ""),
              concept: c.name,
              story: c.story,
              desc: `${CHAR_NAME[c.char]} \xB7 ${mode === "night" ? "\uB2E4\uD06C" : "\uB77C\uC774\uD2B8"}`,
              accent: p.accent,
              motifs: c.motifs,
              ...b
            });
          }
        }
        const SEASONS = [
          {
            id: "spring",
            kind: "\uACC4\uC808",
            name: "\uBD04 \uC18C\uD48D",
            story: "\uBC9A\uAF43 \uC544\uB798 \uB3C4\uC2DC\uB77D\uC744 \uD3BC\uCE5C 12\uC9C0\uC2E0 \uC18C\uD48D\uB0A0",
            motifs: ["petal", "clover", "heart"],
            accent: "#E06A8E",
            day: { bg: "#FFF5F6", bg2: "#F3F8EC", panel: "#FFFBFC", text: "#3A2C31" },
            night: { bg: "#1F1720", bg2: "#17191A", panel: "#291F2A", text: "#F7EAF0", accent: "#F29AB5" }
          },
          {
            id: "summer",
            kind: "\uACC4\uC808",
            name: "\uC5EC\uB984 \uBC14\uCE89\uC2A4",
            story: "\uC120\uAE00\uB77C\uC2A4 \uB07C\uACE0 \uBC14\uB2E4\uB85C! \uD29C\uBE0C\xB7\uC218\uBC15\xB7\uC11C\uD551",
            motifs: ["starfish", "watermelon", "sun"],
            accent: "#1A8FB8",
            day: { bg: "#EEF8FC", bg2: "#FFF7E6", panel: "#F9FDFF", text: "#1E3442" },
            night: { bg: "#0D1B26", bg2: "#0B1820", panel: "#132634", text: "#E3F2FA", accent: "#4FC3E8" }
          },
          {
            id: "autumn",
            kind: "\uACC4\uC808",
            name: "\uAC00\uC744 \uB098\uB4E4\uC774",
            story: "\uBCA0\uB808\uBAA8 \uC4F0\uACE0 \uB2E8\uD48D\uAE38 \uC0B0\uCC45, \uB3C4\uD1A0\uB9AC\xB7\uAC10 \uB530\uAE30",
            motifs: ["maple", "acorn", "leaf"],
            accent: "#C9561A",
            day: { bg: "#FFF4E8", bg2: "#FBEBD9", panel: "#FFFAF4", text: "#3E2A1B" },
            night: { bg: "#1E150F", bg2: "#19120C", panel: "#281D15", text: "#F6E9DC", accent: "#F08A4B" }
          },
          {
            id: "winter",
            kind: "\uACC4\uC808",
            name: "\uACA8\uC6B8 \uB208\uAF43",
            story: "\uBAA9\uB3C4\uB9AC \uB450\uB974\uACE0 \uCF54\uCF54\uC544 \uD55C \uC794, \uB208\uC0AC\uB78C \uB9CC\uB4E4\uAE30",
            motifs: ["snowflake", "cloud", "heart"],
            accent: "#3F78CF",
            day: { bg: "#F1F6FD", bg2: "#E9F0FA", panel: "#FAFCFF", text: "#22314A" },
            night: { bg: "#111A2B", bg2: "#0E1524", panel: "#172238", text: "#E6EEFA", accent: "#7FB0F5" }
          },
          {
            id: "halloween",
            kind: "\uD589\uC0AC",
            name: "\uD560\uB85C\uC708 \uB098\uC774\uD2B8",
            story: "\uB9C8\uB140 \uBAA8\uC790 \uC4F0\uACE0 \uC0AC\uD0D5 \uBC14\uAD6C\uB2C8 \uB4E4\uACE0 \uD2B8\uB9AD \uC624\uC5B4 \uD2B8\uB9BF!",
            motifs: ["pumpkin", "bat", "ghost"],
            accent: "#E0701A",
            day: { bg: "#FFF4E6", bg2: "#F4EEFA", panel: "#FFFAF3", text: "#33243F" },
            night: { bg: "#1C1428", bg2: "#170F21", panel: "#241A33", text: "#F2E9FF", sun: "#FF8F8F", sat: "#9BB8FF", accent: "#FF8A2A" }
          },
          {
            id: "christmas",
            kind: "\uD589\uC0AC",
            name: "\uBA54\uB9AC \uD06C\uB9AC\uC2A4\uB9C8\uC2A4",
            story: "\uC0B0\uD0C0 \uBAA8\uC790\uC640 \uC120\uBB3C \uC0C1\uC790, \uBC18\uC9DD\uC774\uB294 \uD2B8\uB9AC",
            motifs: ["gift", "xtree", "star"],
            accent: "#CF3A3A",
            day: { bg: "#FFF8F3", bg2: "#F4F9F2", panel: "#FFFCFA", text: "#3A2420" },
            night: { bg: "#10221A", bg2: "#0D1C15", panel: "#162C22", text: "#F3EFE6", accent: "#F05A5A" }
          },
          {
            id: "newyear",
            kind: "\uBA85\uC808",
            name: "\uD574\uD53C \uB274\uC774\uC5B4",
            story: "\uACE0\uAE54\uBAA8\uC790 \uC4F0\uACE0 \uC0C8\uD574 \uCE74\uC6B4\uD2B8\uB2E4\uC6B4!",
            motifs: ["firework", "star", "dot"],
            banner: "newyear",
            accent: "#D99208",
            day: { bg: "#FFF9EB", bg2: "#F7F0FF", panel: "#FFFDF6", text: "#33283F" },
            night: { bg: "#15132A", bg2: "#110F22", panel: "#1D1A36", text: "#F1ECFA", accent: "#F4C04A" }
          },
          {
            id: "seollal",
            kind: "\uBA85\uC808",
            name: "\uC124\uB0A0 \xB7 \uADFC\uD558\uC2E0\uB144",
            story: "\uBCF5\uC8FC\uBA38\uB2C8\uC640 \uB9E4\uD654, \uADFC\uD558\uC2E0\uB144 \uC778\uC0AC",
            motifs: ["lantern", "petal", "cloud"],
            banner: "seollal",
            accent: "#C8372D",
            day: { bg: "#FFF6E9", bg2: "#FDEFE2", panel: "#FFFBF5", text: "#3B2418" },
            night: { bg: "#21120F", bg2: "#1B0F0C", panel: "#2B1915", text: "#F8E9E0", accent: "#F0645A" }
          },
          {
            id: "chuseok",
            kind: "\uBA85\uC808",
            name: "\uCD94\uC11D \xB7 \uD55C\uAC00\uC704",
            story: "\uBCF4\uB984\uB2EC \uC544\uB798 \uAC10\xB7\uC1A1\uD3B8, \uD48D\uC131\uD55C \uD55C\uAC00\uC704",
            motifs: ["persimmon", "fullmoon", "leaf"],
            banner: "chuseok",
            accent: "#D9701A",
            day: { bg: "#FFF6E6", bg2: "#FBEFDD", panel: "#FFFBF4", text: "#3A2A18" },
            night: { bg: "#141526", bg2: "#11121F", panel: "#1C1D33", text: "#F3EDE2", accent: "#F5B04A" }
          }
        ];
        const MODE_NAME = { day: "\uB77C\uC774\uD2B8", night: "\uB2E4\uD06C" };
        for (const z of SEASONS) {
          for (const mode of ["day", "night"]) {
            const p = z[mode];
            THEMES.push({
              id: "season-" + z.id + (mode === "night" ? "-night" : ""),
              group: "season",
              season: z.id,
              kind: z.kind,
              mode,
              banner: z.banner || null,
              name: z.name + (mode === "night" ? " \xB7 \uB2E4\uD06C" : ""),
              concept: z.name,
              desc: `\uC2DC\uC98C \uD63C\uD569 \xB7 ${MODE_NAME[mode]}`,
              story: z.story,
              accent: p.accent || z.accent,
              motifs: z.motifs,
              ...build(p)
            });
          }
        }
        for (const mode of ["day", "night"]) {
          THEMES.push({
            ...THEMES.find((t) => t.id === "season-spring" + (mode === "night" ? "-night" : "")),
            id: "season-auto" + (mode === "night" ? "-night" : ""),
            kind: "\uC790\uB3D9",
            mode,
            name: "\uACC4\uC808 \uB530\uB77C \uC790\uB3D9" + (mode === "night" ? " \xB7 \uB2E4\uD06C" : ""),
            concept: "\uACC4\uC808 \uB530\uB77C \uC790\uB3D9",
            desc: `\uC2DC\uC98C \uD63C\uD569 \xB7 ${MODE_NAME[mode]}`,
            story: "\uB0A0\uC9DC\uC5D0 \uB9DE\uCDB0 \uBD04\xB7\uC5EC\uB984\xB7\uAC00\uC744\xB7\uACA8\uC6B8\xB7\uD560\uB85C\uC708\xB7\uD06C\uB9AC\uC2A4\uB9C8\uC2A4\xB7\uC0C8\uD574\xB7\uC124\uB0A0\xB7\uCD94\uC11D\uC73C\uB85C \uC800\uC808\uB85C \uBC14\uB00C\uC5B4\uC694",
            auto: true
          });
        }
        const OUTFITS = ["spring", "summer", "autumn", "winter", "halloween", "christmas"];
        const OUTFIT_STORY = { spring: "\uBC9A\uAF43 \uC544\uB798 \uB3C4\uC2DC\uB77D \uC18C\uD48D", summer: "\uC120\uAE00\uB77C\uC2A4 \uB07C\uACE0 \uBC14\uB2E4\uB85C!", autumn: "\uBCA0\uB808\uBAA8 \uC4F0\uACE0 \uB2E8\uD48D\uAE38 \uC0B0\uCC45", winter: "\uBAA9\uB3C4\uB9AC \uB450\uB974\uACE0 \uCF54\uCF54\uC544 \uD55C \uC794", halloween: "\uB9C8\uB140 \uBAA8\uC790 \uC4F0\uACE0 \uD2B8\uB9AD \uC624\uC5B4 \uD2B8\uB9BF!", christmas: "\uC0B0\uD0C0 \uBAA8\uC790\uC640 \uC120\uBB3C \uC0C1\uC790" };
        const OUTFIT_NAME = { spring: "\uBD04 \uC18C\uD48D", summer: "\uC5EC\uB984 \uBC14\uCE89\uC2A4", autumn: "\uAC00\uC744 \uB098\uB4E4\uC774", winter: "\uACA8\uC6B8 \uB208\uAF43", halloween: "\uD560\uB85C\uC708", christmas: "\uD06C\uB9AC\uC2A4\uB9C8\uC2A4" };
        const CONCEPTS = ["base", "auto", ...OUTFITS];
        for (const c of LINA) {
          for (const o of OUTFITS) {
            const z = SEASONS.find((x) => x.id === o);
            for (const mode of ["day", "night"]) {
              const sp = z[mode], cp = c[mode];
              const p = { ...sp, bg: mix(sp.bg, cp.bg, 0.35), bg2: sp.bg2 && mix(sp.bg2, cp.bg2 || cp.bg, 0.35), panel: mix(sp.panel, cp.panel, 0.35) };
              THEMES.push({
                id: `lina-${c.char}-${o}-${mode}`,
                group: "linaverse",
                char: c.char,
                mode,
                ck: o,
                outfit: o,
                name: `${OUTFIT_NAME[o]}` + (mode === "night" ? " \xB7 \uB2E4\uD06C" : ""),
                concept: OUTFIT_NAME[o],
                story: OUTFIT_STORY[o],
                desc: `${CHAR_NAME[c.char]} \xB7 ${MODE_NAME[mode]}`,
                accent: sp.accent || z.accent,
                motifs: z.motifs,
                ...build(p)
              });
            }
          }
          for (const mode of ["day", "night"]) {
            THEMES.push({
              ...THEMES.find((t) => t.id === `lina-${c.char}-autumn-${mode}`),
              id: `lina-${c.char}-auto-${mode}`,
              ck: "auto",
              outfit: null,
              auto: true,
              name: "\uACC4\uC808 \uC637 \uC790\uB3D9" + (mode === "night" ? " \xB7 \uB2E4\uD06C" : ""),
              concept: "\uACC4\uC808 \uC637 \uC790\uB3D9",
              story: `\uB0A0\uC9DC\uC5D0 \uB9DE\uCDB0 ${CHAR_NAME[c.char]}\uAC00 \uACC4\uC808 \uC637\uC73C\uB85C \uAC08\uC544\uC785\uC5B4\uC694`,
              desc: `${CHAR_NAME[c.char]} \xB7 ${MODE_NAME[mode]}`
            });
          }
        }
        function L() {
          return typeof window !== "undefined" && window.Lunar || (typeof __require === "function" ? require_lunar() : null);
        }
        function seasonKey(date) {
          const d = date || /* @__PURE__ */ new Date(), y = d.getFullYear(), m2 = d.getMonth() + 1, day = d.getDate();
          const near = (s, k) => {
            if (!s) return false;
            const t = /* @__PURE__ */ new Date(s + "T00:00:00");
            return Math.abs((new Date(y, m2 - 1, day) - t) / 864e5) <= k;
          };
          const lu = L();
          if (m2 === 1 && day <= 3) return "newyear";
          if (lu && near(lu.seollal(y), 2)) return "seollal";
          if (lu && near(lu.chuseok(y), 2)) return "chuseok";
          if (m2 === 10 && day >= 20) return "halloween";
          if (m2 === 12 && day <= 25) return "christmas";
          if (m2 === 12) return "winter";
          if (m2 >= 3 && m2 <= 5) return "spring";
          if (m2 >= 6 && m2 <= 8) return "summer";
          if (m2 >= 9 && m2 <= 11) return "autumn";
          return "winter";
        }
        const outfitOf = (k) => ({ newyear: "winter", seollal: "winter", chuseok: "autumn" })[k] || k;
        const bannerOf = (k) => ["newyear", "seollal", "chuseok"].includes(k) ? k : null;
        const byId = new Map(THEMES.map((t) => [t.id, t]));
        const GROUPS = [["light", "\uAE30\uBCF8 \uB77C\uC774\uD2B8"], ["dark", "\uAE30\uBCF8 \uB2E4\uD06C"], ["linaverse", "12\uC9C0\uC2E0 \uCE90\uB9AD\uD130"], ["season", "\uC2DC\uC98C \uD63C\uD569 \uCEEC\uB809\uC158"]];
        const PREMIUM_GROUPS = ["linaverse", "season"];
        const FREE_SHAPES = ["square", "soft"];
        const PREMIUM_SHAPES = ["shade", "block", "tile", "notebook", "stamp", "cozy", "puffy", "bubble", "glass", "candy"];
        const isPremium = (id) => {
          const t = byId.get(id);
          return !!(t && PREMIUM_GROUPS.includes(t.group));
        };
        const PLAN = "preview";
        const canUse = (_id) => PLAN === "preview" || PLAN === "premium";
        THEMES.forEach((t) => {
          t.premium = PREMIUM_GROUPS.includes(t.group);
        });
        function actual(id, date) {
          const t = byId.get(id);
          if (t && t.auto) {
            const k = seasonKey(date), n = t.mode === "night";
            if (t.char) return byId.get(`lina-${t.char}-${outfitOf(k)}-${t.mode}`) || t;
            return byId.get("season-" + k + (n ? "-night" : "")) || t;
          }
          return t || null;
        }
        const TYPO_PRESETS = {
          bigdate: { name: "\uD070 \uB0A0\uC9DC \xB7 \uC587\uAC8C", desc: "\uB0A0\uC9DC \uC22B\uC790\uB294 \uD06C\uACE0 \uAC00\uB298\uAC8C, \uC77C\uC815\uC740 \uC791\uACE0 \uB2E8\uC815\uD558\uAC8C", date: 1.55, dateWeight: 300, chip: 0.8, list: 0.95, clock: 3.6, icon: 1, weekday: 0.82, title: 1.7 },
          balanced: { name: "\uADE0\uD615", desc: "\uCC98\uC74C \uC4F0\uAE30 \uBB34\uB09C\uD55C \uAE30\uBCF8 \uD06C\uAE30", date: 1.1, dateWeight: 500, chip: 0.82, list: 0.98, clock: 3, icon: 1, weekday: 0.82, title: 1.6 },
          clear: { name: "\uB610\uB837\uD558\uAC8C", desc: "\uB0A0\uC9DC\xB7\uC77C\uC815 \uBAA8\uB450 \uAD75\uACE0 \uD06C\uAC8C", date: 1.4, dateWeight: 700, chip: 0.95, list: 1.1, clock: 3.2, icon: 1.15, weekday: 0.95, title: 1.9 },
          minimal: { name: "\uBBF8\uB2C8\uBA40", desc: "\uC791\uACE0 \uAC00\uBCCD\uAC8C, \uC815\uBCF4\uB97C \uB9CE\uC774", date: 0.95, dateWeight: 400, chip: 0.76, list: 0.9, clock: 2.6, icon: 0.9, weekday: 0.76, title: 1.4 },
          large: { name: "\uD06C\uAC8C \uBCF4\uAE30", desc: "\uBA40\uB9AC\uC11C\uB3C4 \uC798 \uBCF4\uC774\uAC8C \uC804\uCCB4\uB97C \uD06C\uAC8C", date: 1.7, dateWeight: 500, chip: 1, list: 1.15, clock: 4.2, icon: 1.25, weekday: 1, title: 2.1 }
        };
        const TYPO_KEYS = ["date", "dateWeight", "chip", "list", "clock", "icon", "weekday", "title"];
        function typo(a) {
          const t = a && a.typo || {};
          const base = TYPO_PRESETS[t.preset] || TYPO_PRESETS.bigdate;
          const out = { ...base };
          if (t.preset === "custom") TYPO_KEYS.forEach((k) => {
            if (t[k] != null && !isNaN(t[k])) out[k] = Number(t[k]);
          });
          return out;
        }
        function resolve(a) {
          a = a || {};
          const t = actual(a.theme) || byId.get("midnight");
          const vars = { ...t.vars };
          let dark = t.dark;
          const bgC = isHex(a.bgColor) ? "#" + String(a.bgColor).replace("#", "") : null;
          const txC = isHex(a.textColor) ? "#" + String(a.textColor).replace("#", "") : null;
          if (bgC || txC) {
            const bg = bgC || vars["--bg-solid"];
            const text = txC || (bgC ? lum(bgC) < 0.45 ? "#ECEAE6" : "#24211C" : vars["--text"]);
            const b = build({ bg, text, panel: bgC ? void 0 : vars["--panel-solid"], pop: bgC ? void 0 : vars["--popover"], sun: bgC ? void 0 : vars["--sun"], sat: bgC ? void 0 : vars["--sat"] });
            Object.assign(vars, b.vars);
            if (!bgC) vars["--bg"] = t.vars["--bg"];
            dark = b.dark;
          }
          return { theme: t, vars, dark };
        }
        function patternFor(t, opacity) {
          if (!t || !t.motifs) return "";
          const m2 = t.motifs.map((k) => MOTIF[k]).filter(Boolean);
          const inner = (svg, x, y, s, r) => svg.replace('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">', `<g transform="translate(${x} ${y}) rotate(${r} ${s / 2} ${s / 2}) scale(${s / 24})">`).replace("</svg>", "</g>");
          const tile = `<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180"><g opacity="${opacity || 0.08}">${inner(m2[0], 18, 20, 26, -12)}${inner(m2[1] || m2[0], 110, 40, 22, 14)}${inner(m2[2] || m2[0], 58, 108, 24, 8)}${inner(m2[0], 140, 128, 18, -20)}</g></svg>`;
          return svgUrl(tile);
        }
        const api = { PREMIUM_GROUPS, FREE_SHAPES, PREMIUM_SHAPES, PLAN, isPremium, canUse, THEMES, GROUPS, LINA, SEASONS, CONCEPTS, OUTFITS, OUTFIT_NAME, CHAR_NAME, MOTIF, byId: (id) => byId.get(id) || null, actual, resolve, patternFor, svgUrl, mix, lum, seasonKey, outfitOf, bannerOf, TYPO_PRESETS, TYPO_KEYS, typo };
        if (typeof module !== "undefined" && module.exports) module.exports = api;
        if (typeof window !== "undefined") root.DeskThemes = api;
      })(typeof window !== "undefined" ? window : globalThis);
    }
  });

  // desktop/renderer/chars.js
  var require_chars = __commonJS({
    "desktop/renderer/chars.js"(exports, module) {
      init_globals();
      var LIST = [
        { id: "rat", name: "\uC950" },
        { id: "ox", name: "\uC18C" },
        { id: "tiger", name: "\uD638\uB791\uC774" },
        { id: "rabbit", name: "\uD1A0\uB07C" },
        { id: "dragon", name: "\uC6A9" },
        { id: "snake", name: "\uBC40" },
        { id: "horse", name: "\uB9D0" },
        { id: "goat", name: "\uC591" },
        { id: "monkey", name: "\uC6D0\uC22D\uC774" },
        { id: "rooster", name: "\uB2ED" },
        { id: "dog", name: "\uAC1C" },
        { id: "pig", name: "\uB3FC\uC9C0" }
      ];
      var PACK = "characters/linaverse-12/";
      var hourIndex = (h) => Math.floor((h + 1) % 24 / 2);
      var ofHour = (h) => LIST[hourIndex(h)];
      var hourRange = (h) => {
        const i = hourIndex(h), s = (i * 2 + 23) % 24, e = (s + 2) % 24;
        const p = (n) => String(n).padStart(2, "0");
        return `${p(s)}~${p(e)}\uC2DC`;
      };
      var ofYear = (y) => LIST[((y - 4) % 12 + 12) % 12];
      var byId = (id) => LIST.find((c) => c.id === id) || null;
      var img = (id) => PACK + id + ".png";
      var josa = (word, a, b) => {
        const c = String(word).charCodeAt(String(word).length - 1);
        return word + (c >= 44032 && c <= 55203 && (c - 44032) % 28 ? a : b);
      };
      var DEFAULT_MAP = { work: "ox", meet: "horse", personal: "pig", anniv: "dragon", bday: "rabbit" };
      var SEASON_ART = ["spring", "summer", "autumn", "winter", "halloween", "christmas"];
      var packed = () => typeof window !== "undefined" && window.LinaPack || null;
      function seasonImg(id, season, v) {
        if (!(season && SEASON_ART.includes(season))) return img(id);
        const key = id + (season === "summer" && v === 2 ? "-2" : ""), P = packed();
        return P && P.seasons[season] && P.seasons[season][key] || PACK + "seasons/" + season + "/" + key + ".webp";
      }
      function bannerImg(id, kind) {
        const P = packed();
        return P && P.banners[kind] && P.banners[kind][id] || PACK + "banners/" + kind + "/" + id + ".webp";
      }
      var dayOfYear = (d) => Math.floor((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(d.getFullYear(), 0, 0)) / 864e5);
      function dailyPet(date, fixed) {
        if (fixed && fixed !== "daily" && byId(fixed)) return fixed;
        return LIST[dayOfYear(date || /* @__PURE__ */ new Date()) % 12].id;
      }
      function hash3(str) {
        let h = 2166136261;
        for (let i = 0; i < str.length; i++) {
          h ^= str.charCodeAt(i);
          h = Math.imul(h, 16777619);
        }
        return h >>> 0;
      }
      function mixPet(date, slot, salt) {
        const d = date || /* @__PURE__ */ new Date();
        return LIST[hash3(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}|${slot || ""}|${salt || 0}`) % 12].id;
      }
      function petFor(date, mode, slot, salt) {
        if (mode && mode !== "daily" && mode !== "mix" && byId(mode)) return mode;
        if (mode === "daily") return dailyPet(date);
        return mixPet(date, slot, salt);
      }
      function lookFor(a, ch, date, force, opt) {
        opt = opt || {};
        const T = typeof window !== "undefined" && window.DeskThemes || (typeof __require === "function" ? require_themes() : null);
        if (!T) return null;
        const d = date || /* @__PURE__ */ new Date(), key = T.seasonKey(d), t = T.actual(a && a.theme, d);
        ch = ch || {};
        let id = force || null, season = null;
        let corner = null;
        if (t && t.char) {
          id = id || t.char;
          season = t.outfit || null;
        } else if (t && t.season) {
          const mode = ch.seasonPet || "mix";
          id = id || petFor(d, mode, "buddy", opt.salt);
          season = T.outfitOf(t.season);
          if (mode === "mix") {
            let c2 = petFor(d, mode, "corner", opt.salt), k = 1;
            while (c2 === id && k < 12) c2 = petFor(d, mode, "corner" + k++, opt.salt);
            corner = c2;
          }
        } else if (force) {
          if (ch.outfit !== false) season = T.outfitOf(key);
        } else return null;
        const v = dayOfYear(d) % 2 ? 2 : 1;
        const bk = t && t.banner || (ch.greeting !== false && (t && (t.char || t.season)) ? T.bannerOf(key) : null);
        if (bk) {
          const other = corner || id;
          return {
            id,
            src: bannerImg(id, bk),
            season,
            v,
            holiday: bk,
            banner: null,
            corner: { id: other, src: t && t.banner ? bannerImg(other, bk) : seasonImg(other, season, v) }
          };
        }
        return {
          id,
          src: seasonImg(id, season, v),
          season,
          v,
          banner: null,
          corner: corner ? { id: corner, src: seasonImg(corner, season, v === 2 ? 1 : 2) } : null
        };
      }
      var api = { LIST, PACK, hourIndex, ofHour, hourRange, ofYear, byId, img, josa, DEFAULT_MAP, SEASON_ART, seasonImg, bannerImg, dailyPet, mixPet, petFor, lookFor };
      if (typeof module !== "undefined" && module.exports) module.exports = api;
      if (typeof window !== "undefined") window.Chars = api;
    }
  });

  // mobile/shim/os.js
  var os_exports = {};
  __export(os_exports, {
    EOL: () => EOL,
    default: () => os_default,
    homedir: () => homedir,
    platform: () => platform,
    release: () => release,
    tmpdir: () => tmpdir
  });
  var ua, m, release, homedir, tmpdir, platform, EOL, os_default;
  var init_os = __esm({
    "mobile/shim/os.js"() {
      init_globals();
      ua = navigator.userAgent || "";
      m = ua.match(/Android ([\d.]+)/);
      release = () => m ? "Android " + m[1] : "web";
      homedir = () => "/data";
      tmpdir = () => "/tmp";
      platform = () => "android";
      EOL = "\n";
      os_default = { release, homedir, tmpdir, platform, EOL };
    }
  });

  // desktop/app-main.js
  var require_app_main = __commonJS({
    "desktop/app-main.js"() {
      init_globals();
      var { app: app2, BrowserWindow: BrowserWindow2, ipcMain: ipcMain2, Tray: Tray2, Menu: Menu2, globalShortcut: globalShortcut2, screen: screen2, nativeImage: nativeImage2, shell: shell2, powerMonitor: powerMonitor2, dialog: dialog2, Notification: Notification3 } = (init_electron(), __toCommonJS(electron_exports));
      var path = require_path_browserify();
      var VERSION = require_package().version;
      if (!app2.requestSingleInstanceLock()) {
        app2.quit();
        process.exit(0);
      }
      app2.setAppUserModelId("com.deskcal.app");
      var store4 = require_store();
      var sync = require_sync();
      var AI = require_ai();
      var Updater = (init_updater(), __toCommonJS(updater_exports));
      var desktop = (init_empty(), __toCommonJS(empty_exports));
      var reminders2 = require_reminders();
      var cloud = require_cloud();
      var Chars = require_chars();
      var TZ = require_tz();
      var Themes = require_themes();
      var ASSET = (n) => path.join(".", "assets", n);
      var PAGE = (n) => path.join(".", "renderer", n);
      var PRELOAD = path.join(".", "preload.js");
      var settings;
      var calWin = null;
      var editorWin = null;
      var settingsWin = null;
      var popupWin = null;
      var tray = null;
      var editing = false;
      var autoEdit = false;
      var lastSyncAt = 0;
      var pinned = false;
      var cache = { events: [], errors: [], updated: null, syncing: false };
      var popupQueue = [];
      var syncTimer = null;
      var ctx = {
        decrypt: store4.decrypt,
        getLocal: store4.getLocalEvents,
        saveLocal: store4.saveLocalEvents
      };
      var appearancePreview = null;
      var appearance = () => appearancePreview || settings.appearance;
      function broadcastAppearance() {
        setTimeout(refreshStickies, 50);
        const a = appearance();
        BrowserWindow2.getAllWindows().forEach((w) => {
          if (!w.isDestroyed()) w.webContents.send("appearance", a);
        });
        pushState();
      }
      var bgFor = () => {
        try {
          return Themes.resolve(appearance()).vars["--bg-solid"];
        } catch {
          return "#141414";
        }
      };
      function targetDisplay() {
        const all = screen2.getAllDisplays();
        return all.find((d) => d.id === settings.displayId) || screen2.getPrimaryDisplay();
      }
      function physicalRect(bounds) {
        const toPx = (r2) => false ? screen2.dipToScreenRect(null, r2) : r2;
        const all = screen2.getAllDisplays().map((d) => toPx(d.bounds));
        const minX = Math.min(...all.map((r2) => r2.x));
        const minY = Math.min(...all.map((r2) => r2.y));
        const r = toPx(bounds);
        return { x: r.x - minX, y: r.y - minY, width: r.width, height: r.height };
      }
      var physicalRectFor = (display2) => physicalRect(display2.bounds);
      var widgetUnder = () => settings.mode === "widget" && !!settings.widget.underIcons;
      function createCalendarWindow() {
        if (calWin && !calWin.isDestroyed()) {
          calWin.removeAllListeners("closed");
          calWin.destroy();
        }
        editing = false;
        pinned = false;
        const d = targetDisplay();
        const isWidget = settings.mode === "widget";
        const w = settings.widget;
        const fitW = w.x == null ? Math.min(w.width, d.workArea.width - 48) : w.width;
        const fitH = w.y == null ? Math.min(w.height, d.workArea.height - 48) : w.height;
        const bounds = isWidget ? { x: w.x ?? d.workArea.x + d.workArea.width - fitW - 24, y: w.y ?? d.workArea.y + 24, width: fitW, height: fitH } : d.bounds;
        calWin = new BrowserWindow2({
          ...bounds,
          frame: false,
          show: false,
          skipTaskbar: true,
          resizable: isWidget && !w.locked,
          movable: !isWidget || !w.locked,
          minimizable: false,
          maximizable: false,
          fullscreenable: false,
          transparent: isWidget && !w.underIcons,
          // 아이콘 아래 층에서는 투명 창이 깨질 수 있어 불투명으로
          backgroundColor: isWidget && !w.underIcons ? "#00000000" : bgFor(),
          hasShadow: false,
          title: "Total Calendar",
          webPreferences: { preload: PRELOAD, backgroundThrottling: false }
        });
        calWin.loadFile(PAGE("calendar.html"));
        calWin.once("ready-to-show", () => {
          applyOpacity();
          if (isWidget && w.underIcons) {
            calWin.showInactive();
            attachWidgetToDesktop();
          } else if (isWidget) {
            calWin.showInactive();
            desktop.sendToBottom(calWin);
          } else {
            calWin.showInactive();
            attachToDesktop();
          }
          pushState();
        });
        calWin.on("blur", () => {
          if (editing) {
            maybeReturn();
            return;
          }
          if (!pinned) setTimeout(() => calWin && !calWin.isDestroyed() && desktop.sendToBottom(calWin), 50);
        });
        if (isWidget) {
          let t = null;
          const save = () => {
            clearTimeout(t);
            t = setTimeout(() => {
              if (!calWin || calWin.isDestroyed() || settings.minimal || pinned) return;
              const b = calWin.getBounds();
              settings.widget = { ...settings.widget, x: b.x, y: b.y, width: b.width, height: b.height };
              store4.saveSettings(settings);
            }, 400);
          };
          calWin.on("moved", save);
          calWin.on("resized", save);
        }
        calWin.on("closed", () => {
          calWin = null;
        });
      }
      function attachToDesktop() {
        if (!calWin || calWin.isDestroyed() || settings.mode !== "wallpaper") return;
        const d = targetDisplay();
        pinned = desktop.pinToDesktop(calWin, physicalRectFor(d));
        if (!pinned) {
          calWin.setBounds(d.bounds);
          desktop.sendToBottom(calWin);
        }
      }
      function attachWidgetToDesktop() {
        if (!calWin || calWin.isDestroyed() || !widgetUnder()) return;
        pinned = desktop.pinToDesktop(calWin, physicalRect(calWin.getBounds()));
        if (!pinned) desktop.sendToBottom(calWin);
      }
      function setEditing(on, opts = {}) {
        if (!calWin || calWin.isDestroyed()) return;
        if (on && editing) {
          calWin.show();
          calWin.focus();
          return;
        }
        if (!on && !editing && settings.mode !== "widget") return;
        if (widgetUnder()) {
          editing = on;
          const w = settings.widget;
          if (on) {
            autoEdit = !!opts.auto;
            if (pinned) desktop.unpin(calWin);
            pinned = false;
            if (w.x != null && !settings.minimal) calWin.setBounds({ x: w.x, y: w.y, width: w.width, height: w.height });
            calWin.setMovable(!w.locked);
            calWin.setResizable(!w.locked);
            calWin.setAlwaysOnTop(true, "floating");
            calWin.show();
            calWin.focus();
          } else {
            autoEdit = false;
            const b = calWin.getBounds();
            if (!settings.minimal) settings.widget = { ...settings.widget, x: b.x, y: b.y, width: b.width, height: b.height };
            store4.saveSettings(settings);
            calWin.setAlwaysOnTop(false);
            attachWidgetToDesktop();
          }
          pushState();
          return;
        }
        if (settings.mode === "widget") {
          if (on) {
            calWin.show();
            calWin.focus();
          } else desktop.sendToBottom(calWin);
          editing = false;
          autoEdit = false;
          return;
        }
        editing = on;
        if (on) {
          autoEdit = !!opts.auto;
          if (pinned) desktop.unpin(calWin);
          pinned = false;
          calWin.setBounds(targetDisplay().workArea);
          calWin.setAlwaysOnTop(true, "floating");
          calWin.show();
          calWin.focus();
        } else {
          autoEdit = false;
          calWin.setAlwaysOnTop(false);
          attachToDesktop();
        }
        pushState();
      }
      var lastAvail = false;
      function onUpdateState(s) {
        BrowserWindow2.getAllWindows().forEach((w) => {
          if (!w.isDestroyed()) w.webContents.send("update:state", s);
        });
        if (s.available !== lastAvail) {
          lastAvail = s.available;
          buildTray();
          pushState();
        }
      }
      ipcMain2.handle("update:state", () => Updater.getState());
      function onCloudState(s) {
        BrowserWindow2.getAllWindows().forEach((w) => {
          if (!w.isDestroyed()) w.webContents.send("account:state", s);
        });
      }
      function onRemoteChange(ch) {
        if (ch.settings && typeof ch.settings === "object" || Array.isArray(ch.sources)) {
          let next = { ...settings };
          if (ch.settings && typeof ch.settings === "object") {
            next = { ...next, ...ch.settings };
            if (ch.settings.appearance) next.appearance = { ...settings.appearance, ...ch.settings.appearance, wallpaperAlign: settings.appearance.wallpaperAlign, wallpaperWidth: settings.appearance.wallpaperWidth };
          }
          if (Array.isArray(ch.sources)) {
            const mine = settings.sources.filter((x) => x.type === "local");
            next.sources = [...mine, ...ch.sources.map((x) => {
              const old = settings.sources.find((o) => o.id === x.id);
              return { ...x, password: old ? old.password : "" };
            })];
          }
          store4.quiet(() => applySettings(next));
        }
        if (ch.events || ch.remind || ch.cats || ch.birth) runSync(true);
        if (ch.notes || ch.stickers) pushState();
        if (ch.stickies) {
          try {
            refreshStickies();
            openAllStickies();
          } catch {
          }
        }
      }
      ipcMain2.handle("account:get", () => cloud.getState());
      ipcMain2.handle("account:signin", (_e, { email, pw, create }) => cloud.signIn(email, pw, create));
      ipcMain2.handle("account:reset", (_e, email) => cloud.resetPassword(email));
      ipcMain2.handle("account:signout", () => {
        cloud.signOut();
        buildTray();
        return cloud.getState();
      });
      ipcMain2.handle("account:sync", () => cloud.sync());
      var SUPPORT_EMAIL = "flskalsn@gmail.com";
      function diagInfo() {
        const os = (init_os(), __toCommonJS(os_exports));
        const d = screen2.getPrimaryDisplay();
        const kinds = (settings.sources || []).filter((s) => s.enabled !== false).map((s) => s.type === "google" ? "Google" : s.type === "outlook" || s.type === "msgraph" ? "Outlook" : s.type === "caldav" ? /naver/i.test(String(s.url || "") + s.name) ? "Naver" : "CalDAV" : s.type === "ics" ? "iCal" : s.type === "local" ? "\uB0B4 PC" : s.type);
        return [
          `\uC571 \uBC84\uC804: ${VERSION}`,
          `Windows: ${os.release()} (${"arm64"})`,
          `Electron: ${"mobile 2.7.0"}`,
          `\uD654\uBA74: ${d.size.width}x${d.size.height} @${d.scaleFactor}x`,
          `\uBAA8\uB4DC: ${settings.mode}${settings.minimal ? " \xB7 \uBBF8\uB2C8" : ""}`,
          `\uD14C\uB9C8: ${settings.appearance && settings.appearance.theme || settings.theme || "-"}`,
          `\uC5F0\uACB0\uB41C \uCE98\uB9B0\uB354: ${kinds.length ? [...new Set(kinds)].join(", ") : "\uC5C6\uC74C"}`,
          `AI: ${(() => {
            try {
              const st = AI.status(aiSettings());
              return st && st.modelSize ? `\uBAA8\uB378 \uC788\uC74C (${st.model})` : "\uBAA8\uB378 \uC5C6\uC74C";
            } catch {
              return "-";
            }
          })()}`
        ].join("\n");
      }
      function sendReport(kind) {
        const subject = `[Total Calendar] ${kind === "idea" ? "\uC758\uACAC" : "\uBB38\uC81C \uC2E0\uACE0"} (v${VERSION})`;
        const body = (kind === "idea" ? "\u25A0 \uC774\uB7F0 \uAE30\uB2A5\uC774 \uC788\uC73C\uBA74 \uC88B\uACA0\uC5B4\uC694:\n\n\n\u25A0 \uC774\uC720\uB098 \uC4F0\uB294 \uC0C1\uD669:\n\n\n" : "\u25A0 \uC5B4\uB5A4 \uBB38\uC81C\uAC00 \uC788\uC5C8\uB098\uC694?\n\n\n\u25A0 \uC5B4\uB5BB\uAC8C \uD558\uBA74 \uB2E4\uC2DC \uC0DD\uAE30\uB098\uC694? (\uC21C\uC11C\uB300\uB85C)\n1.\n2.\n\n\u25A0 \uD654\uBA74 \uCEA1\uCC98\uAC00 \uC788\uC73C\uBA74 \uBD99\uC5EC \uC8FC\uC138\uC694.\n\n\n") + "---- \uC544\uB798\uB294 \uC790\uB3D9\uC73C\uB85C \uCC44\uC6CC\uC9C4 \uC815\uBCF4\uC608\uC694 (\uC9C0\uC6CC\uB3C4 \uB3FC\uC694) ----\n" + diagInfo();
        const url = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        return shell2.openExternal(url).then(() => true).catch(() => false);
      }
      ipcMain2.handle("app:report", (_e, kind) => sendReport(kind));
      ipcMain2.handle("app:diag", () => {
        const text = diagInfo();
        try {
          (init_electron(), __toCommonJS(electron_exports)).clipboard.writeText(`\uBC1B\uB294 \uC0AC\uB78C: ${SUPPORT_EMAIL}

${text}`);
        } catch {
        }
        return { email: SUPPORT_EMAIL, text };
      });
      ipcMain2.handle("update:check", () => Updater.check());
      app2.on("before-quit", () => {
        try {
          if (settings) store4.saveSettings(settings);
        } catch {
        }
      });
      ipcMain2.handle("update:prepare", async () => {
        if (!app2.isPackaged && true) throw new Error("\uAC1C\uBC1C \uC2E4\uD589\uC5D0\uC11C\uB294 \uC5C5\uB370\uC774\uD2B8\uB97C \uC801\uC6A9\uD560 \uC218 \uC5C6\uC5B4\uC694");
        return Updater.prepare();
      });
      ipcMain2.handle("update:apply", () => {
        if (app2.isPackaged && Updater.getState().phase === "ready") Updater.applyAndRestart(app2);
      });
      async function updateFromTray() {
        openSettings();
        setTimeout(() => {
          if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send("settings:goto", "update");
        }, 700);
      }
      var GREP = { daily: "DAILY", weekly: "WEEKLY", monthly: "MONTHLY", yearly: "YEARLY" };
      var utcZ = (d) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
      function remMinutes(r) {
        const m2 = { minute: 1, hour: 60, day: 1440, week: 10080, month: 43200 }[r.unit] || 0;
        return (Number(r.n) || 0) * m2;
      }
      function exportEvents(inputs, targets) {
        const fs = (init_fs(), __toCommonJS(fs_exports));
        const safe = (t) => String(t || "\uC77C\uC815").replace(/[\\/:*?"<>|\r\n]+/g, " ").trim().slice(0, 40) || "\uC77C\uC815";
        let k = 0;
        for (const input of inputs || []) {
          const ev = { ...sync.normalizeInput(input), uid: `${(init_crypto(), __toCommonJS(crypto_exports)).randomUUID()}@deskcal` };
          const rems = Array.isArray(input.reminders) ? input.reminders.map(remMinutes).filter((m2) => m2 > 0).sort((a, b) => a - b) : null;
          if (targets.outlook) {
            let ics = sync.buildIcs(ev);
            if (rems && rems.length) ics = ics.replace("END:VEVENT", `BEGIN:VALARM\r
ACTION:DISPLAY\r
DESCRIPTION:${ev.title}\r
TRIGGER:-PT${rems[0]}M\r
END:VALARM\r
END:VEVENT`);
            const file = path.join(app2.getPath("temp"), `DeskCal_${Date.now()}_${k}_${safe(ev.title)}.ics`);
            fs.writeFileSync(file, ics, "utf8");
            setTimeout(() => shell2.openPath(file), k * 900);
          }
          if (targets.google) {
            const dates = ev.allDay ? `${ev.start.replace(/-/g, "")}/${ev.end.replace(/-/g, "")}` : `${utcZ(new Date(ev.start))}/${utcZ(new Date(ev.end))}`;
            const q = new URLSearchParams({ action: "TEMPLATE", text: ev.title, dates });
            if (ev.location) q.set("location", ev.location);
            if (ev.notes) q.set("details", ev.notes);
            if (ev.repeat && GREP[ev.repeat] && !ev.lunar) q.set("recur", `RRULE:FREQ=${GREP[ev.repeat]}`);
            setTimeout(() => shell2.openExternal("https://calendar.google.com/calendar/render?" + q.toString()), k * 900 + (targets.outlook ? 400 : 0));
          }
          k++;
        }
        return k;
      }
      var naverSource = () => (settings.sources || []).find((s) => s.type === "caldav" && /naver/i.test(String(s.url || "") + s.name) && !s.holiday);
      async function sendToNaver(inputs, mainSourceId) {
        const src = naverSource();
        if (!src || src.id === mainSourceId) return 0;
        let n = 0;
        for (const input of inputs || []) {
          const { lunar, ...rest } = input;
          const uid = await sync.createEvent(src, { ...rest, categoryName: catName(input.categoryChoice || "auto") }, ctx);
          if (Array.isArray(input.reminders)) setRemind(uid, input.reminders);
          n++;
        }
        if (n) runSync();
        return n;
      }
      ipcMain2.handle("export:send", async (_e, { inputs, targets, sourceId }) => {
        targets = targets || {};
        settings.exportTargets = { outlook: !!targets.outlook, google: !!targets.google, naver: !!targets.naver };
        store4.saveSettings(settings);
        let n = 0;
        if (targets.outlook || targets.google) n += exportEvents(inputs, targets);
        if (targets.naver) n += await sendToNaver(inputs, sourceId);
        return n;
      });
      ipcMain2.handle("source:test", async (_e, s) => {
        try {
          const old = (settings.sources || []).find((o) => o.id === s.id) || {};
          const pw = s.password || (old.password ? store4.decrypt(old.password) : "");
          if (!s.username || !pw) return { ok: false, error: "\uC544\uC774\uB514\uC640 \uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uBE44\uBC00\uBC88\uD638\uB97C \uB123\uC5B4 \uC8FC\uC138\uC694" };
          const names = await sync.testSource({ ...old, ...s }, pw);
          return { ok: true, calendars: names };
        } catch (e) {
          const m2 = String(e && e.message || e);
          return { ok: false, error: /fetch failed|ENOTFOUND|ECONN|ETIMEDOUT|ERR_/i.test(m2) ? `\uC11C\uBC84\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694 (\uC778\uD130\uB137 \uC5F0\uACB0\uC774\uB098 \uD68C\uC0AC \uBC29\uD654\uBCBD \uD655\uC778) \xB7 \uC790\uC138\uD788: ${m2.slice(0, 300)}` : m2 };
        }
      });
      ipcMain2.handle("export:get", () => ({ outlook: false, google: false, naver: false, ...settings.exportTargets || {}, naverReady: !!naverSource(), naverId: (naverSource() || {}).id || "" }));
      var aiWin = null;
      function openAI(text) {
        if (aiWin && !aiWin.isDestroyed()) {
          aiWin.show();
          aiWin.focus();
          if (text) aiWin.webContents.send("ai:text", text);
          return;
        }
        const d = screen2.getDisplayNearestPoint(screen2.getCursorScreenPoint());
        const W = 620, H = 820;
        aiWin = new BrowserWindow2({
          width: W,
          height: H,
          minWidth: 520,
          minHeight: 600,
          x: Math.round(d.workArea.x + (d.workArea.width - W) / 2),
          y: Math.round(d.workArea.y + (d.workArea.height - H) / 2),
          frame: false,
          resizable: true,
          alwaysOnTop: true,
          skipTaskbar: false,
          show: false,
          backgroundColor: bgFor(),
          title: "AI\uB85C \uC77C\uC815 \uB4F1\uB85D",
          webPreferences: { preload: PRELOAD }
        });
        aiWin.__text = text || "";
        aiWin.loadFile(PAGE("ai.html"));
        aiWin.once("ready-to-show", () => {
          aiWin.show();
          aiWin.focus();
        });
        aiWin.on("closed", () => {
          aiWin = null;
          if (autoEdit && calWin && !calWin.isDestroyed() && !calWin.isFocused()) maybeReturn();
        });
      }
      var aiSettings = () => settings.ai || {};
      var aiSend = (s) => {
        if (aiWin && !aiWin.isDestroyed()) aiWin.webContents.send("ai:progress", s);
      };
      ipcMain2.handle("ai:open", (_e, text) => openAI(text));
      ipcMain2.handle("ai:init", (e) => {
        const win = BrowserWindow2.fromWebContents(e.sender);
        return { text: win && win.__text || "", sources: publicSources(), categories: settings.categories || [], lastWriteSource: settings.lastWriteSource, status: AI.status(aiSettings()) };
      });
      ipcMain2.handle("ai:status", () => AI.status(aiSettings()));
      ipcMain2.handle("ai:setModel", (_e, id) => {
        settings.ai = { ...aiSettings(), model: id, modelPath: "" };
        store4.saveSettings(settings);
        AI.unload();
        return AI.status(aiSettings());
      });
      ipcMain2.handle("ai:download", async () => {
        await AI.download(aiSettings().model || "qwen3-4b");
        return AI.status(aiSettings());
      });
      ipcMain2.handle("ai:cancel", () => AI.cancelDownload());
      ipcMain2.handle("ai:delete", () => {
        AI.deleteModels();
        settings.ai = { ...aiSettings(), modelPath: "" };
        store4.saveSettings(settings);
        return AI.status(aiSettings());
      });
      ipcMain2.handle("ai:pickFile", async (e) => {
        const r = await dialog2.showOpenDialog(BrowserWindow2.fromWebContents(e.sender), { title: "AI \uBAA8\uB378 \uD30C\uC77C (.gguf) \uACE0\uB974\uAE30", filters: [{ name: "GGUF \uBAA8\uB378", extensions: ["gguf"] }], properties: ["openFile"] });
        if (r.canceled || !r.filePaths[0]) return AI.status(aiSettings());
        settings.ai = { ...aiSettings(), modelPath: r.filePaths[0] };
        store4.saveSettings(settings);
        AI.unload();
        return AI.status(aiSettings());
      });
      ipcMain2.handle("ai:analyze", (_e, text) => AI.analyze(text, aiSettings()));
      ipcMain2.handle("ai:saveMany", async (_e, { sourceId, items }) => {
        const target = findSource(sourceId);
        if (!target) throw new Error("\uCE98\uB9B0\uB354\uB97C \uC120\uD0DD\uD574 \uC8FC\uC138\uC694");
        let n = 0;
        for (const input of items || []) {
          const choice = input.categoryChoice || "auto";
          const uid = await sync.createEvent(target, { ...input, categoryName: catName(choice) }, ctx);
          setCategory(uid, choice);
          if (Array.isArray(input.reminders)) setRemind(uid, input.reminders);
          n++;
        }
        settings.lastWriteSource = sourceId;
        store4.saveSettings(settings);
        await runSync();
        return n;
      });
      var curOpacity = () => Math.min(1, Math.max(0.2, settings.opacity ?? (settings.mode === "widget" ? settings.widget.opacity ?? 1 : 1)));
      var opacityByCss = () => settings.mode === "widget" && !settings.widget.underIcons;
      function applyOpacity() {
        if (!calWin || calWin.isDestroyed()) return;
        try {
          calWin.setOpacity(opacityByCss() ? 1 : curOpacity());
        } catch {
        }
      }
      ipcMain2.handle("opacity:set", (_e, v, done) => {
        settings.opacity = Math.min(1, Math.max(0.2, Number(v) || 1));
        applyOpacity();
        if (done) {
          store4.saveSettings(settings);
          pushState();
        }
      });
      var stickyWins = /* @__PURE__ */ new Map();
      var STICKY_COLORS = [["yellow", "\uB178\uB791"], ["pink", "\uBD84\uD64D"], ["mint", "\uBBFC\uD2B8"], ["sky", "\uD558\uB298"], ["lavender", "\uB77C\uBCA4\uB354"], ["peach", "\uBCF5\uC22D\uC544"], ["white", "\uD770\uC0C9"], ["ink", "\uBA39\uC0C9"]];
      var STICKY_MODES = [["basic", "\uAE30\uBCF8 \uBA54\uBAA8\uC7A5"], ["lined", "\uC904\uB178\uD2B8"], ["check", "\uCCB4\uD06C\uB9AC\uC2A4\uD2B8 (\uD560 \uC77C)"], ["char", "\u2726 \uCE90\uB9AD\uD130 \uBA54\uBAA8\uC7A5 (\uBB34\uB8CC \uCCB4\uD5D8 \uC911!)"]];
      function stickyById(id) {
        return store4.getStickies().find((n) => n.id === id);
      }
      function updateSticky(id, patch) {
        const list = store4.getStickies();
        const n = list.find((x) => x.id === id);
        if (!n) return null;
        Object.assign(n, patch, { updated: Date.now() });
        store4.saveStickies(list);
        return n;
      }
      function stickyPayload(n) {
        return { note: n, appearance: appearance(), characters: settings.characters };
      }
      var stickyPinMode = () => false;
      function stickyRect(id) {
        const n = stickyById(id);
        return n ? { x: n.x, y: n.y, width: n.w || 280, height: n.h || 260 } : null;
      }
      function pinSticky(win) {
        if (!win || win.isDestroyed()) return;
        win.__editing = false;
        win.webContents.send("sticky:edit", false);
        if (!stickyPinMode()) {
          win.showInactive();
          desktop.sendToBottom(win);
          return;
        }
        const r = stickyRect(win.__sticky);
        if (!r) return;
        win.setAlwaysOnTop(false);
        win.__pinned = desktop.pinToDesktop(win, physicalRect(r));
        if (!win.__pinned) {
          win.showInactive();
          desktop.sendToBottom(win);
        }
      }
      function editSticky(win, focus = true) {
        if (!win || win.isDestroyed()) return;
        if (win.__pinned) {
          desktop.unpin(win);
          win.__pinned = false;
          const r = stickyRect(win.__sticky);
          if (r) win.setBounds(r);
        }
        win.__editing = true;
        win.setAlwaysOnTop(true, "floating");
        win.show();
        if (focus) win.focus();
        win.webContents.send("sticky:edit", true);
      }
      function stickyAt(dip) {
        for (const [id, w] of stickyWins) {
          if (w.isDestroyed() || w.__editing) continue;
          const r = stickyRect(id);
          if (r && dip.x >= r.x && dip.y >= r.y && dip.x < r.x + r.width && dip.y < r.y + r.height) return w;
        }
        return null;
      }
      function openSticky(n, edit) {
        if (stickyWins.has(n.id)) {
          const w = stickyWins.get(n.id);
          if (!w.isDestroyed()) {
            edit ? editSticky(w) : pinSticky(w);
            return w;
          }
        }
        const wa = targetDisplay().workArea;
        const solid = stickyPinMode();
        if (n.x == null) {
          n.x = Math.round(wa.x + wa.width / 2 - 140);
          n.y = Math.round(wa.y + wa.height / 3);
          updateSticky(n.id, { x: n.x, y: n.y });
        }
        const win = new BrowserWindow2({
          x: n.x,
          y: n.y,
          width: n.w || 280,
          height: n.h || 260,
          frame: false,
          transparent: !solid,
          backgroundColor: solid ? "#FFF3B0" : "#00000000",
          resizable: false,
          skipTaskbar: true,
          minimizable: false,
          maximizable: false,
          fullscreenable: false,
          hasShadow: false,
          show: false,
          title: "\uBA54\uBAA8\uC7A5",
          webPreferences: { preload: PRELOAD, backgroundThrottling: false }
        });
        win.__sticky = n.id;
        stickyWins.set(n.id, win);
        win.loadFile(PAGE("sticky.html"), { query: solid ? { solid: "1" } : {} });
        win.once("ready-to-show", () => {
          if (edit) editSticky(win);
          else pinSticky(win);
        });
        win.on("blur", () => setTimeout(() => {
          if (win.isDestroyed() || win.isFocused() || win.__busy) return;
          if (win.__editing || !stickyPinMode()) pinSticky(win);
        }, 250));
        let t = null;
        win.on("moved", () => {
          clearTimeout(t);
          t = setTimeout(() => {
            if (win.isDestroyed() || win.__pinned) return;
            const b = win.getBounds();
            updateSticky(n.id, { x: b.x, y: b.y });
          }, 300);
        });
        win.on("closed", () => stickyWins.delete(n.id));
        return win;
      }
      function newSticky(text, near) {
        const list = store4.getStickies();
        const wa = targetDisplay().workArea;
        const k = list.length % 6;
        const n = {
          id: (init_crypto(), __toCommonJS(crypto_exports)).randomUUID(),
          text: text || "",
          mode: "basic",
          color: STICKY_COLORS[list.length % 6][0],
          fs: 1,
          x: near ? near.x + 30 : Math.round(wa.x + wa.width / 2 - 140 + k * 26),
          y: near ? near.y + 30 : Math.round(wa.y + wa.height / 3 + k * 26),
          w: 280,
          h: 260,
          created: Date.now()
        };
        list.push(n);
        store4.saveStickies(list);
        openSticky(n, true);
        return n;
      }
      function broadcastSticky(id) {
        const w = stickyWins.get(id), n = stickyById(id);
        if (w && n && !w.isDestroyed()) w.webContents.send("sticky", stickyPayload(n));
      }
      var senderSticky = (e) => {
        const w = BrowserWindow2.fromWebContents(e.sender);
        return w && w.__sticky;
      };
      ipcMain2.handle("sticky:get", (e) => {
        const n = stickyById(senderSticky(e));
        return n ? stickyPayload(n) : null;
      });
      ipcMain2.handle("sticky:save", (e, patch) => {
        const ok = ["text", "mode", "color", "char", "fs"];
        const clean = {};
        for (const k of ok) if (patch && k in patch) clean[k] = patch[k];
        updateSticky(senderSticky(e), clean);
      });
      ipcMain2.handle("sticky:bounds", (e, b, done) => {
        const id = senderSticky(e), w = stickyWins.get(id);
        if (!w || w.isDestroyed()) return;
        if (w.__pinned) editSticky(w);
        const nb = { x: Math.round(b.x), y: Math.round(b.y), width: Math.max(180, Math.round(b.width)), height: Math.max(140, Math.round(b.height)) };
        w.setBounds(nb);
        if (done) updateSticky(id, { x: nb.x, y: nb.y, w: nb.width, h: nb.height });
      });
      ipcMain2.handle("sticky:new", (e, text) => {
        const w = BrowserWindow2.fromWebContents(e.sender);
        newSticky(text, w && w.__sticky ? w.getBounds() : null);
      });
      ipcMain2.handle("sticky:menu", (e) => {
        const id = senderSticky(e), n = stickyById(id), win = stickyWins.get(id);
        if (!n || !win) return;
        const set2 = (patch) => {
          updateSticky(id, patch);
          broadcastSticky(id);
        };
        win.__busy = true;
        setTimeout(() => {
          win.__busy = false;
        }, 400);
        const pick = n.char || "daily";
        Menu2.buildFromTemplate([
          { label: "\uBAA8\uC591", submenu: STICKY_MODES.map(([k, l]) => ({ label: l, type: "radio", checked: (n.mode || "basic") === k, click: () => set2({ mode: k }) })) },
          { label: "\uC885\uC774 \uC0C9", enabled: n.mode !== "char", submenu: STICKY_COLORS.map(([k, l]) => ({ label: l, type: "radio", checked: n.color === k, click: () => set2({ color: k }) })) },
          { label: "\uCE90\uB9AD\uD130", submenu: [
            { label: "\uB9E4\uC77C \uBC14\uB00C\uAE30", type: "radio", checked: pick === "daily", click: () => set2({ char: null, mode: "char" }) },
            { type: "separator" },
            ...Chars.LIST.map((c) => ({ label: c.name, type: "radio", checked: pick === c.id, click: () => set2({ char: c.id, mode: "char" }) }))
          ] },
          { label: "\uAE00\uC790 \uD06C\uAE30", submenu: [[0.85, "\uC791\uAC8C"], [1, "\uBCF4\uD1B5"], [1.2, "\uD06C\uAC8C"], [1.45, "\uC544\uC8FC \uD06C\uAC8C"]].map(([v, l]) => ({ label: l, type: "radio", checked: (n.fs || 1) === v, click: () => set2({ fs: v }) })) },
          { type: "separator" },
          { label: "\uC774 \uBA54\uBAA8\uB85C \uC77C\uC815 \uB9CC\uB4E4\uAE30 (AI)", enabled: !!String(n.text || "").trim(), click: () => openAI(String(n.text || "").replace(/^\[[ x]\] /gm, "")) },
          { type: "separator" },
          { label: "\uC0C8 \uBA54\uBAA8\uC9C0", click: () => newSticky("", win.getBounds()) },
          { label: "\uC774 \uBA54\uBAA8\uC9C0 \uB5BC\uAE30 (\uC0AD\uC81C)", click: async () => {
            if (String(n.text || "").trim()) {
              win.__busy = true;
              const r = await dialog2.showMessageBox(win, { type: "question", buttons: ["\uB5BC\uAE30", "\uCDE8\uC18C"], defaultId: 1, cancelId: 1, message: "\uC774 \uBA54\uBAA8\uC9C0\uB97C \uB5C4\uAE4C\uC694? \uC801\uC5B4 \uB454 \uB0B4\uC6A9\uB3C4 \uC9C0\uC6CC\uC838\uC694." });
              win.__busy = false;
              if (r.response !== 0) return;
            }
            store4.saveStickies(store4.getStickies().filter((x) => x.id !== id));
            win.destroy();
          } }
        ]).popup({ window: win, callback: () => {
          win.__busy = false;
        } });
      });
      function openAllStickies() {
        store4.getStickies().forEach(openSticky);
      }
      function refreshStickies() {
        for (const [id] of stickyWins) broadcastSticky(id);
      }
      function calendarRectDip() {
        if (settings.mode === "wallpaper") return targetDisplay().bounds;
        if (widgetUnder()) {
          const w = settings.widget;
          if (settings.minimal) {
            const b = calWin.getBounds();
            return b;
          }
          return { x: w.x, y: w.y, width: w.width, height: w.height };
        }
        return null;
      }
      function onDesktopClick(p) {
        const dip0 = false ? screen2.screenToDipPoint(p) : p;
        const sw = stickyAt(dip0);
        if (sw) {
          editSticky(sw);
          return;
        }
        if (!calWin || calWin.isDestroyed() || editing || !pinned) return;
        if (settings.clickToEdit === false) return;
        const r = calendarRectDip();
        if (!r) return;
        const dip = false ? screen2.screenToDipPoint(p) : p;
        if (dip.x < r.x || dip.y < r.y || dip.x >= r.x + r.width || dip.y >= r.y + r.height) return;
        calWin.webContents.send("desk-click", { x: dip.x - r.x, y: dip.y - r.y, t: Date.now() });
      }
      var hoverKey = "";
      setInterval(() => {
        if (!calWin || calWin.isDestroyed() || editing || !pinned) {
          if (hoverKey) {
            hoverKey = "";
            calWin && !calWin.isDestroyed() && calWin.webContents.send("desk-hover", null);
          }
          return;
        }
        const r = calendarRectDip();
        if (!r) return;
        const p = screen2.getCursorScreenPoint();
        const inside = p.x >= r.x && p.y >= r.y && p.x < r.x + r.width && p.y < r.y + r.height;
        const key = inside ? `${p.x},${p.y}` : "";
        if (key === hoverKey) return;
        hoverKey = key;
        calWin.webContents.send("desk-hover", inside ? { x: p.x - r.x, y: p.y - r.y } : null);
      }, 180);
      function maybeReturn() {
        if (!autoEdit || !editing || !calWin || calWin.isDestroyed()) return;
        setTimeout(() => {
          if (!autoEdit || !editing || !calWin || calWin.isDestroyed()) return;
          const f2 = BrowserWindow2.getFocusedWindow();
          if (f2 === calWin) return;
          if (editorWin && !editorWin.isDestroyed()) return;
          if (f2 && f2 !== calWin && f2 !== popupWin) return;
          setEditing(false);
        }, 250);
      }
      function widgetAction(action) {
        if (settings.mode !== "widget" || !calWin || calWin.isDestroyed()) return;
        const wa = targetDisplay().workArea;
        const b = calWin.getBounds();
        const M = 20;
        const pos = {
          "top-right": { x: wa.x + wa.width - b.width - M, y: wa.y + M },
          "bottom-right": { x: wa.x + wa.width - b.width - M, y: wa.y + wa.height - b.height - M },
          "top-left": { x: wa.x + M, y: wa.y + M },
          "bottom-left": { x: wa.x + M, y: wa.y + wa.height - b.height - M },
          center: { x: Math.round(wa.x + (wa.width - b.width) / 2), y: Math.round(wa.y + (wa.height - b.height) / 2) }
        }[action];
        if (pos) {
          if (pinned) {
            desktop.unpin(calWin);
            pinned = false;
          }
          calWin.setBounds({ ...b, ...pos });
          settings.widget = { ...settings.widget, ...pos };
          if (widgetUnder() && !editing) attachWidgetToDesktop();
        }
        if (action === "lock" || action === "unlock") {
          settings.widget.locked = action === "lock";
          calWin.setMovable(!settings.widget.locked);
          calWin.setResizable(!settings.widget.locked);
        }
        store4.saveSettings(settings);
        pushState();
        buildTray();
      }
      function setMinimal(on) {
        on = !!on;
        if (settings.minimal === on) return;
        settings.minimal = on;
        if (settings.mode === "widget" && calWin && !calWin.isDestroyed()) {
          const b = calWin.getBounds();
          const scale = settings.appearance && settings.appearance.fontScale || 1;
          if (on) {
            settings.widgetFull = { x: b.x, y: b.y, width: b.width, height: b.height };
            const w = Math.round(304 * scale), h = Math.round(330 * scale);
            calWin.setBounds({ x: b.x + b.width - w, y: b.y, width: w, height: h });
          } else if (settings.widgetFull) {
            const f2 = settings.widgetFull, now = calWin.getBounds();
            calWin.setBounds({ x: now.x + now.width - f2.width, y: now.y, width: f2.width, height: f2.height });
          }
          if (pinned) {
            desktop.unpin(calWin);
            pinned = false;
            attachWidgetToDesktop();
          }
        }
        store4.saveSettings(settings);
        pushState();
        buildTray();
      }
      function openEditor(payload) {
        const d = screen2.getDisplayNearestPoint(screen2.getCursorScreenPoint());
        if (editorWin && !editorWin.isDestroyed()) editorWin.destroy();
        const W = 480, H = 820;
        editorWin = new BrowserWindow2({
          width: W,
          height: H,
          x: Math.round(d.workArea.x + (d.workArea.width - W) / 2),
          y: Math.round(d.workArea.y + (d.workArea.height - H) / 2),
          frame: false,
          resizable: false,
          alwaysOnTop: true,
          skipTaskbar: false,
          show: false,
          backgroundColor: bgFor(),
          title: "\uC77C\uC815",
          webPreferences: { preload: PRELOAD }
        });
        editorWin.__payload = payload || {};
        editorWin.loadFile(PAGE("editor.html"));
        editorWin.once("ready-to-show", () => {
          editorWin.show();
          editorWin.focus();
        });
        editorWin.on("closed", () => {
          editorWin = null;
          if (autoEdit && calWin && !calWin.isDestroyed() && !calWin.isFocused()) maybeReturn();
        });
      }
      var aboutWin = null;
      function openAbout() {
        if (aboutWin && !aboutWin.isDestroyed()) {
          aboutWin.show();
          aboutWin.focus();
          return;
        }
        aboutWin = new BrowserWindow2({
          width: 560,
          height: 860,
          minWidth: 380,
          minHeight: 560,
          show: false,
          autoHideMenuBar: true,
          backgroundColor: "#FFF8F0",
          title: "Total Calendar \uC18C\uAC1C",
          icon: ASSET("icon.png"),
          webPreferences: { preload: PRELOAD }
        });
        aboutWin.loadFile(PAGE("about.html"));
        aboutWin.once("ready-to-show", () => aboutWin.show());
        aboutWin.on("closed", () => {
          aboutWin = null;
        });
      }
      function openSettingsAt(where) {
        openSettings();
        setTimeout(() => {
          if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send("settings:goto", where);
        }, 700);
      }
      function openSettings() {
        if (settingsWin && !settingsWin.isDestroyed()) {
          settingsWin.show();
          settingsWin.focus();
          return;
        }
        settingsWin = new BrowserWindow2({
          width: 1040,
          height: 860,
          minWidth: 820,
          minHeight: 600,
          show: false,
          autoHideMenuBar: true,
          backgroundColor: bgFor(),
          title: "Total Calendar \uC124\uC815",
          icon: ASSET("icon.png"),
          webPreferences: { preload: PRELOAD }
        });
        settingsWin.loadFile(PAGE("settings.html"));
        settingsWin.once("ready-to-show", () => settingsWin.show());
        settingsWin.on("closed", () => {
          settingsWin = null;
          if (appearancePreview) {
            appearancePreview = null;
            broadcastAppearance();
          }
        });
      }
      function showPopup() {
        if (!popupQueue.length) {
          if (popupWin && !popupWin.isDestroyed()) popupWin.close();
          return;
        }
        const wa = screen2.getPrimaryDisplay().workArea;
        const W = 440;
        if (!popupWin || popupWin.isDestroyed()) {
          popupWin = new BrowserWindow2({
            width: W,
            height: 160,
            x: wa.x + wa.width - W - 16,
            y: wa.y + wa.height - 176,
            frame: false,
            resizable: false,
            skipTaskbar: true,
            alwaysOnTop: true,
            show: false,
            transparent: true,
            backgroundColor: "#00000000",
            focusable: true,
            webPreferences: { preload: PRELOAD }
          });
          popupWin.setAlwaysOnTop(true, "screen-saver");
          popupWin.loadFile(PAGE("popup.html"));
          popupWin.once("ready-to-show", () => popupWin.showInactive());
          popupWin.on("closed", () => {
            popupWin = null;
          });
        } else {
          popupWin.webContents.send("popup", popupQueue);
          popupWin.showInactive();
        }
      }
      function publicSources() {
        return settings.sources.filter((s) => s.enabled !== false).map((s) => ({
          id: s.id,
          name: s.name,
          color: s.color,
          type: s.type,
          holiday: !!s.holiday,
          writable: !s.holiday && (s.type === "local" || s.type === "caldav")
        }));
      }
      function stateForRenderer() {
        return {
          updateAvailable: Updater.getState().available ? Updater.getState().latest.version : "",
          events: cache.events,
          errors: cache.errors,
          updated: cache.updated,
          syncing: cache.syncing,
          sources: publicSources(),
          view: settings.view,
          mode: settings.mode,
          editing,
          iconGutter: settings.iconGutter,
          hotkeyEdit: settings.hotkeyEdit,
          hotkeyQuickAdd: settings.hotkeyQuickAdd,
          panels: settings.panels[settings.mode] || {},
          colorBy: settings.colorBy,
          appearance: appearance(),
          locked: !!settings.widget.locked,
          minimal: !!settings.minimal,
          underIcons: widgetUnder(),
          pinned,
          autoEdit,
          opacity: curOpacity(),
          opacityCss: opacityByCss(),
          lastWriteSource: settings.lastWriteSource,
          notes: decoratedNotes(),
          characters: settings.characters,
          stickerDays: settings.characters?.enabled && settings.characters?.stickers ? store4.getStickers().days : {},
          categories: (settings.categories || []).map((c) => ({ id: c.id, name: c.name, color: c.color }))
        };
      }
      function pushState() {
        if (calWin && !calWin.isDestroyed()) calWin.webContents.send("state", stateForRenderer());
      }
      function decorate(events) {
        const map = store4.getCategoryMap();
        const rmap = store4.getRemindMap();
        const bmap = store4.getBirthYears();
        const cats = settings.categories || [];
        const byName = new Map(cats.map((c) => [c.name.trim(), c]));
        const rules = cats.map((c) => ({ c, words: String(c.keywords || "").split(",").map((w) => w.trim()).filter(Boolean) }));
        return events.map((e) => {
          if (e.holiday) return { ...e, sourceColor: e.color, categoryChoice: "none", categoryId: null, category: "", remind: [] };
          const choice = map[e.uid] || "auto";
          let cat = null;
          if (choice !== "auto" && choice !== "none") cat = cats.find((c) => c.id === choice) || null;
          if (choice === "auto") {
            cat = e.categoryName && byName.get(e.categoryName.trim()) || null;
            if (!cat) {
              const t = String(e.title || "");
              const hit = rules.find((r) => r.words.some((w) => t.includes(w)));
              cat = hit ? hit.c : null;
            }
          }
          const sourceColor = e.color;
          return {
            ...e,
            sourceColor,
            categoryChoice: choice,
            remind: Array.isArray(rmap[e.uid]) ? rmap[e.uid] : void 0,
            birthYear: bmap[e.uid] || null,
            categoryId: cat ? cat.id : null,
            category: cat ? cat.name : "",
            color: settings.colorBy === "category" && cat ? cat.color : sourceColor
          };
        });
      }
      function decoratedNotes() {
        const cats = settings.categories || [];
        const rules = cats.map((c) => ({ c, words: String(c.keywords || "").split(",").map((w) => w.trim()).filter(Boolean) }));
        return store4.getNotes().map((n) => {
          const choice = n.categoryChoice || "auto";
          let cat = null;
          if (choice !== "auto" && choice !== "none") cat = cats.find((c) => c.id === choice) || null;
          if (choice === "auto") {
            const hit = rules.find((r) => r.words.some((w) => n.text.includes(w)));
            cat = hit ? hit.c : null;
          }
          return { ...n, category: cat ? cat.name : "", color: cat ? cat.color : "var(--accent)" };
        }).sort((a, b) => a.done - b.done || (b.updated || 0) - (a.updated || 0));
      }
      function setRemind(uid, list) {
        if (!uid) return;
        const m2 = store4.getRemindMap();
        if (Array.isArray(list)) m2[uid] = list.slice(0, 20);
        else delete m2[uid];
        store4.saveRemindMap(m2);
      }
      function setBirthYear(uid, y) {
        if (!uid) return;
        const m2 = store4.getBirthYears();
        const n = Number(y);
        if (n >= 1900 && n <= 2100) m2[uid] = n;
        else delete m2[uid];
        store4.saveBirthYears(m2);
      }
      function delivererFor(ev) {
        const C = settings.characters || {};
        if (!C.enabled || !C.deliverer) return null;
        const t = Themes.actual(settings.appearance.theme);
        if (t && (t.char || t.season)) {
          const lk2 = Chars.lookFor(settings.appearance, C, /* @__PURE__ */ new Date());
          if (lk2) return { id: lk2.id, by: "theme", concept: t.concept || t.name, season: lk2.season, v: lk2.v };
        }
        const pick = ev.categoryId && C.map ? C.map[ev.categoryId] : null;
        const id = pick && pick !== "hour" && Chars.byId(pick) ? pick : C.buddy && C.buddy !== "theme" && Chars.byId(C.buddy) ? C.buddy : "rabbit";
        const lk = Chars.lookFor(settings.appearance, C, /* @__PURE__ */ new Date(), id);
        return { id, by: pick && pick !== "hour" ? "category" : "buddy", season: lk ? lk.season : null, v: lk ? lk.v : 1 };
      }
      function awardSticker(note) {
        const C = settings.characters || {};
        if (!C.enabled || !C.stickers || note.sticker) return null;
        const st = store4.getStickers();
        const missing = Chars.LIST.filter((c2) => !st.owned[c2.id]);
        const pool = missing.length && Math.random() < 0.6 ? missing : Chars.LIST;
        const c = pool[Math.floor(Math.random() * pool.length)];
        const isNew = !st.owned[c.id];
        st.owned[c.id] = (st.owned[c.id] || 0) + 1;
        st.total = (st.total || 0) + 1;
        const d = /* @__PURE__ */ new Date(), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        st.days[key] = [...st.days[key] || [], c.id].slice(-12);
        store4.saveStickers(st);
        note.sticker = c.id;
        return { id: c.id, name: c.name, isNew, count: Object.keys(st.owned).length };
      }
      function setCategory(uid, choice) {
        if (!uid) return;
        const map = store4.getCategoryMap();
        if (!choice || choice === "auto") delete map[uid];
        else map[uid] = choice;
        store4.saveCategoryMap(map);
      }
      var catName = (choice) => (settings.categories || []).find((c) => c.id === choice)?.name || "";
      async function runSync(fromCloud) {
        if (fromCloud !== true) cloud.sync().catch(() => {
        });
        if (cache.syncing) return;
        cache.syncing = true;
        lastSyncAt = Date.now();
        pushState();
        try {
          const { events, errors } = await sync.fetchAll(settings, ctx);
          cache.raw = events;
          cache.events = decorate(events);
          cache.errors = errors;
          cache.updated = (/* @__PURE__ */ new Date()).toISOString();
        } catch (e) {
          cache.errors = [String(e.message || e)];
        } finally {
          cache.syncing = false;
          pushState();
          checkReminders();
        }
      }
      function scheduleSync() {
        clearInterval(syncTimer);
        syncTimer = setInterval(runSync, Math.max(1, settings.refreshMinutes || 3) * 6e4);
      }
      function checkReminders() {
        const state2 = store4.getReminderState();
        const due = reminders2.due(cache.events, settings, state2);
        store4.saveReminderState(state2);
        if (!due.length) return;
        const keys = new Set(popupQueue.map((p) => p.key));
        due.forEach((d) => {
          if (!keys.has(d.key)) {
            const c = delivererFor(d.event);
            popupQueue.push({ ...d, char: c && c.id, charBy: c && c.by, concept: c && c.concept, season: c && c.season, v: c && c.v });
          }
        });
        showPopup();
      }
      function buildTray() {
        if (!tray) {
          tray = new Tray2(nativeImage2.createFromPath(ASSET("tray.png")));
          tray.setToolTip("Total Calendar");
          tray.on("double-click", () => setEditing(true));
        }
        const up = Updater.getState();
        tray.setContextMenu(Menu2.buildFromTemplate([
          ...up.available ? [{ label: `\u2605 \uC0C8 \uBC84\uC804 ${up.latest.version} \uC5C5\uB370\uC774\uD2B8\uD558\uAE30`, click: updateFromTray }, { type: "separator" }] : [],
          { label: "\uC0C8 \uC77C\uC815", accelerator: settings.hotkeyQuickAdd, click: () => openEditor({}) },
          { label: "AI\uB85C \uC77C\uC815 \uB4F1\uB85D (\uAE00\xB7\uBA54\uC77C \uBD99\uC5EC\uB123\uAE30)", click: () => openAI("") },
          { label: "\uC0C8 \uBA54\uBAA8\uC7A5 \uAEBC\uB0B4\uAE30 (\uBC14\uD0D5\uD654\uBA74\uC5D0 \uB530\uB85C)", click: () => newSticky("") },
          { label: "\uBBF8\uB2C8 \uB2EC\uB825 \uBAA8\uB4DC", type: "checkbox", checked: !!settings.minimal, click: () => setMinimal(!settings.minimal) },
          { label: settings.mode === "widget" && !settings.widget.underIcons ? "\uCE98\uB9B0\uB354 \uC55E\uC73C\uB85C \uAC00\uC838\uC624\uAE30" : "\uD3B8\uC9D1 \uBAA8\uB4DC (\uC55E\uC73C\uB85C \uAEBC\uB0B4\uAE30)", accelerator: settings.hotkeyEdit, click: () => setEditing(!editing) },
          { label: "\uC9C0\uAE08 \uB3D9\uAE30\uD654", click: runSync },
          { type: "separator" },
          { label: "\uBC14\uD0D5\uD654\uBA74 \uBAA8\uB4DC", type: "radio", checked: settings.mode === "wallpaper", click: () => applySettings({ ...settings, mode: "wallpaper" }) },
          { label: "\uC704\uC82F \uBAA8\uB4DC", type: "radio", checked: settings.mode === "widget", click: () => applySettings({ ...settings, mode: "widget" }) },
          { label: `\uBCF4\uC774\uB294 \uD654\uBA74 (${settings.mode === "widget" ? "\uC704\uC82F" : "\uBC14\uD0D5\uD654\uBA74"} \uBAA8\uB4DC)`, submenu: PANEL_LABELS.map(([k, label]) => ({
            label,
            type: "checkbox",
            checked: settings.panels[settings.mode][k] !== false,
            click: () => togglePanel(k)
          })) },
          { label: "\uC704\uC82F \uC704\uCE58", visible: settings.mode === "widget", submenu: [
            { label: "\uC624\uB978\uCABD \uC704", click: () => widgetAction("top-right") },
            { label: "\uC624\uB978\uCABD \uC544\uB798", click: () => widgetAction("bottom-right") },
            { label: "\uC67C\uCABD \uC704", click: () => widgetAction("top-left") },
            { label: "\uC67C\uCABD \uC544\uB798", click: () => widgetAction("bottom-left") },
            { label: "\uAC00\uC6B4\uB370", click: () => widgetAction("center") },
            { type: "separator" },
            { label: "\uC544\uC774\uCF58 \uC544\uB798\uC5D0 \uB450\uAE30 (\uC544\uC774\uCF58\uC774 \uC704\uC82F \uC704\uC5D0 \uBCF4\uC784)", type: "checkbox", checked: !!settings.widget.underIcons, click: () => applySettings({ ...settings, widget: { ...settings.widget, underIcons: !settings.widget.underIcons } }) },
            { label: "\uC704\uCE58\xB7\uD06C\uAE30 \uC7A0\uAE08", type: "checkbox", checked: !!settings.widget.locked, click: () => widgetAction(settings.widget.locked ? "unlock" : "lock") }
          ] },
          { label: "\uBC14\uD0D5\uD654\uBA74\uC5D0 \uB2E4\uC2DC \uBD99\uC774\uAE30", visible: settings.mode === "wallpaper", click: () => createCalendarWindow() },
          { type: "separator" },
          { label: cloud.getState().signedIn ? `\uACC4\uC815 \xB7 \uB3D9\uAE30\uD654 (${cloud.getState().email})` : "\uB85C\uADF8\uC778 \xB7 PC\u2194\uD734\uB300\uD3F0 \uB3D9\uAE30\uD654\u2026", click: () => {
            openSettings();
            setTimeout(() => {
              if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send("settings:goto", "account");
            }, 700);
          } },
          { label: "\uC124\uC815\u2026", click: openSettings },
          { label: "Total Calendar \uC18C\uAC1C \xB7 \uD504\uB9AC\uBBF8\uC5C4", click: openAbout },
          { label: "\uB370\uC774\uD130 \uD3F4\uB354 \uC5F4\uAE30", click: () => shell2.openPath(store4.DIR) },
          { label: "\uBB38\uC81C \uC2E0\uACE0 \xB7 \uC758\uACAC \uBCF4\uB0B4\uAE30\u2026", click: () => sendReport("bug") },
          { label: "\uC885\uB8CC", click: () => {
            app2.isQuitting = true;
            app2.quit();
          } }
        ]));
      }
      var PANEL_LABELS = [["list", "\uC67C\uCABD \uBAA9\uB85D \uD328\uB110 \uC804\uCCB4"], ["clock", "\uC2DC\uACC4\xB7\uB0A0\uC9DC"], ["next", "\uB2E4\uC74C \uC77C\uC815"], ["toolbar", "\uB3C4\uAD6C \uBC84\uD2BC"], ["today", "\uC624\uB298 \uC77C\uC815"], ["tomorrow", "\uB0B4\uC77C \uC77C\uC815"], ["memo", "\uBA54\uBAA8 (\uB0A0\uC9DC \uC5C6\uB294 \uAE00)"], ["calendar", "\uB2EC\uB825 (\uC6D4\xB7\uC8FC)"], ["footer", "\uD558\uB2E8 \uC815\uBCF4"]];
      function togglePanel(key) {
        const p = settings.panels[settings.mode];
        p[key] = p[key] === false;
        if ((key === "list" || key === "calendar") && p.list === false && p.calendar === false) p[key === "list" ? "calendar" : "list"] = true;
        store4.saveSettings(settings);
        pushState();
        buildTray();
      }
      function registerHotkeys() {
        globalShortcut2.unregisterAll();
        const tryReg = (acc, fn) => {
          try {
            if (acc) globalShortcut2.register(acc, fn);
          } catch {
          }
        };
        tryReg(settings.hotkeyQuickAdd, () => openEditor({}));
        tryReg(settings.hotkeyEdit, () => setEditing(!editing));
      }
      function applyAutoStart() {
        if (!app2.isPackaged) return;
        try {
          app2.setLoginItemSettings({ openAtLogin: false, name: "DeskCal", path: "", args: [] });
        } catch {
        }
        try {
          app2.setLoginItemSettings({ openAtLogin: !!settings.autoStart, enabled: !!settings.autoStart, name: "Total Calendar", path: "", args: [] });
        } catch {
        }
      }
      function applySettings(next) {
        const prev = settings;
        settings = next;
        appearancePreview = null;
        store4.saveSettings(settings);
        sync.forgetClients();
        applyAutoStart();
        cache.events = decorate(cache.raw || []);
        const layoutChanged = prev.mode !== next.mode || prev.displayId !== next.displayId || !!(prev.widget || {}).underIcons !== !!(next.widget || {}).underIcons;
        if (layoutChanged) createCalendarWindow();
        else pushState();
        broadcastAppearance();
        buildTray();
        registerHotkeys();
        scheduleSync();
        runSync();
      }
      var findEvent = (id) => cache.events.find((e) => e.id === id);
      var findSource = (id) => settings.sources.find((s) => s.id === id);
      ipcMain2.handle("state:get", () => stateForRenderer());
      ipcMain2.handle("sync:now", () => runSync());
      ipcMain2.handle("appearance:get", () => appearance());
      ipcMain2.handle("appearance:preview", (_e, a) => {
        appearancePreview = { ...settings.appearance, ...a };
        broadcastAppearance();
      });
      ipcMain2.handle("widget:action", (_e, a) => widgetAction(a));
      ipcMain2.handle("minimal:set", (_e, on) => setMinimal(on));
      ipcMain2.handle("panel:toggle", (_e, key) => togglePanel(key));
      ipcMain2.handle("view:set", (_e, view) => {
        settings.view = view;
        store4.saveSettings(settings);
        pushState();
      });
      ipcMain2.handle("edit:set", (_e, on) => setEditing(!!on));
      ipcMain2.handle("edit:activate", () => {
        setEditing(true, { auto: true });
        if (Date.now() - lastSyncAt > 6e4) runSync();
        return true;
      });
      ipcMain2.handle("win:bounds", (_e, b, done) => {
        if (!calWin || calWin.isDestroyed() || settings.mode !== "widget" || settings.widget.locked) return;
        if (pinned) return;
        const minW = settings.minimal ? 220 : 320, minH = settings.minimal ? 220 : 260;
        const nb = { x: Math.round(b.x), y: Math.round(b.y), width: Math.max(minW, Math.round(b.width)), height: Math.max(minH, Math.round(b.height)) };
        calWin.setBounds(nb);
        if (done && !settings.minimal) {
          settings.widget = { ...settings.widget, ...nb };
          store4.saveSettings(settings);
        }
      });
      ipcMain2.handle("wall:width", (_e, pct, done) => {
        const v = Math.max(30, Math.min(100, Math.round(pct)));
        settings.appearance = { ...settings.appearance, wallpaperWidth: v };
        if (done) store4.saveSettings(settings);
        broadcastAppearance();
      });
      ipcMain2.handle("appearance:patch", (_e, patch) => {
        const ok = ["listWidthWidget", "listWidthWall"];
        const clean = {};
        for (const k of ok) if (patch && k in patch) clean[k] = Math.max(0, Math.round(Number(patch[k]) || 0));
        settings.appearance = { ...settings.appearance, ...clean };
        store4.saveSettings(settings);
        broadcastAppearance();
      });
      ipcMain2.handle("event:move", async (_e, { eventId, days }) => {
        const ev = findEvent(eventId);
        if (!ev) throw new Error("\uC77C\uC815\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4");
        if (!ev.writable) throw new Error("\uC774 \uCE98\uB9B0\uB354\uB294 \uC77D\uAE30 \uC804\uC6A9\uC774\uB77C \uC62E\uAE38 \uC218 \uC5C6\uC5B4\uC694");
        if (ev.recurring) throw new Error("\uBC18\uBCF5 \uC77C\uC815\uC740 \uC6D0\uB798 \uCE98\uB9B0\uB354\uC5D0\uC11C \uC62E\uACA8 \uC8FC\uC138\uC694");
        const n = Math.round(days);
        if (!n) return true;
        const shiftYmd = (s, k) => {
          const d = /* @__PURE__ */ new Date(s + "T00:00:00");
          d.setDate(d.getDate() + k);
          return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        };
        let input;
        if (ev.allDay) {
          input = { allDay: true, date: shiftYmd(ev.start, n), endDate: shiftYmd(shiftYmd(ev.end, -1), n) };
        } else {
          const zone = ev.tz && TZ.valid(ev.tz) ? ev.tz : null;
          const part = (iso) => {
            const d = new Date(new Date(iso).getTime() + n * 864e5);
            const w = zone ? TZ.wall(d, zone) : d;
            const p2 = (x) => String(x).padStart(2, "0");
            return { date: `${w.getFullYear()}-${p2(w.getMonth() + 1)}-${p2(w.getDate())}`, time: `${p2(w.getHours())}:${p2(w.getMinutes())}` };
          };
          const a = part(ev.start), b = part(ev.end);
          input = { allDay: false, date: a.date, startTime: a.time, endDate: b.date, endTime: b.time, tz: zone || "" };
        }
        const data = { ...input, title: ev.title, location: ev.location || "", notes: ev.notes || "", categoryName: catName(ev.categoryChoice) || ev.categoryName || "" };
        await sync.updateEvent(findSource(ev.sourceId), ev, data, ctx);
        await runSync();
        return true;
      });
      ipcMain2.handle("ctx:menu", (e, info) => {
        const win = BrowserWindow2.fromWebContents(e.sender);
        const send = (action, extra) => win && !win.isDestroyed() && win.webContents.send("ctx-action", { action, ...info, ...extra });
        const items = [];
        if (info.kind === "event") {
          const ev = findEvent(info.id);
          if (!ev) return;
          items.push({ label: "\uC5F4\uAE30\xB7\uC218\uC815", click: () => openEditor({ eventId: ev.id }) });
          items.push({ label: "\uCE74\uD14C\uACE0\uB9AC", submenu: [
            { label: "\uC790\uB3D9", type: "radio", checked: ev.categoryChoice === "auto", click: () => {
              setCategory(ev.uid, "auto");
              cache.events = decorate(cache.raw || []);
              pushState();
            } },
            ...(settings.categories || []).map((c) => ({ label: c.name, type: "radio", checked: ev.categoryChoice === c.id, click: () => {
              setCategory(ev.uid, c.id);
              cache.events = decorate(cache.raw || []);
              pushState();
            } })),
            { label: "\uC5C6\uC74C", type: "radio", checked: ev.categoryChoice === "none", click: () => {
              setCategory(ev.uid, "none");
              cache.events = decorate(cache.raw || []);
              pushState();
            } }
          ] });
          if (ev.writable && !ev.recurring) {
            items.push({ type: "separator" });
            items.push({ label: "\uD558\uB8E8 \uB4A4\uB85C", click: () => send("move", { days: 1 }) });
            items.push({ label: "\uC77C\uC8FC\uC77C \uB4A4\uB85C", click: () => send("move", { days: 7 }) });
            items.push({ type: "separator" });
            items.push({ label: "\uC0AD\uC81C", click: async () => {
              const r = await dialog2.showMessageBox(win, { type: "question", buttons: ["\uC0AD\uC81C", "\uCDE8\uC18C"], defaultId: 1, cancelId: 1, title: "\uC77C\uC815 \uC0AD\uC81C", message: `'${ev.title}' \uC77C\uC815\uC744 \uC0AD\uC81C\uD560\uAE4C\uC694?` });
              if (r.response !== 0) return;
              try {
                await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
                setCategory(ev.uid, "auto");
                await runSync();
              } catch (err2) {
                send("error", { message: String(err2.message || err2) });
              }
            } });
          }
        } else if (info.kind === "note") {
          const n = store4.getNotes().find((x) => x.id === info.id);
          if (!n) return;
          items.push({ label: n.done ? "\uC644\uB8CC \uCDE8\uC18C" : "\uC644\uB8CC", click: () => send("toggle") });
          items.push({ label: "\uC218\uC815\xB7\uB0A0\uC9DC \uB123\uAE30", click: () => openEditor({ noteId: n.id }) });
          items.push({ label: "\uBC14\uD0D5\uD654\uBA74 \uBA54\uBAA8\uC7A5\uC73C\uB85C \uBD99\uC774\uAE30", click: () => newSticky(n.text) });
          items.push({ type: "separator" });
          items.push({ label: "\uC0AD\uC81C", click: () => {
            store4.saveNotes(store4.getNotes().filter((x) => x.id !== n.id));
            pushState();
          } });
        } else if (info.kind === "day") {
          items.push({ label: "\uC5EC\uAE30\uC5D0 \uBE60\uB974\uAC8C \uCD94\uAC00", click: () => send("quick") });
          items.push({ label: "\uC790\uC138\uD788 \uCD94\uAC00 (\uC77C\uC815 \uCC3D)", click: () => openEditor({ date: info.date }) });
          items.push({ label: "\uC774\uB0A0 \uC77C\uC815 \uBAA8\uC544 \uBCF4\uAE30", click: () => send("daypop") });
        }
        if (items.length) items.push({ type: "separator" });
        items.push({ label: "\uBC14\uD0D5\uD654\uBA74\uC5D0 \uBA54\uBAA8\uC7A5 \uBD99\uC774\uAE30", click: () => newSticky("") });
        items.push({ label: "\uC624\uB298\uB85C", click: () => send("today") });
        items.push({ label: "\uC9C0\uAE08 \uB3D9\uAE30\uD654", click: () => runSync() });
        if (editing) items.push({ label: "\uBC14\uD0D5\uD654\uBA74\uC73C\uB85C \uB3CC\uC544\uAC00\uAE30", click: () => setEditing(false) });
        Menu2.buildFromTemplate(items).popup({ window: win });
      });
      ipcMain2.handle("editor:open", (_e, payload) => openEditor(payload));
      ipcMain2.handle("settings:open", () => openSettings());
      ipcMain2.handle("win:close", (e) => BrowserWindow2.fromWebContents(e.sender)?.close());
      ipcMain2.handle("about:open", () => openAbout());
      ipcMain2.handle("about:go", (e, where) => {
        BrowserWindow2.fromWebContents(e.sender)?.close();
        openSettingsAt(where === "skin" ? "skin" : "account");
      });
      ipcMain2.handle("editor:init", (e) => {
        const win = BrowserWindow2.fromWebContents(e.sender);
        const p = win && win.__payload || {};
        const ev = p.eventId ? findEvent(p.eventId) : null;
        const note = p.noteId ? store4.getNotes().find((n) => n.id === p.noteId) || null : null;
        return {
          event: ev,
          note,
          date: p.date || null,
          text: p.text || "",
          sources: publicSources(),
          categories: settings.categories || [],
          defaultReminders: settings.reminders,
          characters: settings.characters,
          lastWriteSource: settings.lastWriteSource
        };
      });
      ipcMain2.handle("event:save", async (_e, { eventId, noteId, sourceId, input }) => {
        const target = findSource(sourceId);
        if (!target) throw new Error("\uCE98\uB9B0\uB354\uB97C \uC120\uD0DD\uD574 \uC8FC\uC138\uC694");
        const choice = input.categoryChoice || "auto";
        const data = { ...input, categoryName: catName(choice) };
        let uid;
        if (eventId) {
          const ev = findEvent(eventId);
          if (!ev) throw new Error("\uC77C\uC815\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB3D9\uAE30\uD654 \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694");
          if (!ev.writable) {
            setCategory(ev.uid, choice);
            setRemind(ev.uid, input.reminders);
            setBirthYear(ev.uid, input.birthYear);
            cache.events = decorate(cache.raw || []);
            pushState();
            return true;
          }
          if (ev.sourceId === sourceId) {
            await sync.updateEvent(target, ev, data, ctx);
            uid = ev.uid;
          } else {
            uid = await sync.createEvent(target, data, ctx);
            await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
            setCategory(ev.uid, "auto");
            setRemind(ev.uid, void 0);
          }
        } else {
          uid = await sync.createEvent(target, data, ctx);
        }
        setCategory(uid, choice);
        setRemind(uid, input.reminders);
        setBirthYear(uid, input.birthYear);
        if (noteId) store4.saveNotes(store4.getNotes().filter((n) => n.id !== noteId));
        settings.lastWriteSource = sourceId;
        store4.saveSettings(settings);
        await runSync();
        return true;
      });
      ipcMain2.handle("event:delete", async (_e, eventId) => {
        const ev = findEvent(eventId);
        if (!ev) throw new Error("\uC77C\uC815\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4");
        await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
        setCategory(ev.uid, "auto");
        await runSync();
        return true;
      });
      ipcMain2.handle("note:save", async (_e, { noteId, eventId, text, categoryChoice }) => {
        const list = store4.getNotes();
        const now = Date.now();
        if (noteId) {
          const n = list.find((x) => x.id === noteId);
          if (n) Object.assign(n, { text, categoryChoice, updated: now });
        } else {
          list.push({ id: (init_crypto(), __toCommonJS(crypto_exports)).randomUUID(), text, categoryChoice, done: false, created: now, updated: now });
        }
        if (eventId) {
          const ev = findEvent(eventId);
          if (ev) {
            if (!ev.writable) throw new Error("\uC774 \uC77C\uC815\uC740 \uC6D0\uB798 \uCE98\uB9B0\uB354\uC5D0\uC11C\uB9CC \uC9C0\uC6B8 \uC218 \uC788\uC5B4\uC694");
            await sync.deleteEvent(findSource(ev.sourceId), ev, ctx);
            setCategory(ev.uid, "auto");
          }
        }
        store4.saveNotes(list);
        if (eventId) await runSync();
        else pushState();
        return true;
      });
      ipcMain2.handle("note:delete", (_e, id) => {
        store4.saveNotes(store4.getNotes().filter((n) => n.id !== id));
        pushState();
        return true;
      });
      ipcMain2.handle("note:toggle", (_e, id) => {
        const list = store4.getNotes();
        const n = list.find((x) => x.id === id);
        let sticker = null;
        if (n) {
          n.done = !n.done;
          n.updated = Date.now();
          if (n.done) sticker = awardSticker(n);
          store4.saveNotes(list);
        }
        pushState();
        return { sticker };
      });
      ipcMain2.handle("settings:get", () => ({
        ...settings,
        displays: screen2.getAllDisplays().map((d, i) => ({ id: d.id, label: `\uBAA8\uB2C8\uD130 ${i + 1} (${d.size.width}\xD7${d.size.height})${d.id === screen2.getPrimaryDisplay().id ? " \xB7 \uC8FC \uBAA8\uB2C8\uD130" : ""}` })),
        sources: settings.sources.map((s) => ({ ...s, password: "", hasPassword: !!s.password })),
        dataDir: store4.DIR,
        stickers: store4.getStickers(),
        desktopPinAvailable: desktop.available()
      }));
      ipcMain2.handle("settings:save", (_e, incoming) => {
        const sources = (incoming.sources || []).map((s) => {
          const old = settings.sources.find((o) => o.id === s.id) || {};
          const out = { ...s };
          delete out.hasPassword;
          out.password = s.password ? store4.encrypt(s.password) : old.password || "";
          return out;
        });
        const base = incoming.__base;
        delete incoming.__base;
        const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
        const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
        const mergeChanged = (cur2, out, b) => {
          const res = { ...cur2 || {} };
          for (const k of Object.keys(out || {})) {
            if (isObj(out[k]) && isObj(res[k])) res[k] = mergeChanged(res[k], out[k], b && b[k]);
            else if (!b || !same(out[k], b[k])) res[k] = out[k];
          }
          return res;
        };
        const always = {};
        if (base && Array.isArray(base.sources)) {
          const baseIds = new Set(base.sources.map((x) => x.id));
          const inIds = new Set(sources.map((x) => x.id));
          const removed = [...baseIds].filter((id) => !inIds.has(id));
          const cur2 = settings.sources.filter((x) => !removed.includes(x.id));
          for (const x of sources) {
            const b0 = base.sources.find((o) => o.id === x.id);
            const strip = (o) => {
              const c = { ...o };
              delete c.password;
              delete c.hasPassword;
              return JSON.stringify(c);
            };
            const changed = !b0 || strip(b0) !== strip(x) || x.password !== (settings.sources.find((o) => o.id === x.id) || {}).password;
            const i = cur2.findIndex((o) => o.id === x.id);
            if (i < 0) cur2.push(x);
            else if (changed) cur2[i] = x;
          }
          always.sources = cur2;
          if (removed.length) cloud.markRemoved("sources", removed);
        } else always.sources = sources;
        if (!base || JSON.stringify(base.categories) !== JSON.stringify(incoming.categories)) always.categories = incoming.categories;
        delete incoming.sources;
        delete incoming.categories;
        const next = { ...mergeChanged(settings, incoming, base), ...always };
        if (base && base.widget && incoming.widget && !same(incoming.widget.opacity, base.widget.opacity)) next.opacity = incoming.widget.opacity;
        if (!next.categories) next.categories = settings.categories;
        delete next.displays;
        delete next.dataDir;
        delete next.desktopPinAvailable;
        delete next.stickers;
        applySettings(next);
        return true;
      });
      ipcMain2.handle("popup:get", () => popupQueue);
      ipcMain2.handle("popup:resize", (_e, h) => {
        if (!popupWin || popupWin.isDestroyed()) return;
        const wa = screen2.getPrimaryDisplay().workArea;
        const height = Math.min(Math.max(120, Math.round(h)), wa.height - 32);
        popupWin.setBounds({ x: wa.x + wa.width - 440 - 16, y: wa.y + wa.height - height - 16, width: 440, height });
      });
      ipcMain2.handle("popup:action", (_e, { key, action }) => {
        const item = popupQueue.find((p) => p.key === key);
        popupQueue = popupQueue.filter((p) => p.key !== key);
        if (item && action === "snooze") {
          const st = store4.getReminderState();
          st.snoozes = [...st.snoozes || [], { eventId: item.event.id, at: Date.now() + 10 * 6e4 }];
          store4.saveReminderState(st);
        }
        if (item && action === "open") openEditor({ eventId: item.event.id });
        showPopup();
      });
      app2.on("second-instance", () => setEditing(true));
      app2.on("window-all-closed", (e) => e.preventDefault());
      app2.on("will-quit", () => globalShortcut2.unregisterAll());
      app2.whenReady().then(() => {
        settings = store4.getSettings();
        const { net: net2 } = (init_electron(), __toCommonJS(electron_exports));
        cloud.init({ store: store4, fetch: net2 && net2.fetch ? net2.fetch.bind(net2) : fetch, device: true ? "phone" : "pc", hooks: { onState: onCloudState, onRemoteChange } });
        AI.init({ userData: app2.getPath("userData"), appDir: ".", onProgress: aiSend });
        Updater.init({ version: VERSION, bootDir: (global.__DESKCAL_BOOT || {}).bundledDir || ".", appDir: ".", userData: app2.getPath("userData"), onState: onUpdateState });
        setTimeout(() => Updater.check(), 20 * 1e3);
        if (settings.lastRunVersion && settings.lastRunVersion !== VERSION && Updater.newer(VERSION, settings.lastRunVersion)) {
          const v = VERSION;
          setTimeout(() => {
            try {
              new Notification3({ title: "Total Calendar \uC5C5\uB370\uC774\uD2B8 \uC644\uB8CC", body: `v${v}\uB85C \uC5C5\uB370\uC774\uD2B8\uB410\uC5B4\uC694. \uBC14\uB010 \uC810\uC740 \uC124\uC815 > \uC5C5\uB370\uC774\uD2B8\uC5D0\uC11C \uBCFC \uC218 \uC788\uC5B4\uC694.`, icon: ASSET("icon.png") }).show();
            } catch {
            }
          }, 4e3);
        }
        setTimeout(() => {
          try {
            (init_fs(), __toCommonJS(fs_exports)).writeFileSync(path.join(".", ".boot"), "0");
          } catch {
          }
        }, 8e3);
        if (settings.lastRunVersion !== VERSION) {
          settings.lastRunVersion = VERSION;
          store4.saveSettings(settings);
        }
        setInterval(() => Updater.check(), 6 * 60 * 60 * 1e3);
        applyAutoStart();
        createCalendarWindow();
        buildTray();
        registerHotkeys();
        scheduleSync();
        runSync();
        setInterval(checkReminders, 3e4);
        desktop.watchDesktopClicks(onDesktopClick);
        if (settings.migrateNotes) {
          delete settings.migrateNotes;
          store4.saveSettings(settings);
          const open = store4.getNotes().filter((n) => !n.done && String(n.text || "").trim());
          if (open.length && !store4.getStickies().length) {
            const list = [{
              id: (init_crypto(), __toCommonJS(crypto_exports)).randomUUID(),
              mode: "check",
              color: "yellow",
              fs: 1,
              w: 300,
              h: 320,
              created: Date.now(),
              text: open.map((n) => "[ ] " + String(n.text).split("\n").filter(Boolean).join(" \xB7 ")).join("\n")
            }];
            store4.saveStickies(list);
          }
        }
        openAllStickies();
        powerMonitor2.on("resume", () => setTimeout(runSync, 4e3));
        powerMonitor2.on("unlock-screen", () => runSync());
        setInterval(() => {
          if (autoEdit && editing && powerMonitor2.getSystemIdleTime() >= 60 && !(editorWin && !editorWin.isDestroyed())) setEditing(false);
        }, 1e4);
        setInterval(pushState, 6e4);
        let t = null;
        const relayout = () => {
          clearTimeout(t);
          t = setTimeout(createCalendarWindow, 800);
        };
        screen2.on("display-metrics-changed", relayout);
        screen2.on("display-added", relayout);
        screen2.on("display-removed", relayout);
        if (void 0) {
          setTimeout(async () => {
            const img = await calWin.webContents.capturePage();
            null.writeFileSync(void 0, img.toPNG());
            app2.exit(0);
          }, 6e3);
          return;
        }
        if (settings.sources.length === 1) openSettings();
        if (!settings.seenAbout) {
          settings.seenAbout = 1;
          store4.saveSettings(settings);
          setTimeout(openAbout, settings.sources.length === 1 ? 4e3 : 2500);
        }
      });
    }
  });

  // mobile/main.js
  init_globals();
  init_http();
  init_electron();
  var import_store3 = __toESM(require_store());

  // package.json
  var package_default = {
    name: "total-calendar-app",
    version: "2.7.0",
    private: true,
    description: "Total Calendar Android",
    scripts: {
      build: "node scripts/build-web.mjs"
    },
    dependencies: {
      "@capacitor/android": "^8.6.0",
      "@capacitor/app": "^8.1.2",
      "@capacitor/core": "^8.6.0",
      "@capacitor/local-notifications": "^8.3.1",
      "@capacitor/preferences": "^8.0.1",
      buffer: "^6.0.3",
      events: "^3.3.0",
      "ical-expander": "^3.2.0",
      "path-browserify": "^1.0.1",
      tsdav: "^2.5.0"
    },
    devDependencies: {
      "@capacitor/cli": "^8.6.0",
      esbuild: "^0.28.2"
    }
  };

  // mobile/notify.js
  init_globals();
  init_dist();

  // node_modules/@capacitor/local-notifications/dist/esm/index.js
  init_globals();
  init_dist();

  // node_modules/@capacitor/local-notifications/dist/esm/definitions.js
  init_globals();
  var Weekday;
  (function(Weekday2) {
    Weekday2[Weekday2["Sunday"] = 1] = "Sunday";
    Weekday2[Weekday2["Monday"] = 2] = "Monday";
    Weekday2[Weekday2["Tuesday"] = 3] = "Tuesday";
    Weekday2[Weekday2["Wednesday"] = 4] = "Wednesday";
    Weekday2[Weekday2["Thursday"] = 5] = "Thursday";
    Weekday2[Weekday2["Friday"] = 6] = "Friday";
    Weekday2[Weekday2["Saturday"] = 7] = "Saturday";
  })(Weekday || (Weekday = {}));

  // node_modules/@capacitor/local-notifications/dist/esm/index.js
  var LocalNotifications = registerPlugin("LocalNotifications", {
    web: () => Promise.resolve().then(() => (init_web2(), web_exports2)).then((m2) => new m2.LocalNotificationsWeb())
  });

  // mobile/notify.js
  var import_reminders = __toESM(require_reminders());
  var import_store = __toESM(require_store());
  var AHEAD = 14 * 864e5;
  var MAX = 60;
  var asked = false;
  var last = "";
  var hash = (s) => {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = h * 31 + s.charCodeAt(i) | 0;
    return Math.abs(h) % 2e9 + 1;
  };
  var fmt = (ev) => {
    if (ev.allDay) return "\uD558\uB8E8 \uC885\uC77C";
    const d = new Date(ev.start);
    return d.toLocaleString("ko-KR", { month: "numeric", day: "numeric", weekday: "short", hour: "numeric", minute: "2-digit" });
  };
  async function scheduleFromState(state2) {
    if (!Capacitor.isNativePlatform()) return;
    try {
      if (!asked) {
        asked = true;
        const p = await LocalNotifications.checkPermissions();
        if (p.display !== "granted") await LocalNotifications.requestPermissions();
        await LocalNotifications.createChannel({ id: "remind", name: "\uC77C\uC815 \uC54C\uB9BC", description: "\uC77C\uC815 \uC804\uC5D0 \uC54C\uB824 \uB4DC\uB824\uC694", importance: 4, visibility: 1, vibration: true }).catch(() => {
        });
      }
      const settings = import_store.default.getSettings();
      const now = Date.now();
      const list = [];
      for (const ev of state2.events || []) {
        for (const t of import_reminders.default.triggersFor(ev, settings.reminders || {})) {
          const at = t.at.getTime();
          if (at <= now + 5e3 || at > now + AHEAD) continue;
          list.push({ at, ev, label: t.label, key: `${ev.id}#${t.kind}` });
        }
      }
      list.sort((a, b) => a.at - b.at);
      const pick = list.slice(0, MAX);
      const sig = pick.map((x) => x.key + x.at).join("|");
      if (sig === last) return;
      last = sig;
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length) await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
      if (!pick.length) return;
      await LocalNotifications.schedule({
        notifications: pick.map((x) => ({
          id: hash(x.key),
          channelId: "remind",
          title: `${x.label} \xB7 ${x.ev.title || "(\uC81C\uBAA9 \uC5C6\uC74C)"}`,
          body: [fmt(x.ev), x.ev.location].filter(Boolean).join(" \xB7 "),
          schedule: { at: new Date(x.at), allowWhileIdle: true },
          extra: { eventId: x.ev.id }
        }))
      });
    } catch (e) {
      console.warn("\uC54C\uB9BC \uC608\uC57D \uC2E4\uD328", e);
    }
  }

  // mobile/widget.js
  init_globals();
  init_dist();
  var import_store2 = __toESM(require_store());
  var Widget = registerPlugin("CalendarWidget");
  var last2 = "";
  var ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  var hm = (d) => `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  var STYLE = {
    light: { bg: "#FFFFFF", fg: "#2B2420" },
    dark: { bg: "#1F1E24", fg: "#F3F1EE" },
    transparent: { bg: "#00000000", fg: "#FFFFFF" }
  };
  var HW_SKIP = "\uD734\uAC00, \uC5F0\uCC28, \uBC18\uCC28, \uBC18\uBC18\uCC28, \uBCD1\uAC00, \uACBD\uC870, \uB300\uCCB4\uD734\uBB34, \uC7AC\uD0DD, \uC678\uADFC";
  var CITIES = {
    \uC11C\uC6B8: [37.5665, 126.978],
    \uC778\uCC9C: [37.4563, 126.7052],
    \uC218\uC6D0: [37.2636, 127.0286],
    \uC131\uB0A8: [37.42, 127.1265],
    \uACE0\uC591: [37.6584, 126.832],
    \uC6A9\uC778: [37.2411, 127.1776],
    \uBD80\uC0B0: [35.1796, 129.0756],
    \uB300\uAD6C: [35.8714, 128.6014],
    \uAD11\uC8FC: [35.1595, 126.8526],
    \uB300\uC804: [36.3504, 127.3845],
    \uC6B8\uC0B0: [35.5384, 129.3114],
    \uC138\uC885: [36.48, 127.289],
    \uCC3D\uC6D0: [35.2281, 128.6811],
    \uCCAD\uC8FC: [36.6424, 127.489],
    \uCC9C\uC548: [36.8151, 127.1139],
    \uC804\uC8FC: [35.8242, 127.148],
    \uD3EC\uD56D: [36.019, 129.3435],
    \uCD98\uCC9C: [37.8813, 127.7298],
    \uAC15\uB989: [37.7519, 128.8761],
    \uC81C\uC8FC: [33.4996, 126.5312]
  };
  var geo = null;
  var geoAsked = 0;
  try {
    geo = JSON.parse(localStorage.getItem("tc_geo") || "null");
  } catch {
  }
  function askGeo(state2) {
    if (!navigator.geolocation || Date.now() - geoAsked < 3 * 36e5) return;
    if (geo && Date.now() - geo.at < 3 * 36e5) return;
    geoAsked = Date.now();
    navigator.geolocation.getCurrentPosition((p) => {
      geo = { lat: +p.coords.latitude.toFixed(3), lon: +p.coords.longitude.toFixed(3), at: Date.now() };
      try {
        localStorage.setItem("tc_geo", JSON.stringify(geo));
      } catch {
      }
      pushWidget(state2);
    }, () => {
    }, { enableHighAccuracy: false, maximumAge: 3 * 36e5, timeout: 2e4 });
  }
  function place(H, state2) {
    if (H.city && H.city !== "auto" && CITIES[H.city]) return { lat: CITIES[H.city][0], lon: CITIES[H.city][1], name: H.city };
    askGeo(state2);
    return geo ? { lat: geo.lat, lon: geo.lon, name: "" } : { lat: 37.5665, lon: 126.978, name: "\uC11C\uC6B8" };
  }
  var lastState = null;
  window.__tcPickPhoto = async () => (await Widget.pickPhoto()).data;
  window.__tcPhotos = {
    list: async () => (await Widget.listPhotos()).photos || [],
    del: async (id) => {
      await Widget.deletePhoto({ id });
      last2 = "";
      if (lastState) pushWidget(lastState);
    }
  };
  window.__tcWidgetPhoto = async (dataUrl, fullUrl) => {
    const b64 = (u) => String(u || "").replace(/^data:[^,]*,/, "");
    await Widget.savePhoto({ data: b64(dataUrl), full: b64(fullUrl) });
    last2 = "";
    if (lastState) pushWidget(lastState);
  };
  async function pushWidget(state2) {
    lastState = state2;
    if (!Capacitor.isNativePlatform()) return;
    try {
      const S = import_store2.default.getSettings();
      const H = { style: "transparent", char: true, events: true, weather: true, ...S.homeWidget || {} };
      const hide = new Set(H.hideSources || []);
      const skip = String(H.skip != null ? H.skip : HW_SKIP).split(/[,，]/).map((x) => x.trim().toLowerCase()).filter(Boolean);
      const important = (ev) => !hide.has(ev.sourceId) && !skip.some((w) => String(ev.title || "").toLowerCase().includes(w));
      const now = /* @__PURE__ */ new Date(), todayKey = ymd(now);
      const from = new Date(now.getFullYear(), now.getMonth() - 1, 1), to = new Date(now.getFullYear(), now.getMonth() + 2, 1);
      const days = {}, upcoming = [], today = [], byDay = {};
      for (const ev of state2.events || []) {
        const s = ev.allDay ? /* @__PURE__ */ new Date(ev.start + "T00:00:00") : new Date(ev.start);
        const e = ev.end ? ev.allDay ? /* @__PURE__ */ new Date(ev.end + "T00:00:00") : new Date(ev.end) : s;
        const lastDay = ev.allDay ? new Date(e.getTime() - 1) : e;
        for (let d = new Date(s.getFullYear(), s.getMonth(), s.getDate()); d <= lastDay && d < to; d.setDate(d.getDate() + 1)) {
          if (d < from) continue;
          const k = ymd(d);
          if (!important(ev)) continue;
          days[k] = days[k] || { n: 0, c: ev.color || "" };
          days[k].n++;
          (byDay[k] = byDay[k] || []).push({ t: s.getTime(), e: (ev.allDay ? lastDay : e).getTime(), title: ev.title || "(\uC81C\uBAA9 \uC5C6\uC74C)", allDay: !!ev.allDay, color: ev.color || "", time: ev.allDay ? "" : hm(s) });
          if (k === todayKey) today.push({ t: s.getTime(), e: (ev.allDay ? lastDay : e).getTime(), title: ev.title || "(\uC81C\uBAA9 \uC5C6\uC74C)", allDay: !!ev.allDay, color: ev.color || "", time: ev.allDay ? "" : hm(s) });
        }
        const endT = (ev.allDay ? lastDay : e).getTime();
        if (endT >= now.getTime() - 6e4 && important(ev)) upcoming.push({ t: s.getTime(), e: endT, title: ev.title || "(\uC81C\uBAA9 \uC5C6\uC74C)", allDay: !!ev.allDay, color: ev.color || "", date: ymd(s), time: ev.allDay ? "" : hm(s) });
      }
      upcoming.sort((a, b) => a.t - b.t);
      for (const k in byDay) byDay[k] = byDay[k].sort((a, b) => a.allDay === b.allDay ? a.t - b.t : a.allDay ? -1 : 1).slice(0, 6);
      today.sort((a, b) => a.allDay === b.allDay ? a.t - b.t : a.allDay ? -1 : 1);
      const root = document.querySelector('iframe.win[data-page="calendar"]');
      let bg = "#FFF8F0", fg = "#3A2E28", accent = state2.appearance && state2.appearance.accent || "#E06A8E";
      let charPath = "";
      try {
        const w = root && root.contentWindow;
        const cs = w && w.getComputedStyle(w.document.documentElement);
        const pick = (n) => cs && cs.getPropertyValue(n).trim() || "";
        bg = pick("--bg-solid") || pick("--bg") || bg;
        fg = pick("--text") || fg;
        accent = pick("--accent") || accent;
      } catch {
      }
      try {
        const w = root && root.contentWindow, img = w && w.document.getElementById("buddy");
        const T = w && w.DeskThemes && w.DeskThemes.actual((state2.appearance || {}).theme, /* @__PURE__ */ new Date());
        const b = (S.characters || {}).buddy;
        const id = img && img.dataset.c || T && T.char || (b && b !== "theme" ? b : "") || "rabbit";
        charPath = "renderer/characters/linaverse-12/" + id + ".png";
      } catch {
        charPath = "renderer/characters/linaverse-12/rabbit.png";
      }
      if (STYLE[H.style]) ({ bg, fg } = STYLE[H.style]);
      const data = {
        updated: Date.now(),
        style: H.style,
        char: H.char !== false,
        events: H.events !== false,
        charPath,
        weather: H.weather !== false,
        wx: place(H, state2),
        charMode: H.charMode || "hour",
        photoAt: H.photoAt || 0,
        photoMin: +H.photoMin || 1,
        byDay,
        wl: { pos: H.pos || "right", psize: H.psize || "l", tsize: H.tsize || "m", datePos: H.datePos || "above", wxPos: H.wxPos || "below", date: H.showDate !== false, clock: H.showClock !== false },
        days,
        today: today.slice(0, 6),
        upcoming: upcoming.slice(0, 12),
        bg,
        fg,
        accent,
        weekStart: state2.appearance && state2.appearance.weekStart || 0,
        h24: !state2.appearance || state2.appearance.timeFormat !== "12"
      };
      const json = JSON.stringify(data);
      if (json === last2) return;
      last2 = json;
      await Widget.update({ json });
    } catch (e) {
      console.warn("\uC704\uC82F \uAC31\uC2E0 \uC2E4\uD328", e);
    }
  }

  // mobile/splash.js
  init_globals();
  function SplashLike() {
    const s = document.getElementById("boot");
    if (!s) return;
    const done = () => {
      s.classList.add("gone");
      setTimeout(() => s.remove(), 400);
    };
    const t = setInterval(() => {
      if (document.querySelector('iframe.win[data-page="calendar"]')?.style.visibility === "visible") {
        clearInterval(t);
        done();
      }
    }, 150);
    setTimeout(() => {
      clearInterval(t);
      done();
    }, 8e3);
  }

  // mobile/main.js
  init_updater();
  init_dist();
  init_esm();
  init_electron();
  window.__APP_VERSION = package_default.version;
  var getSettings = import_store3.default.getSettings;
  import_store3.default.getSettings = () => {
    const s = getSettings();
    s.mode = "widget";
    s.minimal = false;
    s.autoStart = false;
    s.opacity = 1;
    s.widget = { ...s.widget, underIcons: false, locked: true, opacity: 1, x: 0, y: 0 };
    s.stickyPin = false;
    if (!s.mobileInit) {
      s.mobileInit = 1;
      s.panels = { ...s.panels, widget: { ...(s.panels || {}).widget || {}, list: true } };
      try {
        import_store3.default.saveSettings(s);
      } catch {
      }
    }
    s.sources = (s.sources || []).map((x) => x.type === "local" && x.name === "\uB0B4 PC" ? { ...x, name: "\uB0B4 \uD734\uB300\uD3F0" } : x);
    return s;
  };
  window.__onCalendarState = (state2) => {
    clearTimeout(window.__stT);
    window.__stT = setTimeout(() => {
      scheduleFromState(state2);
      pushWidget(state2);
      paintBars();
    }, 600);
  };
  var lastBg = "";
  function paintBars() {
    try {
      const f2 = document.querySelector('iframe.win[data-page="calendar"]');
      const cs = f2 && f2.contentWindow.getComputedStyle(f2.contentWindow.document.body);
      const bg = cs && cs.backgroundColor && cs.backgroundColor !== "rgba(0, 0, 0, 0)" ? cs.backgroundColor : f2 && f2.contentWindow.getComputedStyle(f2.contentWindow.document.documentElement).getPropertyValue("--bg-solid").trim() || "#FFF8F0";
      if (bg === lastBg) return;
      lastBg = bg;
      document.documentElement.style.background = bg;
      document.body.style.background = bg;
      const m2 = bg.match(/\d+(\.\d+)?/g);
      let dark = false;
      if (m2 && m2.length >= 3) dark = 0.299 * m2[0] + 0.587 * m2[1] + 0.114 * m2[2] < 128;
      else if (/^#/.test(bg)) {
        const h = bg.length === 4 ? bg.replace(/#(.)(.)(.)/, "#$1$1$2$2$3$3") : bg;
        const n = parseInt(h.slice(1, 7), 16);
        dark = 0.299 * (n >> 16) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255) < 128;
      }
      SystemBars.setStyle({ style: dark ? SystemBarsStyle.Dark : SystemBarsStyle.Light }).catch(() => {
      });
    } catch (e) {
    }
  }
  window.__toast = (text) => {
    let t = document.getElementById("mtoast");
    if (!t) {
      t = document.createElement("div");
      t.id = "mtoast";
      document.body.appendChild(t);
    }
    t.textContent = text;
    t.classList.add("on");
    clearTimeout(t.__h);
    t.__h = setTimeout(() => t.classList.remove("on"), 4200);
  };
  setTimeout(() => updater_default.autoUpdate(window.__toast), 8e3);
  window.__updateNow = () => updater_default.updateNow(window.__toast);
  require_app_main();
  __appReady();
  SplashLike();
  function handleUrl(u) {
    if (!u) return;
    if (/^totalcal:\/\/new/i.test(u)) setTimeout(() => __invoke(null, "editor:open", [{}]), 600);
  }
  if (Capacitor.isNativePlatform()) {
    App.addListener("appUrlOpen", (e) => handleUrl(e && e.url));
    App.getLaunchUrl().then((r) => r && handleUrl(r.url)).catch(() => {
    });
  }
})();
